from geraljson import getJSON
from geral import *
from consist import *


def consistCadastrarProprietario(reqJSON):
    isPF = len(getJSON(reqJSON, 'prop_cnpjcpf')) == 11
    ret = ''
    ret += consistDigit(reqJSON, 'prop_cnpjcpf', 'CNPJ/CPF', [11, 14])
    rntrc = getJSON(reqJSON, 'prop_rntrc')
    if rntrc == '00000000' or rntrc == '000000000':
        ret += ' [RNTRC vazio!]'
    #else:
    #    ret += consistDigit(reqJSON, 'prop_rntrc', 'RNTRC', [9]) Cada operadora vai validar isso de um jeito diferente, uma com 9 outra com 8 digitos
    ret += consistEmpty(reqJSON, 'prop_nome', 'Nome')
    ret += consistEmpty(reqJSON, 'prop_endereco', 'Endereço')
    ret += consistEmpty(reqJSON, 'prop_numero', 'Número')
    ret += consistEmpty(reqJSON, 'prop_bairro', 'Bairro')
    ret += consistDigit(reqJSON, 'prop_cep', 'CEP', [8])
    ret += consistDigit(reqJSON, 'prop_codibge', 'Código do IBGE da Cidade', [7])
    if isPF:
        ret += consistEmptyOrDefault(reqJSON, 'prop_datanasc', 'Data Nasc.', '0000-00-00')
    if (consistDigit(reqJSON, 'prop_foneddd', 'Fone/DDD', [2]) != '' or consistDigit(reqJSON, 'prop_fonenumero', 'Fone/Número', [8, 9]) != '' or getJSON(reqJSON, 'prop_foneddd') == '00') and \
        (consistDigit(reqJSON, 'prop_celularddd', 'Celular/DDD', [2]) != '' or consistDigit(reqJSON, 'prop_celularnumero', 'Celular/Número', [9]) != '' or getJSON(reqJSON, 'prop_celularddd') == '00') and \
        (consistDigit(reqJSON, 'prop_faxddd', 'Fax/DDD', [2]) != '' or consistDigit(reqJSON, 'prop_faxnumero', 'Fax/Número', [8]) != '' or getJSON(reqJSON, 'prop_faxddd') == '00'):
        ret += ' [Nenhum telefone válido informado com DDD + Número (Fixo com 8 posições ou celular com 9 posições)!]'
    return ret

