from sqlalchemy import create_engine, Table, Column, Integer, Float, String, DateTime, MetaData, ForeignKey, BLOB, TEXT

metadata = MetaData()

emonitoruf = Table('emonitoruf', metadata, \
    Column('codemonitoruf', Integer, primary_key=True), \
    Column('coduf', String, nullable=False) \
    )

emonitoracao = Table('emonitoracao', metadata, \
    Column('codemonitoracao', Integer, primary_key=True), \
    Column('descricao', String, nullable=False) \
    )

emonitorufacao = Table('emonitorufacao', metadata, \
    Column('codemonitorufacao', Integer, primary_key=True), \
    Column('codemonitoruf', None, ForeignKey('emonitoruf.codemonitoruf')),
    Column('codemonitoracao', None, ForeignKey('emonitoracao.codemonitoracao')),
    Column('urlcabecmsg', String), \
    Column('urldadosmsg', String), \
    Column('urldadosmsgelement', String), \
    Column('urlprinc', String), \
    Column('urlacao', String), \
    Column('nomearqxsd', String), \
    Column('versaodados', String), \
    Column('versao', String), \
    Column('tpamb', String), \
    Column('codpm', String) \
    )

emonitorspoolfb = Table('emonitorspool', metadata, \
                        Column('codemonitorspool', Integer, primary_key=True), \
                        Column('codinstalacao', Integer, nullable=False),
                        Column('codempresa', Integer, nullable=False),
                        Column('codemonitoracao', None, ForeignKey('emonitoracao.codemonitoracao')),
                        Column('coduf', String), \
                        Column('numuf', Integer), \
                        Column('tpamb', String), \
                        Column('datains', DateTime), \
                        Column('chave', String), \
                        Column('datahoraenviolote', DateTime), \
                        Column('arqxml', BLOB), \
                        Column('nreqlote', String), \
                        Column('nprot', String), \
                        Column('datahorareclote', DateTime), \
                        Column('status', Integer), \
                        Column('arqxmlret', BLOB), \
                        Column('msgret', String), \
                        Column('emailret', String), \
                        Column('justcanc', String), \
                        Column('nprotcanc', String), \
                        Column('arqxmlass', BLOB), \
                        Column('anoinut', String), \
                        Column('cnpjinut', String), \
                        Column('modelonfinut', String), \
                        Column('serienfinut', String), \
                        Column('numnfiniinut', String), \
                        Column('numnffiminut', String), \
                        Column('justinut', String), \
                        Column('nprotinut', String), \
                        Column('codpm', String), \
                        Column('numpm', Integer), \
                        Column('versao', String), \
                        Column('arqxmlresp', BLOB), \
                        Column('nseqevento', Integer), \
                        Column('tpevento', String), \
                        Column('xcorrecao', BLOB), \
                        Column('chavecnpjfil', String), \
                        Column('chavemodelofil', String), \
                        Column('chaveseriefil', String), \
                        Column('chavenumdoc', String), \
                        Column('chavenumint', String), \
                        )

emonitorspoolpg = Table('emonitorspool', metadata, \
                        Column('codemonitorspool', Integer, primary_key=True), \
                        Column('codinstalacao', Integer, nullable=False),
                        Column('codempresa', Integer, nullable=False),
                        Column('codemonitoracao', None, ForeignKey('emonitoracao.codemonitoracao')),
                        Column('coduf', String), \
                        Column('numuf', Integer), \
                        Column('tpamb', String), \
                        Column('datains', DateTime), \
                        Column('chave', String), \
                        Column('datahoraenviolote', DateTime), \
                        Column('arqxml', TEXT), \
                        Column('nreqlote', String), \
                        Column('nprot', String), \
                        Column('datahorareclote', DateTime), \
                        Column('status', Integer), \
                        Column('arqxmlret', TEXT), \
                        Column('msgret', String), \
                        Column('emailret', String), \
                        Column('justcanc', String), \
                        Column('nprotcanc', String), \
                        Column('arqxmlass', TEXT), \
                        Column('anoinut', String), \
                        Column('cnpjinut', String), \
                        Column('modelonfinut', String), \
                        Column('serienfinut', String), \
                        Column('numnfiniinut', String), \
                        Column('numnffiminut', String), \
                        Column('justinut', String), \
                        Column('nprotinut', String), \
                        Column('codpm', String), \
                        Column('numpm', Integer), \
                        Column('versao', String), \
                        Column('arqxmlresp', TEXT), \
                        Column('nseqevento', Integer), \
                        Column('tpevento', String), \
                        Column('xcorrecao', TEXT), \
                        Column('chavecnpjfil', String), \
                        Column('chavemodelofil', String), \
                        Column('chaveseriefil', String), \
                        Column('chavenumdoc', String), \
                        Column('chavenumint', String), \
                        extend_existing=True
                        )

biautors = Table('biautors', metadata, \
    Column('codbiautors', Integer, primary_key=True), \
    Column('codinstalacao', Integer, nullable=False),
    Column('codempresa', Integer, nullable=False),
    Column('tipo', String, nullable=False), \
    Column('data', DateTime, nullable=False), \
    Column('quantautors', Integer, nullable=False) \
    )

bisistemaext = Table('bisistemaext', metadata, \
    Column('codbisistemaext', Integer, primary_key=True), \
    Column('codinstalacao', Integer, nullable=False),
    Column('codempresa', Integer, nullable=False),
    Column('tipo', Integer, nullable=False), \
    Column('data', DateTime, nullable=False), \
    Column('quant', Integer, nullable=False) \
    )

bimdfe = Table('bimdfe', metadata, \
    Column('codbimdfe', Integer, primary_key=True), \
    Column('codemonitorspool', Integer, nullable=False), \
    Column('datains', DateTime), \
    Column('data', DateTime), \
    Column('chave', String),
    Column('codtpevento', Integer),
    Column('veiculoplaca', String), \
    Column('propcnpjcpf', String), \
    Column('propie', String), \
    Column('propnome', String), \
    Column('propuf', String), \
    Column('proptipoantt', String), \
    Column('emitcnpjcpf', String), \
    Column('emitnome', String), \
    Column('emitie', String), \
    Column('emitendereco', String), \
    Column('emitnumero', String), \
    Column('emitcomplender', String), \
    Column('emitbairro', String), \
    Column('emitibge', String), \
    Column('emitcep', String), \
    Column('emitfone', String), \
    Column('emitemail', String), \
    Column('motcpf', String), \
    Column('motnome', String), \
    Column('origibge', String), \
    Column('origcep', String), \
    Column('origlat', Float), \
    Column('origlon', Float), \
    Column('destibge', String), \
    Column('destcep', String), \
    Column('destlat', Float), \
    Column('destlon', Float), \
    Column('respteccnpjcpf', String), \
    Column('resptecnome', String), \
    Column('mercdesc', String), \
    Column('mercncm', String), \
    Column('vcarga', Float), \
    Column('qcarga', Float) \
    )

# empresa


engineEMonitor = None # PG/EMP (futuramente tambem EM1/EM2)
engineEdi = None # PG/EMP
engineSitesat = None # PG/SSs

# def getEngineFB(prop):
#     try:
#         alias = prop['Alias'].data
#         alias = alias[alias.rindex(':') + 1:]
#         minConnPool = int(prop['MinConnPool'].data)
#         maxConnPool = int(prop['MaxConnPool'].data) - minConnPool
#         maxCheckoutConnPool = 600  # 10 minutos
#         return create_engine(
#             'firebird+fdb://' + prop['Usuario'].data + ':' + prop['Senha'].data + '@localhost/' + alias,
#             pool_size=minConnPool, max_overflow=maxConnPool, pool_recycle=maxCheckoutConnPool, pool_pre_ping=True)
#     except Exception as e:
#         #print(e)
#         return None


# def getEngineFBLight(prop):
#     try:
#         alias = prop['Alias'].data
#         alias = alias[alias.rindex(':') + 1:]
#         minConnPool = 1
#         maxConnPool = 5 - minConnPool
#         maxCheckoutConnPool = 300  # 5 minutos
#         return create_engine(
#             'firebird+fdb://' + prop['Usuario'].data + ':' + prop['Senha'].data + '@localhost/' + alias,
#             pool_size=minConnPool, max_overflow=maxConnPool, pool_recycle=maxCheckoutConnPool, pool_pre_ping=True)
#     except Exception as e:
#         #print(e)
#         return None


# def getConnFB(engine):
#     try:
#         if engine is None:
#             return None
#         else:
#             return engine.connect()
#     except Exception as e:
#         #print(e)
#         return None


def getEnginePG(prop, aliasSufix):
    try:
        alias = prop['Alias'+aliasSufix].data
        if alias.startswith('jdbc:postgresql://'):
            indexIni = len('jdbc:postgresql://')
            indexFim = alias.find('?',indexIni)
            alias = alias[indexIni:indexFim]
        minConnPool = int(prop['MinConnPool' + aliasSufix].data)
        maxConnPool = int(prop['MaxConnPool' + aliasSufix].data) - minConnPool
        maxCheckoutConnPool = 600 # 10 minutos
        return create_engine(
            'postgresql://' + prop['Usuario' + aliasSufix].data + ':' + prop['Senha' + aliasSufix].data + '@' + alias,
            pool_size=minConnPool, max_overflow=maxConnPool, pool_recycle=maxCheckoutConnPool, pool_pre_ping=True) #, echo=True, echo_pool='debug')
    # select count(*) from pg_stat_activity;
    except Exception as e:
        #print(e)
        return None


# criado de forma semelhante ao getEnginePG mas que abre apenas uma conexao com o BD EMONITOR
def getEnginePGLight(prop, aliasSufix):
    try:
        alias = prop['Alias'+aliasSufix].data
        if alias.startswith('jdbc:postgresql://'):
            indexIni = len('jdbc:postgresql://')
            indexFim = alias.find('?',indexIni)
            alias = alias[indexIni:indexFim]
        minConnPool = 1
        maxConnPool = 5 - minConnPool
        maxCheckoutConnPool = 300  # 5 minutos
        return create_engine(
            'postgresql://' + prop['Usuario' + aliasSufix].data + ':' + prop['Senha' + aliasSufix].data + '@' + alias,
            pool_size=minConnPool, max_overflow=maxConnPool, pool_recycle=maxCheckoutConnPool, pool_pre_ping=True)
    except Exception as e:
        #print(e)
        return None


# criado de forma semelhante ao getEnginePGLight mas usado com o BD do SITESAT e nao do EMONITOR
def getEnginePGLightInterno(prop, aliasSufix):
    try:
        alias = prop['Alias'+aliasSufix].data
        if alias.startswith('jdbc:postgresql://'):
            indexIni = len('jdbc:postgresql://')
            indexFim = alias.find('?',indexIni)
            alias = alias[indexIni:indexFim]
        minConnPool = 1
        maxConnPool = 5 - minConnPool
        maxCheckoutConnPool = 300  # 5 minutos
        return create_engine(
            'postgresql://' + prop['Usuario' + aliasSufix + 'Interno'].data + ':' + prop['Senha' + aliasSufix + 'Interno'].data + '@' + alias,
            pool_size=minConnPool, max_overflow=maxConnPool, pool_recycle=maxCheckoutConnPool, pool_pre_ping=True)
    except Exception as e:
        #print(e)
        return None


def getConnPG(engine):
    try:
        if engine is None:
            return None
        else:
            return engine.connect()
    except Exception as e:
        #print(e)
        return None


# POR ENQTO PROJETO DE MIGRACAO EMONITOR PG PARADO
#engine = create_engine('postgresql://postgres:masterkey@localhost/emonitor',pool_size=200,max_overflow=2000)
# CONEXAO NO FB
# https://firebirdsql.org/file/documentation/drivers_documentation/python/fdb/getting-started.html
# https://docs.sqlalchemy.org/en/13/dialects/firebird.html
# https://docs.sqlalchemy.org/en/13/core/connections.html#sqlalchemy.engine.Engine.connect
#engine = create_engine('firebird+fdb://sysdba:masterkey@localhost//sistemas/websafbd/websaf.fdb',pool_size=200,max_overflow=2000)

