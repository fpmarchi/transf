# Classe usada para disparar comandos SQL no BD PG integrado ao EMONITORJAVA
# pois o EMONITORPY ira receber as requisicoes via gunicorn/flask no main,
# executar os SQLs de interacao com o EMONITORJAVA e, dependendo do caso,
# obter a resposta e ja retornar para o SOR

from flask import jsonify
import base64
import gzip

import geral
from metadata import getConnPG
import dao


def _gen_response_json(msgRet, erro, codEmonitorSpool = None, listaEs: str = None):
    responseJSON = {}
    responseJSON['erro'] = erro
    responseJSON['msgRet'] = msgRet
    if codEmonitorSpool is not None:
        responseJSON['codEmonitorSpool'] = str(codEmonitorSpool)
    if not geral.strempty(listaEs):
        responseJSON['listaEs'] = base64.b64encode(gzip.compress(listaEs.encode())).decode()
    return jsonify(responseJSON)


def ativo(engine, request):
    #
    msgRet = geral.check_user_password_ws(request)
    if msgRet is not None:
        erro = 't'
    else:
        with getConnPG(engine) as conn:
            if dao.isAtivo(conn):
                erro = 'f'
                msgRet = 'WEBSERVICE DO EMONITOR ATIVO E ACESSANDO BANCO DE DADOS'
            else:
                erro = 't'
                msgRet = 'ERRO AO TENTAR ACESSAR BANCO DE DADOS VIA WEBSERVICE DO EMONITOR'
    #
    geral.printdh('emAtivo: ' + msgRet)
    return _gen_response_json(msgRet, erro)


def insertEMonitorSpool(engine, request):
    #
    codEmonitorSpool = -1
    msgRet = geral.check_user_password_ws(request)
    sql = ''
    if msgRet is not None:
        erro = 't'
    else:
        try:
            requestJSON = request.json
            #
            sql = requestJSON['sql']
            sql = gzip.decompress(base64.b64decode(sql)).decode()
            if geral.strempty(sql):
                erro = 't'
                msgRet = 'ERRO NA EXECUCAO DE SQL VAZIO'
                return _gen_response_json(msgRet, erro)
            #
            arqXML = geral.getstrnotempty(requestJSON['arqXML'])
            arqXML = gzip.decompress(base64.b64decode(arqXML)).decode()
            arqXML = geral.clearUnicodeNoASCII(arqXML).replace('^M','').replace('\n','').replace('\r','')
            #
        except Exception as e:
            erro = 't'
            msgRet = 'Erro em emj.insertEMonitorSpool ao tentar descompactar sql/arqXML'
            print(msgRet)
            print(e)
            return _gen_response_json(msgRet, erro)
        #
        with getConnPG(engine) as conn:
            codEmonitorSpool = dao.insertEMonitorSpool(conn, sql, arqXML)
            if codEmonitorSpool == -1:
                erro = 't'
                msgRet = 'ERRO NA EXECUCAO DO SQL DE INSERCAO DE SPOOL'
            else:
                erro = 'f'
                msgRet = 'SQL EXECUTADO COM SUCESSO'
    #
    geral.printdh('emIns: ' + msgRet + ' - SQL=' + sql)
    return _gen_response_json(msgRet=msgRet, erro=erro, codEmonitorSpool=codEmonitorSpool)


def updateEMonitorSpool(engine, request):
    #
    msgRet = geral.check_user_password_ws(request)
    sql = ''
    if msgRet is not None:
        erro = 't'
    else:
        try:
            requestJSON = request.json
            #
            sql = requestJSON['sql']
            sql = gzip.decompress(base64.b64decode(sql)).decode()
            if geral.strempty(sql):
                erro = 't'
                msgRet = 'ERRO NA EXECUCAO DE SQL VAZIO'
                return _gen_response_json(msgRet, erro)
            #
        except Exception as e:
            erro = 't'
            msgRet = 'Erro em emj.updateEMonitorSpool ao tentar descompactar sql'
            print(msgRet)
            print(e)
            return _gen_response_json(msgRet, erro)
        #
        with getConnPG(engine) as conn:
            erro = dao.updateEMonitorSpool(conn, sql)
            if erro:
                erro = 't'
                msgRet = 'ERRO NA EXECUCAO DO SQL DE ALTERACAO DE SPOOL'
            else:
                erro = 'f'
                msgRet = 'SQL EXECUTADO COM SUCESSO'
    #
    geral.printdh('emUpd: ' + msgRet + ' - SQL=' + sql)
    return _gen_response_json(msgRet=msgRet, erro=erro)


# COMENTADO POIS SERA USADO APENAS emSel/selectEMonitorSpool
# def selectEMonitorSpoolByCod(engine, request):
#     #
#     msgRet = geral.check_user_password_ws(request)
#     if msgRet is not None:
#         erro = 't'
#         return _gen_response_json(msgRet, erro)
#     else:
#         requestJSON = request.json
#         #
#         codEmonitorSpool = requestJSON['codEmonitorSpool']
#         sqlFields = 'codEmonitorSpool,status,msgRet,dataIns,chave,dataHoraEnvioLote,nRecLote,dataHoraRecLote,tpAmb,nProt,nProtCanc,arqXMLAss,arqXMLResp,nProtInut,codEmonitorAcao,codInstalacao,codEmpresa'
#         sqlWhere = 'WHERE codemonitorspool = ' + str(codEmonitorSpool)
#         sqlOrder = ''
#         #
#         with getConnPG(engine) as conn:
#             erro, sql, listaEs = dao.execSqlComp(conn, sqlFields, sqlWhere, sqlOrder)
#             if erro:
#                 erro = 't'
#                 msgRet = 'ERRO NA EXECUCAO DO SQL DE CONSULTA'
#             else:
#                 erro = 'f'
#                 msgRet = 'SQL EXECUTADO COM SUCESSO'
#             #
#             return _gen_response_json(msgRet=msgRet, erro=erro, listaEs=listaEs)


def selectEMonitorSpool(engine, request):
    #
    msgRet = geral.check_user_password_ws(request)
    if msgRet is not None:
        erro = 't'
        return _gen_response_json(msgRet, erro)
    else:
        requestJSON = request.json
        #
        sqlFields = requestJSON['sqlFields']
        if geral.strempty(sqlFields):
            sqlFields = 'codEmonitorSpool,status,msgRet,dataIns,chave,dataHoraEnvioLote,nRecLote,dataHoraRecLote,tpAmb,nProt,nProtCanc,arqXMLAss,arqXMLResp,nProtInut,codEmonitorAcao,codInstalacao,codEmpresa'
        else:
            sqlFields = base64.b64decode(sqlFields).decode()
        sqlWhere = base64.b64decode(requestJSON['sqlWhere']).decode()
        sqlOrder = base64.b64decode(requestJSON['sqlOrder']).decode()
        #
        with getConnPG(engine) as conn:
            erro, sql, listaEs = dao.execSqlComp(conn, sqlFields, sqlWhere, sqlOrder)
            if erro:
                erro = 't'
                msgRet = 'ERRO NA EXECUCAO DO SQL DE CONSULTA'
            else:
                erro = 'f'
                msgRet = 'SQL EXECUTADO COM SUCESSO'
            #
            geral.printdh('emSel: ' + msgRet + ' - SQL=' + sql)
            return _gen_response_json(msgRet=msgRet, erro=erro, listaEs=listaEs)


def selectGeral(engine, request):
    #
    msgRet = geral.check_user_password_ws(request)
    if msgRet is not None:
        erro = 't'
        return _gen_response_json(msgRet, erro)
    else:
        requestJSON = request.json
        #
        sql = base64.b64decode(requestJSON['sql']).decode()
        campos = base64.b64decode(requestJSON['campos']).decode()
        #
        with getConnPG(engine) as conn:
            erro, sql, listaEs = dao.execSqlGeral(conn, sql, campos)
            if erro:
                erro = 't'
                msgRet = 'ERRO NA EXECUCAO DO SQL DE CONSULTA'
            elif geral.strempty(listaEs):
                erro = 't'
                msgRet = 'NENHUM REGISTRO ENCONTRADO COM SQL DE CONSULTA'
            else:
                erro = 'f'
                msgRet = 'SQL EXECUTADO COM SUCESSO'
            #
            geral.printdh('emSelGeral: ' + msgRet + ' - SQL=' + sql)
            return _gen_response_json(msgRet=msgRet, erro=erro, listaEs=listaEs)


