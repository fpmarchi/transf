from threading import Thread
from datetime import datetime
from geral import printdh
from geralsis import getCertProperties
from metadata import getConnPG
import gzip
from formatdate import *
import dao
from geralxml import *
from sefaz_spooler import PRODUCAO, HOMOLOGACAO
from nfe_spooler import callNFe, ACAO_NFE_CONSULTANFDIST, ACAO_NFE_DOWNLOADNF2, ACAO_NFE_CONSULTA4, ACAO_NFE_RECEPCAOEVENTO4
from cte_spooler import callCTe, ACAO_CTE_RECEPCAOEVENTO3, ACAO_CTE_RECEPCAOEVENTO4


EMONITORSPOOL_PRESEQUENCIA = 0
EMONITORSPOOL_PENDENTE = 1
EMONITORSPOOL_LIDO = 2
EMONITORSPOOL_EMPROCESSAMENTO = 3
EMONITORSPOOL_PROCESSADO = 4
#EMONITORSPOOL_CANCELADO = 5
EMONITORSPOOL_ERROPROCESSAMENTO = 6

def getWSDist(engine, request):
    # parametros passados na URL
    codInstalacao = request.args.get('inst',type=int)
    codEmpresa = request.args.get('emp',type=int)
    cnpjInut = request.args.get('cnpjinut',default='')
    codEMonitorSpool = request.args.get('codEMonitorSpool',default='')
    dataIni = request.args.get('dataIni')
    dataFim = request.args.get('dataFim')
    chave = request.args.get('chave',default='')
    tipo = request.args.get('tipo',default='T')
    todosXMLs = request.args.get('todosXMLs',default='C')
    printdh('Processando getWSDist - Inst.' + str(codInstalacao) + '/' + str(codEmpresa))
    #
    with getConnPG(engine) as conn:
        erro, sql, listaEs = dao.getWSDist(conn, codInstalacao, codEmpresa, cnpjInut, codEMonitorSpool, dataIni, dataFim, chave, tipo, todosXMLs)
        if erro:
            return '<erro>true</erro><msgRet>SQL COM ERRO: ' + str(sql) + '</msgRet><listaEs></listaEs>'
        else:
            if listaEs == '':
                return '<erro>false</erro><msgRet>SQL SEM DADOS: ' + str(sql) + '</msgRet><listaEs></listaEs>'
            else:
                return '<erro>false</erro><msgRet>SQL COM DADOS: ' + str(sql) + '</msgRet><listaEs>' + listaEs + '</listaEs>'


def getXMLsWSDist(engine, request):
    # parametros passados na URL
    codEMonitorSpool = request.args.get('codEMonitorSpool',default='')
    printdh('Processando getXMLsWSDist - Spool ' + str(codEMonitorSpool))
    #
    with getConnPG(engine) as conn:
        erro, sql, arqXMLEnvio, arqXMLResp = dao.getXMLsWSDist(conn, codEMonitorSpool)
        if erro:
            return '<erro>true</erro><msgRet>SQL COM ERRO: ' + str(sql) + '</msgRet><listaEs></listaEs>'
        else:
            if arqXMLEnvio == '':
                return '<erro>false</erro><msgRet>SQL SEM DADOS: ' + str(sql) + '</msgRet><arqXMLEnvio></arqXMLEnvio><arqXMLResp></arqXMLResp>'
            else:
                return '<erro>false</erro><msgRet>SQL COM DADOS: ' + str(sql) + '</msgRet><arqXMLEnvio>' + arqXMLEnvio + '</arqXMLEnvio><arqXMLResp>' + arqXMLResp + '</arqXMLResp>'


def contarVarias(engine, request):
    try:
        # parametros passados na URL
        insts = request.data.decode()
        dataIni = request.args.get('dataIni') + ' ' + HORAZERO
        dataFim = request.args.get('dataFim') + ' ' + HORALIMITE
        listInsts = insts.split(',')
        with getConnPG(engine) as conn:
            result = ''
            for inst in listInsts:
                printdh('Contando - Inst.' + inst)
                ct = dao.ctBiAutors2(conn, inst, '', '', dataIni, dataFim)
                result += str(ct) + ','
            if result != '':
                result = result[0:len(result)-1] # tirar ultima virgula
            return '<ret>' + createtag('erro', 'false') + createtag('msgErro', '') + createtag('result', result) + '</ret>'
    except Exception as e:
        print('Erro em contarVarias')
        print(e)
        return '<ret>' + createtag('erro','true') + createtag('msgErro','ERRO DE PROCESSAMENTO DE SQL COM BD') + createtag('result','') + '</ret>'


def contarVariosSistemaExt(engine, request):
    try:
        # parametros passados na URL
        insts = request.data.decode()
        tipo = int(request.args.get('tipo'))
        dataIni = request.args.get('dataIni') + ' ' + HORAZERO
        dataFim = request.args.get('dataFim') + ' ' + HORALIMITE
        listInsts = insts.split(',')
        with getConnPG(engine) as conn:
            result = ''
            for inst in listInsts:
                printdh('Contando - Inst.' + inst)
                ct = dao.ctBiSistemaExt2(conn, inst, '', tipo, dataIni, dataFim)
                result += str(ct) + ','
            if result != '':
                result = result[0:len(result)-1] # tirar ultima virgula
            return '<ret>' + createtag('erro', 'false') + createtag('msgErro', '') + createtag('result', result) + '</ret>'
    except Exception as e:
        print('Erro em contarVariosSistemaExt')
        print(e)
        return '<ret>' + createtag('erro','true') + createtag('msgErro','ERRO DE PROCESSAMENTO DE SQL COM BD') + createtag('result','') + '</ret>'


printlog = False


def execSqlComp(engine, request) -> str:
    body = base64.b64decode(request.data.decode()).decode()
    # parametros passados dentro do body
    listParams = list(body.split('\n'))
    param = listParams[0].split('sqlFields=')
    if len(param) == 2:
        sqlFields = list(param)[1]
    else:
        sqlFields = ''
    param = listParams[1].split('sqlWhere=')
    if len(param) == 2:
        sqlWhere = list(param)[1]
    else:
        sqlWhere = ''
    param = listParams[2].split('sqlOrder=')
    if len(param) == 2:
        sqlOrder = list(param)[1]
    else:
        sqlOrder = ''
    if printlog:
        printdh('Processando execSqlComp')
    #
    with getConnPG(engine) as conn:
        erro, sql, listaEs = dao.execSqlComp(conn, sqlFields, sqlWhere, sqlOrder)
        if erro:
            return '<erro>true</erro><msgRet>SQL COM ERRO: ' + str(sql) + '</msgRet><listaEs></listaEs>'
        else:
            if listaEs == '':
                return '<erro>false</erro><msgRet>SQL SEM DADOS: ' + str(sql) + '</msgRet><listaEs></listaEs>'
            else:
                return '<erro>false</erro><msgRet>SQL COM DADOS: ' + str(sql) + '</msgRet>' + listaEs


def execSqlGeral(engine, request) -> str:
    body = base64.b64decode(request.data.decode()).decode()
    # parametros passados dentro do body
    listParams = list(body.split('\n'))
    sql = list(listParams[0].split('sql='))[1]
    campos = list(listParams[1].split('campos='))[1]
    if printlog:
        printdh('Processando execSqlGeral')
    #
    with getConnPG(engine) as conn:
        erro, sql, listaEs = dao.execSqlGeral(conn, sql, campos)
        if erro:
            return '<erro>true</erro><msgRet>SQL COM ERRO: ' + str(sql) + '</msgRet><lista></lista>'
        else:
            if listaEs == '':
                return '<erro>false</erro><msgRet>SQL SEM DADOS: ' + str(sql) + '</msgRet><lista></lista>'
            else:
                return '<erro>false</erro><msgRet>SQL COM DADOS: ' + str(sql) + '</msgRet><lista>' + listaEs + '</lista>'


# METODO ABAIXO FUNCIONAL PARA EVENTOS:
# - Ciencia/Desconh/OpNaoReal/ConfirmaOp-NFe
# - Desacordo-CTe
# - Download/Consulta-NFe semelhante ao WS distauto
def execSqlIns(engine, request) -> str:
    body = base64.b64decode(request.data.decode()).decode()
    # parametros passados dentro do body
    listParams = list(body.split('\n'))
    sql = list(listParams[0].split('sql='))[1].upper()
    if printlog:
        printdh('Processando execSqlIns')
    #
    with getConnPG(engine) as conn:
        erro, codEmonitorSpool = dao.execSqlIns(conn, sql)
        if erro:
            return '<erro>true</erro><msgRet>SQL COM ERRO: ' + sql + '</msgRet><codEmonitorSpool></codEmonitorSpool>'
        else:
            ThreadCall(engine, codEmonitorSpool).start()
            return '<erro>false</erro><msgRet>SQL EXECUTADO: ' + sql + '</msgRet><codEmonitorSpool>' + str(codEmonitorSpool) + '</codEmonitorSpool>'


class ThreadCall(Thread):

    def __init__(self, engine, codEmonitorSpool):
        Thread.__init__(self)
        self.engine = engine
        self.codEmonitorSpool = codEmonitorSpool

    def run(self):
        with getConnPG(self.engine) as conn:
            spool = dao.getEMonitorSpool(conn, self.codEmonitorSpool)
            inst = spool['codinstalacao']
            emp = spool['codempresa']
            codEMonitorAcao = spool['codemonitoracao']
            codUF = spool['coduf']
            numUF = spool['numuf']
            #
            pfx_path, pfx_password = getCertProperties(conn, inst, emp, 0)
            #
            tpamb = spool['tpamb']
            if tpamb is None or tpamb == '':
                tpamb = PRODUCAO
            #
            if codEMonitorAcao == ACAO_NFE_DOWNLOADNF2:
                rsEMonitorUFAcao = dao.getEMonitorUFAcaoByFKs(conn, ACAO_NFE_CONSULTANFDIST, codUF, tpamb, '1.00')
            else:
                rsEMonitorUFAcao = dao.getEMonitorUFAcaoByFKs(conn, codEMonitorAcao, codUF, tpamb, spool['versao'])
            #
            if codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO3 or codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO4:
                request, ret, resp, erros = callCTe(pfx_path, pfx_password, codEMonitorAcao, codUF, numUF, '', rsEMonitorUFAcao, spool)
            else:
                request, ret, resp, erros = callNFe(pfx_path, pfx_password, codEMonitorAcao, codUF, numUF, '', rsEMonitorUFAcao, spool)
            if erros != '':
                if codEMonitorAcao == ACAO_NFE_RECEPCAOEVENTO4 or codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO3 or codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO4:
                    # verificar se deu erro devido usuario clicar varias vezes no mesmo botao
                    spool = dao.eventoProcessadoByChave(conn, spool['chave'])
                    resp = {}
                    if spool is not None:
                        resp['msgret'] = spool['msgret']
                        resp['nprot'] = spool['nprot']
                        resp['datahorareclote'] = str(spool['datahorareclote'])
                        resp['nprotinut'] = ''
                        request = spool['arqxmlass']
                        ret = spool['arqxmlret']
                        status = EMONITORSPOOL_PROCESSADO
                    else:
                        resp['msgret'] = erros
                        resp['nprot'] = ''
                        resp['datahorareclote'] = str(datetime.now())
                        resp['nprotinut'] = ''
                        status = EMONITORSPOOL_ERROPROCESSAMENTO
                else:
                    # ACAO_NFE_CONSULTA4
                    resp = {}
                    resp['msgret'] = erros
                    resp['nprot'] = ''
                    resp['datahorareclote'] = str(datetime.now())
                    resp['nprotinut'] = ''
                    status = EMONITORSPOOL_ERROPROCESSAMENTO
                    # PENDENTE ACAO_NFE_DOWNLOADNF2
            else:
                status = EMONITORSPOOL_PROCESSADO
            # select codemonitorspool,datains,nprot,datahorareclote,msgret,status,arqxmlresp from emonitorspool where codemonitorspool >= 2988;
            ret = ret.replace('\'','"')
            dao.updEMonitorSpool(conn, resp['nprot'], resp['datahorareclote'], resp['msgret'], request, ret, ret, status, resp['nprotinut'], self.codEmonitorSpool)

