from metadata import getEnginePG, getConnPG
from geralsis import *
from geral import strtofile, printdh
from nfe_spooler import ACAO_NFE_CONSULTANFDISTAUTO
from cte_spooler import ACAO_CTE_CONSULTACTDISTAUTO
from mdfe_spooler import ACAO_MDFE_CONSULTAMDFDISTAUTO
import dao


printdh('Iniciando processamento do ULTNSU...')

conn = getConnPG(getEnginePG(prop,'EMonitor'))
codEMonitorSpool = 1
listSQL = list()

def procUltNsu(tipo: str, codEMonitorAcao: int):
    global conn, codEMonitorSpool, listSQL
    dados = dao.getFieldsDistInstalacoes(conn, tipo.lower())
    printdh('Processando ' + tipo + 'DistInstalacoes...')
    for instempfil in dados:
        inst = instempfil['codinstalacao']
        emp = instempfil['codempresa']
        cnpjcpf = instempfil['cnpjcpf']
        numuf = instempfil['numuf']
        spool = dao.getSpoolUltNSUDist(conn, inst, emp, cnpjcpf, numuf, codEMonitorAcao)
        if spool is None:
            continue
        printdh('Processando ' + str(inst) + str(emp) + str(cnpjcpf) + str(numuf))
        listSQL.append('INSERT INTO emonitorspool(' +
                       'codemonitorspool,codinstalacao,codempresa,codemonitoracao,coduf,numuf,' +
                       'datains,chave,datahorareclote,status,msgret,tpamb,' +
                       'cnpjinut,anoinut) ' +
                       'VALUES (' +
                       str(codEMonitorSpool) + ',' +
                       str(inst) + ',' +
                       str(emp) + ',' +
                       str(codEMonitorAcao) + ',' +
                       '\'' + str(spool['coduf']) + '\',' +
                       str(spool['numuf']) + ',' +
                       '\'' + str(spool['datains']) + '\',' +
                       '\'' + spool['chave'] + '\',' +
                       '\'' + str(spool['datahorareclote']) + '\',' +
                       '4,' +
                       '\'' + spool['msgret'] + '\',' +
                       '1,' +
                       '\'' + cnpjcpf + '\',' +
                       '\'' + numuf + '\'' +
                       ');\n')
        codEMonitorSpool = codEMonitorSpool + 1


#################################################################################################

listSQL.append('DELETE FROM EMonitorSpool;\n')

procUltNsu('NFe', ACAO_NFE_CONSULTANFDISTAUTO)
procUltNsu('CTe', ACAO_CTE_CONSULTACTDISTAUTO)
procUltNsu('MDFe', ACAO_MDFE_CONSULTAMDFDISTAUTO)

listSQL.append('ALTER SEQUENCE CODEMONITORSPOOL_GEN RESTART WITH ' + str(codEMonitorSpool) + ';\n')

SQL = ''.join(listSQL)

strtofile('/sistemas/emonitorpy/tmp/ultnsu.sql',SQL)

printdh('Terminando processamento do ULTNSU...')
