from geraljson import getJSON

def consistEmpty(reqJSON, fieldName, fieldTitle):
    fieldValue = getJSON(reqJSON, fieldName)
    if fieldValue is None or fieldValue.strip() == '':
        return ' [' + fieldTitle + ' vazio!]'
    else:
        return ''

def consistEmptyOrDefault(reqJSON, fieldName, fieldTitle, defaultValue):
    fieldValue = getJSON(reqJSON, fieldName)
    if fieldValue is None or fieldValue.strip() == '' or fieldValue == defaultValue:
        return ' [' + fieldTitle + ' deve ser informado!]'
    else:
        return ''


def consistDigit(reqJSON, fieldName, fieldTitle, listNumDigit):
    ret = consistEmpty(reqJSON, fieldName, fieldTitle)
    if ret != '':
        return ret
    fieldValue = getJSON(reqJSON, fieldName)
    if not fieldValue.isdigit():
        return ' [' + fieldTitle + ' deve conter apenas números!]'
    if listNumDigit:
        fieldLen = len(fieldValue)
        strNumDigit = ''
        for numDigit in listNumDigit:
            if numDigit == fieldLen:
                return ''
            strNumDigit += str(numDigit) + ' ou '
        strNumDigit = strNumDigit[0:len(strNumDigit)-4]
        return ' [' + fieldTitle + ' deve conter ' + strNumDigit + ' números!]'
    return ''


def consistGTZero(reqJSON, fieldName, fieldTitle, listNumDigit):
    ret = consistDigit(reqJSON, fieldName, fieldTitle, listNumDigit)
    if ret == '':
        fieldValue = getJSON(reqJSON, fieldName)
        if float(fieldValue) <= 0:
            return ' [' + fieldTitle + ' deve ser um valor > 0!]'
    return ''


def consistGEZero(reqJSON, fieldName, fieldTitle, listNumDigit):
    ret = consistDigit(reqJSON, fieldName, fieldTitle, listNumDigit)
    if ret == '':
        fieldValue = getJSON(reqJSON, fieldName)
        if float(fieldValue) < 0:
            return ' [' + fieldTitle + ' deve ser um valor >= 0!]'
    return ''


def consistLTZero(reqJSON, fieldName, fieldTitle, listNumDigit):
    ret = consistDigit(reqJSON, fieldName, fieldTitle, listNumDigit)
    if ret == '':
        fieldValue = getJSON(reqJSON, fieldName)
        if float(fieldValue) >= 0:
            return ' [' + fieldTitle + ' deve ser um valor < 0!]'
    return ''


def consistLEZero(reqJSON, fieldName, fieldTitle, listNumDigit):
    ret = consistDigit(reqJSON, fieldName, fieldTitle, listNumDigit)
    if ret == '':
        fieldValue = getJSON(reqJSON, fieldName)
        if float(fieldValue) > 0:
            return ' [' + fieldTitle + ' deve ser um valor <= 0!]'
    return ''


