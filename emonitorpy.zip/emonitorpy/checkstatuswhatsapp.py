import json
import requests
import mail

headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
}
TECNOSPEED_URL = 'https://api.plugzapi.com.br'
TECNOSPEED_INSTANCE = '3BCDA2B83FBE70DCA38E2A5F1760FC74'
TECNOSPEED_TOKEN = '3BCDA2B83FBE71C533B22A5F1760FC74'
READTIMEOUTWS = 180

def check_status():
    try:
        full_url = f'{TECNOSPEED_URL}/instances/{TECNOSPEED_INSTANCE}/token/{TECNOSPEED_TOKEN}/status'
        response = requests.get(full_url, headers=headers, timeout=READTIMEOUTWS)
        responseJSON = response.json()
        prettyJSON = json.dumps(responseJSON, indent=4)
        print(prettyJSON)
        enviarEmail = response.status_code != 200 or not responseJSON.get('connected') or not responseJSON.get('smartphoneConnected')
        #
    except Exception as e:
        print('Erro em check_status')
        print(e)
        responseJSON = {'erro': 't', 'msgRet': 'ERRO NA CHECAGEM DE STATUS DO WHATSAPP: ' + str(e)}
        prettyJSON = json.dumps(responseJSON, indent=4)
        enviarEmail = True

    if enviarEmail:
        print('Status irregular detectado, enviando e-mail para servidores.')
        htmlEscapedResponse = prettyJSON.replace(' ', '&nbsp;')
        htmlTable = []
        htmlTable.append('<table style="font-family: monospace, monospace; border: 1px solid black;">')
        htmlTable.append('<tr>')
        htmlTable.append('<td>')
        htmlTable.append(htmlEscapedResponse)
        htmlTable.append('</td>')
        htmlTable.append('</tr>')
        htmlTable.append('</table>')
        mail.send(
            dest_mail='servidor@intersite.com.br',
            title='ERRO NO STATUS DO DISPOSITIVO DO WHATSAPP TECNOSPEED',
            message=f'Houve a detecção de um status irregular na instância da integração WhatsApp Tecnospeed.\n'
                    + ''.join(htmlTable)
        )

####################################################################################
# CODIGO ABAIXO main...
####################################################################################

if __name__ == '__main__':
    print('Iniciando verificação de status da instância do WhatsApp Tecnospeed.')
    check_status()
    exit(0)
