'''
Executar no EMP este programa

select codemonitorspool,codinstalacao,chave from emonitorspool where status = 4 and datains >= '2020-4-3' order by codinstalacao,datains desc;
update emonitorspool set chave = '000000000196000' where codemonitorspool = 453895;
update emonitorspool set chave = '000000000199000' where codemonitorspool = 453896;
commit;
'''

from geralsis import prop, usePropDist
from metadata import getEnginePG, getConnPG
import dao
from sefaz_spooler import ThreadDist


engineSefazPG = getEnginePG(prop, 'EMonitor')
if not usePropDist():
    conn = getConnPG(engineSefazPG)

SleepTimeBetweenNFeDistThread=prop['SleepTimeBetweenNFeDistThread'].data
if usePropDist():
    NFeDistInstalacoes = prop['NFeDistInstalacoes'].data
else:
    NFeDistInstalacoes = dao.getDistInstalacoes(conn,'nfe')

SleepTimeBetweenCTeDistThread=prop['SleepTimeBetweenCTeDistThread'].data
if usePropDist():
    CTeDistInstalacoes = prop['CTeDistInstalacoes'].data
else:
    CTeDistInstalacoes = dao.getDistInstalacoes(conn,'cte')

SleepTimeBetweenMDFeDistThread=prop['SleepTimeBetweenMDFeDistThread'].data
if usePropDist():
    MDFeDistInstalacoes = prop['MDFeDistInstalacoes'].data
else:
    MDFeDistInstalacoes = dao.getDistInstalacoes(conn,'mdfe')

if not usePropDist():
    conn.close()

if int(SleepTimeBetweenNFeDistThread) != -1:
    ThreadDist(engineSefazPG, 1, SleepTimeBetweenNFeDistThread, NFeDistInstalacoes).start()
    # se tem processamento de dist, pelo menos de NFe existe, CTe e MDFe que podem ser opcionais
    if int(SleepTimeBetweenCTeDistThread) != -1:
        ThreadDist(engineSefazPG, 2, SleepTimeBetweenCTeDistThread, CTeDistInstalacoes).start()
    if int(SleepTimeBetweenMDFeDistThread) != -1:
        ThreadDist(engineSefazPG, 3, SleepTimeBetweenMDFeDistThread, MDFeDistInstalacoes).start()

'''
select t1.status,count(t1.status) from emonitorspool t1 join instempfil t2 on t1.codinstalacao = t2.codinstalacao and t1.codempresa = t2.codempresa and t1.cnpjinut = t2.cnpjcpf and t1.anoinut = t2.numuf where t1.datains >= '2023-05-03 11:00' and t1.codemonitoracao = 11 group by t1.status;
select t1.codinstalacao, t1.codempresa, t1.cnpjinut, t1.anoinut, t1.status, t1.chave, t1.msgret from emonitorspool t1 join instempfil t2 on t1.codinstalacao = t2.codinstalacao and t1.codempresa = t2.codempresa and t1.cnpjinut = t2.cnpjcpf and t1.anoinut = t2.numuf where t1.datains >= '2023-05-03 10:00' and t1.codemonitoracao = 11 order by t1.codinstalacao, t1.codempresa, t1.cnpjinut, t1.anoinut;
'''
