from geraljson import getJSON
from consist import *


def consistCadastrarConhecimento(reqJSON):
    ret = ''
    ret += consistDigit(reqJSON, 'conh_ncm', 'NCM da Mercadoria', [4])
    #ret += consistGTZero(reqJSON, 'conh_kmrodado', 'KM Padrão da Viagem (Aba C. Dados Compl.)', [])
    return ret


def consistObterPdfConhecimento(reqJSON):
    # PENDENTE
    ret = ''
    return ret


def consistCancelarConhecimento(reqJSON):
    # PENDENTE
    ret = ''
    return ret

