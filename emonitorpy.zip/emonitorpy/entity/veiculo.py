from geraljson import getJSON
from geral import *
from consist import *


def consistCadastrarVeiculo(reqJSON, prefixTag):
    ret = ''
    ret += consistEmpty(reqJSON, prefixTag + 'placa', 'Placa')
    if ret != '' and prefixTag.startswith('car'):
        return 'VAZIO'# pois as carretas nao sao obrigatorias
    return ret

