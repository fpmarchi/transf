from geraljson import getJSON
from geral import *
from consist import *


def consistCadastrarMotorista(reqJSON):
    ret = ''
    ret += consistDigit(reqJSON, 'mot_cpf', 'CPF', [11])
    ret += consistDigit(reqJSON, 'mot_cnh', 'CNH', [11])
    ret += consistEmpty(reqJSON, 'mot_nome', 'Nome')
    ret += consistEmpty(reqJSON, 'mot_endereco', 'Endereço')
    ret += consistEmpty(reqJSON, 'mot_numero', 'Número')
    ret += consistEmpty(reqJSON, 'mot_bairro', 'Bairro')
    ret += consistDigit(reqJSON, 'mot_cep', 'CEP', [8])
    ret += consistDigit(reqJSON, 'mot_codibge', 'Código do IBGE da Cidade', [7])
    ret += consistEmptyOrDefault(reqJSON, 'mot_datanasc', 'Data Nasc.', '0000-00-00')
    if (consistDigit(reqJSON, 'mot_foneddd', 'Fone/DDD', [2]) != '' or consistDigit(reqJSON, 'mot_fonenumero', 'Fone/Número', [8, 9]) != '' or getJSON(reqJSON, 'mot_foneddd') == '00') and \
        (consistDigit(reqJSON, 'mot_celularddd', 'Celular/DDD', [2]) != '' or consistDigit(reqJSON, 'mot_celularnumero', 'Celular/Número', [9]) != '' or getJSON(reqJSON, 'mot_celularddd') == '00'):
        ret += ' [Nenhum telefone válido informado com DDD + Número (Fixo com 8 posições ou celular com 9 posições)!]'
    return ret

