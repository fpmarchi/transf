import re
import tempfile
from os import path, stat, listdir
from contextlib import contextmanager
from datetime import date, datetime, timedelta
from typing import Any, Dict, Type, Callable, Union
from unicodedata import normalize

import OpenSSL.crypto
import time
from formatdate import *
import hashlib
import mimetypes
from cryptography import x509
from cryptography.hazmat.backends import default_backend


timems = lambda: int(round(time.time() * 1000))


def strempty(s):
    return s is None or s == ''


def getstrnotempty(s):
    if s is None:
        s = ''
    return s


@contextmanager
def pfx_to_pem(pfx_path, pfx_password):
    """ Decrypts the .pfx file to be used with requests. """
    with tempfile.NamedTemporaryFile(suffix='.pem') as t_pem:
        f_pem = open(t_pem.name, 'wb')
        pfx = open(pfx_path, 'rb').read()
        p12 = OpenSSL.crypto.load_pkcs12(pfx, pfx_password)
        f_pem.write(OpenSSL.crypto.dump_privatekey(OpenSSL.crypto.FILETYPE_PEM, p12.get_privatekey()))
        f_pem.write(OpenSSL.crypto.dump_certificate(OpenSSL.crypto.FILETYPE_PEM, p12.get_certificate()))
        ca = p12.get_ca_certificates()
        if ca is not None:
            for cert in ca:
                f_pem.write(OpenSSL.crypto.dump_certificate(OpenSSL.crypto.FILETYPE_PEM, cert))
        f_pem.close()
        yield t_pem.name


def pfx_expiration_date(pfx_path, pfx_password):
    with tempfile.NamedTemporaryFile(suffix='.pem') as t_pem:
        f_pem = open(t_pem.name, 'wb')
        pfx = open(pfx_path, 'rb').read()
        p12 = OpenSSL.crypto.load_pkcs12(pfx, pfx_password)
        pem_data = OpenSSL.crypto.dump_certificate(OpenSSL.crypto.FILETYPE_PEM, p12.get_certificate())
        cert = x509.load_pem_x509_certificate(pem_data, default_backend())
        return cert.not_valid_after


def pfx_cert_info(pfx_path, pfx_password):
    with tempfile.NamedTemporaryFile(suffix='.pem') as t_pem:
        f_pem = open(t_pem.name, 'wb')
        pfx = open(pfx_path, 'rb').read()
        p12 = OpenSSL.crypto.load_pkcs12(pfx, pfx_password)
        pem_data = OpenSSL.crypto.dump_certificate(OpenSSL.crypto.FILETYPE_PEM, p12.get_certificate())
        cert = x509.load_pem_x509_certificate(pem_data, default_backend())
        info = []
        for item in cert.subject.rdns:
            cnCert = str(item)
            # print(cnCert)
            if not strempty(cnCert):
                index = 1 + cnCert.find('(')
                if index:
                    info.append(cnCert[index:-2])
        return info


def pfx_cnpjcpf(pfx_path, pfx_password):
    with tempfile.NamedTemporaryFile(suffix='.pem') as t_pem:
        f_pem = open(t_pem.name, 'wb')
        pfx = open(pfx_path, 'rb').read()
        p12 = OpenSSL.crypto.load_pkcs12(pfx, pfx_password)
        pem_data = OpenSSL.crypto.dump_certificate(OpenSSL.crypto.FILETYPE_PEM, p12.get_certificate())
        cert = x509.load_pem_x509_certificate(pem_data, default_backend())
        cnpjCpf = ''
        for item in cert.subject.rdns:
            cnCert = str(item)
            if not strempty(cnCert):
                indexIni = cnCert.find('CN=')
                if indexIni == -1:
                    continue
                indexIni = cnCert.find(':',indexIni)
                i = indexIni + 1
                ct = 0
                while (ct < 14):
                    c = cnCert[i]
                    if c >= '0' and c <= '9':
                        cnpjCpf += str(c)
                    else:
                        break
                    i += 1
                    ct += 1
        return cnpjCpf


def datetimefilename():
    dh = datetime.now()
    return padlzero(dh.day,2) + padlzero(dh.month,2) + padlzero(dh.year,4) + '_' + padlzero(dh.hour,2) + padlzero(dh.minute,2)


def datefilename():
    dh = date.today()
    return padlzero(dh.day,2) + padlzero(dh.month,2) + padlzero(dh.year,4)


def defstrtodate(s):
    return strtodate(s,'%d/%m/%Y')


def defstrtodatetime(s):
    return strtodatetime2(s,'%d/%m/%Y %H:%M:%S')


def dbstrtodate(s):
    return strtodate(s, '%Y-%m-%d')


def dbstrtodatetime(s):
    return strtodatetime2(s, '%Y-%m-%d %H:%M:%S')


def wsstrtodate(s):
    return strtodate(s, '%Y-%m-%dT%H:%M:%S.%f')


def wsstrtodate2(s):
    return strtodate(s, '%Y-%m-%dT%H:%M:%S') # sem milisegundos


def wsstrtoDDMMAAAA(s):
    # 1983-12-06 AAAA-MM-DD
    return s[8:10] + '/' + s[5:7] + '/' + s[0:4]


def wsstrtoAAAAMMDD(s):
    # 14/02/1999 -> 1999-02-14
    if s != '':
        return s[6:10] + '-' + s[3:5] + '-' + s[0:2]
    else:
        return ''


def strtodate(s,f):
    return datetime.strptime(s,f).date()


def strtodatetime(s,f): # devolve uma string da data/hora
    return str(datetime.strptime(s,f))


def strtodatetime2(s,f): # devolve uma data/hora
    return datetime.strptime(s,f)


def incdatetimeactual(inc):
    return incdatetime(date.today(),inc)


def incdatetime(dh,inc):
    return dh + timedelta(inc)


def datetimeactualtostr():
    dh = datetime.now()
    return datetimetostr(dh)


def datetimetostr(dh):
    return padlzero(dh.day,2) + '/' + padlzero(dh.month,2) + '/' + padlzero(dh.year,4) + ' ' + padlzero(dh.hour,2) + ':' + padlzero(dh.minute,2) + ':' + padlzero(dh.second,2)


def dateactualtostr():
    dh = date.today()
    return datetostr(dh)


def datetostr(dh):
    return padlzero(dh.day,2) + '/' + padlzero(dh.month,2) + '/' + padlzero(dh.year,4)


def dbdatetimeactualtostr():
    dh = datetime.now()
    return dbdatetimetostr(dh)


def dbdatetimetostr(dh):
    return padlzero(dh.year,4) + '-' + padlzero(dh.month,2) + '-' + padlzero(dh.day,2) + ' ' + padlzero(dh.hour,2) + ':' + padlzero(dh.minute,2) + ':' + padlzero(dh.second,2)


def dbdateactualtostr():
    dh = date.today()
    return dbdatetostr(dh)


def dbdatetostr(dh):
    return padlzero(dh.year,4) + '-' + padlzero(dh.month,2) + '-' + padlzero(dh.day,2)


def dbdatetimeactualzero():
    return dbdatetimezero(dbdateactualtostr())


def dbdatetimezero(dh):
    return dbdatetostr(dh) + ' ' + HORAZERO


def dbdatetimeactuallim():
    return dbdatetimelim(dbdateactualtostr())


def dbdatetimelim(dh):
    return dbdatetostr(dh) + ' ' + HORALIMITE


def wsdatetimetostr(dh=datetime.now(),timezone='03:00'):
    return padlzero(dh.year,4) + '-' + padlzero(dh.month,2) + '-' + padlzero(dh.day,2) + 'T' + padlzero(dh.hour,2) + ':' + padlzero(dh.minute,2) + ':' + padlzero(dh.second,2) + '-' + timezone


def filetostr(filename):
    return open(filename,'r').read()


def filetolist(filename):
    return open(filename,'r').readlines()


def strtofile(filename, s):
    if s is None:
        s = ''
    open(filename, 'w').write(s)


def filedatetimemodified(filename, formatted=False):
    dh = stat(filename).st_mtime
    if formatted:
        return time.ctime(dh)
    else:
        return dh


def fileexists(filename):
    return path.isfile(filename)


def direxists(dirname):
    return path.isdir(dirname)


def dirlist(dirname, onlyfiles=False, onlydirs=False):
    l = listdir(dirname)
    lRet = []
    if onlyfiles or onlydirs:
        for d in l:
            if (onlyfiles and path.isfile(dirname+'/'+d)) or (onlydirs and path.isdir(dirname+'/'+d)):
                lRet.append(d)
        return lRet
    else:
        return l


def padl(val, width, padval):
    s = str(val)
    return s.rjust(width,padval)


def padlzero(val, width):
    return padl(val,width,'0')


def padr(val, width, padval):
    s = str(val)
    return s.ljust(width,padval)


def padrzero(val, width):
    return padr(val,width,'0')


def cut(val, width):
    if val is not None and len(val) > width:
        val = val[0:width]
    return val


def filestrreplace(filename, strbefore, strini, strfin, newvalue):
    s = filetostr(filename)
    index = s.index(strbefore)
    index = s.index(strini,index) + len(strini)
    index2 = s.index(strfin,index)
    value = s[index:index2]
    s = s.replace(value,newvalue,1)
    strtofile(filename, s)


def clearNoDigits(s):
    ret = ''
    for c in s:
        if (c >= '0' and c <= '9'):
            ret += c
    return ret


def clearNoLetters(s):
    ret = ''
    for c in s:
        if (c >= 'A' and c <= 'Z') or (c >= 'a' and c <= 'z'):
            ret += c
    return ret


def clearUnicodeNoASCII(s):
    s = s.replace("\x00", "\uFFFD")
    return s.encode('ascii', 'ignore').decode()


def clearNoASCII(s):
    ret = ''
    for c in s:
        if (c >= '0' and c <= '9') or (c >= 'A' and c <= 'Z') or (c >= 'a' and c <= 'z'):
            ret += c
    return ret


def clearNoASCII2(s):
    ret = ''
    for c in s:
        if (c >= '0' and c <= '9') or (c >= 'A' and c <= 'Z') or (c >= 'a' and c <= 'z') or (c == '.'):
            ret += c
    return ret


def clearNoASCII3(s):
    ret = ''
    for c in s:
        if (c >= '0' and c <= '9') or (c >= 'A' and c <= 'Z') or (c >= 'a' and c <= 'z') or (c == '.') or (c == ' '):
            ret += c
    return ret


def removeAccents(s):
    ret = ''
    for c in s:
        if c == 'Á' or c == 'Ä' or c == 'À' or c == 'Â' or c == 'Ã':
            ret += 'A'
        elif c == 'á' or c == 'ä' or c == 'à' or c == 'â' or c == 'ã':
            ret += 'a'
        elif c == 'É' or c == 'Ë' or c == 'È' or c == 'Ê':
            ret += 'E'
        elif c == 'é' or c == 'ë' or c == 'è' or c == 'ê':
            ret += 'e'
        elif c == 'Í' or c == 'Ï' or c == 'Ì' or c == 'Î':
            ret += 'I'
        elif c == 'í' or c == 'ï' or c == 'ì' or c == 'î':
            ret += 'i'
        elif c == 'Ó' or c == 'Ö' or c == 'Ò' or c == 'Ô' or c == 'Õ':
            ret += 'O'
        elif c == 'ó' or c == 'ö' or c == 'ò' or c == 'ô' or c == 'õ':
            ret += 'o'
        elif c == 'Ú' or c == 'Ü' or c == 'Ù' or c == 'Û':
            ret += 'U'
        elif c == 'Ý':
            ret += 'Y'
        elif c == 'ý':
            ret += 'y'
        elif c == 'Ç':
            ret += 'C'
        elif c == 'ç':
            ret += 'c'
        elif c == '©':
            ret += 'c'
        elif c == '§':
            ret += 's'
        elif c == 'ª':
            ret += 'a'
        elif c == 'º':
            ret += 'o'
        elif c == '°':
            ret += 'o'
        elif c == 'Ñ':
            ret += 'N'
        elif c == 'ñ':
            ret += 'n'
        elif c == '&':
            ret += 'E'
        else:
            ret += c
    return ret


def printdh(msg):
    print(datetimeactualtostr() + ' - ' + msg + ' ...')


def printsefazdist(msg, tipo):
    debug = False
    if tipo == 1:
        if debug:
            print(datetimeactualtostr() + ' - ' + msg + ' ...')
        else:
            print(datetimeactualtostr() + ' - ' + msg + ' ...', file=open('/sistemas/emonitorpy/log/sefaznfedist.log', 'a'))
    elif tipo == 2:
        if debug:
            print(datetimeactualtostr() + ' - ' + msg + ' ...')
        else:
            print(datetimeactualtostr() + ' - ' + msg + ' ...', file=open('/sistemas/emonitorpy/log/sefazctedist.log', 'a'))
    else:
        if debug:
            print(datetimeactualtostr() + ' - ' + msg + ' ...')
        else:
            print(datetimeactualtostr() + ' - ' + msg + ' ...', file=open('/sistemas/emonitorpy/log/sefazmdfedist.log', 'a'))


def strtonum(s, defVal):
    if s is None or s == '' or s == 'null':
        return defVal
    else:
        return s

def numtostr(i, defVal):
    if i is None or i == 0 or i == '':
        return defVal
    else:
        return str(i)


def formatstrnum(snum, prec = 2):
    if strempty(snum) or snum == 'null':
        snum = '0'
    return ('{0:.'+str(prec)+'f}').format(float(snum))


def unix_date_to_date(unixDate):
    ts = unixDate / 1000
    return datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')


def getInicioFimViagemMotDateTime(jsonSor):
    try:
        getJSON = jsonSor.getJSON
        dataIni = getJSON('conh_dataini')
        dataHoraEmissao = getJSON('conh_datahoraemissao')
        #
        if dataIni != '':
            dataHoraSaida = dataIni
        else:
            dataHoraSaida = dataHoraEmissao
        #
        if len(dataHoraSaida) == 10:
            dataHoraSaida += ' 00:00:00'
        #
        if 'T' in dataHoraSaida:
            dataHoraSaidaDate = datetime.strptime(dataHoraSaida, '%Y-%m-%dT%H:%M:%S')
        else:
            dataHoraSaidaDate = datetime.strptime(dataHoraSaida, '%Y-%m-%d %H:%M:%S')
        #
        dataFim = getJSON('conh_datafim')
        dataPrevDescarga = getJSON('conh_dataprevisaodescarga')
        if dataFim != '':
            dataHoraChegada = dataFim
        elif dataPrevDescarga != '':
            dataHoraChegada = dataPrevDescarga
        else:
            dataHoraChegada = datetime.fromordinal(dataHoraSaidaDate.toordinal() + 30)
            dataHoraChegada = dbdatetimetostr(dataHoraChegada)
        #
        if len(dataHoraChegada) == 10:
            dataHoraChegada += ' 00:00:00'
        #
        if 'T' in dataHoraChegada:
            dataHoraChegadaDate = datetime.strptime(dataHoraChegada, '%Y-%m-%dT%H:%M:%S')
        else:
            dataHoraChegadaDate = datetime.strptime(dataHoraChegada, '%Y-%m-%d %H:%M:%S')
        #
        return dataHoraSaidaDate, dataHoraChegadaDate
    except Exception as e:
        print('Erro em getInicioFimViagemMotDateTime')
        print(e)


def encryptMd5(string):
    pw = string
    result = hashlib.md5(pw.encode('utf-8'))
    return result.hexdigest()

def extractPathFromFilename(filename):
    index = filename.rindex('/')
    return filename[0:index]


def extractNameFromFilename(filename):
    index = filename.rindex('/') + 1
    return filename[index:]


def getMimeType(filename):
    try:
        mimetypes.init()
        return mimetypes.guess_type(filename)[0]
    except Exception as e:
        print('Erro em getMimeType')
        print(e)
        return None


def deep_get(target: dict, path_: str, default=None) -> Any:
    """
        Utilizada para obter valores de dicionários  multidimensionais de maneira simplificada

        :param target: dict
        :param path_: str
        :param default: Any
        :return: Qualquer valor presente na ultima chave presente no path
                 ou o valor padrão informado. Retorna None em ultimo caso
    """

    keys = re.compile(r"(?<!\\)\.").split(path_)

    try:
        for key in keys:
            target = target[key.replace('\\', '')]
    except (Exception,):
        return default

    return target


def conditional_key(name: Any, value: Any, condition: bool = None) -> Dict[Any, Any]:
    """
        Permite a definição de uma chave dependente de seu preenchimento ou de uma valor boleano.
        Essa função deve ser utilizada em declarações literais de dicionários com o operador **

        :param name: (dict)
            Nome da chave.
        :param value: (str)
            Valor a ser vinculado a chave.
        :param condition: (Any, Opcional)
            Condição de inserção.
        :return: (Dict[Any, Any]) Retorna um dicionário com uma chave e valor, ele deve ser desempacotado com o
        operador **. Ex.: {**conditional_key([params])}
    """

    if condition is None:
        return {name: value} if value else {}

    return {name: value} if condition else {}


def conditional_keys(condition: bool, keys: dict, alternative_keys: dict = None) -> Dict[Any, Any]:
    """
        Permite a definição de um conjunto de chaves dependentes de uma condição.
        Essa função deve ser utilizada em declarações literais de dicionários com o operador **

        :param condition: (Any, Opcional)
            Condição de inserção.
        :param keys: (dict)
            Dicionário com as chaves e valores a serem considerados em uma condição válida.
        :param alternative_keys: (dict, Opcional)
            Dicionário com as chaves e valores a serem considerados em uma condição inválida
        :return: (Dict[Any, Any]) Retorna um dicionário com as devida chaves, ele deve ser desempacotado com o
        operador **. Ex.: {**conditional_key([params])}
    """

    if alternative_keys is None:
        alternative_keys = {}

    if condition is True:
        return keys
    else:
        return alternative_keys


def set_context(name: str, target: dict, context: dict):
    """
       Utilizada para definir um contexto com valores ao mapear propriedades de dicionários.
       Pode ser utilizado ao processar um dicionário na declaração literal de outro.

        :param context:
            dicionário com os valores desejados.
        :param target:
            dicionário para inserção dos dados.
        :param name:
            Nome da chave a ser inserida.
        :return: (str) O nome passado como parâmetro.
    """
    if context is None:
        context = {}

    try:
        target.clear()
        target.update(context)
        return name
    except (Exception,):
        return name


def remove_accents(str_: str) -> str:
    """
        Remove a acentuação da string especificada.

        :param str_: (str)
            String alvo.
        :return: (str) Retorna a string sem os acentos.
    """

    return normalize('NFKD', str_ or '').encode('ASCII', 'ignore').decode('ASCII')


def static_vars(**kwargs: Any) -> Callable:
    """
        @Decorator Factory
        Permite a definição de um contexto com variaveis estaticas entre as execuções de um método.

        :param kwargs: (Any)
            String alvo.

        Ex.:
            @static_vars(bonds={
                'S': 'F',
                'F': 'F',
                'R': 'F',
                'O': 'F',
                'N': 'T',
                'A': 'A',
                'M': 'A',
                'G': 'A'
            })
            def _get_bond(in_sat: str) -> str:
                return _get_bond.bonds.get(in_sat, '')

        :return: (Calleble) Retorna a string sem os acentos.
    """

    def decorate(func) -> Callable:
        for k in kwargs:
            setattr(func, k, kwargs[k])
        return func
    return decorate


def safe_cast(value: Any, type_: Type, default: Any = None) -> Any:
    """
        Possibilia um maior controle entre as conversões de tipo.

        :param value: (Any)
            Valor a ser convertido.
        :param type_: (Type)
            Tipo desejado.
        :param default: (Any)
            Valor a ser retornado caso a conversão não seja bem sucedida.
        :return: (Any)
            Retorna o valor convertido ou o valor padrão informado.
    """

    try:
        return type_(value)
    except (ValueError, TypeError):
        return default


def datetime_from_iso(date_: str) -> Union[datetime, None]:
    try:
        return datetime.strptime(date_, '%Y-%m-%dT%H:%M:%S')
    except (Exception,):
        return None


def round_by_abnt(decimal: Union[float, str], target: int = 2):
    def make_float(integer_, decimals_):
        return float('.'.join((integer_, decimals_)))

    if type(decimal) is str:
        if decimal.find(',') != -1:
            decimal = decimal.replace('.', '').replace(',', '.')

    if str(decimal).find('.') == -1:
        return float(decimal)

    integer, decimals = f'{decimal}'.split('.')

    if len(decimals) <= target:
        return make_float(integer, decimals)

    decimal_list = [int(s) for s in decimals[:target + 2]]
    decimal_list = decimal_list + [-1] * (target + 2 - len(decimal_list))

    vin = decimal_list[-2]
    t = decimal_list[-3]

    if vin == 5:
        if decimal_list[-1] == 0:
            if t % 2 != 0:
                decimal_list[-3] += 1
        else:
            decimal_list[-3] += 1
    elif vin > 5:
        decimal_list[-3] += 1

    decimal_list = decimal_list[:-2]

    add = 0
    decimal_list.reverse()
    for i in range(len(decimal_list)):
        decimal_list[i] += add
        if decimal_list[i] == 10:
            decimal_list[i] = 0
            add = 1
        else:
            add = 0
    decimal_list.reverse()

    integer = str(int(integer) + add)
    return make_float(integer, ''.join(map(str, decimal_list)))


# chave de uso geral
INTERSITE = 'InTeRsItE'
def encrypt_password(password: str, key: str = INTERSITE, passwordOA: bool = False) -> str:
    # passwordOA é uma restricao do Delphi na hora de encriptar senhas
    if not passwordOA:
        password = password.replace('O','A')
    i = 0
    keyLen = len(key)
    while i < keyLen:
        passwordNew = ''
        j = 0
        passwordLen = len(password)
        while j < passwordLen:
            c = chr(ord(key[i]) ^ ord(password[j]))
            if passwordOA and c == '\0':
                c = ord(password[j])
            passwordNew += str(c)
            j += 1
        i += 1
        password = passwordNew
    return password



def check_user_password(user: str, password: str, key: str = INTERSITE, passwordOA: bool = False, testWS: bool = False) -> str:
    if testWS:
        return None
    if user != encrypt_password('websaf', key, passwordOA):
        return 'USUARIO INVALIDO'
    if password != encrypt_password('masterkey', key, passwordOA):
        return 'SENHA INVALIDA'
    return None


def check_user_password_ws(request):
    usuario = request.args.get('u',type=str)
    senha = request.args.get('s',type=str)
    #
    return check_user_password(usuario, senha)


def cache_wrapper_factory(target: dict) -> Callable:
    def wrapper(key: Union[str, int], value: Any):
        target[key] = value
        return value

    return wrapper


def format_cell(dd: str, number: str) -> str:
    try:
        if dd and number:
            return '(' + dd + ')' + number[0:5] + '-' + number[5:9]
        else:
            return ''
    except (Exception,):
        return ''

def format_plate(plate: str) -> str:
    if plate:
        return plate[:3] + '-' + plate[3:]
    else:
        return ''
