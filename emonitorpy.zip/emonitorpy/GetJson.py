class GetJson:
    def __init__(self, reqJSON):
        self.reqJSON = reqJSON

    def getJSON(self, fieldname):
        ret = self.reqJSON.get(fieldname)
        if ret is None:
            return ''
        else:
            return ret