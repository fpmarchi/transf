from typing import Tuple
from geralxml import *
from geral import *
import nfse_spooler
import json

import xmltodict


def process_request_coplan(cod_acao_emonitor: int, cod_ibge: int,
                           req: dict, assinatura: AssinaturaA1) -> Tuple[str, str]:
    if cod_acao_emonitor == nfse_spooler.ACAO_NFSE_RECEPCAO:
        xml, erro = request_coplan_recepcao(cod_ibge, req, assinatura)
    elif cod_acao_emonitor == nfse_spooler.ACAO_NFSE_CONSULTA_SITLOTE_RPS:
        return request_coplan_consulta_sit_lote(req)
    elif cod_acao_emonitor == nfse_spooler.ACAO_NFSE_CONSULTA_NFSE_POR_RPS:
        return request_coplan_consulta_nfse_por_rps(req)
    elif cod_acao_emonitor == nfse_spooler.ACAO_NFSE_CANCELAMENTO:
        return request_coplan_cancelamento(cod_acao_emonitor, req, assinatura)
    else:
        return '', 'Acao ' + str(cod_acao_emonitor) + ' sem Implementação'

    return xml, erro


def envelop(service1: str, service2: str, str_xml: str, version: int = 2.02):
    if not str_xml:
        return str_xml

    header = {
        'cabecalho': (
            {
                'versaoDados': version
            },
            {
                'attr': {
                    'xmlns': 'http://www.abrasf.org.br/nfse.xsd',
                    'versao': version
                }
            }
        )
    }

    soap_env: dict = {
        'soapenv:Envelope': (
            {
                'soapenv:Header': '',
                'soapenv:Body': {
                    'trib:nfse_web_service.' + service1: {
                        'trib:' + service2: {
                            'trib1:nfseCabecMsg': (dict_to_xml(header), {'cdata': True}),
                            'nfseDadosMsg': (str_xml, {'cdata': True}),

                        }
                    }
                }
            },
            {
                'attr': {
                    'xmlns:soapenv': 'http://schemas.xmlsoap.org/soap/envelope/',
                    'xmlns:trib': 'Tributario',
                    'xmlns:trib1': 'Tributario_PRD_Oficia',
                }
            }
        )
    }

    return dict_to_xml(soap_env, indent=True, prolog=True)


def request_coplan_recepcao(cod_ibge: int, req: dict, assinatura: AssinaturaA1) -> Tuple[str, str]:
    rps, erros = process_xml_request_coplan_recepcao(req, cod_ibge)

    lote: dict = {
        'EnviarLoteRpsEnvio': (
            {
                'LoteRps': (
                    {
                        'NumeroLote': req.get('conh_nreclote', ''),
                        'CpfCnpj': {
                            'Cnpj': req.get('conh_filial_cnpjcpf', '')
                        },
                        'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
                        'QuantidadeRps': 1,
                        'ListaRps': {
                            'Rps': rps
                        }
                    },
                    {
                        'attr': {
                            'Id': 'lote' + req.get('conh_rps', ''),
                            'versao': '2.02'
                        }
                    },
                )
            },
            {
                'attr': {
                    'xmlns': 'http://www.abrasf.org.br/nfse.xsd'
                }
            }
        )
    }

    lote_str = dict_to_xml(lote)
    sign_str = assinatura.assinar(lote_str, True, 'Id', certificado_rpslote=True)
    lote_str = lote_str.replace('</Rps></ListaRps>', sign_str + '</Rps></ListaRps>')
    lote_str = assinatura.assinar(lote_str, True, 'Id', True)

    return envelop('RECEPCIONARLOTERPS', 'Recepcionarloterpsrequest', lote_str), ''


def process_xml_request_coplan_recepcao(req: dict, cod_ibge: int):
    rps: dict = {
        'InfDeclaracaoPrestacaoServico  ': (
            {
                'Rps': {
                    'IdentificacaoRps': {
                        'Numero': req.get('conh_rps', ''),
                        'Serie': req.get('conh_serie', ''),
                        'Tipo': 1
                    },
                    'DataEmissao': req.get('conh_datahoraemissao', '').split('T')[0],
                    'Status': '1',
                },
                'Competencia': req.get('conh_datahoraemissao', '').split('T')[0],
                'Servico': {
                    'Valores': {
                        'ValorServicos': req.get('conh_freteempresa', 0),
                        'ValorDeducoes': 0,
                        'ValorPis': 0,
                        'ValorCofins': 0,
                        'ValorIr': 0,
                        'ValorCsll': 0,
                        'OutrasRetencoes': 0,
                        **conditional_keys(
                            req.get('conh_cliente_cidade_codibge') != '5107602' and req.get('conh_pagaiss') != '2',
                            {
                                'ValorIss': req.get('conh_valoriss'),
                                'Aliquota': safe_cast(req.get('conh_taxaiss', 0), float, 0)
                            },
                            {
                                'ValorIss': 0,
                                'Aliquota': 0
                            }
                        ),
                        'DescontoIncondicionado': 0,
                        'DescontoCondicionado': 0
                    },
                    'IssRetido': (1 if req.get('conh_pagaiss') == '2' else 2),
                    **conditional_key('ResponsavelRetencao', '1', req.get('conh_pagaiss') == '2'),
                    'ItemListaServico': req.get('conh_codservico', ''),
                    'CodigoCnae': req.get('conh_cnae', ''),
                    'CodigoTributacaoMunicipio': req.get('conh_codtributacao', ''),
                    'Discriminacao': req.get('conh_descservico'),
                    'CodigoMunicipio': req.get('conh_cliente_cidade_codibge') if req.get(
                        'conh_pagaiss') == '2' else cod_ibge,
                    'ExigibilidadeISS': 1,
                    'MunicipioIncidencia': cod_ibge if req.get('conh_cliente_cidade_codibge') == cod_ibge else req.get(
                        'conh_cliente_cidade_codibge', '')
                },
                'Prestador': {
                    'CpfCnpj': {
                        'Cnpj': req.get('conh_filial_cnpjcpf', '')
                    },
                    'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
                },
                'Tomador': {
                    'IdentificacaoTomador': {
                        'CpfCnpj': {
                            'Cnpj' if len(req.get('conh_cliente_cnpjcpf', '')) > 11 else
                            'Cpf': req.get('conh_cliente_cnpjcpf', '')
                        }
                    },
                    'RazaoSocial': req.get('conh_cliente_nome', ''),
                    'Endereco': {
                        'Endereco': req.get('conh_cliente_endereco', ''),
                        'Numero': req.get('conh_cliente_numero', ''),
                        **conditional_key('Complemento', req.get('conh_cliente_complemento', '')),
                        'Bairro': req.get('conh_cliente_bairro', ''),
                        'CodigoMunicipio': req.get('conh_cliente_cidade_codibge', ''),
                        'Uf': req.get('conh_cliente_cidade_uf', ''),
                        'Cep': req.get('conh_cliente_cep', '')
                    },
                    'Contato': {
                        'Telefone': req.get('conh_cliente_fone', ''),
                        **conditional_key('Email', req.get('conh_cliente_email', ''))
                    }
                },
                'OptanteSimplesNacional': '2',
                'IncentivoFiscal': '2',
            },
            {
                'attr': {
                    'Id': 'rps' + req.get('conh_rps', '')
                }
            }
        )
    }

    return dict_to_xml(rps), ''


def request_coplan_consulta_sit_lote(req: dict):
    xml = {
        'ConsultarLoteRpsEnvio': (
            {
                'Prestador': {
                    'CpfCnpj': {
                        'Cnpj' if len(req.get('conh_filial_cnpjcpf', '')) > 11 else
                        'Cpf': req.get('conh_filial_cnpjcpf', '')
                    },
                    'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
                },
                'Protocolo': req.get('conh_nprot', '')
            }, {
                'attr': {
                    'xmlns': 'http://www.abrasf.org.br/nfse.xsd'
                }
            }
        )
    }

    return envelop('CONSULTARLOTERPS', 'Consultarloterpsrequest', dict_to_xml(xml)), ''


def request_coplan_consulta_nfse_por_rps(req: dict):
    xml = {
        'ConsultarNfseRpsEnvio': (
            {
                'IdentificacaoRps': {
                    'Numero': req.get('conh_rps', ''),
                    'Serie': req.get('conh_serie', ''),
                    'Tipo': 1
                },
                'Prestador': {
                    'CpfCnpj': {
                        'Cnpj' if len(req.get('conh_filial_cnpjcpf', '')) > 11 else
                        'Cpf': req.get('conh_filial_cnpjcpf', '')
                    },
                    'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
                }
            }, {
                'attr': {
                    'xmlns': 'http://www.abrasf.org.br/nfse.xsd'
                }
            }
        )
    }

    return envelop('CONSULTARNFSEPORRPS', 'Consultarnfseporrpsrequest', dict_to_xml(xml)), ''


def request_coplan_cancelamento(cod_ibge, req, assinatura):
    xml = {
        'CancelarNfseEnvio': (
            {
                'Pedido': {
                    'InfPedidoCancelamento': (
                        {
                            'IdentificacaoNfse': {
                                'Numero': req.get('conh_numeronfse', ''),
                                'CpfCnpj': {
                                    'Cnpj' if len(req.get('conh_filial_cnpjcpf', '')) > 11 else
                                    'Cpf': req.get('conh_filial_cnpjcpf', '')
                                },
                                'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
                                'CodigoMunicipio': cod_ibge,
                            },
                            'CodigoCancelamento': 1
                        },
                        {
                            'attr': {
                                'Id': 'nfse' + req.get('conh_numeronfse', '')
                            }
                        }
                    )
                }
            },
            {
                'attr': {
                    'xmlns': 'http://www.abrasf.org.br/nfse.xsd'
                }
            }
        )
    }

    pedido_str = dict_to_xml(xml)
    pedido_str = assinatura.assinar(pedido_str, True, 'Id')
    pedido_str = pedido_str.replace('</Pedido>', '')
    pedido_str = pedido_str.replace('</Signature>', '</Signature></Pedido>')

    return envelop('CANCELARNFSE', 'Cancelarnfserequest', pedido_str), ''


def process_response_coplan(cod_emonitor_acao, ret):
    numero_nfe = ''
    result = {}

    if cod_emonitor_acao == nfse_spooler.ACAO_NFSE_RECEPCAO:
        response = deep_get(xmltodict.parse(ret.replace('.', '')),
                            'SOAP-ENV:Envelope.SOAP-ENV:Body.nfse_web_serviceRECEPCIONARLOTERPSResponse.Recepcionarloterpsresponse.outputXML')
        response = deep_get(xmltodict.parse(response), 'EnviarLoteRpsResposta')
        if response.get('Protocolo'):
            result = {
                'sucesso': True,
                'lote': response.get('NumeroLote', ''),
                'data_recebimento': response.get('DataRecebimento', ''),
                'protocolo': response.get('Protocolo', ''),
            }
        else:
            result = {
                'sucesso': False,
                'erros': process_response_list_element(
                    deep_get(xmltodict.parse(response), 'RecepcionarLoteRpsResposta.ListaMensagemRetornoLote')),
            }

    elif cod_emonitor_acao == nfse_spooler.ACAO_NFSE_CONSULTA_SITLOTE_RPS:
        response = deep_get(xmltodict.parse(ret.replace('.', '')),
                            'SOAP-ENV:Envelope.SOAP-ENV:Body.nfse_web_serviceCONSULTARLOTERPSResponse.Consultarloterpsresponse.outputXML')
        situacao = deep_get(xmltodict.parse(response), 'ConsultarLoteRpsResposta.Situacao')

        if situacao == '3':
            result = {
                'sucesso': False,
                'erros': process_response_list_element(
                    deep_get(xmltodict.parse(response), 'ConsultarLoteRpsResposta.ListaMensagemRetornoLote')),
            }

        elif situacao == '4':
            data: dict = deep_get(xmltodict.parse(response), 'ConsultarLoteRpsResposta.ListaNfse.CompNfse')
            data = data if type(data) is list else [data]
            result = {
                'sucesso': True,
                'situacao': situacao,
                'notas': []
            }
            for target in data:
                target: dict = deep_get(target, 'Nfse.InfNfse')
                result['notas'].append({
                    'status': deep_get(target, 'DeclaracaoPrestacaoServico.InfDeclaracaoPrestacaoServico.Rps.Status'),
                    'numero': target.get('Numero', ''),
                    'codigo_verificacao': target.get('CodigoVerificacao', ''),
                    'data_emissao': target.get('DataEmissao', ''),
                    'pdf': target.get('OutrasInformacoes', '')
                })
        else:
            result = {
                'sucesso': False,
                'erros': process_response_list_element(
                    deep_get(xmltodict.parse(response), 'ConsultarLoteRpsResposta.ListaMensagemRetorno')),
            }

    elif cod_emonitor_acao == nfse_spooler.ACAO_NFSE_CONSULTA_NFSE_POR_RPS:
        response = deep_get(xmltodict.parse(ret.replace('.', '')),
                            'SOAP-ENV:Envelope.SOAP-ENV:Body.nfse_web_serviceCONSULTARNFSEPORRPSResponse.Consultarnfseporrpsresponse.outputXML')

        data: dict = deep_get(xmltodict.parse(response), 'ConsultarNfseRpsResposta.CompNfse.Nfse.InfNfse')
        if data:
            result = {
                'sucesso': True,
                'status': deep_get(data, 'DeclaracaoPrestacaoServico.InfDeclaracaoPrestacaoServico.Rps.Status'),
                'numero': data.get('Numero', ''),
                'codigo_verificacao': data.get('CodigoVerificacao', ''),
                'data_emissao': data.get('DataEmissao', ''),
                'pdf': data.get('OutrasInformacoes', '')
            }
        else:
            result = {
                'sucesso': False,
                'erros': process_response_list_element(
                    deep_get(xmltodict.parse(response), 'ConsultarNfseRpsResposta.ListaMensagemRetorno')),
            }
    elif cod_emonitor_acao == nfse_spooler.ACAO_NFSE_CANCELAMENTO:
        response = deep_get(xmltodict.parse(ret.replace('.', '')),
                            'SOAP-ENV:Envelope.SOAP-ENV:Body.nfse_web_serviceCANCELARNFSEResponse.Cancelarnfseresponse.outputXML')
        message = deep_get(xmltodict.parse(response),
                           'CancelarNfseResposta.ListaMensagemRetorno.MensagemRetorno.Mensagem')

        if 'Cancelamento da NFS-e por erro na emissao nao pode ser feito por esse servico' in message:
            result = {
                'sucesso': False,
                'erros': [{
                    'codigo': '',
                    'mensagem': 'Não é possível realizar cancelamento via webservice',
                    'sugestao': 'Cancelar na prefeitura e depois emitir uma nova NFSE no sat',
                }]
            }
        else:
            result = {
                'sucesso': False,
                'erros': process_response_list_element(
                    deep_get(xmltodict.parse(response), 'CancelarNfseResposta.ListaMensagemRetorno')),
            }
    return '<json><![CDATA[' + json.dumps(result) + ']]></json>', '', numero_nfe


def process_response_list_element(data_: Tuple[dict, list]) -> list:
    if not data_:
        return []

    data_ = data_ if type(data_) is list else [data_]

    try:
        result_list = []
        msg: dict
        msg2: dict
        if deep_get(data_[0], 'MensagemRetorno.Codigo'):
            for msg in data_:
                msg = msg.get('MensagemRetorno', {})
                result_list.append({
                    'codigo': msg.get('Codigo', ''),
                    'mensagem': msg.get('Mensagem', ''),
                    'sugestao': msg.get('Correcao', '')
                })
        else:
            for msg in data_:
                msg = msg.get('MensagemRetorno', {})
                for msg2 in msg:
                    result_list.append({
                        'codigo': msg2.get('Codigo', ''),
                        'mensagem': msg2.get('Mensagem', ''),
                        'sugestao': msg2.get('Correcao', '')
                    })
        return result_list

    except (Exception,):
        return []
