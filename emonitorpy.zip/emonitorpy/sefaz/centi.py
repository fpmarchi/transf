import xml.dom.minidom as mdom
from geralsis import prop
from geralxml import *
from geraljson import *
from geral import *
import nfse_spooler


def processRequestCenti(codEMonitorAcao, codIBGE, reqJSON, assinatura):
    if codEMonitorAcao == nfse_spooler.ACAO_NFSE_RECEPCAO:
        return processRequestCentiRecepcao(codIBGE, reqJSON, assinatura)
    elif codEMonitorAcao == nfse_spooler.ACAO_NFSE_CONSULTA_NFSE:
        return processRequestCentiConsulta(codIBGE, reqJSON)
    elif codEMonitorAcao == nfse_spooler.ACAO_NFSE_CANCELAMENTO:
        return processRequestCentiCancelamento(codIBGE, reqJSON)
    else:
        return '', 'Acao ' + codEMonitorAcao + ' sem Implementacao'


def processRequestCentiRecepcao(codIBGE, reqJSON, assinatura):
    strXML, erros = processXmlRequestCentiRecepcao(codIBGE, reqJSON)
    if erros != '':
        return '', erros
    #
    try:
        strXML = '<?xml version="1.0" encoding="utf-8" ?>' + \
                  '<GerarNfseEnvio xmlns="http://www.centi.com.br/files/nfse.xsd">' + \
                  assinatura.assinar(strXML=strXML, retorna_string=True) + \
                  '</GerarNfseEnvio>'
    except Exception as e:
        print('Erro em processRequestCentiRecepcao')
        print(e)
        return '', 'Erro em processRequestCentiRecepcao ao assinar XML => ' + str(e)
    # PENDENTE: nao esta checando com este xsd, pois diz que nao existe Rps
    # try:
    #     pathSchema = prop['DirPrinc'].data + 'PMs/' + codIBGE + '/nfse.xsd'
    #     errosSchema = validateSchema(strXML, pathSchema)
    #     if errosSchema != '':
    #         return '', errosSchema
    # except Exception as e:
    #     print('Erro em processRequestCentiRecepcao')
    #     print(e)
    #     return '', 'Erro em processRequestCentiRecepcao ao validar XML com XSD => ' + str(e)
    #
    return strXML, ''


def processXmlRequestCentiRecepcao(codIBGE, reqJSON):
    try:
        strXML = '<Rps>'
        strXML += '<InfDeclaracaoPrestacaoServico>'
        ########################################
        strXML += '<Rps Id="' + getJSON(reqJSON, 'conh_rps') + '">'
        strXML += '<IdentificacaoRps>'
        strXML += createtag('Numero', getJSON(reqJSON, 'conh_rps'))
        strXML += createtag('Serie', getJSON(reqJSON, 'conh_serie'))
        strXML += createtag('Tipo', '1') # fixo RPS
        strXML += '</IdentificacaoRps>'
        #
        strXML += createtag('DataEmissao', getJSON(reqJSON, 'conh_datahoraemissao'))
        strXML += createtag('Status', '1') # fixo Normal
        strXML += '</Rps>'
        strXML += createtag('Competencia', getJSON(reqJSON, 'conh_datahoraemissao'))
        ########################################
        strXML += '<Servico>'
        strXML += '<Valores>'
        strXML += createtag('ValorServicos', getJSON(reqJSON, 'conh_freteempresa'))
        strXML += createtag('ValorDeducoes', '0')
        strXML += createtag('ValorPis', getJSON(reqJSON, 'conh_valorpis'))
        strXML += createtag('ValorCofins', getJSON(reqJSON, 'conh_valorcofins'))
        strXML += createtag('ValorInss', getJSON(reqJSON, 'conh_valorinssempresa'))
        strXML += createtag('ValorIr', getJSON(reqJSON, 'conh_valorirrf'))
        strXML += createtag('ValorCsll', getJSON(reqJSON, 'conh_valorcsll'))
        strXML += createtag('OutrasRetencoes', '0')
        strXML += createtag('ValorIss', getJSON(reqJSON, 'conh_valoriss'))
        strXML += createtag('Aliquota', getJSON(reqJSON, 'conh_taxaiss'))
        strXML += createtag('DescontoIncondicionado', '0')
        strXML += createtag('DescontoCondicionado', '0')
        strXML += '</Valores>'
        #
        if getJSON(reqJSON, 'conh_pagaiss') == '1':
            strXML += createtag('IssRetido', '2')
        else:
            strXML += createtag('IssRetido', '1')
        strXML += createtag('ResponsavelRetencao', '1') # fixo Tomador
        strXML += createtag('ItemListaServico', getJSON(reqJSON, 'conh_codservico'))
        strXML += createtag('CodigoCnae', getJSON(reqJSON, 'conh_cnae'))
        if getJSON(reqJSON, 'conh_codtributacao') != '':
            strXML += createtag('CodigoTributacaoMunicipio', getJSON(reqJSON, 'conh_codtributacao'))
        strXML += createtag('Discriminacao', getJSON(reqJSON, 'conh_descservico'))
        strXML += createtag('CodigoMunicipio', codIBGE)
        strXML += createtag('CodigoPais', '1058') # fixo Brasil
        strXML += createtag('ExigibilidadeISS', '1') # fixo Exigível
        strXML += createtag('MunicipioIncidencia', codIBGE) # mesmo da NFSe
        strXML += '</Servico>'
        ########################################
        strXML += '<Prestador>'
        strXML += '<CpfCnpj>'
        cnpjCpfFil = getJSON(reqJSON, 'conh_filial_cnpjcpf')
        if len(cnpjCpfFil) == 14:
            strXML += createtag('Cnpj', cnpjCpfFil)
        else:
            strXML += createtag('Cpf', cnpjCpfFil)
        strXML += '</CpfCnpj>'
        strXML += createtag('InscricaoMunicipal', getJSON(reqJSON, 'conh_filial_inscmun'))
        strXML += '</Prestador>'
        ########################################
        strXML += '<Tomador>'
        strXML += '<IdentificacaoTomador>'
        strXML += '<CpfCnpj>'
        cnpjCpfCl = getJSON(reqJSON, 'conh_cliente_cnpjcpf')
        if len(cnpjCpfCl) == 14:
            strXML += createtag('Cnpj', cnpjCpfCl)
        else:
            strXML += createtag('Cpf', cnpjCpfCl)
        strXML += '</CpfCnpj>'
        strXML += '</IdentificacaoTomador>'
        strXML += createtag('RazaoSocial', getJSON(reqJSON, 'conh_cliente_nome'))
        strXML += '<Endereco>'
        strXML += createtag('Endereco', getJSON(reqJSON, 'conh_cliente_endereco'))
        strXML += createtag('Numero', getJSON(reqJSON, 'conh_cliente_numero'))
        strXML += createtag('Bairro', getJSON(reqJSON, 'conh_cliente_bairro'))
        strXML += createtag('CodigoMunicipio', getJSON(reqJSON, 'conh_cliente_cidade_codibge'))
        strXML += createtag('Uf', getJSON(reqJSON, 'conh_cliente_cidade_uf'))
        codIBGEPais = getJSON(reqJSON, 'conh_cliente_pais_codibge')
        if codIBGEPais.startswith('0'):
            codIBGEPais = codIBGEPais[1:5]
        strXML += createtag('CodigoPais', codIBGEPais)
        strXML += createtag('Cep', getJSON(reqJSON, 'conh_cliente_cep'))
        strXML += '</Endereco>'
        strXML += '<Contato>'
        strXML += createtag('Telefone', getJSON(reqJSON, 'conh_cliente_fone'))
        strXML += createtag('Email', getJSON(reqJSON, 'conh_cliente_email'))
        strXML += '</Contato>'
        strXML += '</Tomador>'
        ########################################
        crt = getJSON(reqJSON, 'conh_filial_crt')
        if crt != '' and crt != '3':
            strXML += createtag('OptanteSimplesNacional', '1')
        else:
            strXML += createtag('OptanteSimplesNacional', '2')
        strXML += createtag('IncentivoFiscal', '2') # fixo Nao
        strXML += '</InfDeclaracaoPrestacaoServico>'
        ########################################
        # neste ponto sera inserida a assinatura
        ########################################
        strXML += '</Rps>'
        return strXML, ''
    except Exception as e:
        print('Erro em processXmlRequestCentiRecepcao')
        print(e)
        return '', 'Erro em processXmlRequestCentiRecepcao ao gerar XML => ' + str(e)


def processRequestCentiConsulta(codIBGE, reqJSON):
    try:
        strXML = '<ConsultarNfseRpsEnvio xmlns="http://www.centi.com.br/files/nfse.xsd">'
        ########################################
        strXML += '<IdentificacaoRps>'
        strXML += createtag('Numero', getJSON(reqJSON, 'conh_numeronfse'))
        strXML += createtag('Serie', getJSON(reqJSON, 'conh_serie'))
        strXML += createtag('Tipo', '1')
        strXML += '</IdentificacaoRps>'
        ########################################
        strXML += '<Prestador>'
        strXML += '<CpfCnpj>'
        cnpjCpfFil = getJSON(reqJSON, 'conh_filial_cnpjcpf')
        if len(cnpjCpfFil) == 14:
            strXML += createtag('Cnpj', cnpjCpfFil)
        else:
            strXML += createtag('Cpf', cnpjCpfFil)
        strXML += '</CpfCnpj>'
        strXML += createtag('InscricaoMunicipal', getJSON(reqJSON, 'conh_filial_inscmun'))
        strXML += '</Prestador>'
        ########################################
        strXML += '</ConsultarNfseRpsEnvio>'
    except Exception as e:
        print('Erro em processRequestCentiConsulta')
        print(e)
        return '', 'Erro em processRequestCentiConsulta ao gerar XML => ' + str(e)
    #
    return strXML, ''


def processRequestCentiCancelamento(codIBGE, reqJSON):
    try:
        strXML = '<CancelarNfseEnvio xmlns="http://www.centi.com.br/files/nfse.xsd">'
        ########################################
        strXML += '<Pedido>'
        strXML += '<InfPedidoCancelamento>'
        ########################################
        strXML += '<IdentificacaoNfse>'
        strXML += createtag('Id', getJSON(reqJSON, 'conh_nreclote'))
        strXML += createtag('Numero', getJSON(reqJSON, 'conh_numeronfse'))
        strXML += '<CpfCnpj>'
        cnpjCpfFil = getJSON(reqJSON, 'conh_filial_cnpjcpf')
        if len(cnpjCpfFil) == 14:
            strXML += createtag('Cnpj', cnpjCpfFil)
        else:
            strXML += createtag('Cpf', cnpjCpfFil)
        strXML += '</CpfCnpj>'
        strXML += createtag('InscricaoMunicipal', getJSON(reqJSON, 'conh_filial_inscmun'))
        strXML += createtag('CodigoMunicipio', codIBGE)
        strXML += createtag('CodigoVerificacao', getJSON(reqJSON, 'conh_nprot'))
        strXML += createtag('DescricaoCancelamento', getJSON(reqJSON, 'conh_obscanc')) # obrigar minimo de 15 caracteres no SOR
        strXML += '</IdentificacaoNfse>'
        ########################################
        strXML += '<CodigoCancelamento>6</CodigoCancelamento>' # 1 - Rasura  2 - Erro preenchimento  3 - Fim do prazo de validade  4 - Fora de sequência numérica e cronológica  5 - Desacordo comercial  6 - Outros
        strXML += '</InfPedidoCancelamento>'
        strXML += '</Pedido>'
        ########################################
        strXML += '</CancelarNfseEnvio>'
    except Exception as e:
        print('Erro em processRequestCentiCancelamento')
        print(e)
        return '', 'Erro em processRequestCentiCancelamento ao gerar XML => ' + str(e)
    #
    return strXML, ''


def processResponseCenti(codEMonitorAcao, codIBGE, ret):
    document = mdom.parseString(ret)
    try:
        tagret = document.getElementsByTagName('ListaNfse')[0]
        tagcompnfse = tagret.getElementsByTagName('CompNfse')[0]
        tagnfse = tagret.getElementsByTagName('Nfse')[0]
        taginfnfse = tagret.getElementsByTagName('InfNfse')[0]
        resp = ''
        numeroNFSe = ''
        for node in taginfnfse.childNodes:
            if node.nodeType == node.ELEMENT_NODE:
                campo = node.localName
                valor = getText(node.childNodes)
                if campo == 'Numero':
                    numeroNFSe = valor
                    resp = resp + createtag('numeroNFSe',valor)
                elif campo == 'IdentificacaoRps':
                    resp = resp + createtag('nRecLote',valor)
                elif campo == 'CodigoVerificacao':
                    resp = resp + createtag('nProt',valor)
                elif campo == 'DataEmissao':
                    resp = resp + createtag('dataHoraRecLote',valor)
                elif campo == 'OutrasInformacoes':
                    resp = resp + createtag('msgRet',valor)
        return resp, '', numeroNFSe
    except Exception as e:
        tagret = document.getElementsByTagName('ListaMensagemRetorno')[0]
        tagmsgs = tagret.getElementsByTagName('MensagemRetorno')
        msgRet = ''
        for tag in tagmsgs:
            msg = getText(tag.childNodes[0].childNodes)
            msgRet = msgRet + msg + ' '
        return '', msgRet, ''

