from typing import Tuple

import nfse_spooler
from ActionProcessor import handle_exception_factory

from geralxml import *
from geralxml import dict_to_xml


def process_request_agili(cod_acao_emonitor: int, cod_ibge: int,
                          req: dict, assinatura: AssinaturaA1) -> Tuple[str, str]:
    if cod_acao_emonitor == nfse_spooler.ACAO_NFSE_RECEPCAO:
        xml, erro = request_agili_criar_nfse(req, cod_ibge, assinatura)
    elif cod_acao_emonitor == nfse_spooler.ACAO_NFSE_CANCELAMENTO:
        xml, erro = request_agili_cancelar_nfse(req, cod_ibge, assinatura)
    elif cod_acao_emonitor == nfse_spooler.ACAO_NFSE_CONSULTA_NFSE:
        xml, erro = request_agili_consultar_nfse(req, cod_ibge, assinatura)
    else:
        return '', 'Acao ' + str(cod_acao_emonitor) + ' sem Implementação'

    return xml, erro


@handle_exception_factory()
def request_agili_criar_nfse(req: dict, cod_ibge: int, assinatura):
    nfse: dict = {
        'GerarNfseEnvio': ({
           'UnidadeGestora': '11050325000103',
           'DeclaracaoPrestacaoServico': {
               'IdentificacaoPrestador': {
                   'ChaveDigital': 'd473002676607ef092173bc6154bbd06',
                   'CpfCnpj': {
                       'Cnpj' if len('35798345000117') > 11 else
                       'Cpf': '35798345000117',
                   },
                   'InscricaoMunicipal': '15258',
               },
               'Rps': {
                   'IdentificacaoRps': {
                       'Numero': '00001',
                       'Serie': 'A',
                        'Tipo': -2,
                        'Descricao': 'RPS',
                   },
                   'DataEmissao': '2022-04-11',
               },
               'DadosTomador': {
                   'IdentificacaoTomador': {
                       'CpfCnpj': {
                           'Cnpj' if len('61156501009293') > 11 else
                           'Cpf': '61156501009293',
                       },
                       'InscricaoMunicipal': '',
                       },

                       'RazaoSocial': 'COFCO INTERNATIONAL BRASIL SA',
                       'LocalEndereco': 1,
                       'Endereco': {
                           'TipoLogradouro': 'Rua',
                           'Logradouro': req.get('conh_cliente_endereco', ''),
                           'Numero': req.get('conh_cliente_numero', ''),
                           'Bairro': req.get('conh_cliente_bairro', ''),
                           'Municipio': {
                               'CodigoMunicipioIBGE': '5105580',
                               'Descricao': 'MARCELANDIA',
                               'Uf': 'MT'
                           },
                           'Pais': {
                               'CodigoPaisBacen': 1058,
                               'Descricao': 'BRAS'
                           },
                           'Cep': '78535000'
                       },
                       'Contato': {
                           'Telefone': req.get('conh_cliente_fone', ''),
                           'Email': req.get('conh_cliente_email', ''),
                       },
                        'InscricaoEstadual': '132392496'
                   },

                  # 'RegimeEspecialTributacao': {
                   #    'Codigo': -2 #precisa verificar
                   #},
                   'OptanteSimplesNacional': 0,
                   'OptanteMEISimei': 1,
                   'ISSQNRetido': 1 if req.get('conh_pagaiss') == '2' else 2,
                    'CodigoAtividadeEconomica': '16.02',
                   'ExigibilidadeISSQN': {
                       'Codigo': -1, #precisa verificar
                       'Descricao': 'CLIE',
                   },
                    'MunicipioIncidencia': {
                        'CodigoMunicipioIBGE': 5105580,  # precisa verificar
                        'Descricao': 'SORRISO',
                        'Uf': 'MT'
                    },
                   'ValorServicos': req.get('conh_freteempresa', ''),
                'ValorDescontos': 0.00,
                'ValorPis': 0.00,
                'ValorCofins': 0.00,
                'ValorIrrf': 0.00,
                'ValorCsll': 0.00,
                'ValorOutrasRetencoes': 0,
                'ValorBaseCalculoISSQN': 2170,
                'ValorISSQNRecolher': 2170,
                'ValorLiquido': 2104.90,
                'Observacao': 'Produto: FERT. 13.33.00+15% S MES, Nota Fiscal: 220888, Valor Produto: 73.989,87, Peso: 31.000,00, Mo',
                   'ListaServico': (
                       [
                           {'Discriminacao': req.get('conh_descservico', ''),
                            'CodigoCnae': '4930202',
                            'ItemLei116': 16.02,
                            'Quantidade': '2',
                            'ValorServico': req.get('conh_freteempresa', '')},
                           # {'Discriminacao': req.get('conh_descservico', ''),
                           #  'Quantidade': '2',
                           #  'ValorServico': req.get('conh_freteempresa', '')},
                           # {'Discriminacao': req.get('conh_descservico', ''),
                           #  'Quantidade': '2',
                           #  'ValorServico': req.get('conh_freteempresa', '')}
                       ],
                       {
                           'list_item': 'DadosServico'
                       }
                   ),

                   'Versao': '1.00',
               }
           },
           {
               'attr': {
                   'xmlns': 'http://www.agili.com.br/nfse_v_1.00.xsd',
               }
           },
        )

    }
    return dict_to_xml(nfse, indent=True), ''


@handle_exception_factory()
def request_agili_consultar_nfse(req: dict, cod_ibge: int, assinatura):
    nfse: dict = {
        'ConsultarNfseFaixaEnvio': ({
            'UnidadeGestora': '03239076000162',
            'IdentificacaoPrestador': {
                'ChaveDigital': 'd473002676607ef092173bc6154bbd06',
                'CpfCnpj': {
                    'Cnpj' if len(req.get('conh_filial_cnpjcpf', '')) > 11 else
                    'Cpf': req.get('conh_filial_cnpjcpf', '')
                },
                'InscricaoMunicipal': 'incrilçcao muniocipal',
            },
            'NumeroNfseInicial': 0,
            'NumeroNfseFinal': 1,
            'Versao': '1.00'
        },
        {
            'attr': {
                'xmlns': 'http://www.agili.com.br/nfse_v_1.00.xsd',
            }
        },
        )
    }

    return dict_to_xml(nfse, indent=True), ''


@handle_exception_factory()
def request_agili_cancelar_nfse(req: dict, cod_ibge: int, assinatura):
    nfse: dict = {
        'CancelarNfseEnvio': ({
            'UnidadeGestora': '03239076000162',
            'PedidoCancelamento': {
                'IdentificacaoNfse': {
                    'Numero': int(req.get('conh_numeronfse', '')),
                    'IdentificacaoPrestador': {
                        'ChaveDigital': 'd473002676607ef092173bc6154bbd06',
                        'CpfCnpj': {
                            'Cnpj' if len('35798345000117') > 11 else
                            'Cpf': '35798345000117'
                        },
                        'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
                    },
                },
                'CodigoCancelamento': 1,
                'JustificativaCancelamento': req.get('conh_obscanc', ''),
                'Versao': '1.00'
            },

        },
            {
                'attr': {
                    'xmlns': 'http://www.agili.com.br/nfse_v_1.00.xsd',
                }
            },
        )
    }

    return dict_to_xml(nfse, indent=True, prolog=True), ''


# 'ListaServico': (
#     [
#         {'Discriminacao': req.get('conh_descservico', ''),
#          'Quantidade': '2',
#          'ValorServico': req.get('conh_freteempresa', '')}
#     ],
#     {
#         'list_item': 'DadosServico'
#     }
# ),

# 'DadosServico': ([
#                      {'Discriminacao': req.get('conh_descservico', ''),
#                       'Quantidade': '2',
#                       'ValorServico': req.get('conh_freteempresa', '')},
#
#                      {'Discriminacao': req.get('conh_descservico', ''),
#                       'Quantidade': '2',
#                       'ValorServico': req.get('conh_freteempresa', '')},
#                      {'Discriminacao': req.get('conh_descservico', ''),
#                       'Quantidade': '2',
#                       'ValorServico': req.get('conh_freteempresa', '')},
#                  ],
#                  {
#                      'list': 'a'
#                  }
#
# ),