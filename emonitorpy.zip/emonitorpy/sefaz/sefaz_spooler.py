import requests
#import certifi_icpbr
import urllib3
from threading import Thread
from time import sleep
from metadata import *
from geral import pfx_to_pem, datetimeactualtostr, fileexists, padlzero
from geralsis import *
import geralxml
from dao import *
from nfe_spooler import *
from cte_spooler import *
from mdfe_spooler import *
from nfse_spooler import *

EMONITORSPOOL_PRESEQUENCIA = 0
EMONITORSPOOL_PENDENTE = 1
EMONITORSPOOL_LIDO = 2
EMONITORSPOOL_EMPROCESSAMENTO = 3
EMONITORSPOOL_PROCESSADO = 4
#EMONITORSPOOL_CANCELADO = 5
EMONITORSPOOL_ERROPROCESSAMENTO = 6

PRODUCAO = '1'
HOMOLOGACAO = '2'

ACAO_STATUSSERVICO = 900
ACAO_REGERARXMLASSCTE = 901
ACAO_REGERARXMLASSNFE = 902
ACAO_REGERARXMLASSMDFE = 903
ACAO_ASSINARXML = 911
ACAO_CHECARDATAEXPCERT = 912

NFE_CODUFDIST = 'AN'
NFE_NUMUFDIST = 90
NFE_VERSAODIST = '1.00'
CTE_CODUFDIST = 'AN'
CTE_NUMUFDIST = 90
CTE_VERSAODIST = '1.00'
MDFE_CODUFDIST = 'SV'
MDFE_NUMUFDIST = 91
MDFE_VERSAODIST = '1.00'

engineSefazFB = None
engineSefazPG = None

def isAcaoNFe(codEMonitorAcao):
    return codEMonitorAcao >= 1 and codEMonitorAcao <= 100


def isAcaoCTe(codEMonitorAcao):
    return codEMonitorAcao >= 101 and codEMonitorAcao <= 200


def isAcaoMDFe(codEMonitorAcao):
    return codEMonitorAcao >= 201 and codEMonitorAcao <= 300


def isAcaoNFSe(codEMonitorAcao):
    return codEMonitorAcao >= 501 and codEMonitorAcao <= 600


def callSefaz(pfx_path, pfx_password, codInstalacao, codEmpresa, codEMonitorAcao, codUF, numUF, tpAmb, versao, req):
    resp = ''
    erros = ''
    if codEMonitorAcao == ACAO_STATUSSERVICO:
        resp = '<msgRet>EMonitor em operação em ' + datetimeactualtostr() + '</msgRet>'
        return resp, erros, '', ''
    global engineSefazPG
    if engineSefazPG is None:
        engineSefazPG = getEnginePG(prop,'EMonitor')
    with getConnPG(engineSefazPG) as conn:
        #
        if isAcaoNFSe(codEMonitorAcao):
            return callNFSe(conn, pfx_path, pfx_password, codInstalacao, codEmpresa, codEMonitorAcao, numUF, tpAmb, versao, req) # numUF = codIBGE
        #
        rsEMonitorUFAcao = getEMonitorUFAcaoByFKs(conn, codEMonitorAcao, codUF, tpAmb, versao)
        if rsEMonitorUFAcao is None:
            erros = '########### URL NAO CADASTRADA PARA A UF=' + codUF + ', ACAO=' + str(codEMonitorAcao) + ', TPAMB=' + tpAmb + ', VERSAO=' + versao + '! ATUALIZE O BANCO DE DADOS DO EMONITOR!'
            return resp, erros, '', ''
        #
        if isAcaoMDFe(codEMonitorAcao):
            return callMDFe(pfx_path, pfx_password, codInstalacao, codEmpresa, codEMonitorAcao, codUF, numUF, req, rsEMonitorUFAcao)
        #
        return resp, erros, '', ''


def processRequestSefaz(pfx_path, pfx_password, codEMonitorAcao, codUF, numUF, request, url, action):
    with pfx_to_pem(pfx_path, pfx_password) as cert:
        try:
            #printdh('Processando acao ' + str(codEMonitorAcao) + ' para a UF ' + codUF)
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            #response = requests.post(url, cert=cert, data=request, headers={'Content-type': 'application/soap+xml; charset=utf-8','SOAPAction': action}, verify=certifi_icpbr.where())
            response = requests.post(url, cert=cert, data=request, headers={'Content-type': 'application/soap+xml; charset=utf-8','SOAPAction': action}, verify=False)
            retcode = response.status_code  # https://pt.wikipedia.org/wiki/Lista_de_códigos_de_estado_HTTP
            if retcode == 401:
                return '', 'ACESSO NEGADO (PROVAVELMENTE DEVIDO A CREDENCIAIS INVÁLIDAS) À SEFAZ (401)'
            elif retcode == 403:
                return '', 'ACESSO NEGADO (PROVAVELMENTE DEVIDO A ERRO DE CERTIFICADO) À SEFAZ (403)'
            elif retcode == 404:
                return '', 'INFORMAÇÃO NÃO ENCONTRADA NO ENDEREÇO ' + url + ' (404)'
            elif retcode == 500:
                return '', 'ERRO INTERNO DO SERVIDOR DA SEFAZ (500)'
            else:
                ret = response.content.decode('utf-8')
                # if codEMonitorAcao == 48:
                #     print('req = ' + str(request))
                #     print('resp = ' + str(ret))
                if ret[0] == '<': # XML normal de resposta
                    return ret, ''
                else:
                    return '', ret # alguma string de erro
        except Exception as e:
            print('Erro em processRequestSefaz')
            print(e)
            return '', 'ERRO NA CHAMADA DA SEFAZ PARA A UF=' + codUF + ', ACAO=' + str(codEMonitorAcao)


def getDadosDist(tipo):
    if tipo == 1:
        return 'NFe', ACAO_NFE_CONSULTANFDIST, ACAO_NFE_CONSULTANFDISTAUTO, NFE_CODUFDIST, NFE_NUMUFDIST, NFE_VERSAODIST, 'NFeDistInstalacoes', 'nfe'
    elif tipo == 2:
        return 'CTe', ACAO_CTE_CONSULTACTDIST, ACAO_CTE_CONSULTACTDISTAUTO, CTE_CODUFDIST, CTE_NUMUFDIST, CTE_VERSAODIST, 'CTeDistInstalacoes', 'cte'
    else:
        return 'MDFe', ACAO_MDFE_CONSULTAMDFDIST, ACAO_MDFE_CONSULTAMDFDISTAUTO, MDFE_CODUFDIST, MDFE_NUMUFDIST, MDFE_VERSAODIST, 'MDFeDistInstalacoes', 'mdfe'


def resetDist(instalacao, listDist):
    for itemDist in listDist:
        if itemDist[0] == instalacao:
            itemDist[1] = False
            return


def hasActiveDist(listDist):
    for itemDist in listDist:
        if itemDist[1]:
            return itemDist[0]
    return ''


def isDuplDist(instalacao, listDist):
    for itemDist in listDist:
        if itemDist[0] == instalacao:
            return True
    return False


class ThreadDist(Thread):

    #def __init__(self, engineSefazFB, engineSefazPG, tipo, sleepTime, instalacoes):
    def __init__(self, engineSefazPG, tipo, sleepTime, instalacoes):
        Thread.__init__(self)
        self.engineSefazPG = engineSefazPG
        self.tipo = tipo
        self.sleepTime = int(sleepTime) / 1000 # emj está em milisegundos e empy em segundos
        self.instalacoes = instalacoes

    def run(self):
        useProp = usePropDist()
        isFB = isTipoBDDistFB()
        connPG = getConnPG(self.engineSefazPG)
        prefixMsg, acaoConsultaDist, acaoConsultaDistAuto, codUFDist, numUFDist, versaoDist, propDistInstalacoes, prefixCampo = getDadosDist(self.tipo)
        rsEMonitorUFAcao = getEMonitorUFAcaoByFKs(connPG, acaoConsultaDist, codUFDist, PRODUCAO, versaoDist)
        while True:
            listDist = [] # cache de threads em execucao
            listInstalacoes = getInstalacoesDist(self.instalacoes)
            ctInstalacoes = 1
            for instalacao in listInstalacoes:
                if isDuplDist(instalacao, listDist):
                    printsefazdist('ERRO: duplicacao da instalacao ' + instalacao + ' no arquivo de properties',self.tipo) # erro de configuracao do arquivo de properties
                    continue
                inst,emp,cnpjcpf,numUF = getCamposDist(instalacao)
                if inst == '':
                    printsefazdist(emp,self.tipo) # erro de configuracao do arquivo de properties
                    continue
                printsefazdist('Processando ' + str(ctInstalacoes) + '. ' + instalacao,self.tipo)
                ctInstalacoes += 1
                pfx_path, pfx_password = getCertProperties(connPG, inst, emp, self.tipo)
                if pfx_path == '' or pfx_password == '':
                    printsefazdist('ERRO: nao foram encontrados os dados do certificado ' + instalacao + ' (caminho e/ou senha) no arquivo de properties',self.tipo) # nao precisa pq getCertProperties ja da msg
                    continue
                if not fileexists(pfx_path):
                    printsefazdist('ERRO: arquivo do certificado (' + pfx_path + ') nao existe',self.tipo)
                    continue
                codEMonitorSpool,nSeqEvento = getUltNSeqEvento(False, connPG, inst, emp, cnpjcpf, numUF, acaoConsultaDistAuto)
                if nSeqEvento > 0 and not isMaxNSeqEvento(nSeqEvento):
                    printsefazdist('ERRO: ocorreu um erro em processamento anterior da ' + instalacao + ' com contador de execucoes = ' + str(nSeqEvento+1) + ', sendo ignorada esta execucao',self.tipo)
                    # setUltNSeqEvento(connFB, codEMonitorSpool, nSeqEvento+1)
                    setUltNSeqEvento(connPG, codEMonitorSpool, nSeqEvento+1)
                    continue
                ultNSU = getUltNSUDist(connPG, inst, emp, cnpjcpf, numUF, acaoConsultaDistAuto)
                if ultNSU == 'CONSUMO INDEVIDO':
                    printsefazdist('ERRO: ocorreram varios bloqueios por consumo indevido de NFe da ' + instalacao + ', sendo ignorada esta execucao', self.tipo)
                    continue
                printsefazdist('Disparando Thread ' + str(ctInstalacoes) + '. ' + instalacao + ' => ultNSU = ' + ultNSU, self.tipo)
                #ThreadCallDist(isFB, self.engineSefazFB, self.engineSefazPG, self.tipo, acaoConsultaDistAuto, codUFDist, numUFDist, instalacao, listDist, pfx_path, pfx_password, inst, emp, cnpjcpf, numUF, ultNSU, rsEMonitorUFAcao).start()
                ThreadCallDist(isFB, self.engineSefazPG, self.tipo, acaoConsultaDistAuto, codUFDist, numUFDist, instalacao, listDist, pfx_path, pfx_password, inst, emp, cnpjcpf, numUF, ultNSU, rsEMonitorUFAcao).start()
                listDist.append([instalacao,True])
                sleep(0.2) # aguardar 0.2s, por seguranca, antes de disparar proxima para nao causar nenhum conflito de recursos
                # ativacao de 300 threads de instalacoes por minuto => 1500 em 5 min
            connPG.close()
            TIMEOUTWAIT = 120 # 2 minutos
            instActive = hasActiveDist(listDist)
            ctWait = 1
            maxWait = 30 # esperar ate este limite as outras threads => ate 60 minutos esperando => isso é necessario para nao ficar eternamente esperando processar empresas que recem comecaram
            while instActive != '' and ctWait <= maxWait:
                printsefazdist('Dormir Principal ' + str(ctWait) + 'x aguardando termino das threads (ex. ' + instActive + ') ' + str(TIMEOUTWAIT / 60) + ' min.', self.tipo)
                sleep(TIMEOUTWAIT) # enqto tiver alguma thread ativa nao pode recomecar
                instActive = hasActiveDist(listDist)
                ctWait += 1
            printsefazdist('Dormir Principal apos termino das threads ' + str(self.sleepTime / 60) + ' min.',self.tipo)
            sleep(self.sleepTime)
            # connFB = getConnFB(self.engineSefazFB)
            connPG = getConnPG(self.engineSefazPG)
            if useProp:
                prop = loadProperties() # recarregar as properties pois podem ter sido adicionadas novas instalacoes
                self.instalacoes = prop[propDistInstalacoes].data
            else:
                self.instalacoes = dao.getDistInstalacoes(connPG,prefixCampo)


class ThreadCallDist(Thread):

    #def __init__(self, isFB, engineSefazFB, engineSefazPG, tipo, acaoConsultaDistAuto, codUFDist, numUFDist, instalacao, listDist, pfx_path, pfx_password, inst, emp, cnpjcpf, numUF, ultNSU, rsEMonitorUFAcao):
    def __init__(self, isFB, engineSefazPG, tipo, acaoConsultaDistAuto, codUFDist, numUFDist, instalacao, listDist, pfx_path, pfx_password, inst, emp, cnpjcpf, numUF, ultNSU, rsEMonitorUFAcao):
        Thread.__init__(self)
        self.isFB = isFB
        #self.engineSefazFB = engineSefazFB
        self.engineSefazPG = engineSefazPG
        self.tipo = tipo
        self.acaoConsultaDistAuto = acaoConsultaDistAuto
        self.codUFDist = codUFDist
        self.numUFDist = numUFDist
        self.instalacao = instalacao
        self.listDist = listDist
        self.pfx_path = pfx_path
        self.pfx_password = pfx_password
        self.inst = inst
        self.emp = emp
        self.cnpjCpfInstalacao = cnpjcpf
        self.numUFInstalacao = numUF
        self.ultNSUInstalacao = ultNSU
        self.rsEMonitorUFAcao = rsEMonitorUFAcao

    def run(self):
        try:
            ctCall = 1
            maxCall = 9 # ANTES ERA 24... ALTERADO DEVIDO A SERPRO LIMITAR A 9 ... tentar ate estas chamadas e depois desistir => 10s x 24 => pouco mais de 4 minutos tentando... é mais pq tem o tempo da comunicacao com a SEFAZ
            ultNSU = ''
            maxNSU = '999999999999999'
            while ultNSU != maxNSU and ctCall <= maxCall: # ficar no loop ate que o ultNSU chegue no maxNSU, ou seja, nao ha mais nada para processar
                req = self.cnpjCpfInstalacao + '_' + self.numUFInstalacao + '_' + self.ultNSUInstalacao
                if self.tipo == 1:
                    request, ret, resp, erros = callNFe(self.pfx_path, self.pfx_password, self.acaoConsultaDistAuto, self.codUFDist, self.numUFDist, req, self.rsEMonitorUFAcao, None)
                elif self.tipo == 2:
                    request, ret, resp, erros = callCTe(self.pfx_path, self.pfx_password, self.acaoConsultaDistAuto, self.codUFDist, self.numUFDist, req, self.rsEMonitorUFAcao, None)
                else:
                    request, ret, resp, erros = callMDFe(self.pfx_path, self.pfx_password, self.inst, self.emp, self.acaoConsultaDistAuto, self.codUFDist, self.numUFInstalacao, req, self.rsEMonitorUFAcao) # usa numNF da Instalacao
                if erros is None or erros == '':
                    try:
                        if self.tipo == 1:
                            root = tree.fromstring(ret)
                            if len(root) > 1:
                                body = root[1][0] # agora tem soap:Header como root[0]
                            else:
                                body = root[0][0] # sem soap:Header como root[0]
                        elif self.tipo == 2:
                            body = tree.fromstring(ret)[0][0][0]
                        else:
                            body = tree.fromstring(ret)[1][0][0]
                        strBody = '<?xml version="1.0" encoding="UTF-8"?>' + geralxml.toString(body)
                    except tree.ParseError:
                        erros = 'Erro ao tentar analisar arvore do campo ARQXMLRESP'
                        strBody = '<?xml version="1.0" encoding="UTF-8"?>' + '<erro>' + self.inst + '_' + self.emp + '_' + req + ' - ' + erros + '</erro>'
                else:
                    strBody = '<?xml version="1.0" encoding="UTF-8"?>' + '<erro>' + self.inst + '_' + self.emp + '_' + req + ' - ' + erros + '</erro>'
                # gravar resposta no spool
                if erros != '':
                    # insEMonitorSpoolDist(EMONITORSPOOL_ERROPROCESSAMENTO,
                    #                      True, connFB, self.inst, self.emp, self.acaoConsultaDistAuto, self.cnpjCpfInstalacao,
                    #                      self.numUFInstalacao,
                    #                      self.codUFDist, self.numUFDist, PRODUCAO, '', erros, request,
                    #                      strBody, strBody, EMONITORSPOOL_ERROPROCESSAMENTO)
                    with getConnPG(self.engineSefazPG) as connPG:
                        insEMonitorSpoolDist(EMONITORSPOOL_ERROPROCESSAMENTO,
                                         False, connPG, self.inst, self.emp, self.acaoConsultaDistAuto, self.cnpjCpfInstalacao,
                                         self.numUFInstalacao,
                                         self.codUFDist, self.numUFDist, PRODUCAO, '', erros, request,
                                         strBody, strBody, EMONITORSPOOL_ERROPROCESSAMENTO)
                    printsefazdist('ERRO THREAD: ' + self.inst + '_' + self.emp + '_' + req + ' - ' + erros,self.tipo)
                    resetDist(self.instalacao, self.listDist)
                    return
                else:
                    if self.tipo == 1:
                        listCampos = list(body[0][0])
                    elif self.tipo == 2:
                        listCampos = list(body[0])
                    else:
                        listCampos = list(body)
                    loteDistDFeInt = ''
                    cStat = ''
                    xMotivo = ''
                    for campo in listCampos:
                        tag = campo.tag
                        if tag.endswith('cStat'):
                            cStat = campo.text
                        elif tag.endswith('xMotivo'):
                            xMotivo = campo.text
                        elif tag.endswith('ultNSU'):
                            ultNSU = campo.text
                        elif tag.endswith('maxNSU'):
                            maxNSU = campo.text
                        elif tag.endswith('loteDistDFeInt'):
                            loteDistDFeInt = campo
                    if self.tipo == 1 and cStat == '656' and 'Consumo Indevido' in xMotivo: # NFe Consumo Excessivo
                        with getConnPG(self.engineSefazPG) as connPG:
                            insEMonitorSpoolDist(EMONITORSPOOL_ERROPROCESSAMENTO,
                                             False, connPG, self.inst, self.emp, self.acaoConsultaDistAuto,
                                             self.cnpjCpfInstalacao,
                                             self.numUFInstalacao,
                                             self.codUFDist, self.numUFDist, PRODUCAO, ultNSU,
                                             'Consumo Indevido de NF-e', request,
                                             strBody, strBody, EMONITORSPOOL_ERROPROCESSAMENTO)
                        printsefazdist('LOTE THREAD ' + str(ctCall) + 'x: ' + self.inst + '_' + self.emp + '_' + req + ' - ult=' + ultNSU + ' - max=' + maxNSU + ' - Consumo Indevido de NF-e - dormir 50 minutos', self.tipo)
                        sleep(1800)  # neste caso, esperar 30 minutos na thread antes de voltar para a thread principal
                        resetDist(self.instalacao, self.listDist)
                        return
                    if self.tipo == 3 and cStat == '730': # MDFe Consumo Excessivo
                        if 'MenorNSUConsulta: ' in xMotivo:
                            index = xMotivo.index('MenorNSUConsulta: ') + len('MenorNSUConsulta: ')
                            ultNSU = xMotivo[index:index+15]
                            self.ultNSUInstalacao = ultNSU
                            printsefazdist('LOTE THREAD ' + str(ctCall) + 'x ALTERANDO ULTNSU (MUITO ANTIGO): ' + self.inst + '_' + self.emp + '_' + req + ' - ult=' + ultNSU + ' - max=' + maxNSU,self.tipo)
                            ctCall += 1
                            continue
                        elif 'Sem MDF-e destinado' in xMotivo:
                            # insEMonitorSpoolDist(EMONITORSPOOL_ERROPROCESSAMENTO,
                            #                      True, connFB, self.inst, self.emp, self.acaoConsultaDistAuto, self.cnpjCpfInstalacao,
                            #                      self.numUFInstalacao,
                            #                      self.codUFDist, self.numUFDist, PRODUCAO, '', 'Sem MDFe-e destinado nos ultimos 6 meses', request,
                            #                      strBody, strBody, EMONITORSPOOL_ERROPROCESSAMENTO)
                            with getConnPG(self.engineSefazPG) as connPG:
                                insEMonitorSpoolDist(EMONITORSPOOL_ERROPROCESSAMENTO,
                                                 False, connPG, self.inst, self.emp, self.acaoConsultaDistAuto, self.cnpjCpfInstalacao,
                                                 self.numUFInstalacao,
                                                 self.codUFDist, self.numUFDist, PRODUCAO, '',
                                                 'Sem MDFe-e destinado nos ultimos 6 meses', request,
                                                 strBody, strBody, EMONITORSPOOL_ERROPROCESSAMENTO)
                            printsefazdist('LOTE THREAD ' + str(ctCall) + 'x: ' + self.inst + '_' + self.emp + '_' + req + ' - ult=' + ultNSU + ' - max=' + maxNSU + ' - Sem MDFe-e destinado nos ultimos 6 meses', self.tipo)
                            resetDist(self.instalacao, self.listDist)
                            return
                    if not loteDistDFeInt is None and loteDistDFeInt != '':
                        printsefazdist('LOTE THREAD ' + str(ctCall) + 'x: ' + self.inst + '_' + self.emp + '_' + req + ' - ult=' + ultNSU + ' - max=' + maxNSU + ' - ' + resp,self.tipo)
                        with getConnPG(self.engineSefazPG) as connPG:
                            insEMonitorSpoolDist(EMONITORSPOOL_ERROPROCESSAMENTO,
                                             False, connPG, self.inst, self.emp, self.acaoConsultaDistAuto, self.cnpjCpfInstalacao, self.numUFInstalacao,
                                             self.codUFDist, self.numUFDist, PRODUCAO, ultNSU, resp, request, strBody, strBody, EMONITORSPOOL_PROCESSADO)
                            if self.acaoConsultaDistAuto == ACAO_MDFE_CONSULTAMDFDISTAUTO:
                                insBiMdfeDist(False, connPG, strBody, -1)
                    else:
                        printsefazdist('SEM LOTE THREAD ' + str(ctCall) + 'x: ' + self.inst + '_' + self.emp + '_' + req + ' - ult=' + ultNSU + ' - max=' + maxNSU + ' - ' + resp,self.tipo)
                        with getConnPG(self.engineSefazPG) as connPG:
                            insEMonitorSpoolDist(EMONITORSPOOL_ERROPROCESSAMENTO,
                                             False, connPG, self.inst, self.emp, self.acaoConsultaDistAuto, self.cnpjCpfInstalacao, self.numUFInstalacao,
                                             self.codUFDist, self.numUFDist, PRODUCAO, ultNSU, resp, request, strBody, strBody, EMONITORSPOOL_ERROPROCESSAMENTO)
                    #if ultNSU != maxNSU and float(maxNSU) - float(ultNSU) > 5000: # permitir diferenca de no maximo 5000
                        #ultNSU = padlzero(str(int(float(maxNSU) - 5000)),15)
                    self.ultNSUInstalacao = ultNSU
                    sleep(10) # esperar um pouco antes de tentar novamente para evitar perigo de ser bloqueado pela SEFAZ
                ctCall += 1
            # apos sair do loop pois processou tudo
            printsefazdist('TERMINO THREAD: ' + self.inst + '_' + self.emp + '_' + req, self.tipo)
            resetDist(self.instalacao, self.listDist)
        except Exception as e:
            print('Erro em ThreadCallDist.run - inst.:' + str(self.inst) + ' - emp.:' + str(self.emp) + ' - acao:' + str(self.acaoConsultaDistAuto))
            print(e)
            resetDist(self.instalacao, self.listDist)


def processBiMdfeDist(engine, request):
    try:
        # parametros passados na URL
        dataIni = request.args.get('di')
        dataFim = request.args.get('df')
        with getConnPG(engine) as conn:
            ret = dao.getBiMdfeDist(False, conn, dataIni, dataFim)
            if ret == '':
                return '<erro>true</erro><msgRet>NENHUM MANIFESTO ENCONTRADO</msgRet>'
            else:
                return '<erro>false</erro><msgRet>' + ret + '</msgRet>'
    except Exception as e:
        print('Erro em processBiMdfeDist')
        print(e)
        return '<erro>true</erro><msgRet>ERRO DE PROCESSAMENTO DE SQL COM BD</msgRet>'

