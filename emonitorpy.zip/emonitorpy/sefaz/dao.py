#-------------------------------------------------------------------------------------------
# gerar metadata do bd no em1:
# isql -u sysdba -p masterkey -ex -o emonitorfb.sql /sistemas/emonitor/bd/emonitor.fdb
# converter emonitorfb.sql para emonitorpg.sql
#-------------------------------------------------------------------------------------------
# instalar o pg no em1/em2 seguindo os passos do servss.sh na pasta /sistemas/emonitor/bdpg
#-------------------------------------------------------------------------------------------

from datetime import datetime
from sqlalchemy.sql import *
import xml.etree.ElementTree as tree
from geral import strtodate, strtodatetime, strtodatetime2, datetimetostr, dbdatetimeactualtostr, cut, strempty, getstrnotempty, formatstrnum
from xml.sax.saxutils import escape
import xmltodict
import gzip

from metadata import *
from formatdate import *
from geralxml import *
from geral import printdh, wsstrtoAAAAMMDD, datetostr, incdatetimeactual


def getEMonitorUFAcaoByFKs(conn, codEMonitorAcao, codUF, tpAmb, versao):
    sql = text('SELECT ufa.* '
               'FROM emonitorufacao ufa '
               'JOIN emonitoruf uf ON ufa.codemonitoruf = uf.codemonitoruf '
               'WHERE ufa.codemonitoracao = :codemonitoracao '
               'AND uf.coduf = :coduf '
               'AND ufa.tpamb = :tpamb '
               'AND ufa.versao = :versao')
    sql = sql.bindparams(codemonitoracao=codEMonitorAcao)
    sql = sql.bindparams(coduf=codUF)
    sql = sql.bindparams(tpamb=tpAmb)
    sql = sql.bindparams(versao=versao)
    #print(sql)
    rs = conn.execute(sql)
    return rs.fetchone()


def getEMonitorSpool(conn, codEMonitorSpool):
    sql = text('SELECT * '
               'FROM emonitorspool '
               'WHERE codemonitorspool = :codemonitorspool '
               )
    sql = sql.bindparams(codemonitorspool=codEMonitorSpool)
    #print(sql)
    return conn.execute(sql).fetchone()


def getCodEMonitorSpool(conn, codInstalacao, codEmpresa, codEMonitorAcao, dataIns):
    sql = text('SELECT codemonitorspool '
               'FROM emonitorspool '
               'WHERE codinstalacao = :codinstalacao '
               'AND codempresa = :codempresa '
               'AND codemonitoracao = :codemonitoracao '
               'AND datains = :datains'
               '')
    sql = sql.bindparams(codinstalacao=codInstalacao)
    sql = sql.bindparams(codempresa=codEmpresa)
    sql = sql.bindparams(codemonitoracao=codEMonitorAcao)
    sql = sql.bindparams(datains=dataIns)
    #print(sql)
    rs = conn.execute(sql)
    dados = rs.fetchone()
    if dados is None:
        return 0
    else:
        return int(dados['codemonitorspool'])


def getXmlsEMonitorSpool(conn, codInstalacao, codEmpresa, tipoDoc, dataIni, dataFim):
    try:
        # Define SQL conforme o tipo de documento solicitado
        if tipoDoc == "1":  # CTEs
            sql_tipo_doc = "AND CODEMONITORACAO IN (101, 121, 131, 143, 104, 124, 134, 103, 123, 133, 108, 128, 138, 148)"
        elif tipoDoc == "2":  # MDFEs
            sql_tipo_doc = "AND CODEMONITORACAO IN (201, 231, 233, 208, 238)"
        elif tipoDoc == "3":  # NFEs
            sql_tipo_doc = "AND CODEMONITORACAO IN (21, 31, 41, 24, 34, 44, 23, 33, 43, 28, 38, 48)"
        elif tipoDoc == "4":  # NFSEs
            sql_tipo_doc = "AND CODEMONITORACAO IN (501, 504, 503, 508)"
        else:  # Todos
            sql_tipo_doc = ""

        # Converte dd/mm/yyyy para mm/dd/yyyy

        sql = text('SELECT arqxmlass, codemonitorspool, chave '
                'FROM emonitorspool '
                'WHERE codinstalacao = :codInstalacao '
                'AND codempresa = :codEmpresa ' +
                'AND ((codemonitoracao IN (21,31,41,101,121,131,143,201,231,233,501) AND nprot IS NOT NULL) '
                'OR (codemonitoracao IN (24,34,44,104,124,134,504) AND nprotinut IS NOT NULL) '
                'OR (codemonitoracao IN (23,33,43,103,123,133,503) AND nprotcanc IS NOT NULL) '
                'OR (codemonitoracao IN (28,38,48,108,128,138,148,208,238,508) AND nprot IS NOT NULL)) '
                'AND status = \'4\' '
                'AND tpamb = \'1\' '
                'AND datains BETWEEN :dataIni AND :dataFim ' +
                sql_tipo_doc +
                'ORDER BY chave')
        #
        sql = sql.bindparams(codInstalacao=codInstalacao)
        sql = sql.bindparams(codEmpresa=codEmpresa)
        sql = sql.bindparams(dataIni=strtodatetime(dataIni + ' 00:00:00', '%d/%m/%Y %H:%M:%S'))
        sql = sql.bindparams(dataFim=strtodatetime(dataFim + ' 23:59:59', '%d/%m/%Y %H:%M:%S'))
        #
        response = conn.execute(sql).fetchall()
        return response
    except Exception as e:
        raise Exception(e)


# IMPORTANTE: METODO ABAIXO ATE O MOMENTO TESTADO APENAS COM FB E NAO COM PG, PARA EM1 E EM2
def insEMonitorSpool(isFB, conn, codInstalacao, codEmpresa, codEMonitorAcao, codUF, numUF, tpAmb, chave, nProt, versao, dataHoraEnvioLote, msgRet, arqXML, arqXMLAss, arqXMLResp, status):
    try:
        dh = datetime.now()
        if isFB:
            sql = emonitorspoolfb.insert()
            conn.execute(sql,
                     codinstalacao=codInstalacao,
                     codempresa=codEmpresa,
                     codemonitoracao=codEMonitorAcao,
                     coduf=codUF,
                     numuf=numUF,
                     tpamb=tpAmb,
                     datains=dh,
                     chave=chave,
                     nprot=nProt,
                     versao=versao,
                     datahoraenviolote=dataHoraEnvioLote,
                     datahorareclote=dh,  # como a principio a insercao sera o unico passo no BD, ja vai gravar igual datains
                     msgret=msgRet,
                     arqxml=arqXML.encode(), # NAO USAR ENCODE QUANDO MIGRAR DE FB PARA PG
                     arqxmlass=arqXMLAss.encode(), # NAO USAR ENCODE QUANDO MIGRAR DE FB PARA PG
                     arqxmlresp=arqXMLResp.encode(), # NAO USAR ENCODE QUANDO MIGRAR DE FB PARA PG
                     status=status  # como a principio a insercao sera o unico passo no BD, ja vai gravar 4=Sem erro ou 6=Com erro
                     # campos nao gravados por enqto: EMailRet,AnoInut,CNPJInut,ModeloNFInut,SerieNFInut,NumNFIniInut,NumNFFimInut,justInut,justCanc,tpEvento,nSeqEvento,xCorrecao
                     )
        else:
            sql = emonitorspoolpg.insert()
            conn.execute(sql,
                     codinstalacao=codInstalacao,
                     codempresa=codEmpresa,
                     codemonitoracao=codEMonitorAcao,
                     coduf=codUF,
                     numuf=numUF,
                     tpamb=tpAmb,
                     datains=dh,
                     chave=chave,
                     nprot=nProt,
                     versao=versao,
                     datahoraenviolote=dataHoraEnvioLote,
                     datahorareclote=dh,
                     # como a principio a insercao sera o unico passo no BD, ja vai gravar igual datains
                     msgret=msgRet,
                     arqxml=arqXML,
                     arqxmlass=arqXMLAss,
                     arqxmlresp=arqXMLResp,
                     status=status # como a principio a insercao sera o unico passo no BD, ja vai gravar 4=Sem erro ou 6=Com erro
                     # campos nao gravados por enqto: EMailRet,AnoInut,CNPJInut,ModeloNFInut,SerieNFInut,NumNFIniInut,NumNFFimInut,justInut,justCanc,tpEvento,nSeqEvento,xCorrecao
                     )
        return getCodEMonitorSpool(conn, codInstalacao, codEmpresa, codEMonitorAcao, dh)
    except Exception as e:
        print('Erro em sefaz.dao.insEMonitorSpool')
        print(e)
        return -1


def insEMonitorSpoolRelerArqProperties(conn, codInstalacao, codEmpresa):
    try:
        dh = datetime.now()
        sql = text('INSERT INTO emonitorspool(codinstalacao,codempresa,codemonitoracao,datains,status) ' +
                   'VALUES(:codinstalacao,:codempresa,:codemonitoracao,:datains,:status)')
        sql = sql.bindparams(codinstalacao=codInstalacao)
        sql = sql.bindparams(codempresa=codEmpresa)
        sql = sql.bindparams(codemonitoracao=910) # ACAO_RELERARQPROPERTIES
        sql = sql.bindparams(datains=dh)
        sql = sql.bindparams(status=1) # EMONITORSPOOL_PENDENTE
        conn.execute(sql)
        return True
    except Exception as e:
        print('Erro em sefaz.dao.insEMonitorSpoolRelerArqProperties')
        print(e)
        return False


def insEMonitorSpoolDist(EMONITORSPOOL_ERROPROCESSAMENTO, isFB, conn,
                         codInstalacao, codEmpresa, codEMonitorAcao, cnpjCpfInstalacao, numUFInstalacao,
                         codUF, numUF, tpAmb, nsu, msgRet, arqXML, arqXMLAss, arqXMLResp, status):
    try:
        if status == EMONITORSPOOL_ERROPROCESSAMENTO:
            # quando der erro, incrementar no campo NSEQEVENTO um contador, de forma que somente ira mandar novamente se o contador chegar a um limite, por ex. 5
            nseqevento = getProxNSeqEvento(isFB, conn, codInstalacao, codEmpresa, cnpjCpfInstalacao, numUFInstalacao, codEMonitorAcao)
        else:
            nseqevento = 0
            #
        dh = datetime.now()
        #
        if isFB:
            sql = emonitorspoolfb.insert()
            conn.execute(sql,
                         codinstalacao=codInstalacao,
                         codempresa=codEmpresa,
                         codemonitoracao=codEMonitorAcao,
                         coduf=codUF,
                         numuf=numUF,
                         tpamb=tpAmb,
                         datains=dh,
                         chave=nsu,
                         datahoraenviolote=dh,
                         datahorareclote=dh,
                         cnpjinut=cnpjCpfInstalacao,
                         anoinut=numUFInstalacao,
                         msgret=msgRet,
                         arqxml=arqXML.encode(),
                         arqxmlass=arqXMLAss.encode(),
                         arqxmlresp=arqXMLResp.encode(),
                         status=status,
                         nseqevento=nseqevento
                         )
        else:
            sql = emonitorspoolpg.insert()
            conn.execute(sql,
                         codinstalacao=codInstalacao,
                         codempresa=codEmpresa,
                         codemonitoracao=codEMonitorAcao,
                         coduf=codUF,
                         numuf=numUF,
                         tpamb=tpAmb,
                         datains=dh,
                         chave=nsu,
                         datahoraenviolote=dh,
                         datahorareclote=dh,
                         cnpjinut=cnpjCpfInstalacao,
                         anoinut=numUFInstalacao,
                         msgret=msgRet,
                         arqxml=arqXML,
                         arqxmlass=arqXMLAss,
                         arqxmlresp=arqXMLResp,
                         status=status,
                         nseqevento=nseqevento
                         )
        #
    except Exception as e:
        print('Erro em sefaz.dao.insEMonitorSpoolDist - acao: ' + str(codEMonitorAcao) + ' - inst: ' + str(codInstalacao) + ' - emp: ' + str(codEmpresa) + ' - cnpj: ' + str(cnpjCpfInstalacao) + ' - uf: ' + str(numUFInstalacao) + ' - msgRet: ' + msgRet)
        print(e)


def getUltNSUDist(conn, codInstalacao, codEmpresa, cnpjCpfInstalacao, numUFInstalacao, codEMonitorAcao):
    # verificar se tem muitas requisicoes de consumo indevido
    if codEMonitorAcao == 11:
        dataIns = wsstrtoAAAAMMDD(datetostr(incdatetimeactual(-1))) # ultimas 24h verificar spools apenas a partir desta data/hora de insercao
        sql = text('SELECT datains, status, chave, msgret '
               'FROM emonitorspool '
               'WHERE codinstalacao = :codinstalacao '
               'AND codempresa = :codempresa '
               'AND cnpjinut = :cnpjinut '
               'AND anoinut = :anoinut '
               'AND codemonitoracao = :codemonitoracao '
               'AND datains >= :datains '
               'ORDER BY datains DESC LIMIT 20')
        sql = sql.bindparams(codinstalacao=codInstalacao)
        sql = sql.bindparams(codempresa=codEmpresa)
        sql = sql.bindparams(cnpjinut=cnpjCpfInstalacao)
        sql = sql.bindparams(anoinut=numUFInstalacao)
        sql = sql.bindparams(codemonitoracao=codEMonitorAcao)
        sql = sql.bindparams(datains=dataIns)
        # print(sql)
        rs = conn.execute(sql)
        if rs is not None:
            dados = rs.fetchall()
            if len(dados) > 0:
                isConsumoIndevido = True
                for item in dados:
                    status = int(item['status'])
                    msgret = item['msgret']
                    if status != 6 or 'Consumo' not in msgret:
                        isConsumoIndevido = False
                        break
                if isConsumoIndevido:
                    return 'CONSUMO INDEVIDO'
    #
    sql = text('SELECT chave AS ultnsu '
               'FROM emonitorspool '
               'WHERE codinstalacao = :codinstalacao '
               'AND codempresa = :codempresa '
               'AND cnpjinut = :cnpjinut '
               'AND anoinut = :anoinut '
               'AND codemonitoracao = :codemonitoracao '
               'AND status = 4 '
               'ORDER BY chave DESC LIMIT 1')
    sql = sql.bindparams(codinstalacao=codInstalacao)
    sql = sql.bindparams(codempresa=codEmpresa)
    sql = sql.bindparams(cnpjinut=cnpjCpfInstalacao)
    sql = sql.bindparams(anoinut=numUFInstalacao)
    sql = sql.bindparams(codemonitoracao=codEMonitorAcao)
    #print(sql)
    rs = conn.execute(sql)
    if rs is None:
        return '000000000000000'
    else:
        dados = rs.fetchone()
        if dados is None:
            return '000000000000000'
        ultNSU = dados['ultnsu']
        if ultNSU is None or ultNSU == '':
            return '000000000000000'
        else:
            return ultNSU


def getSpoolUltNSUDist(conn, codInstalacao, codEmpresa, cnpjCpfInstalacao, numUFInstalacao, codEMonitorAcao):
    sql = text('SELECT * '
               'FROM emonitorspool '
               'WHERE codinstalacao = :codinstalacao '
               'AND codempresa = :codempresa '
               'AND cnpjinut = :cnpjinut '
               'AND anoinut = :anoinut '
               'AND codemonitoracao = :codemonitoracao '
               'AND status = 4 '
               'ORDER BY datains DESC '
               'LIMIT 1'
               )
    sql = sql.bindparams(codinstalacao=codInstalacao)
    sql = sql.bindparams(codempresa=codEmpresa)
    sql = sql.bindparams(cnpjinut=cnpjCpfInstalacao)
    sql = sql.bindparams(anoinut=numUFInstalacao)
    sql = sql.bindparams(codemonitoracao=codEMonitorAcao)
    #print(sql)
    return conn.execute(sql).fetchone()


def getUltNSeqEvento(isFB, conn, codInstalacao, codEmpresa, cnpjCpfInstalacao, numUFInstalacao, codEMonitorAcao):
    if isFB:
        sql = text('SELECT FIRST 1 codemonitorspool, nseqevento '
               'FROM emonitorspool '
               'WHERE codinstalacao = :codinstalacao '
               'AND codempresa = :codempresa '
               'AND cnpjinut = :cnpjinut '
               'AND anoinut = :anoinut '
               'AND codemonitoracao = :codemonitoracao '
               'ORDER BY datains DESC')
    else: # isPG
        sql = text('SELECT codemonitorspool, nseqevento '
               'FROM emonitorspool '
               'WHERE codinstalacao = :codinstalacao '
               'AND codempresa = :codempresa '
               'AND cnpjinut = :cnpjinut '
               'AND anoinut = :anoinut '
               'AND codemonitoracao = :codemonitoracao '
               'ORDER BY datains DESC LIMIT 1')
    sql = sql.bindparams(codinstalacao=codInstalacao)
    sql = sql.bindparams(codempresa=codEmpresa)
    sql = sql.bindparams(cnpjinut=cnpjCpfInstalacao)
    sql = sql.bindparams(anoinut=numUFInstalacao)
    sql = sql.bindparams(codemonitoracao=codEMonitorAcao)
    #print(sql)
    rs = conn.execute(sql)
    if rs is None:
        return 0,0 # nunca teve spool => pode processar comunicacao com SEFAZ
    else:
        dados = rs.fetchone()
        if dados is None:
            return 0,0  # nunca teve spool => pode processar comunicacao com SEFAZ
        nseqevento = dados['nseqevento']
        if nseqevento is None:
            return 0,0 # casos anteriores a esta implementacao onde nseqevento for null => pode processar comunicacao com SEFAZ
        else:
            codemonitorspool = dados['codemonitorspool']
            return codemonitorspool,nseqevento


def getProxNSeqEvento(isFB, conn, codInstalacao, codEmpresa, cnpjCpfInstalacao, numUFInstalacao, codEMonitorAcao):
    if isFB:
        sql = text('SELECT FIRST 1 nseqevento '
               'FROM emonitorspool '
               'WHERE codinstalacao = :codinstalacao '
               'AND codempresa = :codempresa '
               'AND cnpjinut = :cnpjinut '
               'AND anoinut = :anoinut '
               'AND codemonitoracao = :codemonitoracao '
               'ORDER BY datains DESC')
    else:
        sql = text('SELECT nseqevento '
               'FROM emonitorspool '
               'WHERE codinstalacao = :codinstalacao '
               'AND codempresa = :codempresa '
               'AND cnpjinut = :cnpjinut '
               'AND anoinut = :anoinut '
               'AND codemonitoracao = :codemonitoracao '
               'ORDER BY datains DESC LIMIT 1')
    sql = sql.bindparams(codinstalacao=codInstalacao)
    sql = sql.bindparams(codempresa=codEmpresa)
    sql = sql.bindparams(cnpjinut=cnpjCpfInstalacao)
    sql = sql.bindparams(anoinut=numUFInstalacao)
    sql = sql.bindparams(codemonitoracao=codEMonitorAcao)
    #print(sql)
    rs = conn.execute(sql)
    if rs is None:
        return 1
    else:
        dados = rs.fetchone()
        if dados is None:
            return 1
        nseqevento = dados['nseqevento']
        if nseqevento is None:
            return 1
        else:
            if isMaxNSeqEvento(nseqevento):
                return 1
            else:
                return nseqevento + 1


def isMaxNSeqEvento(nseqevento):
    __MAXNSEQEVENTO = 3 # estimativa de +/- 1h a cada interacao
    return nseqevento == __MAXNSEQEVENTO


def setUltNSeqEvento(conn, codEMonitorSpool, nSeqEvento):
    try:
        sql = 'UPDATE emonitorspool ' \
            'SET nseqevento = ' + str(nSeqEvento) + ' ' + \
            'WHERE codemonitorspool = ' + str(codEMonitorSpool)
        conn.execute(text(sql))
        return True
    except Exception as e:
        print('Erro em sefaz.dao.setUltNSeqEvento')
        print(e)
        return False


def getWSDist(conn, codInstalacao, codEmpresa, cnpjInut, codEMonitorSpool, dataIni, dataFim, chave, tipo, todosXMLs):
    if cnpjInut != '':
        filtroCnpjInut = 'AND cnpjinut = \'' + cnpjInut + '\' '
    else:
        filtroCnpjInut = ''
    #
    if codEMonitorSpool != '':
        filtroCodEMonitorSpool = 'AND codemonitorspool = ' + str(codEMonitorSpool) + ' '
    else:
        filtroCodEMonitorSpool = 'AND datains BETWEEN \'' + dataIni + ' ' + HORAZERO + '\' AND \'' + dataFim + ' ' + HORALIMITE + '\' '
    #
    if tipo == 'N': # NFE
        filtroTipo = 'AND codemonitoracao = 11 '
    elif tipo == 'C': # CTE
        filtroTipo = 'AND codemonitoracao = 111 '
    elif tipo == 'M': # MDFE
        filtroTipo = 'AND codemonitoracao = 211 '
    else: # TODOS
        filtroTipo = 'AND codemonitoracao IN (11,111,211) '
    #
    sql = 'SELECT codemonitorspool, codemonitoracao, to_char(datains,\'DD/MM/YYYY HH24:MI:SS\') as datains, status, chave, msgret, arqxmlresp ' + \
        'FROM emonitorspool ' + \
        'WHERE codinstalacao = ' + str(codInstalacao) + ' ' + \
        'AND codempresa = ' + str(codEmpresa) + ' ' + \
        filtroCnpjInut + \
        filtroCodEMonitorSpool + \
        filtroTipo + \
        'AND status = 4 ' + \
        'ORDER BY codemonitoracao, datains, codemonitorspool'
    #
    rs = conn.execute(text(sql))
    if rs is None:
        return True, sql, ''
    dados = rs.fetchall()
    if len(dados) == 0:
        return False, sql, ''
    listRet = list()
    for rec in dados:
        codEmonitorAcao = rec['codemonitoracao']
        if codEmonitorAcao < 100:
            tipo = 'NFe'
        elif codEmonitorAcao < 200:
            tipo = 'CTe'
        else:
            tipo = 'MDFe'
        codEMonitorSpool = int(rec['codemonitorspool'])
        arqXMLResp = rec['arqxmlresp']
        lXMLs = _getXMLs(codEMonitorSpool, arqXMLResp, tipo)
        if lXMLs is None:
            continue
        ct = 0
        for xml in lXMLs:
            if todosXMLs == 'C' and \
                (xml.find("<resEvento") >= 0 or xml.find("<retEnvEvento") >= 0 or \
                xml.find("<resNFe") >= 0 or xml.find("<procEventoNFe") >= 0 or \
                xml.find("<resCTe") >= 0 or xml.find("<procEventoCTe") >= 0 or \
                xml.find("<resMDFe") >= 0 or xml.find("<procEventoMDFe") >= 0):
                continue # nao devolver XMLs resumidos
            if chave is not None and chave != '' and xml.find(chave) == -1:
                continue
            listRet.append('<item>')
            listRet.append(createtag('spool', str(codEMonitorSpool)))
            listRet.append(createtag('tipo', tipo))
            listRet.append(createtag('acao', str(rec['codemonitoracao'])))
            listRet.append(createtag('datains', str(rec['datains'])))
            listRet.append(createtag('status', str(rec['status'])))
            listRet.append(createtag('nsu', rec['chave']))
            if tipo == 'NFe':
                listRet.append(createtag('chave', gettagstring(xml, 'chNFe')))
            elif tipo == 'CTe':
                listRet.append(createtag('chave', gettagstring(xml, 'chCTe')))
            elif tipo == 'MDFe':
                listRet.append(createtag('chave', gettagstring(xml, 'chMDFe')))
            listRet.append(createtag('msgret', rec['msgret']))
            listRet.append(createtag('arqxmlresp', base64.b64encode(gzip.compress(bytes(xml.encode()))).decode()))
            listRet.append('</item>')
            ct += 1
        printdh('Spool: ' + str(codEMonitorSpool) + ' com ' + str(ct) + ' XMLs.')
    return False, sql, ''.join(listRet)


def _getXMLs(codEMonitorSpool: int, xml: str, tipo: str):
    try:
        root = tree.fromstring(xml)
    except tree.ParseError:
        return None
    #
    try:
        if tipo == 'NFe':
            node = root[0] # nfeDistDFeInteresseResult
            node = node[0] # retDistDFeInt
            node = node[7] # loteDistDFeInt
        elif tipo == 'CTe':
            node = root[0] # retDistDFeInt
            node = node[7] # loteDistDFeInt
        elif tipo == 'MDFe':
            node = root[7] # loteDistDFeInt
        if node is not None:
            node = list(node) # lista de docZip
        if node is not None and len(node) > 0:
            lRet = list()
            for item in node:
                ret = item.text
                try:
                    ret = gzip.decompress(base64.b64decode(ret))
                    lRet.append(ret.decode())
                except Exception as e:
                    print('Erro gzip.decompress em _getXMLs spool ' + str(codEMonitorSpool))
                    print(e)
                    return None
            return lRet
        else:
            return None
    except Exception as e:
        print('Erro em sefaz.dao._getXMLs spool ' + str(codEMonitorSpool))
        print(e)
        return None


def getXMLsWSDist(conn, codEMonitorSpool):
    #
    sql = 'SELECT arqxml, arqxmlresp ' + \
        'FROM emonitorspool ' + \
        'WHERE codemonitorspool = ' + str(codEMonitorSpool) + ' '
    #
    rs = conn.execute(text(sql))
    if rs is None:
        return True, sql, '', ''
    dados = rs.fetchone()
    if len(dados) == 0:
        return False, sql, '', ''
    else:
        arqXMLEnvio = base64.b64encode(gzip.compress(bytes(dados['arqxml'].encode()))).decode()
        arqXMLResp = base64.b64encode(gzip.compress(bytes(dados['arqxmlresp'].encode()))).decode()
        return False, sql, arqXMLEnvio, arqXMLResp


def ctBiAutors(conn, codInstalacao, codEmpresa, tipo, dataHoraIni, dataHoraFim):
    #
    if tipo == 'N': # NFE
        filtroTipo = 'AND codemonitoracao = 41 '
    elif tipo == 'C': # CTE
        filtroTipo = 'AND codemonitoracao IN (131,143) '
    elif tipo == 'M': # MDFE
        filtroTipo = 'AND codemonitoracao IN (231,233) '
    elif tipo == 'S': # NFSE
        filtroTipo = 'AND codemonitoracao = 501 '
    else: # TODOS
        filtroTipo = 'AND codemonitoracao IN (41,131,143,231,233,501) '
    #
    if codEmpresa != '':
        filtroCodEmpresa = 'AND codempresa = ' + codEmpresa + ' '
    else:
        filtroCodEmpresa = ''
    #
    sql = 'SELECT COUNT(codemonitorspool) AS ct ' + \
        'FROM emonitorspool ' + \
        'WHERE codinstalacao = ' + codInstalacao + ' ' + \
        filtroCodEmpresa + \
        filtroTipo + \
        'AND datains BETWEEN \'' + dataHoraIni + '\' AND \'' + dataHoraFim + '\' ' + \
        'AND tpamb = \'1\' ' + \
        'AND status = 4'
    #print(sql)
    rs = conn.execute(text(sql))
    if rs is None:
        return 0
    dados = rs.fetchone()
    if dados is None:
        return 0
    ct = dados['ct']
    if ct is None:
        return 0
    return ct

'''
set plan on;
Select Count(T1.CodEMonitorSpool) Quant
From EMonitorSpool T1
Where T1.CodEMonitorAcao in (1,21,31,41,101,121,131,143,201,231,233,501)
And T1.TpAmb = 1
And T1.Status = 4 /*PROCESSADO*/
And T1.DataIns Between '2020-4-1' And '2020-4-10'
And T1.CodInstalacao = 2029
And T1.CodEmpresa = 1;
'''

def ctBiAutors2(conn, codInstalacao, codEmpresa, tipo, dataHoraIni, dataHoraFim):
    #
    if tipo != '':
        filtroTipo = 'AND tipo = \'' + tipo + '\' '
    else: # TODOS
        filtroTipo = ''
    #
    if codEmpresa != '':
        filtroCodEmpresa = 'AND codempresa = ' + codEmpresa + ' '
    else:
        filtroCodEmpresa = ''
    #
    sql = 'SELECT SUM(quantautors) AS ct ' + \
        'FROM biautors ' + \
        'WHERE codinstalacao = ' + codInstalacao + ' ' + \
        filtroCodEmpresa + \
        filtroTipo + \
        'AND data BETWEEN \'' + dataHoraIni + '\' AND \'' + dataHoraFim + '\''
    #print(sql)
    rs = conn.execute(text(sql))
    if rs is None:
        return 0
    dados = rs.fetchone()
    if dados is None:
        return 0
    ct = dados['ct']
    if ct is None:
        return 0
    return ct


def insBiAutors(conn, codInstalacao, codEmpresa, tipo, data, quantAutors):
    try:
        sql = biautors.insert()
        conn.execute(sql,
                     codinstalacao=codInstalacao,
                     codempresa=codEmpresa,
                     tipo=tipo,
                     data=data,
                     quantautors=quantAutors
                     )
        return True
    except Exception as e:
        print('Erro em sefaz.dao.insBiAutors')
        print(e)
        return False


def delBiAutors(conn, codInstalacao, codEmpresa, tipo, data):
    try:
        sql = 'DELETE FROM biautors ' \
            'WHERE codinstalacao = ' + codInstalacao + ' ' + \
            'AND codempresa = ' + codEmpresa + ' ' + \
            'AND tipo = \'' + tipo + '\' ' + \
            'AND data = \'' + str(data) + '\''
        conn.execute(text(sql))
        return True
    except Exception as e:
        print('Erro em sefaz.dao.delBiAutors')
        print(e)
        return False


def ctBiSistemaExt(conn, codInstalacao, codEmpresa, tipo, dataHoraIni, dataHoraFim):
    #
    if tipo > 0:
        filtroTipo = 'AND tipo = ' + str(tipo) + ' '
    else: # TODOS
        filtroTipo = ''
    #
    if codEmpresa != '':
        filtroCodEmpresa = 'AND codempresa = ' + codEmpresa + ' '
    else:
        filtroCodEmpresa = ''
    #
    sql = 'SELECT COUNT(codsistemaext) AS ct ' + \
        'FROM sistemaext ' + \
        'WHERE codinstalacao = ' + codInstalacao + ' ' + \
        filtroCodEmpresa + \
        filtroTipo + \
        'AND datareq BETWEEN \'' + dataHoraIni + '\' AND \'' + dataHoraFim + '\' ' + \
        'AND tpamb = \'1\' ' + \
        'AND status = 4'
    #print(sql)
    rs = conn.execute(text(sql))
    if rs is None:
        return 0
    dados = rs.fetchone()
    if dados is None:
        return 0
    ct = dados['ct']
    if ct is None:
        return 0
    return ct


def ctBiSistemaExt2(conn, codInstalacao, codEmpresa, tipo, dataHoraIni, dataHoraFim):
    #
    if tipo > 0:
        filtroTipo = 'AND tipo = ' + str(tipo) + ' '
    else: # TODOS
        filtroTipo = ''
    #
    if codEmpresa != '':
        filtroCodEmpresa = 'AND codempresa = ' + codEmpresa + ' '
    else:
        filtroCodEmpresa = ''
    #
    sql = 'SELECT SUM(quant) AS ct ' + \
        'FROM bisistemaext ' + \
        'WHERE codinstalacao = ' + codInstalacao + ' ' + \
        filtroCodEmpresa + \
        filtroTipo + \
        'AND data BETWEEN \'' + dataHoraIni + '\' AND \'' + dataHoraFim + '\''
    #print(sql)
    rs = conn.execute(text(sql))
    if rs is None:
        return 0
    dados = rs.fetchone()
    if dados is None:
        return 0
    ct = dados['ct']
    if ct is None:
        return 0
    return ct


def insBiSistemaExt(conn, codInstalacao, codEmpresa, tipo, data, quant):
    try:
        sql = bisistemaext.insert()
        conn.execute(sql,
                     codinstalacao=codInstalacao,
                     codempresa=codEmpresa,
                     tipo=tipo,
                     data=data,
                     quant=quant
                     )
        return True
    except Exception as e:
        print('Erro em sefaz.dao.insBiSistemaExt')
        print(e)
        return False


def delBiSistemaExt(conn, codInstalacao, codEmpresa, tipo, data):
    try:
        sql = 'DELETE FROM bisistemaext ' \
            'WHERE codinstalacao = ' + codInstalacao + ' ' + \
            'AND codempresa = ' + codEmpresa + ' ' + \
            'AND tipo = ' + str(tipo) + \
            'AND data = \'' + str(data) + '\''
        conn.execute(text(sql))
        return True
    except Exception as e:
        print('Erro em sefaz.dao.delBiSistemaExt')
        print(e)
        return False


#######################################################
# Manutencao das tabelas instemp e instempfil
#######################################################

def uninstallInstEmp(conn, inst, emp):
    try:
        sql = 'DELETE FROM instemp WHERE codInstalacao = ' + str(inst) + ' AND codEmpresa = ' + str(emp)
        conn.execute(text(sql))
        return True
    except Exception as e:
        print('Erro em sefaz.dao.uninstallInstEmp')
        print(e)
        return False


def uninstallInstEmpFilAll(conn, inst, emp):
    try:
        sql = 'DELETE FROM instempfil WHERE codInstalacao = ' + str(inst) + ' AND codEmpresa = ' + str(emp)
        conn.execute(text(sql))
        return True
    except Exception as e:
        print('Erro em sefaz.dao.uninstallInstEmpFilAll')
        print(e)
        return False


def delInstEmp(conn):
    try:
        sql = 'DELETE FROM instemp'
        conn.execute(text(sql))
        return True
    except Exception as e:
        print('Erro em sefaz.dao.delInstEmp')
        print(e)
        return False


def hasInstEmp(conn, inst, emp) -> bool:
    sql = text('SELECT COUNT(*) ct '
               'FROM instemp '
               'WHERE codinstalacao = :codinstalacao '
               'AND codempresa = :codempresa '
               '')
    sql = sql.bindparams(codinstalacao=inst)
    sql = sql.bindparams(codempresa=emp)
    #print(sql)
    rs = conn.execute(sql)
    dados = rs.fetchone()
    return dados is not None and dados['ct'] > 0


def getInstEmpAll(conn):
    try:
        sql = text('SELECT * '
                   'FROM instemp '
                   'ORDER BY codinstalacao, codempresa ')
        rs = conn.execute(sql)
        dados = rs.fetchall()
        return dados
    except Exception as e:
        raise Exception(e)


def insInstEmp(conn, inst, emp, email, nomearq, senha, checkexp):
    try:
        sql = \
            'INSERT INTO instemp(codinstalacao,codempresa,enddestemailsair,nomearqcertifcliente,senhacertifcliente,checkexpcertifcliente,datains)' + \
            ' VALUES(' + str(inst) + ',' + str(emp) + ',\'' + email + '\',\'' + nomearq + '\',\'' + senha + '\',\'' + checkexp + '\',current_timestamp)'
        conn.execute(text(sql))
        return True
    except Exception as e:
        print('Erro em sefaz.dao.insInstEmp')
        print(e)
        return False


def updInstEmp(conn, inst, emp, email, nomearq, senha, checkexp):
    try:
        sql = \
            'UPDATE instemp SET ' + \
            'enddestemailsair = \'' + email + '\', ' + \
            'nomearqcertifcliente = \'' + nomearq + '\', ' + \
            'senhacertifcliente = \'' + senha + '\', ' \
            'checkexpcertifcliente = \'' + checkexp + '\', ' + \
            'dataalt = current_timestamp ' + \
            'WHERE codinstalacao = ' + str(inst) + ' ' \
            'AND codempresa = ' + str(emp)
        conn.execute(text(sql))
        return True
    except Exception as e:
        print('Erro em sefaz.dao.updInstEmp')
        print(e)
        return False


def delInstEmpFil(conn):
    try:
        sql = 'DELETE FROM instempfil'
        conn.execute(text(sql))
        return True
    except Exception as e:
        print('Erro em sefaz.dao.delInstEmpFil')
        print(e)
        return False


def hasInstEmpFil(conn, inst, emp, cnpjcpf, numuf, tipo='') -> bool:
    if tipo != '':
        sqltipo = 'AND ' + tipo + 'dist = \'S\''
    else:
        sqltipo = ''
    sql = text('SELECT COUNT(*) ct '
               'FROM instempfil '
               'WHERE codinstalacao = :codinstalacao '
               'AND codempresa = :codempresa '
               'AND cnpjcpf = :cnpjcpf '
               'AND numuf = :numuf ' +
               sqltipo
               )
    sql = sql.bindparams(codinstalacao=inst)
    sql = sql.bindparams(codempresa=emp)
    sql = sql.bindparams(cnpjcpf=cnpjcpf)
    sql = sql.bindparams(numuf=numuf)
    #print(sql)
    rs = conn.execute(sql)
    dados = rs.fetchone()
    return dados is not None and dados['ct'] > 0


def insInstEmpFil(conn, inst, emp, cnpjcpf, numuf, nomecampo, valorcampo):
    try:
        sql = \
            'INSERT INTO instempfil(codinstalacao,codempresa,cnpjcpf,numuf,'+nomecampo+',datains)' + \
            ' VALUES(' + str(inst) + ',' + str(emp) + ',\'' + str(cnpjcpf) + '\',\'' + str(numuf) + '\',\''+valorcampo+'\',current_timestamp)'
        conn.execute(text(sql))
        return True
    except Exception as e:
        print('Erro em sefaz.dao.insInstEmpFil')
        print(e)
        return False


def updInstEmpFil(conn, inst, emp, cnpjcpf, numuf, nomecampo, valorcampo):
    try:
        sql = \
            'UPDATE instempfil SET ' + \
            nomecampo + ' = \'' + valorcampo + '\', ' + \
            'dataalt = current_timestamp ' + \
            'WHERE codinstalacao = ' + str(inst) + ' ' \
            'AND codempresa = ' + str(emp) + ' ' \
            'AND cnpjcpf = \'' + str(cnpjcpf) + '\' ' \
            'AND numuf = \'' + str(numuf) + '\''
        conn.execute(text(sql))
        return True
    except Exception as e:
        print('Erro em sefaz.dao.updInstEmpFil')
        print(e)
        return False


def getFieldsOutrasInstalacoes(conn):
    sql = text('SELECT codinstalacao, codempresa '
               'FROM instemp '
               'ORDER BY codinstalacao, codempresa')
    #print(sql)
    rs = conn.execute(sql)
    return rs.fetchall()


def getEndDestEmailSair(conn, cod_instalacao, cod_empresa):
    try:
        sql = text('SELECT enddestemailsair '
                   'FROM instemp '
                   'WHERE codinstalacao = :codInstalacao '
                   'AND codempresa = :codEmpresa ')

        sql = sql.bindparams(codInstalacao=cod_instalacao)
        sql = sql.bindparams(codEmpresa=cod_empresa)

        response = conn.execute(sql).fetchone()
        return response[0]
    except Exception as e:
        raise Exception(e)


def getOutrasInstalacoes(conn):
    dados = getFieldsOutrasInstalacoes(conn)
    if dados is None:
        return ''
    else:
        listRet = list()
        #ret: str = ''
        for instemp in dados:
            inst = instemp['codinstalacao']
            emp = instemp['codempresa']
            listRet.append(str(inst) + '_' + str(emp) + ',')
            #ret = ret + str(inst) + '_' + str(emp) + ','
        ret = ''.join(listRet)
        return ret[0:len(ret)-1]


def getCnpjCpfsInstalacao(conn, inst):
    try:
        sql = text('SELECT DISTINCT cnpjcpf '
                   'FROM instempfil '
                   'WHERE codinstalacao = ' + str(inst) + ' '
                   'ORDER BY cnpjcpf')
        #print(sql)
        rs = conn.execute(sql)
        dados = rs.fetchall()
        listRet = list()
        for item in dados:
            cnpjCpf = item['cnpjcpf']
            if len(cnpjCpf) > 11:
                cnpjCpf = cnpjCpf[0:8]
            if cnpjCpf not in listRet:
                listRet.append(cnpjCpf)
        return listRet
    except Exception as e:
        print('Erro em sefaz.dao.getCnpjCpfsInstalacao')
        print(e)
        return list()


def getFieldsDistInstalacoes(conn, tipo):
    sql = text('SELECT codinstalacao, codempresa, cnpjcpf, numuf '
               'FROM instempfil '
               'WHERE ' + tipo + 'dist = \'S\' '
               'ORDER BY codinstalacao, codempresa, cnpjcpf, numuf')
    #print(sql)
    rs = conn.execute(sql)
    return rs.fetchall()


def getDistInstalacoes(conn, tipo):
    dados = getFieldsDistInstalacoes(conn, tipo)
    if dados is None:
        return ''
    else:
        listRet = list()
        #ret: str = ''
        for instempfil in dados:
            inst = instempfil['codinstalacao']
            emp = instempfil['codempresa']
            cnpjcpf = instempfil['cnpjcpf']
            numuf = instempfil['numuf']
            listRet.append(str(inst) + '_' + str(emp) + '_' + str(cnpjcpf) + '_' + str(numuf) + ',')
            #ret = ret + str(inst) + '_' + str(emp) + '_' + str(cnpjcpf) + '_' + str(numuf) + ','
        ret = ''.join(listRet)
        return ret[0:len(ret)-1]


#######################################################
# Execucao de SELECTs genericos solicitados pelo SOR (migracao do EMWS)
#######################################################

printlog = False

# Teste:
# print(dao.execSqlComp(conn,'chave,msgret','where codinstalacao = 3','order by chave'))
def execSqlComp(conn, sqlFields: str, sqlWhere: str, sqlOrder: str):
    sqlWhereUp = sqlWhere.upper()
    #
    isNFeDistAuto: bool = sqlWhereUp.find('AND CODEMONITORACAO = 11') > -1
    isCTeDistAuto: bool = sqlWhereUp.find('AND CODEMONITORACAO = 111') > -1
    isMDFeDistAuto: bool = sqlWhereUp.find('AND CODEMONITORACAO = 211') > -1
    #
    sql = text('SELECT ' + sqlFields + ' FROM emonitorspool ' + sqlWhere + ' ' + sqlOrder)
    if isNFeDistAuto or isCTeDistAuto or isMDFeDistAuto:
        sql = text(str(sql) + ' LIMIT 20') # retornar no maximo 20 spools por vez
    if printlog:
        printdh(str(sql))
    try:
        #
        rs = conn.execute(sql)
        dados = rs.fetchall()
        if dados is None:
            return False, sql, ''
        else:
            listFields = list(sqlFields.split(','))
            listRet = list()
            #ret: str = ''
            ct = 0;
            for spool in dados:
                ct = ct + 1
                listRet.append('<listaEs>')
                #ret = ret + '<listaEs>'
                for field in listFields:
                    value = str(spool[field.lower()])
                    if value == 'None':
                        value = ''
                    listRet.append('<' + field + '>' + value + '</' + field + '>')
                    #ret = ret + '<' + field + '>' + value + '</' + field + '>'
                listRet.append('</listaEs>')
                #ret = ret + '</listaEs>'
            if printlog:
                printdh('Gerados ' + str(ct) + ' registro(s).')
            ret = ''.join(listRet)
            return False, str(sql), ret
    except Exception as e:
        print('Erro em sefaz.dao.execSqlComp')
        print(e)
        return True, sql, ''


# Teste:
# print(dao.execSqlGeral(conn,'SELECT codemonitorspool,datains,chave,status FROM emonitorspool WHERE datains >= \'2021-11-01\'','codemonitorspool,datains,chave,status'))
def execSqlGeral(conn, sql: str, campos: str):
    sqlAux = sql.lower().strip()
    if not sqlAux.startswith('select') or sqlAux.find('where') < 0:
        return True, sql, ''
    #
    if printlog:
        printdh(str(sql))
    try:
        #
        rs = conn.execute(text(sql))
        dados = rs.fetchall()
        if dados is None:
            return False, sql, ''
        else:
            listFields = list(campos.split(','))
            listRet = list()
            for spool in dados:
                i = 0
                listRet.append('<reg>')
                for field in listFields:
                    value = str(spool[i])
                    if value == 'None':
                        value = ''
                    listRet.append('<' + field + '>' + value + '</' + field + '>')
                    i = i + 1
                listRet.append('</reg>')
            ret = ''.join(listRet)
            return False, str(sql), ret
    except Exception as e:
        print('Erro em sefaz.dao.execSqlGeral')
        print(e)
        return True, sql, ''


# Teste:
# print(dao.execSqlIns(conn,'insert into emonitorspool(codemonitorspool,status) values(:codemonitorspool,1)'))
def execSqlIns(conn, sql: str):
    try:
        codEmonitorSpool = conn.execute(text('SELECT NEXTVAL(\'codemonitorspool_gen\')')).fetchone()[0]
        sql = sql.replace('"','\'')
        sql = sql.replace(':CODEMONITORSPOOL',str(codEmonitorSpool))
        if printlog:
            printdh(str(sql))
        conn.execute(text(sql))
        return False, codEmonitorSpool
    except Exception as e:
        print('Erro em sefaz.dao.execSqlIns')
        print(e)
        return True, 0


def updEMonitorSpool(conn, nProt, dataHoraRecLote, msgRet, arqXMLAss, arqXMLRet, arqXMLResp, status, nProtInut, codEMonitorSpool):
    if nProtInut is not None and nProtInut != '':
        sqlNProtInut = ', nprotinut = \'' + nProtInut + '\' '
    else:
        sqlNProtInut = ''
    try:
        sql = 'UPDATE emonitorspool SET ' \
              'nprot = \'' + nProt + '\', ' \
              'datahorareclote = \'' + dataHoraRecLote + '\', ' \
              'msgret = \'' + msgRet.replace('\'','') + '\', ' \
              'arqxmlass = \'' + arqXMLAss + '\', ' \
              'arqxmlret = \'' + arqXMLRet.replace('\'','') + '\', ' \
              'arqxmlresp = \'' + arqXMLResp.replace('\'','') + '\', ' \
              'status = ' + str(status) + ' ' + \
              sqlNProtInut + \
              'WHERE codemonitorspool = ' + str(codEMonitorSpool)
        conn.execute(text(sql))
        return False
    except Exception as e:
        print('Erro em sefaz.dao.updEMonitorSpool')
        print(e)
        return True

##########################################################################
# INICIO: criados outros metodos, semelhante aos existentes acima, mas que serao usados na interacao com o emj
def isAtivo(conn):
    try:
        sql = text('SELECT versao FROM empresa WHERE codempresa = 1')
        conn.execute(sql)
        return True
    except Exception as e:
        print('Erro em sefaz.dao.isAtivo')
        print(e)
        return False


def insertEMonitorSpool(conn, sql, arqXML):
    try:
        codEmonitorSpool = conn.execute(text('SELECT NEXTVAL(\'codemonitorspool_gen\')')).fetchone()[0]
        #
        sql = sql.replace('"','\'')
        sql = sql.replace(':codEmonitorSpool',str(codEmonitorSpool))
        sql = sql.replace('\'NOW\'', 'current_timestamp') # FB/NOW => PG/current_timestamp
        sql = sql.replace('"NOW"', 'current_timestamp') # FB/NOW => PG/current_timestamp
        sql = sql.replace('\'null\'', '\'\'')
        sql = sql.replace('"null"', '\'\'')
        if sql.find(':arqXML') >= 0:
            sql = text(sql)
            sql = sql.bindparams(arqXML=arqXML)
        else:
            sql = text(sql)
        if printlog:
            printdh('dao.insertEMonitorSpool: ' + str(sql))
        conn.execute(sql)
    except Exception as e:
        print('Erro em sefaz.dao.insertEMonitorSpool: ' + sql)
        print(e)
        return -1
    #
    try:
        ############################################################################
        # verificar pela chave se existe outro spool ja autorizado,
        # para evitar chamar novamente a SEFAZ
        ############################################################################
        sql = 'SELECT codemonitoracao, chave FROM emonitorspool WHERE codemonitorspool = ' + str(codEmonitorSpool)
        dados = conn.execute(text(sql)).fetchall()[0]
        codEmonitorAcaoAtual = dados['codemonitoracao']
        chaveAtual = getstrnotempty(dados['chave'])
        if len(chaveAtual) >= 44 and codEmonitorAcaoAtual in [41,131,231]:
            sql = 'SELECT datahoraenviolote, arqxml, nreclote, datahorareclote, arqxmlret, msgret, nprot, arqxmlass, arqxmlresp ' \
                  'FROM emonitorspool ' \
                  'WHERE chave = \'' + chaveAtual + '\' ' \
                  'AND status = 4 ' \
                  'AND nprot IS NOT NULL AND char_length(nprot) = 15 ' \
                  'AND tpamb = \'1\' ' \
                  'AND codemonitorspool != ' + str(codEmonitorSpool) + ' ' \
                  'LIMIT 1'
            dados = conn.execute(text(sql)).fetchall()
            #
            if dados is not None and len(dados) > 0:
                dados = dados[0]
                if str(dados['datahoraenviolote']) == 'null':
                    dados['datahoraenviolote'] = dbdatetimeactualtostr()
                if str(dados['datahorareclote']) == 'null':
                    dados['datahorareclote'] = dbdatetimeactualtostr()
                # tem outro spool ja autorizado, apenas setar o spool atual com os dados de autorizacao
                sql = 'UPDATE emonitorspool SET ' \
                      'status = 4, ' \
                      'datahoraenviolote = \'' + str(dados['datahoraenviolote']) + '\', ' \
                      'arqxml = \'' + getstrnotempty(dados['arqxml']) + '\', ' \
                      'nreclote = \'' + getstrnotempty(dados['nreclote']) + '\', ' \
                      'datahorareclote = \'' + str(dados['datahorareclote']) + '\', ' \
                      'arqxmlret = \'' + getstrnotempty(dados['arqxmlret']) + '\', ' \
                      'msgret = \'' + getstrnotempty(dados['msgret']) + '\', ' \
                      'nprot = \'' + getstrnotempty(dados['nprot']) + '\', ' \
                      'arqxmlass = \'' + getstrnotempty(dados['arqxmlass']) + '\', ' \
                      'arqxmlresp = \'' + getstrnotempty(dados['arqxmlresp']) + '\' ' \
                      'WHERE codemonitorspool = ' + str(codEmonitorSpool)
                conn.execute(text(sql))
            else:
                cnpjFil = chaveAtual[6:20]
                modeloFil = chaveAtual[20:22]
                serieFil = chaveAtual[22:25]
                numDoc = chaveAtual[25:34]
                numInt = chaveAtual[35:43]
                #
                sql = 'SELECT codemonitorspool, chave ' \
                      'FROM emonitorspool ' \
                      'WHERE chavecnpjfil = \'' + cnpjFil + '\' ' \
                      'AND chavemodelofil = \'' + modeloFil + '\' ' \
                      'AND chaveseriefil = \'' + serieFil + '\' ' \
                      'AND chavenumdoc = \'' + numDoc + '\' ' \
                      'AND nprot IS NOT NULL AND char_length(nprot) = 15 ' \
                      'AND tpamb = \'1\' ' \
                      'AND status = 4 ' \
                      'AND codemonitorspool != ' + str(codEmonitorSpool) + ' ' \
                      'LIMIT 1'
                dados = conn.execute(text(sql)).fetchall()
                if dados is not None and len(dados) > 0:
                    dados = dados[0]
                    # tem outro spool ja autorizado mas com chave diferente, apesar de ser o mesmo numDoc, setar o spool atual pra erro
                    msgRet = 'Tentativa de autorizar um documento com mesmo numero fiscal [' + numDoc + ']. ' \
                            'Ja existe autorizacao com spool [' + str(dados['codemonitorspool']) + '] ' \
                            'e chave [' + dados['chave'] + '].'
                    if printlog:
                        printdh('dao.insertEMonitorSpool: ' + msgRet)
                    sql = 'UPDATE emonitorspool SET ' \
                          'status = 6, ' \
                          'msgret = \'' + msgRet + '\' ' \
                          'WHERE codemonitorspool = ' + str(codEmonitorSpool)
                    conn.execute(text(sql))
                else:
                    sql = 'SELECT codemonitorspool, chave ' \
                          'FROM emonitorspool ' \
                          'WHERE chavecnpjfil = \'' + cnpjFil + '\' ' \
                          'AND chavemodelofil = \'' + modeloFil + '\' ' \
                          'AND chaveseriefil = \'' + serieFil + '\' ' \
                          'AND chavenumint = \'' + numInt + '\' ' \
                          'AND nprot IS NOT NULL AND char_length(nprot) = 15 ' \
                          'AND tpamb = \'1\' ' \
                          'AND status = 4 ' \
                          'AND codemonitorspool != ' + str(codEmonitorSpool) + ' ' \
                          'LIMIT 1'
                    dados = conn.execute(text(sql)).fetchall()
                    if dados is not None and len(dados) > 0:
                        dados = dados[0]
                        # tem outro spool ja autorizado mas com chave diferente, apesar de ser o mesmo numInt, setar o spool atual pra erro
                        msgRet = 'Tentativa de autorizar um documento com mesmo numero interno [' + numInt + ']. ' \
                                'Ja existe autorizacao com spool [' + str(dados['codemonitorspool']) + '] ' \
                                'e chave [' + dados['chave'] + '].'
                        if printlog:
                            printdh('dao.insertEMonitorSpool: ' + msgRet)
                        sql = 'UPDATE emonitorspool SET ' \
                              'status = 6, ' \
                              'msgret = \'' + msgRet + '\' ' \
                              'WHERE codemonitorspool = ' + str(codEmonitorSpool)
                        conn.execute(text(sql))
                    else:
                        sql = 'SELECT codemonitorspool, chave ' \
                              'FROM emonitorspool ' \
                              'WHERE chavecnpjfil = \'' + cnpjFil + '\' ' \
                              'AND chavemodelofil = \'' + modeloFil + '\' ' \
                              'AND chaveseriefil = \'' + serieFil + '\' ' \
                              'AND chavenumint = \'' + numInt + '\' ' \
                              'AND codemonitoracao = ' + str(codEmonitorAcaoAtual) + ' ' \
                              'AND tpamb = \'1\' ' \
                              'AND status IS NOT NULL AND status != 6 ' \
                              'AND codemonitorspool != ' + str(codEmonitorSpool) + ' ' \
                              'LIMIT 1'
                        dados = conn.execute(text(sql)).fetchall()
                        if dados is not None and len(dados) > 0:
                            dados = dados[0]
                            # tem outro spool em processamento mas com chave diferente, apesar de ser o mesmo numInt, setar o spool atual pra erro
                            msgRet = 'Tentativa de autorizar um documento com mesmo numero interno [' + numInt + ']. ' \
                                    'Ja esta em processamento a autorizacao com spool [' + str(dados['codemonitorspool']) + '] ' \
                                    'e chave [' + dados['chave'] + '].'
                            if printlog:
                                printdh('dao.insertEMonitorSpool: ' + msgRet)
                            sql = 'UPDATE emonitorspool SET ' \
                                  'status = 6, ' \
                                  'msgret = \'' + msgRet + '\' ' \
                                  'WHERE codemonitorspool = ' + str(codEmonitorSpool)
                            conn.execute(text(sql))
        #
    except Exception as e:
        print('Erro em sefaz.dao.insertEMonitorSpool: checagens gerais apos insercao')
        print(e)
    # mesmo que de erro das checagens acima, o spool foi inserido e sera processado
    return int(codEmonitorSpool)


def updateEMonitorSpool(conn, sql):
    sqlAux = sql.lower().strip()
    if not sqlAux.startswith('update emonitorspool set') or sqlAux.find('where') < 0:
        return True
    #
    try:
        if printlog:
            printdh('dao.updateEMonitorSpool: ' + str(sql))
        conn.execute(text(sql))
        return False
    except Exception as e:
        print('Erro em sefaz.dao.updateEMonitorSpool: ' + sql)
        print(e)
        return True


# FIM: criados outros metodos, semelhante aos existentes acima, mas que serao usados na interacao com o emj
##########################################################################

def eventoProcessadoByChave(conn, chave):
    sql = text('SELECT nprot, datahorareclote, msgret, arqxmlass, arqxmlret ' # , arqxmlresp = arqxmlret
               'FROM emonitorspool '
               'WHERE codemonitoracao IN (28,38,48,128,138,148,208,238) '
               'AND status = 4 '
               'AND nprot IS NOT NULL '
               'AND chave = \'' + chave + '\' '
               'LIMIT 1')
    #print(sql)
    rs = conn.execute(sql)
    return rs.fetchone()


def insBiMdfeDist(isFB, conn, xml, codEMonitorSpool):
    try:
        dh = datetime.now()
        #
        if codEMonitorSpool == -1:
            sql = text('SELECT MAX(codemonitorspool) AS spool FROM emonitorspool')
            codEMonitorSpool = conn.execute(sql).fetchone()['spool']
        #
        docDist = xmltodict.parse(xml)
        listDocZip = docDist['ns0:retDistDFeInt']['ns0:loteDistDFeInt']['ns0:docZip']
        if not isinstance(listDocZip, list):
            listDocZip = [listDocZip]
        #
        for docZip in listDocZip:
            if not docZip['@schema'].startswith('procMDFe'):
                continue
            #
            doc = xmltodict.parse(gzip.decompress(base64.b64decode(docZip['#text'])).decode())
            #
            infMDFe = doc['mdfeProc']['MDFe']['infMDFe']
            ide = infMDFe['ide']
            data = ide['dhEmi'][0:19].replace('T',' ')
            chave = doc['mdfeProc']['protMDFe']['infProt']['chMDFe']
            #
            veicTracao = infMDFe['infModal']['rodo']['veicTracao']
            veiculoplaca = veicTracao['placa']
            #
            try:
                prop = veicTracao['prop']
                try:
                    propcnpjcpf = prop['CNPJ']
                except:
                    propcnpjcpf = prop['CPF']
                propie = prop['IE']
                propnome = cut(prop['xNome'],100)
                propuf = prop['UF']
                proptipoantt = prop['tpProp']
            except:
                propcnpjcpf = '00000000000000'
                propie = 'ISENTO'
                propnome = 'NAO INFORMADO'
                propuf = 'NI'
                proptipoantt = '0'
                #
            emit = infMDFe['emit']
            emitcnpjcpf = emit['CNPJ']
            emitnome = cut(emit['xNome'],70)
            emitie = emit['IE']
            enderemit = emit['enderEmit']
            emitendereco = cut(enderemit['xLgr'],70)
            try:
                emitnumero = enderemit['nro']
            except:
                emitnumero = ''
            try:
                emitcomplender = cut(enderemit['xCpl'],40)
            except:
                emitcomplender = ''
            try:
                emitbairro = cut(enderemit['xBairro'],30)
            except:
                emitbairro = ''
            emitibge = enderemit['cMun']
            emitcep = enderemit['CEP']
            try:
                emitfone = enderemit['fone']
            except:
                emitfone = '0000000000'
            try:
                emitemail = cut(enderemit['email'],200)
            except:
                emitemail = ''
            #
            try:
                condutor = veicTracao['condutor']
                motcpf = condutor['CPF']
                motnome = cut(condutor['xNome'],100)
            except:
                motcpf = '00000000000'
                motnome = ''
            #
            origibge = ide['infMunCarrega']['cMunCarrega']
            destibge = infMDFe['infDoc']['infMunDescarga']['cMunDescarga']
            #
            try:
                infRespTec = infMDFe['infRespTec']
                respteccnpjcpf = infRespTec['CNPJ']
                resptecnome = cut(infRespTec['xContato'],100)
            except:
                respteccnpjcpf = '00000000000000'
                resptecnome = 'NAO INFORMADO'
            #
            prodPred = infMDFe['prodPred']
            mercdesc = cut(prodPred['xProd'],100)
            #
            try:
                tot = infMDFe['tot']
                vcarga = tot['vCarga']
                qcarga = tot['qCarga']
            except:
                vcarga = 0
                qcarga = 0
            #
            try:
                sql = bimdfe.insert()
                conn.execute(sql,
                             codemonitorspool=codEMonitorSpool,
                             datains=dh,
                             data=data,
                             chave=chave,
                             codtpevento=0,
                             veiculoplaca=veiculoplaca,
                             propcnpjcpf=propcnpjcpf,
                             propie=propie,
                             propnome=propnome,
                             propuf=propuf,
                             proptipoantt=proptipoantt,
                             emitcnpjcpf=emitcnpjcpf,
                             emitnome=emitnome,
                             emitie=emitie,
                             emitendereco=emitendereco,
                             emitnumero=emitnumero,
                             emitcomplender=emitcomplender,
                             emitbairro=emitbairro,
                             emitibge=emitibge,
                             emitcep=emitcep,
                             emitfone=emitfone,
                             emitemail=emitemail,
                             motcpf=motcpf,
                             motnome=motnome,
                             origibge=origibge,
                             destibge=destibge,
                             respteccnpjcpf=respteccnpjcpf,
                             resptecnome=resptecnome,
                             mercdesc=mercdesc,
                             vcarga=vcarga,
                             qcarga=qcarga
                             )
            except Exception as e:
                print('Erro em sefaz.dao.insBiMdfeDist - insert')
                print(e)

        #
    except Exception as e:
        print('Erro em sefaz.dao.insBiMdfeDist')
        print(e)


def getBiMdfeDist(isFB, conn, dataIni, dataFim):
    dataIni = dataIni + ' 00:00:00'
    dataFim = dataFim + ' 23:59:59'
    #
    try:
        #'propcnpjcpf,propie,propnome,propuf,proptipoantt'
        #'ORDER BY respteccnpjcpf, emitcnpjcpf, emitie, propcnpjcpf, propie')
        sqlFields = \
            'respteccnpjcpf,resptecnome,' + \
            'emitcnpjcpf,emitie,emitnome,emitendereco,emitnumero,emitcomplender,emitbairro,emitibge,emitcep,emitfone,emitemail'
        sql = text('SELECT DISTINCT ' + sqlFields + ' ' +
                   'FROM bimdfe '
                   'WHERE datains BETWEEN :dataIni AND :dataFim '
                   'ORDER BY respteccnpjcpf, emitcnpjcpf, emitie')
        sql = sql.bindparams(dataIni=strtodatetime(dataIni, '%d/%m/%Y %H:%M:%S'))
        sql = sql.bindparams(dataFim=strtodatetime(dataFim, '%d/%m/%Y %H:%M:%S'))
        dados = conn.execute(sql).fetchall()
        #
        listFields = list(sqlFields.split(','))
        listRet = list()
        for bimdfe in dados:
            i = 0
            listRet.append('<reg>')
            for field in listFields:
                value = str(bimdfe[i])
                if value == 'None':
                    value = ''
                listRet.append('<' + field + '>' + escape(value) + '</' + field + '>')
                i = i + 1
            listRet.append('</reg>')
        ret = ''.join(listRet)
        return base64.b64encode(gzip.compress(bytes(ret.encode()))).decode()
        #
    except Exception as e:
        print('Erro em sefaz.dao.getBiMdfeDist: ' + dataIni + ' a ' + dataFim)
        print(e)
        return ''


def getBiMdfePropVeic(conn, propCnpjCpf, veiculoPlaca, dataIni, comp=False):
    dataIni = dataIni.replace('-','/')
    #
    try:
        sqlFields = 'data,chave,codTpEvento,' \
                    'emitCnpjCpf,emitNome,emitEmail,' \
                    'veiculoPlaca'
        if comp:
            sqlFields += ',' \
                         'propCnpjCpf,propIE,propNome,' \
                         'motCpf,motNome,' \
                         'origIBGE,origCEP,origLat,origLon,' \
                         'destIBGE,destCEP,destLat,destLon,' \
                         'mercDesc,mercNCM,' \
                         'freteMot,vCarga,qCarga'
        # select codemonitorspool,datains,data,chave,codtpevento,veiculoplaca,propcnpjcpf,motcpf from bimdfe where propcnpjcpf = '02570279129' and veiculoplaca = 'LYC5B15' and data >= '2022-11-02' order by data,chave;
        sql = text('SELECT DISTINCT ' + sqlFields + ' ' +
                   'FROM bimdfe '
                   'WHERE propcnpjcpf = :propCnpjCpf '
                   'AND veiculoplaca = :veiculoPlaca '
                   'AND data >= :dataIni '
                   'ORDER BY data,chave')
        sql = sql.bindparams(propCnpjCpf=propCnpjCpf)
        sql = sql.bindparams(veiculoPlaca=veiculoPlaca)
        sql = sql.bindparams(dataIni=strtodate(dataIni, '%d/%m/%Y'))
        dados = conn.execute(sql).fetchall()
        #
        listFields = list(sqlFields.split(','))
        return _genXmlBiMdfe(listFields, dados)
        #
    except Exception as e:
        print('Erro em sefaz.dao.getBiMdfePropVeic: ' + propCnpjCpf + ' / ' + veiculoPlaca + ' / ' + dataIni)
        print(e)
        return ''


def getBiMdfeMot(conn, motCpf, dataIni, comp=False):
    dataIni = dataIni.replace('-','/')
    #
    try:
        sqlFields = 'data,chave,codTpEvento,' \
                    'emitCnpjCpf,emitNome,emitEmail,' \
                    'veiculoPlaca'
        if comp:
            sqlFields += ',' \
                         'propCnpjCpf,propIE,propNome,' \
                         'motCpf,motNome,' \
                         'origIBGE,origCEP,origLat,origLon,' \
                         'destIBGE,destCEP,destLat,destLon,' \
                         'mercDesc,mercNCM,' \
                         'freteMot,vCarga,qCarga'
        # select codemonitorspool,datains,data,chave,codtpevento,veiculoplaca,propcnpjcpf,motcpf from bimdfe where motcpf = '35250283187' and data >= '2022-11-02' order by data,chave;
        sql = text('SELECT DISTINCT ' + sqlFields + ' ' +
                   'FROM bimdfe '
                   'WHERE motCpf = :motCpf '
                   'AND data >= :dataIni '
                   'ORDER BY data,chave')
        sql = sql.bindparams(motCpf=motCpf)
        sql = sql.bindparams(dataIni=strtodate(dataIni, '%d/%m/%Y'))
        dados = conn.execute(sql).fetchall()
        #
        listFields = list(sqlFields.split(','))
        return _genXmlBiMdfe(listFields, dados)
        #
    except Exception as e:
        print('Erro em sefaz.dao.getBiMdfeMot: ' + motCpf + ' / ' + dataIni)
        print(e)
        return ''


def getBiMdfePer(conn, dataIni, dataFim, comp=False):
    dataIni = dataIni.replace('-','/')
    dataFim = dataFim.replace('-','/')
    #
    try:
        sqlFields = 'data,chave,codTpEvento,' \
                    'emitCnpjCpf,emitNome,emitEmail,' \
                    'veiculoPlaca'
        if comp:
            sqlFields += ',' \
                         'propCnpjCpf,propIE,propNome,' \
                         'motCpf,motNome,' \
                         'origIBGE,origCEP,origLat,origLon,' \
                         'destIBGE,destCEP,destLat,destLon,' \
                         'mercDesc,mercNCM,' \
                         'freteMot,vCarga,qCarga'
        sql = text('SELECT DISTINCT ' + sqlFields + ' ' +
                   'FROM bimdfe '
                   'WHERE data BETWEEN :dataIni AND :dataFim '
                   'ORDER BY data,chave')
        sql = sql.bindparams(dataIni=strtodatetime(dataIni + ' 00:00:00', '%d/%m/%Y %H:%M:%S'))
        sql = sql.bindparams(dataFim=strtodatetime(dataFim + ' 23:59:59', '%d/%m/%Y %H:%M:%S'))
        dados = conn.execute(sql).fetchall()
        #
        listFields = list(sqlFields.split(','))
        return _genXmlBiMdfe(listFields, dados)
        #
    except Exception as e:
        print('Erro em sefaz.dao.getBiMdfePer: ' + dataIni + ' / ' + dataFim)
        print(e)
        return ''


def _genXmlBiMdfe(listFields, dados):
    listRet = list()
    for bimdfe in dados:
        i = 0
        listRet.append('<mdfe>')
        for field in listFields:
            value = getstrnotempty(str(bimdfe[i]))
            if value == 'None':
                value = 'null'
            #
            if field == 'data':
                value = datetimetostr(strtodatetime2(value, '%Y-%m-%d %H:%M:%S')).replace('/', '-') + '.0'
            if field in ['origLat', 'origLon', 'destLat', 'destLon']:
                value = formatstrnum(value, 6)
            if field in ['freteMot', 'vCarga', 'qCarga']:
                value = formatstrnum(value)
            #
            listRet.append('<' + field + '>' + escape(value) + '</' + field + '>')
            i = i + 1
        listRet.append('</mdfe>')
    ret = ''.join(listRet)
    return ret


