'''
    NAO SERA MAIS FEITO POIS NAO TEM VANTAGEM SOBRE A VERSAO ATUAL EMJ, TER QUE FAZER ESTE MONTE DE CODIGO
    - autorizar, consultar, cancelar, encerrar, incCondutor
      - consultar: gravar spool no comeco (PENDENTE) e no final (PROCESSADO OU ERRO), assinar XML antes de enviar
        retornar getCodEMonitorSpool getDataHoraRecLote getNRecLote getNProt getNProtCanc getArqXMLAss getArqXMLResp (evento assinado)
        ver campos em EMonitorDAO.getStatusSpool
      - autorizar: gravar spool no comeco (PENDENTE) e no final (PROCESSADO OU ERRO), assinar XML antes de enviar
        ver campos em EMonitorDAO.getStatusSpool
      - alterar getSpoolsByChave e verifPKChaveDoc (Controller e PainelMDFe)
    - TESTE COMPLETO EM HOMOLOGACAO
      - testar autorizar
      - testar consultar que retorna autorizado ou cancelado ou encerrado
    - mapear tabelas instemp e instempdist do properties, script de migracao de properties para bdpg
    - gerenciar melhor os logs e xmls gerados, talvez ate dentro do proprio bd pelo menos os xmls
    - tirar Debug=true e codigo no isServidorEMonitorPY no EMonitorDAO apos todas as acoes funcionarem
      e nao vai precisar mais um monte de ACOES em isAcaoRemoteWSToProcessMDFe
    - emi/emws:
      - FormReadXML/InstallWS.readXML (se for de resp consulta spool)
      - FormSendXMLsIS/InstallWS.sendXMLs
      - envio (instalacao e atualizacao) de cert para servidores tambem atualizando bd do empg(instemp/instempdist)
      - alterar /sefaz do main.py para ao inves de olhar o properties puxar do bd
    - ACAO_REGERARXMLASSMDFE, ACAO_ASSINARXML, ACAO_CHECARDATAEXPCERT
    - websaf/emws: calcular doctos emitidos tambem olhando bdpg
'''

import xml.etree.ElementTree as tree

import sefaz_spooler
from geralxml import *
from geral import removeAccents

# Acoes do MDF-e 3
ACAO_MDFE_RECEPCAO3 = 231
ACAO_MDFE_RETRECEPCAO3 = 232
ACAO_MDFE_CONSULTA3 = 235
ACAO_MDFE_STATUSSERVICO3 = 236
ACAO_MDFE_RECEPCAOEVENTO3 = 238
ACAO_MDFE_CONSNAOENC = 237
#
ACAO_MDFE_CONSULTAMDFDIST = 210;
ACAO_MDFE_CONSULTAMDFDISTAUTO = 211;

RET_ENVLOTEEVENTO_NOERRO = "135"


def callMDFe(pfx_path, pfx_password, codInstalacao, codEmpresa, codEMonitorAcao, codUF, numUF, req, rsEMonitorUFAcao):
    #
    if codEMonitorAcao == ACAO_MDFE_CONSULTAMDFDISTAUTO:
        request = requestConsultaMDFDistAuto(rsEMonitorUFAcao, req)
    #
    request = requestHeader(rsEMonitorUFAcao, numUF) + request + requestFooter()
    #print(request)
    #
    url = rsEMonitorUFAcao['urlprinc']
    action = rsEMonitorUFAcao['urlacao']
    # PENDENTE VERIFICAR A PARTIR DAQUI O RETORNO DE QUATRO RESPOSTAS
    ret, erros = sefaz_spooler.processRequestSefaz(pfx_path, pfx_password, codEMonitorAcao, codUF, numUF, request, url, action)
    if erros != '':
        return request, ret, '', erros
    else:
        resp, erros = processResponse(codEMonitorAcao, ret)
        if erros != '':
            return request, ret, '', erros
        else:
            return request, ret, resp, '' # ret = XML normal de resposta, resp = apenas xMotivo (distauto) ou POR ENQTO SEM USO
    '''
    if erros != '':
        # PENDENTE VERIFICAR A PARTIR DAQUI O RETORNO DE QUATRO RESPOSTAS
        return '', erros, request, ret
    else:
        resp, erros = processResponse(codEMonitorAcao, ret)
        # PENDENTE VERIFICAR A PARTIR DAQUI O RETORNO DE QUATRO RESPOSTAS
        return resp, '', request, ret # response é o XML completo de resposta
    '''


def requestHeader(rsEMonitorUFAcao, numUF):
    header = list()
    header.append('<?xml version="1.0" encoding="utf-8" ?>')
    header.append('<env:Envelope xmlns:env="http://www.w3.org/2003/05/soap-envelope" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">')
    header.append('<env:Header>')
    header.append('<mdfeCabecMsg xmlns="' + rsEMonitorUFAcao['urlcabecmsg'] + '">')
    header.append(createtag('cUF', str(numUF)))
    header.append(createtag('versaoDados', rsEMonitorUFAcao['versaodados']))
    header.append('</mdfeCabecMsg>')
    header.append('</env:Header>')
    return ''.join(header)


def requestFooter():
    return '</env:Envelope>'


def requestConsultaMDFDistAuto(rsEMonitorUFAcao, request):
    listCampos = list(request.split('_'))
    req = list()
    req.append('<env:Body>')
    #req.append('<mdfeDistDFeInteresse xmlns="' + rsEMonitorUFAcao['urldadosmsg'] + '">')
    req.append('<mdfeDadosMsg xmlns="' + rsEMonitorUFAcao['urldadosmsg'] + '">')
    req.append('<distDFeInt xmlns="' + rsEMonitorUFAcao['urldadosmsgelement'] + '" versao="' + rsEMonitorUFAcao['versaodados'] + '">')
    req.append(createtag('tpAmb', rsEMonitorUFAcao['tpamb']))
    #req.append(createtag('cUFAutor', listCampos[1].strip()))
    if len(listCampos[0]) == 14:
        req.append(createtag('CNPJ', listCampos[0].strip()))
    else:
        req.append(createtag('CPF', listCampos[0].strip()))
    req.append('<distNSU>')
    req.append(createtag('ultNSU', listCampos[2]))
    req.append('</distNSU>')
    req.append('</distDFeInt>')
    req.append('</mdfeDadosMsg>')
    #req.append('</mdfeDistDFeInteresse>')
    req.append('</env:Body>')
    return ''.join(req)


def processResponse(codEMonitorAcao, ret):
    #
    try:
        root = tree.fromstring(ret)
    except tree.ParseError:
        return '','Nao foi possivel processar XML de retorno de MDFe'
    body = root[1]
    result = body[0]
    ret = result[0]
    listCampos = list(ret)
    if codEMonitorAcao == ACAO_MDFE_RECEPCAOEVENTO3: # por enqto nao usado, apenas pra ficar sincronizado com codigos nfe/cte
        resp = {}
        resp['msgret'] = ''
        resp['nprot'] = ''
        resp['datahorareclote'] = ''
        resp['nprotinut'] = '' # nao usado
    #
    temErro = False
    msgRet = ''
    for campo in listCampos:
        tag = campo.tag
        value = campo.text
        if tag.endswith('cStat'): # por enqto nao usado, apenas pra ficar sincronizado com codigos nfe/cte
            if codEMonitorAcao == ACAO_MDFE_RECEPCAOEVENTO3:
                if (codEMonitorAcao == ACAO_MDFE_RECEPCAOEVENTO3 and value != RET_ENVLOTEEVENTO_NOERRO):
                    temErro = True
                    resp['msgret'] += '(' + value + ') '
        elif tag.endswith('xMotivo'):
            msgRet = value
            if codEMonitorAcao == ACAO_MDFE_RECEPCAOEVENTO3: # por enqto nao usado, apenas pra ficar sincronizado com codigos nfe/cte
                resp['msgret'] += value
    #
    if codEMonitorAcao == ACAO_MDFE_CONSULTAMDFDISTAUTO:
        return removeAccents(msgRet), ''
    else:
        # ACAO_CTE_RECEPCAOEVENTO3 ou ACAO_CTE_RECEPCAOEVENTO4 # por enqto nao usado, apenas pra ficar sincronizado com codigos nfe/cte
        if temErro:
            return resp, resp['msgret']
        else:
            return resp, ''


'''
def callMDFe(pfx_path, pfx_password, codEMonitorAcao, codUF, numUF, req, rsEMonitorUFAcao):
    #
    if codEMonitorAcao == ACAO_MDFE_CONSULTA3:
        request = requestConsulta(rsEMonitorUFAcao, req)
    elif codEMonitorAcao == ACAO_MDFE_STATUSSERVICO3:
        request = requestStatusServico(rsEMonitorUFAcao)
    request = requestHeader(rsEMonitorUFAcao, numUF) + request + requestFooter()
    #print(request)
    #
    url = rsEMonitorUFAcao['urlprinc']
    action = rsEMonitorUFAcao['urlacao']
    #
    response, erros = sefaz_spooler.processRequestSefaz(pfx_path, pfx_password, codEMonitorAcao, codUF, numUF, request, url, action)
    if erros != '':
        return '', erros
    else:
        return processResponse(codEMonitorAcao, response)


def requestHeader(rsEMonitorUFAcao, numUF):
    header = '<?xml version="1.0" encoding="utf-8" ?>'
    header += '<env:Envelope xmlns:env="http://www.w3.org/2003/05/soap-envelope" xmlns="' + rsEMonitorUFAcao['urlcabecmsg'] + '">'
    header += '<env:Header>'
    header += '<mdfeCabecMsg>'
    header += createtag('cUF', numUF)
    header += createtag('versaoDados', rsEMonitorUFAcao['versaodados'])
    header += '</mdfeCabecMsg>'
    header += '</env:Header>'
    return header


def requestFooter():
    return '</env:Envelope>'


def requestConsulta(rsEMonitorUFAcao, request):
    req = '<env:Body>'
    req += '<mdfeDadosMsg>'
    req += '<consSitMDFe xmlns="' + rsEMonitorUFAcao['urldadosmsgelement'] + '" versao="' + rsEMonitorUFAcao['versaodados'] + '">'
    req += createtag('tpAmb', rsEMonitorUFAcao['tpamb'])
    req += createtag('xServ', 'CONSULTAR')
    req += createtag('chMDFe', request)
    req += '</consSitMDFe>'
    req += '</mdfeDadosMsg>'
    req += '</env:Body>'
    return req


def requestStatusServico(rsEMonitorUFAcao):
    req = '<env:Body>'
    req += '<mdfeDadosMsg>'
    req += '<consStatServMDFe xmlns="' + rsEMonitorUFAcao['urldadosmsgelement'] + '" versao="' + rsEMonitorUFAcao['versaodados'] + '">'
    req += createtag('tpAmb', rsEMonitorUFAcao['tpamb'])
    req += createtag('xServ', 'STATUS')
    req += '</consStatServMDFe>'
    req += '</mdfeDadosMsg>'
    req += '</env:Body>'
    return req


def processResponse(codEMonitorAcao, ret):
    resp = ''
    erros = ''
    #
    root = tree.fromstring(ret)
    body = root[1]
    result = body[0]
    ret = result[0]
    listCampos = list(ret)
    #
    cStat = ''
    msgRet = ''
    for campo in listCampos:
        tag = campo.tag
        if tag.endswith('cStat'):
            cStat = campo.text
        elif tag.endswith('xMotivo'):
            msgRet = campo.text
    #
    if codEMonitorAcao == ACAO_MDFE_CONSULTA3:
        if cStat in ['100','101','132']:
            resp = '<msgRet>' + msgRet + '</msgRet>'
        else:
            erros = msgRet
    else:
        resp = '<msgRet>' + msgRet + '</msgRet>'
    #
    return removeAccents(resp), removeAccents(erros)
'''


