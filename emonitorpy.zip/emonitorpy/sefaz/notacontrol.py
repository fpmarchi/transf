import json
import sys
from collections import Callable
from functools import wraps
from typing import Tuple

import xmltodict

import nfse_spooler
from geral import conditional_key, deep_get, formatstrnum
from geralxml import *
from geralxml import dict_to_xml


# Define o tipo de exceção localValorIss
class NotaControlException(Exception):
    pass


# Decorators (Devem ser declarados antes do uso)
def _handle_exception(func: Callable) -> Callable:
    @wraps(func)
    def wrapper(*args, **kwargs) -> Tuple[str, str]:
        try:
            return func(*args, **kwargs)
        except NotaControlException as e:
            return '', str(e)
        except Exception as e:
            _, _, exc_tb = sys.exc_info()
            filename = exc_tb.tb_frame.f_code.co_filename
            debug = f'Erro inesperado em: {func.__name__} => {filename}:{exc_tb.tb_lineno}. Detalhes:\n{str(e)}'

            print(debug, file=sys.stderr)
            return '', 'Ocorreu um erro inesperado elaborar os XML de envio para a Nota Control.'

    return wrapper


def process_request_notacontrol(action: int, cod_ibge: int,
                                req: dict, assinatura: AssinaturaA1, tp_amb) -> Tuple[str, str]:
    if action == nfse_spooler.ACAO_NFSE_RECEPCAO:
        xml, erro = request_notacontrol_recepcao(cod_ibge, req, assinatura)
    elif action == nfse_spooler.ACAO_NFSE_CONSULTA_SITLOTE_RPS:
        xml, erro = request_notacontrol_consulta_sit_lote(req)
    elif action == nfse_spooler.ACAO_NFSE_CONSULTA_NFSE_POR_RPS:
        xml, erro = request_notacontrol_consulta_nfse_por_rps(req, assinatura)
    elif action == nfse_spooler.ACAO_NFSE_CANCELAMENTO:
        xml, erro = request_notacontrol_cancelamento(req, assinatura, tp_amb)
    elif action == nfse_spooler.ACAO_NFSE_IMPRIME_NFSE:
        xml, erro = request_notacontrol_imprime_nfse(req, assinatura)
    else:
        return '', 'Acao ' + str(action) + ' sem Implementação'

    return xml, erro


def envelop(service: str, data: str, version: int = 2.04):
    if not data:
        return data

    header = {
        'cabecalho': (
            {
                'versaoDados': '2.04'
            },
            {
                'attr': {
                    'versao': version,
                    'xmlns': 'http://www.abrasf.org.br/nfse.xsd'
                }
            }
        )
    }

    soap_env: dict = {
        'soapenv:Envelope': (
            {
                'soapenv:Header': None,
                'soapenv:Body': {
                    f'nfse:{service}': {
                        'nfseCabecMsg': dict_to_xml(header),
                        'nfseDadosMsg': data
                    }
                }
            },
            {
                'attr': {
                    'xmlns:soapenv': 'http://schemas.xmlsoap.org/soap/envelope/',
                    'xmlns:nfse': 'http://nfse.abrasf.org.br'
                }
            }
        )
    }

    return dict_to_xml(soap_env, indent=True, prolog=True)


def request_notacontrol_recepcao(cod_ibge: int, req: dict, assinatura: AssinaturaA1) -> Tuple[str, str]:
    rps, erros = xml_request_notacontrol_recepcao(req, cod_ibge)

    lote: dict = {
        'EnviarLoteRpsEnvio': (
            {
                'LoteRps': (
                    {
                        'NumeroLote': req.get('conh_nreclote', ''),
                        'Prestador': {
                            'CpfCnpj': {
                                'Cnpj': req.get('conh_filial_cnpjcpf', '')
                            },
                            'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
                        },
                        'QuantidadeRps': 1,
                        'ListaRps': {
                            'Rps': rps
                        }
                    },
                    {
                        'attr': {
                            'Id': 'lote' + req.get('conh_rps', ''),
                            'versao': '2.04'
                        }
                    },
                )
            },
            {
                'attr': {
                    'xmlns': 'http://www.abrasf.org.br/nfse.xsd'
                }
            }
        )
    }

    lote_str = dict_to_xml(lote)
    sign_str = assinatura.assinar(lote_str, True, 'Id', certificado_rpslote=True)
    lote_str = lote_str.replace('</Rps></ListaRps>', sign_str + '</Rps></ListaRps>')
    lote_str = assinatura.assinar(lote_str, True, 'Id', True)

    return envelop('RecepcionarLoteRps', lote_str), ''


def xml_request_notacontrol_recepcao(req: dict, cod_ibge: int):
    item_lista_servico = str(req.get('conh_codservico', ''))

    if '.' not in item_lista_servico:
        item_lista_servico = item_lista_servico[0:2] + '.' + item_lista_servico[2:4]

    rps: dict = {
        'InfDeclaracaoPrestacaoServico ': (
            {
                'Rps': {
                    'IdentificacaoRps': {
                        'Numero': req.get('conh_rps', ''),
                        'Serie': req.get('conh_serie', ''),
                        'Tipo': 1
                    },
                    'DataEmissao': req.get('conh_datahoraemissao', '').split('T')[0],
                    'Status': '1',
                },
                'Competencia': req.get('conh_datahoraemissao', '').split('T')[0],
                'Servico': {
                    'Valores': {
                        'ValorServicos': req.get('conh_freteempresa', 0),
                        'ValorDeducoes': 0,
                        'ValorPis': req.get('conh_valorpis', 0),
                        'ValorCofins': req.get('conh_valorcofins', 0),
                        'ValorIr': 0,
                        'ValorCsll': req.get('conh_valorvlcsll', 0),
                        'OutrasRetencoes': 0,
                        # 'ValorIss': req.get('conh_valoriss', 0),

                        **conditional_key('ValorIss', req.get('conh_valoriss', 0), (
                                req.get('conh_origem_cidade_codibge', '') != '5103403')),

                        #'Aliquota': formatstrnum(req.get('conh_taxaiss', 0)),
                        **conditional_key('Aliquota', formatstrnum(req.get('conh_taxaiss', 0)), (
                                    req.get('conh_origem_cidade_codibge', '') != '5103403' )),

                        # 'DescontoIncondicionado': 0,
                        # 'DescontoCondicionado': 0
                    },
                    'IssRetido': (1 if req.get('conh_pagaiss') == '2' else 2),
                    # **conditional_key('ResponsavelRetencao', '1', req.get('conh_pagaiss') == '2'),
                    'ItemListaServico': item_lista_servico,
                    'CodigoCnae': req.get('conh_cnae', ''),
                    # **conditional_key('CodigoCnae', req.get('conh_cnae', ''), cod_ibge != '5103403'),
                    'CodigoTributacaoMunicipio': req.get('conh_filial_regesptrib'),
                    'Discriminacao': req.get('conh_descservico'),
                    'CodigoMunicipio': req.get('conh_cliente_cidade_codibge') if req.get(
                        'conh_pagaiss') == '2' else cod_ibge,
                    # 'CodigoPais': '1058',
                    'ExigibilidadeISS': 1,
                    'MunicipioIncidencia': cod_ibge if req.get('conh_origem_cidade_codibge') == cod_ibge else req.get(
                        'conh_origem_cidade_codibge', '')
                },
                'Prestador': {
                    'CpfCnpj': {
                        'Cnpj': req.get('conh_filial_cnpjcpf', '')
                    },
                    'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
                },
                'TomadorServico': {
                    'IdentificacaoTomador': {
                        'CpfCnpj': {
                            'Cnpj' if len(req.get('conh_cliente_cnpjcpf', '')) > 11 else
                            'Cpf': req.get('conh_cliente_cnpjcpf', '')
                        }
                    },
                    'RazaoSocial': req.get('conh_cliente_nome', ''),
                    'Endereco': {
                        'Endereco': req.get('conh_cliente_endereco', ''),
                        'Numero': req.get('conh_cliente_numero', ''),
                        **conditional_key('Complemento', req.get('conh_cliente_complemento', '')),
                        'Bairro': req.get('conh_cliente_bairro', ''),
                        'CodigoMunicipio': req.get('conh_cliente_cidade_codibge', ''),
                        'Uf': req.get('conh_cliente_cidade_uf', ''),
                        'Cep': req.get('conh_cliente_cep', '')
                    },
                    'Contato': {
                        'Telefone': req.get('conh_cliente_fone', ''),
                        **conditional_key('Email', req.get('conh_cliente_email', ''))
                    }
                },
                # 'RegimeEspecialTributacao': '2',
                'OptanteSimplesNacional': '2',
                'IncentivoFiscal': '2',
            },
            {
                'attr': {
                    'Id': 'rps' + req.get('conh_rps', '')
                }
            },
        )
    }
    return dict_to_xml(rps), ''


def request_notacontrol_consulta_sit_lote(req: dict):
    xml = {
        'ConsultarLoteRpsEnvio': (
            {
                'Prestador': {
                    'CpfCnpj': {
                        'Cnpj' if len(req.get('conh_filial_cnpjcpf', '')) > 11 else
                        'Cpf': req.get('conh_filial_cnpjcpf', '')
                    },
                    'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
                },
                'Protocolo': req.get('conh_nprot', '')
            }, {
                'attr': {
                    'xmlns': 'http://www.abrasf.org.br/nfse.xsd'
                }
            }
        )
    }

    return envelop('ConsultarLoteRps', dict_to_xml(xml)), ''


def request_notacontrol_consulta_nfse_por_rps(req: dict, assinatura: AssinaturaA1):
    xml = {
        'ConsultarNfseRpsEnvio': (
            {
                'Pedido': (
                    {
                        'IdentificacaoRps': {
                            'Numero': req.get('conh_rps', ''),
                            'Serie': req.get('conh_serie', ''),
                            'Tipo': 1
                        },
                        'Prestador': {
                            'CpfCnpj': {
                                'Cnpj' if len(req.get('conh_filial_cnpjcpf', '')) > 11 else
                                'Cpf': req.get('conh_filial_cnpjcpf', '')
                            },
                            'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
                        }
                    },
                    {
                        'attr': {
                            'Id': 'rps' + req.get('conh_rps', '')

                        }
                    },
                )
            },
            {
                'attr': {
                    'xmlns': 'http://www.abrasf.org.br/nfse.xsd'
                }
            }
        )
    }

    xml_str = dict_to_xml(xml)
    xml_str = assinatura.assinar(xml_str, True, 'Id')
    xml_str = xml_str.replace('</ConsultarNfseRpsEnvio>', '')
    xml_str = xml_str.replace('</ConsultarNfseRpsEnvio>', '')
    xml_str = xml_str.replace('</Signature>', '</Signature></ConsultarNfseRpsEnvio>')

    xml_str = xml_str.replace(' Id=' + '"rps' + req.get('conh_rps', '') + '"', '')

    return envelop('ConsultarNfsePorRps', xml_str), ''


def request_notacontrol_cancelamento(req, assinatura, tp_amb):
    xml = {
        'CancelarNfseEnvio': (
            {
                'Pedido': {
                    'InfPedidoCancelamento': (
                        {
                            'IdentificacaoNfse': {
                                'Numero': req.get('conh_numeronfse', ''),
                                'CpfCnpj': {
                                    'Cnpj' if len(req.get('conh_filial_cnpjcpf', '')) > 11 else
                                    'Cpf': req.get('conh_filial_cnpjcpf', '')
                                },
                                'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
                                # servidor em homolog fica em CG então só da para cancelar por CG em homolog
                                'CodigoMunicipio': '5002704' if tp_amb == '2' else '5103403'
                            },
                            'CodigoCancelamento': 2
                        },
                        {
                            'attr': {
                                'Id': 'nfse' + req.get('conh_numeronfse', '')
                            }
                        }
                    )
                }
            },
            {
                'attr': {
                    'xmlns': 'http://www.abrasf.org.br/nfse.xsd'
                }
            }
        )
    }

    xml_str = dict_to_xml(xml)
    xml_str = assinatura.assinar(xml_str, True, 'Id')
    xml_str = xml_str.replace('</Pedido>', '')
    xml_str = xml_str.replace('</Signature>', '</Signature></Pedido>')

    return envelop('CancelarNfse', xml_str), ''


def request_notacontrol_imprime_nfse(req: dict, assinatura: AssinaturaA1):
    xml = {
        'ConsultarUrlNfseEnvio': (
            {
                'Pedido': (
                    {
                        'Prestador': {
                            'CpfCnpj': {
                                'Cnpj' if len(req.get('conh_filial_cnpjcpf', '')) > 11 else
                                'Cpf': req.get('conh_filial_cnpjcpf', '')
                            },
                            'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
                        },
                        'IdentificacaoRps': {
                            'Numero': req.get('conh_rps', ''),
                            'Serie': req.get('conh_serie', ''),
                            'Tipo': 1
                        },
                        'Pagina': 1
                    },
                    {
                        'attr': {
                            'Id': 'rps' + req.get('conh_rps', '')

                        }
                    },
                )
            },
            {
                'attr': {
                    'xmlns': 'http://www.abrasf.org.br/nfse.xsd'
                }
            }
        )
    }

    xml_str = dict_to_xml(xml)
    xml_str = assinatura.assinar(xml_str, True, 'Id')
    xml_str = xml_str.replace('</ConsultarUrlNfseEnvio>', '')
    xml_str = xml_str.replace('</ConsultarUrlNfseEnvio>', '')
    xml_str = xml_str.replace('</Signature>', '</Signature></ConsultarUrlNfseEnvio>')

    xml_str = xml_str.replace(' Id=' + '"rps' + req.get('conh_rps', '') + '"', '')

    return envelop('ConsultarUrlNfse', xml_str), ''


def process_response_notacontrol(action: int, cod_ibge: int, ret: str):
    resp: dict = deep_get(xmltodict.parse(ret), 'env:Envelope.env:Body')

    try:
        result = {}
        numero_nfe = ''

        error_500 = deep_get(xmltodict.parse(ret.replace('.', '')),
                            's:Envelope.s:Body.s:Fault')
        if error_500:
            result = {
                'sucesso': False,
                'erros': [ {
                    'codigo': error_500.get('faultcode'),
                    'mensagem': error_500.get('faultstring'),
                    'sugestao': error_500.get('faultstring')
                }]
            }
        elif action == nfse_spooler.ACAO_NFSE_RECEPCAO:
            resp = deep_get(xmltodict.parse(ret.replace('.', '')),
                            's:Envelope.s:Body.RecepcionarLoteRpsResponse.EnviarLoteRpsResposta')

            if resp.get('Protocolo'):
                result = {
                    'sucesso': True,
                    'lote': resp.get('NumeroLote', ''),
                    'data_recebimento': resp.get('DataRecebimento', ''),
                    'protocolo': resp.get('Protocolo', ''),
                }
            else:
                result = {
                    'sucesso': False,
                    'erros': process_response_list_element(
                        deep_get(resp, 'ListaMensagemRetorno')),
                }
        elif action == nfse_spooler.ACAO_NFSE_CONSULTA_SITLOTE_RPS:
            resp = deep_get(xmltodict.parse(ret.replace('.', '')),
                            's:Envelope.s:Body.ConsultarLoteRpsResponse.ConsultarLoteRpsResposta')

            situacao = resp.get('Situacao')
            if situacao == '3' or situacao == '2':
                result = {
                    'sucesso': False,
                    'erros': process_response_list_element(
                        deep_get(resp, 'ListaMensagemRetorno')),
                }
            elif situacao == '4':
                data: dict = deep_get(resp, 'ListaNfse.CompNfse')
                data = data if type(data) is list else [data]
                result = {
                    'sucesso': True,
                    'situacao': situacao,
                    'notas': []
                }
                for target in data:
                    target: dict = deep_get(target, 'Nfse.InfNfse')
                    result['notas'].append({
                        'status': deep_get(target,
                                           'DeclaracaoPrestacaoServico.InfDeclaracaoPrestacaoServico.Rps.Status'),
                        'numero': target.get('Numero', ''),
                        'codigo_verificacao': target.get('CodigoVerificacao', ''),
                        'data_emissao': target.get('DataEmissao', ''),
                        'pdf': target.get('OutrasInformacoes', '')
                    })
        elif action == nfse_spooler.ACAO_NFSE_CONSULTA_NFSE_POR_RPS:
            response = deep_get(xmltodict.parse(ret.replace('.', '')), 's:Envelope.s:Body.ConsultarNfsePorRpsResponse')

            data: dict = deep_get(response, 'ConsultarNfseRpsResposta.CompNfse.Nfse.InfNfse')
            cancel: dict = deep_get(response, 'ConsultarNfseRpsResposta.CompNfse.NfseCancelamento.Confirmacao')

            if cancel:
                cod_cancel = deep_get(cancel, 'Pedido.InfPedidoCancelamento.CodigoCancelamento', '')
                result = {
                    'sucesso': True,
                    'data_confirmacao': cancel.get('DataHora', ''),
                    'status': 2,
                    'numero': data.get('Numero', ''),
                    'codigo_verificacao': data.get('CodigoVerificacao', ''),
                    'data_emissao': data.get('DataEmissao', ''),
                    'pdf': data.get('OutrasInformacoes', ''),
                    'codigo_cancelamento': cod_cancel,
                    'motivo_cancelamento': {
                        '1': 'Erro na emissão',
                        '2': 'Serviço não prestado',
                        '3': 'Erro de assinatura',
                        '4': 'Duplicidade da nota',
                        '5': 'Erro de processamento'
                    }.get(cod_cancel, '')
                }
            elif data:
                result = {
                    'sucesso': True,
                    'status': deep_get(data, 'DeclaracaoPrestacaoServico.InfDeclaracaoPrestacaoServico.Rps.Status'),
                    'numero': data.get('Numero', ''),
                    'codigo_verificacao': data.get('CodigoVerificacao', ''),
                    'data_emissao': data.get('DataEmissao', ''),
                    'pdf': data.get('OutrasInformacoes', '')
                }
            else:
                result = {
                    'sucesso': False,
                    'erros': process_response_list_element(
                        deep_get(response, 'ConsultarNfseRpsResposta.ListaMensagemRetorno')),
                }
        elif action == nfse_spooler.ACAO_NFSE_CANCELAMENTO:
            response = deep_get(xmltodict.parse(ret.replace('.', '')), 's:Envelope.s:Body.CancelarNfseResponse')
            data: dict =  deep_get(response, 'CancelarNfseResposta.RetCancelamento.NfseCancelamento.Confirmacao')

            if data:
                cod_cancel = deep_get(data, 'Pedido.InfPedidoCancelamento.CodigoCancelamento', '')
                result = {
                    'sucesso': True,
                    'data_confirmacao': data.get('DataHora', ''),
                    'codigo_cancelamento': cod_cancel,
                    'motivo_cancelamento': {
                        '1': 'Erro na emissão',
                        '2': 'Serviço não prestado',
                        '3': 'Erro de assinatura',
                        '4': 'Duplicidade da nota',
                        '5': 'Erro de processamento'
                    }.get(cod_cancel, '')
                }
            else:
                result = {
                    'sucesso': False,
                    'erros': process_response_list_element(
                        deep_get(response,'CancelarNfseResposta.ListaMensagemRetorno'))
                }
        elif action == nfse_spooler.ACAO_NFSE_IMPRIME_NFSE:
            response = deep_get(xmltodict.parse(ret), 's:Envelope.s:Body.ConsultarUrlNfseResponse')
            data: dict = deep_get(response, 'ConsultarUrlNfseResposta.ListaLinks.Links')
            if data:
                result = {
                    'sucesso': True,
                    'url_visualizacao_nfse': data.get('UrlVisualizacaoNfse', ''),
                    'url_verifica_autenticidade': data.get('UrlVerificaAutenticidade', ''),
                }
            else:
                result = {
                    'sucesso': False,
                    'erros': process_response_list_element(
                        deep_get(response, 'ConsultarNfseRpsResposta.ListaMensagemRetorno')),
                }

        return '<json><![CDATA[' + json.dumps(result) + ']]></json>', '', numero_nfe

    except Exception as e:
        return '', 'EMPY: Erro ao tratar retorno da Nota Control: ' + str(e), ''


def process_response_list_element(data_: Tuple[dict, list]) -> list:
    if not data_:
        return []

    data_ = data_ if type(data_) is list else [data_]

    try:
        result_list = []
        msg: dict
        msg2: dict
        if deep_get(data_[0], 'MensagemRetorno.Codigo'):
            for msg in data_:
                msg = msg.get('MensagemRetorno', {})
                result_list.append({
                    'codigo': msg.get('Codigo', ''),
                    'mensagem': msg.get('Mensagem', ''),
                    'sugestao': msg.get('Correcao', '')
                })
        else:
            for msg in data_:
                msg = msg.get('MensagemRetorno', {})
                for msg2 in msg:
                    result_list.append({
                        'codigo': msg2.get('Codigo', ''),
                        'mensagem': msg2.get('Mensagem', ''),
                        'sugestao': msg2.get('Correcao', '')
                    })
        return result_list

    except (Exception,):
        return []
