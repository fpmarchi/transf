import xml.etree.ElementTree as tree
import gzip
import base64
import geral

spools = geral.filetostr('/home/edilmar/Downloads/emonitorspool.txt').split('\n')

ct = 0
for spool in spools:
    if spool is None or spool == '':
        continue
    if 'loteDistDFeInt' not in spool:
        continue
    ct += 1
    print(str(ct))
    root = tree.fromstring(spool)
    node = root[0][0][7]
    if node is None:
        print('erro1')
        continue
    node = list(node)  # lista de docZip
    if node is None or len(node) == 0:
        print('erro2')
        continue
    for item in node:
        xml = item.text
        try:
            xml = gzip.decompress(base64.b64decode(xml)).decode()
            if '51220827559782000150550010000192921658526902' in xml:
                print('achou')
                geral.strtofile('/home/edilmar/Downloads/51220827559782000150550010000192921658526902.xml', xml)
        except Exception as e:
            print('Erro gzip.decompress')
            print(e)
            continue


