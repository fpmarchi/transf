import base64
import fnmatch
import gzip
import os
import stat
from datetime import datetime
from io import BytesIO
from os.path import join, normpath, dirname
from typing import Callable, Iterable

import pysftp
from paramiko.sftp import SFTPError
from paramiko.sftp_attr import SFTPAttributes

from ActionProcessor import handle_exception_factory
from geral import static_vars, safe_cast, conditional_key

# In MB
_MAX_FILE_SIZE = 10


class SFTPException(Exception):
    pass


class File:
    name: str
    original_name: str
    path: str
    content: BytesIO

    def __init__(self, content=None):
        if content is None:
            content = BytesIO()

        self.content = content


def _sftp_exception_callback(data: dict) -> dict:
    command_index = process_commands.command_index
    result = {
        'sucess': False,
        **conditional_key('command_index', command_index, command_index >= 0),
        'msg_error': data.get('ex_message', '')
    }

    return result


def _sftp_unexpected_exception_callback(data: dict) -> dict:
    ex = data.get('ex')
    try:
        if ex and isinstance(ex, SFTPError):
            msg_error = f'Erro na comunicação SFTP: {ex.args[0]} - {ex.args[1]}'
        elif ex and isinstance(ex, PermissionError):
            msg_error = 'O seu usuário não tem permissão para realizar essa operação'
        else:
            msg_error = data.get('default_return')(data)[1]
    except (Exception,):
        msg_error = 'Não foi possível obter a descrição do erro'

    command_index = process_commands.command_index
    result = {
        'sucess': False,
        **conditional_key('command_index', command_index, command_index >= 0),
        'msg_error': msg_error
    }

    return result


_handle_exception = handle_exception_factory(
    SFTPException,
    _sftp_exception_callback,
    _sftp_unexpected_exception_callback
)


#
# Definição de middleware
#
@static_vars(GZIP_MAGIC_NUMBER=b'\037\213')
def _middleware_gzip_decompress(file: File):
    if file.content.read(2) != _middleware_gzip_decompress.GZIP_MAGIC_NUMBER:
        return

    file.content.seek(0)
    gz = gzip.GzipFile(fileobj=file.content, mode='r')
    file.content = gz
    file.name = file.name.rstrip('.gz')


#
# Definição de wrappers
#
def _cd_wrapper(sftp_conn: pysftp.Connection, params: dict):
    path = params.get('path')
    try:
        sftp_conn.chdir(path)
    except FileNotFoundError:
        raise SFTPException('O diretório informado não existe')
    except SFTPError as e:
        if e.args[0] == 20:
            raise SFTPException('O caminho informado não é um diretório')
        raise e

    return {
        'command': 'cd',
        'current_dir': sftp_conn.pwd
    }


@static_vars(middleware_config={
    'gzip_decompress': _middleware_gzip_decompress
})
def _get_wrapper(sftp_conn: pysftp.Connection, params: dict):
    common_filters = params.get('filters', {})
    common_middlewares = params.get('middlewares', [])
    files = params.get('files', [])
    folder_ls = {}
    files_to_get = []
    added_files = []

    result = {
        'command': 'get',
        'current_dir': sftp_conn.pwd,
        'files': []
    }

    for file_info in files:
        path = file_info.get('path', '')

        if not file_info.get('filters'):
            file_info['filters'] = common_filters

        if not file_info.get('middlewares'):
            file_info['middlewares'] = common_middlewares

        file_name = path.rsplit('/', 1)[-1]
        is_glob = any(e in file_name for e in ['*', '?', '[', ']'])
        if is_glob:
            base_dir = dirname(join(sftp_conn.pwd, path))
            if not folder_ls.get(base_dir):
                ls_result = _ls_wrapper(sftp_conn, {'path': base_dir, 'filters': file_info['filters']})

                if not ls_result.get('success'):
                    result['files'].append(ls_result)
                    continue
            else:
                ls_result = folder_ls[base_dir]

            for file in ls_result.get('file_list', []):
                if file.get('is_folder') or file.get('full_path') in added_files:
                    continue

                if fnmatch.fnmatch(file.get('name'), file_name):
                    added_files.append(file.get('full_path'))
                    files_to_get.append({
                        'path': file.get('full_path'),
                        'middlewares': file_info['middlewares']
                    })
        else:
            files_to_get.append(file_info)

    for file in files_to_get:
        path = file.get('path', '')
        middlewares = file.get('middlewares')

        file_ = File()
        file_.name = os.path.basename(path)
        file_.original_name = file_.name
        try:
            info = sftp_conn.stat(path)
            if info.st_size > _MAX_FILE_SIZE * 1024 * 1024:
                raise SFTPException('Não é permitido obter arquivos maiores que ' + str(_MAX_FILE_SIZE) + 'MB')

            if stat.S_ISDIR(info.st_mode):
                raise SFTPException('Só é possível obter um arquivo, o caminho informado é de um diretório')

            sftp_conn.getfo(path, file_.content)
        except (SFTPException, FileNotFoundError) as ex:
            if ex and isinstance(ex, FileNotFoundError):
                error = 'O arquivo informado não existe'
            else:
                error = str(ex)

            result['files'].append({
                'success': False,
                'msg_error': error
            })

            continue

        file_.content.seek(0)
        for middleware_name in middlewares:
            middleware = _get_wrapper.middleware_config.get(middleware_name)

            if callable(middleware):
                middleware(file_)
                file_.content.seek(0)

        content = base64.b64encode(file_.content.read()).decode('ascii')
        file_.content.close()

        result['files'].append({
            'success': True,
            'name': file_.name,
            'original_name': file_.original_name,
            'path': sftp_conn.normalize(path),
            'encoded_in': 'base64',
            'file_content': content
        })

    return result


def _put_wrapper(sftp_conn: pysftp.Connection, params: dict):
    files = params.get('files', [])

    result = {
        'command': 'put',
        'current_dir': sftp_conn.pwd,
        'files': []
    }
    for file in files:
        path = file.get('path', '')
        content = file.get('content', '')

        data = BytesIO()
        data.write(base64.b64decode(content))

        file_ = File(data)
        file_.content.seek(0)
        try:
            sftp_conn.putfo(file_.content, path)

            result['files'].append({
                'success': True,
                'path': sftp_conn.normalize(sftp_conn.pwd + '/' + path),
            })
        except FileNotFoundError:
            result['files'].append({
                'success': False,
                'msg_error': 'O caminho não existe no servidor SFTP'
            })
            continue

        file_.content.close()

    return result


def _filter_date(data: dict) -> Callable[[SFTPAttributes], bool]:
    start = None
    if 'start' in data:
        try:
            start = datetime.strptime(data.get('start'), '%Y-%m-%dT%H:%M:%S').timestamp()
        except (Exception,):
            raise SFTPException('Erro ao ler a propriedade start do filtro "date"')

    end = None
    if 'end' in data:
        try:
            end = datetime.strptime(data.get('end'), '%Y-%m-%dT%H:%M:%S').timestamp()
        except (Exception,):
            raise SFTPException('Erro ao ler a propriedade end do filtro "date"')

    def filter_(file_info: SFTPAttributes) -> bool:
        mod_time = file_info.st_mtime

        return (not start or start < mod_time) and (not end or mod_time < end)

    return filter_


@static_vars(filter_config={
    'date': _filter_date
})
def _ls_wrapper(sftp_conn: pysftp.Connection, params: dict):
    filters = params.get('filters', {})
    path = params.get('path')

    try:
        info_list: Iterable[SFTPAttributes] = sftp_conn.listdir_attr(path)
    except FileNotFoundError:
        return {
            'success': False,
            'msg_error': 'O caminho não existe no servidor SFTP'
        }

    base_path = normpath(join(sftp_conn.pwd, path))
    if not base_path.endswith('/'):
        base_path += '/'

    try:
        for ft_name, ft_data in filters.items():
            filter_ = _ls_wrapper.filter_config.get(ft_name)

            if callable(filter_):
                info_list = filter(filter_(ft_data), info_list)
    except SFTPException as e:
        return {
            'success': False,
            'msg_error': str(e)
        }

    return {
        'command': 'ls',
        'success': True,
        'current_dir': sftp_conn.pwd,
        'file_list': list(
            {
                'name': info.filename,
                'full_path': base_path + info.filename,
                'is_folder': stat.S_ISDIR(info.st_mode),
                'last_modification': datetime.fromtimestamp(info.st_mtime).isoformat()
            } for info in info_list
        )
    }


def _rm_wrapper(sftp_conn: pysftp.Connection, params: dict):
    files = params.get('files', [])
    folder_ls = {}
    files_to_delete = []
    added_files = []

    for file_info in files:
        path = file_info.get('path', '')

        file_name = path.rsplit('/', 1)[-1]
        is_glob = any(e in file_name for e in ['*', '?', '[', ']'])
        if is_glob:
            base_dir = dirname(join(sftp_conn.pwd, path))
            if not folder_ls.get(base_dir):
                try:
                    ls_result = _ls_wrapper(sftp_conn, {'path': base_dir})
                    folder_ls[base_dir] = ls_result
                except FileNotFoundError:
                    return {
                        'success': False,
                        'msg_error': 'O caminho não existe no servidor SFTP'
                    }
            else:
                ls_result = folder_ls[base_dir]

            for file in ls_result.get('file_list', []):
                if file.get('is_folder') or file.get('full_path') in added_files:
                    continue

                if fnmatch.fnmatch(file.get('name'), file_name):
                    added_files.append(file.get('full_path'))
                    files_to_delete.append({
                        'path': file.get('full_path'),
                        'middlewares': file_info['middlewares']
                    })
        else:
            files_to_delete.append(file_info)

    files = []
    result = {
        'command': 'rm',
        'current_dir': sftp_conn.pwd,
        'files': files
    }

    for file in files_to_delete:
        path = file.get('path', '')
        ret = {
            'success': True
        }

        try:
            sftp_conn.remove(path)
            ret['path'] = normpath(join(sftp_conn.pwd, path))
        except FileNotFoundError:
            ret['success'] = False
            ret['msg_error'] = 'O arquivo não existe no servidor SFTP'

        files.append(ret)

    return result


def _rmdir_wrapper(sftp_conn: pysftp.Connection, params: dict):
    path = params.get('path')

    try:
        ls_result = _ls_wrapper(sftp_conn, {'path': path})
    except FileNotFoundError:
        return {
            'success': False,
            'msg_error': 'O caminho não existe no servidor SFTP'
        }

    if ls_result.get('file_list', []):
        return {
            'success': False,
            'msg_error': 'Para ser removido, o diretório, deve estar vazio'
        }

    result = {
        'command': 'rmdir',
        'current_dir': sftp_conn.pwd,
        'file': normpath(join(sftp_conn.pwd, path)),
        'success': True,
    }

    try:
        sftp_conn.rmdir(path)
    except FileNotFoundError:
        return {
            'success': False,
            'msg_error': 'A pasta não existe no servidor SFTP'
        }

    return result


#
# Função de entrada de wrappers
#
@_handle_exception
@static_vars(commands={
    'cd': _cd_wrapper,
    'get': _get_wrapper,
    'put': _put_wrapper,
    'ls': _ls_wrapper,
    'rm': _rm_wrapper,
    'rmdir': _rmdir_wrapper
}, command_index=-1)
def process_commands(config: dict):
    if not config.get('url'):
        raise SFTPException('URL não informada')
    if not config.get('login'):
        raise SFTPException('Login não informado')
    if not config.get('password'):
        raise SFTPException('Senha não informado')

    process_commands.command_index = -1
    command_catalog = process_commands.commands
    url = config.get('url')
    port = safe_cast(config.get('port', 22), int)
    login = config.get('login')
    senha = config.get('password')

    results = []
    cnopts = pysftp.CnOpts()
    cnopts.hostkeys = None
    with pysftp.Connection(url, port=port, username=login, password=senha, cnopts=cnopts) as sftp_conn:
        ret = {
            'success': True,
            'results': results
        }

        for command_spec in config.get('commands', []):
            process_commands.command_index += 1

            name = command_spec.get('name')
            method = command_catalog.get(name)

            if not method:
                raise SFTPException(f'O comando {name}, não é suportado')

            if not command_spec.get('params'):
                raise SFTPException(f'A propriedade "params" deve ser informada')

            results.append(method(sftp_conn, command_spec.get('params')))

    return ret
