import json
from typing import Tuple
from urllib.parse import urlparse, urlunparse

from requests import Response, post

from dispacher import ActionProcessor
from dispacher.action_processor import HttpMethod
from dispacher.decorators import handle_exception_factory, parse_props
from geral import deep_get, conditional_key
from geralxml import mount_xml_response


class EfreteHubException(Exception):
    pass


class EfreteHub(ActionProcessor):
    HOST = ''
    TEST_HOST = 'https://dev.efrete.com.br'

    GENERATE_TOKEN = 1800
    CONSULT_TOLLS = 1801
    ADD_TOLL_VOUCHER = 1802
    CONSULT_TOLLS_TICKET = 1803
    CANCEL_TOLL_VOUCHER = 1804
    GET_PDF_RECEIPT = 1805

    def __init__(self):
        self.BASE_PATH = '/Services'
        self.TEST_BASE_PATH = '/Services'

        super().__init__()

        self.add_callable_records('url', {
            self.GENERATE_TOKEN: self.make_url_assembler('/Logon/Login'),
            self.CONSULT_TOLLS: self.make_url_assembler('/ValePedagioParceiro/ConsultarPedagiosv2'),
            self.ADD_TOLL_VOUCHER: self.make_url_assembler('/ValePedagioParceiro/AdicionarValePedagiov2',),
            self.CONSULT_TOLLS_TICKET: self.make_url_assembler('/ValePedagioParceiro/ConsultarValePedagio',
                                                               HttpMethod.GET),
            self.CANCEL_TOLL_VOUCHER: self.make_url_assembler('/ValePedagioParceiro/CancelarValePedagio'),
            self.GET_PDF_RECEIPT: self.make_url_assembler('/ValePedagioParceiro/ObterReciboPdf', HttpMethod.GET),

        })

    __token_cache: dict = {}

    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        try:

            headers = {'Content-type': 'application/json'}

            return headers, ''

        except(Exception,):
            return {}, 'Por favor verifique as credenciais de acesso para Efrete Vale Pedagio!'

    def _get_token(self) -> str:
        data = self.context
        props = data.get('props')

        password = props.get('senha', '')
        username = props.get('usuario', '')
        integrator = props.get('token', '')

        if not username or not password or not integrator:
            raise Exception('O nome, email ou token não foram informados.')

        url = data.get('url')
        parsed_uri = list(urlparse(url))
        parsed_uri[2] = ''

        local_ctx = {
            'url': urlunparse(parsed_uri),
            'props': props
        }
        url = self.dispatch(self.GENERATE_TOKEN, local_ctx, 'url')[0]

        if not url:
            raise EfreteHubException('Não foi possível obter a URL de para requisitar o token.')

        try:
            auth_request = {
                'Senha': password,
                'Usuario': username,
                'Integrador': integrator,
                'Versao': 1,
            }

            resp = post(url, json=auth_request)
        except Exception as e:
            raise EfreteHubException('Erro ao buscar token de autorização na Efrete Vale Pedagio!\n' + str(e))

        if resp.status_code == 200:
            token = resp.json().get('Token', '')
            if token:
                return token
            else:
                raise EfreteHubException(
                    'Ocorreu um erro ao tentar realizar a autenticação: ' + deep_get(resp.json(), 'Excecao.Mensagem'))
        else:
            raise EfreteHubException('Erro ao obter token: ' + resp.content.decode('utf-8'))


#
#   Códigos independentes de instancia EfreteHub
#

# Tratamento de exceções
def _efretehub_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi92623 possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a Efrete Hub Vale Pedagio:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    EfreteHubException,
    _efretehub_exception_callback,
    any_exception_callback
)

#
#   Códigos dependentes de instancia
#

# Instancia limpa e sem configuração (singleton)
_efretehub = EfreteHub()

# Decorators da instancia
_link_to_request = _efretehub.link_to_factory('request')
_link_to_response = _efretehub.link_to_factory('response')


# Login paragerar o token Bearer para realizar as autenticações
@_link_to_request(_efretehub.CONSULT_TOLLS)
@_handle_exception
def _out_consult_tolls(req: dict, props: dict):
    points_of_interest = []

    if req.get('envio_pontos_interesses', ''):
        points_of_interest = req.get('envio_pontos_interesses', '').split(',')

    req_data = {
        'Integrador': props.get('token', ''),
        'Versao': 1,
        'Token': _efretehub._get_token(),
        'ParceiroPedagio': req.get('parceiro_pedagio', ''),
        'ClienteCpfCnpj': req.get('cnpj_empresa', ''),
        'EmbarcadorCpfCnpj': req.get('conh_prop_cnpjcpf', ''),

        # Futuramente pode ser utilizado, pois atualmente não está na v2
        # 'Origem': {
        #     'CodigoMunicipio': safe_cast(req.get('conh_codibgeorig', ''), int, 0),
        #     **conditional_key('Latitude', safe_cast(req.get('conh_lat_cid_origem', ''), float, 0), not not req.get('conh_lat_cid_origem')),
        #     **conditional_key('Longitude', safe_cast(req.get('conh_lon_cid_origem', ''), float, 0),
        #                       not not req.get('conh_lon_cid_origem')),
        # },
        # 'Destino': {
        #     'CodigoMunicipio': safe_cast(req.get('conh_codibgedest', ''), int, 0),
        #     **conditional_key('Latitude', req.get('conh_lat_cid_destino', ''), not not req.get('conh_lat_cid_destino')),
        #     **conditional_key('Longitude', req.get('conh_lon_cid_destino', ''),
        #                       not not req.get('conh_lat_cid_destino')),
        # },

        **conditional_key('PontosInteresse', points_of_interest, not not points_of_interest),

        # 'CodigoRota': req.get('codrota_efrete', ''),
        'RetornarRotasAlternativas': False,
        'RetornarImagemRota': True,
        'TipoVeiculo': req.get('tipo_veiculo', ''),
        'NumeroEixos': req.get('quant_eixo_cavalo', ''),
        'Placa': req.get('conh_veic_placa', ''),
        'TipoRodagem': req.get('tipo_rodagem', ''),
    }

    return json.dumps(req_data), ''


@_link_to_request(_efretehub.ADD_TOLL_VOUCHER)
@_handle_exception
def _out_add_toll_voucher(req: dict, props: dict):
    req_data = {
        'Integrador': props.get('token', ''),
        'Versao': 1,
        'Token': _efretehub._get_token(),
        'ParceiroPedagio': req.get('parceiro_pedagio', ''),
        'ClienteCpfCnpj': req.get('cnpj_empresa', ''),
        'EmbarcadorCpfCnpj': req.get('conh_prop_cnpjcpf', ''),

        # Futuramente pode ser utilizado, pois atualmente não está na v2
        # 'CodigoMunicipioOrigem': safe_cast(req.get('conh_codibgeorig', ''), int, 0),
        # 'CodigoMunicipioDestino': safe_cast(req.get('conh_codibgedest', ''), int, 0),
        # 'CodigoRota': req.get('codrota_efrete', ''),

        'TipoVeiculo': req.get('tipo_veiculo', ''),
        'NumeroEixos': req.get('quant_eixo_cavalo', ''),
        'Placa': req.get('conh_veic_placa', ''),
        'CodigoContrato': req.get('ciot_efrete', ''),
        'Valor': req.get('valor_pedagio', 0),

        'PracasPedagio': [
            {
                'CodigoAntt': toll_place.get('codigo_antt_praca_pedagio', ''),
                'Sentido': toll_place.get('sentido_praca_pedagio', ''),
                'Valor': toll_place.get('valor_praca_pedagio', '')
            }
            for toll_place in req.get('pracas_pedagio', [])
        ],

        'DataValidade': req.get('conh_dataprevisaodescarga', ''),
        'TipoRodagem': req.get('tipo_rodagem', ''),
    }

    return json.dumps(req_data), ''


@_link_to_request(_efretehub.CONSULT_TOLLS_TICKET)
@_handle_exception
def _out_consult_tolls_ticket(req: dict, props: dict):
    req_data = {
        'Integrador': props.get('token', ''),
        'Versao': 1,
        'Token': _efretehub._get_token(),
        'ClienteCpfCnpj': req.get('cnpj_empresa', ''),
        'CodigoValePedagio': req.get('codigo_vale_pedagio', ''),
    }

    return json.dumps(req_data), ''


@_link_to_request(_efretehub.CANCEL_TOLL_VOUCHER)
@_handle_exception
def _out_cancel_toll_voucher(req: dict, props: dict):
    req_data = {
        'Integrador': props.get('token', ''),
        'Versao': 1,
        'Token': _efretehub._get_token(),
        'ClienteCpfCnpj': req.get('cnpj_empresa', ''),
        'CodigoValePedagio': req.get('codigo_vale_pedagio', ''),
        'Motivo': req.get('motivo', ''),
    }

    return json.dumps(req_data), ''


@_link_to_request(_efretehub.GET_PDF_RECEIPT)
@_handle_exception
def _out_get_pdf_receipt(req: dict, props: dict):
    req_data = {
        'Integrador': props.get('token', ''),
        'Versao': 1,
        'Token': _efretehub._get_token(),
        'ClienteCpfCnpj': req.get('cnpj_empresa', ''),
        'CodigoValePedagio': req.get('codigo_vale_pedagio', ''),
    }

    return json.dumps(req_data), ''


#
# Tratamento de retornos
@_link_to_response(_efretehub.DEFAULT_FUNCTION)
@_handle_exception
def _in_default(resp: Response) -> Tuple[str, str]:
    ret = resp.json()

    error = deep_get(ret, 'Excecao.Mensagem')

    try:
        if error:
            resp_data = {
                'sucesso': False,
                'msg_erro': error
            }
        elif 'Sucesso' in ret and ret.get('Sucesso'):
            resp_data = {
                'sucesso': True,
                'conteudo': ret
            }
        else:
            resp_data = {
                'sucesso': False,
                'msg_erro': ret
            }
    except Exception as e:
        resp_data = {
            'sucesso': False,
            'msg_erro': 'Ocorreu um erro desconhecido ao tentar retornar as informações do EmonitorPy:\n' + str(e)
        }

    return mount_xml_response(resp_data), ''
