from vale_pedagio.efretehub import EfreteHub

_efretehub = EfreteHub.get_instance(min_action=1800, max_action=1849)
