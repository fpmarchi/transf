from jproperties import Properties
from geral import timems, filedatetimemodified, filetostr, strtofile
from sqlalchemy.sql import *
from sefaz.dao import getInstEmpAll
from entity.emonitor.metadata import getConnPG, getEnginePGLight


certs_path = '/sistemas/emonitor/certificados/'
inst_path = '/sistemas/emonitor/instalacoes/'
prop_path = inst_path + '100010/1/emonitor.properties'
prop_dh = filedatetimemodified(prop_path)


def loadProperties():
    prop = Properties()
    with open(prop_path, "rb") as f:
        prop.load(f)
    useProp = prop["UseProp"].data == "S"
    if useProp:
        return prop
    else:
        try:
            engineEMonitor = getEnginePGLight(prop, 'EMonitor')
            with getConnPG(engineEMonitor) as conn:
                inst_emp_all = getInstEmpAll(conn)
            for instemp in inst_emp_all:
                instalacao = instemp["codinstalacao"]
                empresa = instemp["codempresa"]
                email = instemp["enddestemailsair"]
                nome_cert = instemp["nomearqcertifcliente"]
                senha_cert = instemp["senhacertifcliente"]
                check_exp = instemp["checkexpcertifcliente"]
                prop.load(f"EndDestEMailSair{instalacao}_{empresa}={email}\n")
                prop.load(f"nomeArqCertifCliente{instalacao}_{empresa}={nome_cert}\n")
                prop.load(f"senhaCertifCliente{instalacao}_{empresa}={senha_cert}\n")
                prop.load(f"checkExpCertifCliente{instalacao}_{empresa}={check_exp}\n")
            return prop
        except Exception as e:
            print(f"Erro ao coletar properties do BD: {e}")


def saveProperty(propname: str, propvalue: str, propsep: str, overwrite: bool):
    try:
        global prop
        propvalueactual = prop[propname].data
        if overwrite:
            prop[propname] = propvalue
        else:
            if propvalueactual is None or propvalueactual == '':
                propvalueactual = ''
                prop[propname] = propvalue
            else:
                prop[propname] = prop[propname].data + propsep + propvalue
        propstr = filetostr(prop_path)
        propstr = propstr.replace(propname + '=' + propvalueactual, propname + '=' + prop[propname].data, 1)
        strtofile(prop_path, propstr)
        #saveProperties()
        loadProperties()
        return True
    except Exception as e:
        print('Erro em saveProperty')
        print(e)
        return False


# nao da para usar, pois bagunca o layout do properties
# def saveProperties():
#     global prop
#     with open(prop_path, "wb") as f:
#         prop.store(f, encoding="utf-8")


def appendProperties(properties: str):
    try:
        propstr = filetostr(prop_path) + '\n#\n' + properties
        strtofile(prop_path, propstr)
        loadProperties()
        return True
    except Exception as e:
        print('Erro em appendProperties')
        print(e)
        return False


def getProperty(property) -> str:
    try:
        global prop
        return prop[property].data
    except Exception as a:
        return ''


def usePropDist() -> bool:
    try:
        global prop
        return prop['UsePropDist'].data == 'S'
    except Exception as a:
        return True # default sempre usar properties e nao BD


def isTipoBDDistFB() -> bool:
    try:
        global prop
        return prop['TipoBDDist'].data == 'FB'
    except Exception as a:
        return True # default sempre usar FB se nao tiver property definida


def isTipoBDDistPG() -> bool:
    return not isTipoBDDistFB()


def getCertProperties(conn, codInstalacao, codEmpresa, tipo):
    useProp = getProperty("UseProp") == "S"
    if conn and not useProp:
        return getCertPropertiesBD(conn, codInstalacao, codEmpresa, tipo)
    else:
        try:
            global prop
            global prop_dh
            prop_dh_actual = filedatetimemodified(prop_path)
            if prop_dh_actual > prop_dh:
                print('Relendo arquivo emonitor.properties devido alteracao...')
                prop = loadProperties()
                prop_dh = prop_dh_actual
            pfx_path = prop['nomeArqCertifCliente'+str(codInstalacao)+'_'+str(codEmpresa)].data
            pfx_password = prop['senhaCertifCliente'+str(codInstalacao)+'_'+str(codEmpresa)].data
            return pfx_path, pfx_password
        except Exception as a:
            if tipo == 0:
                print('ERRO: getCertProperties - ' + str(codInstalacao) + ' - ' + str(codEmpresa) + ' com problema no properties')
            return '', ''


def getCertPropertiesBD(conn,codInstalacao,codEmpresa,tipo):
    try:
        pfx_path, pfx_password = getCertInstEmp(conn, codInstalacao, codEmpresa)
        if (pfx_path == '' or pfx_password == '') and tipo == 0:
            print('ERRO: getCertProperties - ' + str(codInstalacao) + ' - ' + str(codEmpresa) + ' nao encontrado do BD')
        return pfx_path, pfx_password
    except Exception as a:
        if tipo == 0:
            print('ERRO: getCertProperties - ' + str(codInstalacao) + ' - ' + str(codEmpresa) + ' com problema no BD')
        return '', ''


# tive que mover do arquivo dao.py para ca, devido a referencia ciclica de imports
def getCertInstEmp(conn, inst, emp):
    sql = text('SELECT nomearqcertifcliente, senhacertifcliente '
               'FROM instemp '
               'WHERE codinstalacao = :codinstalacao '
               'AND codempresa = :codempresa '
               '')
    sql = sql.bindparams(codinstalacao=inst)
    sql = sql.bindparams(codempresa=emp)
    #print(sql)
    rs = conn.execute(sql)
    dados = rs.fetchone()
    if dados is None:
        return '', ''
    else:
        return dados['nomearqcertifcliente'], dados['senhacertifcliente']


def getOutrasInstalacoes():
    useProp = getProperty("UseProp") == "S"
    if useProp:
        list(getProperty('OutrasInstalacoes').split(','))
    else:
        engineEMonitor = getEnginePGLight(prop, 'EMonitor')
        with getConnPG(engineEMonitor) as conn:
            inst_emp_all = getInstEmpAll(conn)

        inst_emp_list = []
        for inst_emp in inst_emp_all:
            inst = inst_emp["codinstalacao"]
            emp = inst_emp["codempresa"]
            inst_emp_list.append(f"{inst}_{emp}")
        return inst_emp_list


def getPrimeiraOutrasInstalacoes():
    return "376_1"


def getInstalacoesDist(instalacoes):
    return list(instalacoes.split(','))


def getCamposDist(instalacao):
    listCampos = list(instalacao.split('_'))
    if len(listCampos) == 4:
        lenCnpjCpf = len(listCampos[2])
        lenUF = len(listCampos[3])
        if lenCnpjCpf != 11 and lenCnpjCpf != 14:
            return '', 'ERRO: Nao foi informado o campo cnpjcpf com 11 ou 14 posicoes - ' + listCampos[2], '', ''
        elif lenUF != 2 or not listCampos[3].isdigit():
            return '', 'ERRO: Nao foi informado o campo uf com 2 posicoes ou nao contem apenas digitos - ' + listCampos[3], '', ''
        else:
            return listCampos[0],listCampos[1],listCampos[2],listCampos[3]
    else:
        return '','ERRO: Nao foram informados os 4 campos inst_emp_cnpjcpf_uf','',''


def isDuplInst(instalacao, listInstalacoes):
    for item in listInstalacoes:
        if item[0] == instalacao:
            return True
    return False


def getCamposInst(instalacao):
    listCampos = list(instalacao.split('_'))
    if len(listCampos) == 2:
        return listCampos[0],listCampos[1]
    else:
        return '',''


def getCamposInstDist(instalacao):
    listCampos = list(instalacao.split('_'))
    if len(listCampos) == 4:
        return listCampos[0],listCampos[1],listCampos[2],listCampos[3]
    else:
        return '','','',''


def getTokenByCnpjCpf(cnpjcpf, listTokens):
    for itemToken in listTokens:
        if itemToken[0] == cnpjcpf:
            actualms = timems()
            tokenms = itemToken[2]
            if actualms - tokenms <= 43200000: # 12 hs de validade (mas nao achei no manual)
                return itemToken[1]
            else:
                listTokens.remove(itemToken)
                return ''
    return ''


def getTokenByLoginSenha(login, senha, listTokens):
    # 0 - login | 1 - senha | 2 - token | 3 - tempo de validade | 4 - data de geracao do token
    try:
        for itemToken in listTokens:
            if itemToken[0] == login and itemToken[1] == senha:
                actualms = timems()  # tempo em segundos
                validadeToken = itemToken[3] * 1000  # Tempo de validade do access_token em segundos -> convertido em ms.
                tokenms = itemToken[4]
                if actualms - tokenms <= validadeToken:
                    return itemToken[1]
                else:
                    listTokens.remove(itemToken)
                    return ''
        return ''
    except Exception as e:
        print('Erro em getTokenByLoginSenha')
        print(e)
        return ''


VERSAO = 'emonitorpy 0.656'
print('\n' + VERSAO)
prop = loadProperties()
