import base64
import re
from io import StringIO
from json import dumps
from typing import Any, Union, List
from xml.etree import ElementTree
from xml.sax import saxutils
from xml.sax.saxutils import escape
import subprocess

import signxml
import xmlschema
from Crypto.Hash import SHA
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5
from lxml import etree
from signxml import XMLSigner

from entity.certificado import CertificadoA1
from geral import round_by_abnt, strtofile, filetostr


def createtag(tag, value):
    return createtag2(tag, '', value)


def createtag2(tag, sufixtag, value):
    return '<' + tag + sufixtag + '>' + value + '</' + tag + '>'


def gettagstring(xml: str, tag: str, beginIndex: int = 0, noAttributes: bool = True, noFields: bool = False) -> str:
    indexIni: int
    indexFim: int
    s: str
    if noFields:
        s = '<' + tag + ' '
        indexIni = xml.find(s, beginIndex)
        if indexIni == -1:
            return ''
        indexIni += len(s)
        indexFim = xml.find('/>', indexIni)
        if indexFim == -1:
            return ''
    else:
        if noAttributes:
            s = '<' + tag + '>'
            indexIni = xml.find(s, beginIndex)
            if indexIni == -1:
                return ''
            indexIni += len(s)
        else:
            s = '<' + tag + ' '
            indexIni = xml.find(s, beginIndex)
            if indexIni == -1:
                return ''
            indexIni = xml.find('>', indexIni)
            if indexIni == -1:
                return ''
            indexIni += 1
        indexFim = xml.find('</' + tag + '>', indexIni)
        if indexFim == -1:
            # PENDENTE: ainda nao descobri pq tem XMLs ficando com ENTER aqui
            indexFim = xml.find('</\n' + tag + '>', indexIni)
            if indexFim == -1:
                return ''
    return xml[indexIni:indexFim]


def toString(elementXml):
    return ElementTree.tostring(elementXml).decode()


def findChildNodeByName(parent, name):
    for node in parent[0].childNodes:
        if node.nodeType == node.ELEMENT_NODE and node.localName == name:
            return getText(node.childNodes)
    return None


def getText(nodelist):
    rc = []
    for node in nodelist:
        if node.nodeType == node.TEXT_NODE:
            rc.append(node.data)
    return ''.join(rc)


# IMPORTANTE: para usar este metodo, é necessario ter o projeto do emonitor.jar atualizado
def assinarXML(nomeBaseXML, strXML, pfx_path, pfx_password):
    try:
        arqXML = '/sistemas/emonitor/tmp/' + nomeBaseXML + '.xml'
        strtofile(arqXML, strXML)
        isDebug = False
        if isDebug:
            emonitor_path = '/sistemas/emonitor/dist/emonitor.jar'
        else:
            emonitor_path = '/sistemas/emonitor/emonitor.jar'
        # /usr/bin/java -jar /sistemas/emonitor/emonitor.jar assinarxml '/home/edilmar/lixo.xml' infEvento '/sistemas/emonitor/instalacoes/2072/1/cert/cert.pfx' 'serasa'
        cmd = '/usr/bin/java -jar ' + emonitor_path + ' assinarxml ' + arqXML + ' infEvento ' + pfx_path + ' ' + pfx_password + ''
        proc = subprocess.run(cmd.split(' '))
        if proc.returncode != 0:
            msgRet = 'Erro ao assinar XML usando emonitor.jar'
            print(msgRet)
            return '', msgRet
        arqXMLAss = '/sistemas/emonitor/tmp/' + nomeBaseXML + '.ass.xml'
        strXML = filetostr(arqXMLAss)
        strXML = strXML[54:]  # tirar <?xml version="1.0" encoding="UTF-8" standalone="no"?>
        # assinatura = AssinaturaA1(certificado=pfx_path, senha=pfx_password)
        # strXML = assinatura.assinar(strXML=strXML, retorna_string=True)
        return strXML
    except Exception as e:
        raise Exception(e)


NAMESPACE_SIG = 'http://www.w3.org/2000/09/xmldsig#'


class Assinatura(object):
    """Classe abstrata responsavel por definir os metodos e logica das classes
    de assinatura digital."""

    certificado = None
    senha = None

    def __init__(self, certificado, senha, autorizador=None):
        self.certificado = certificado
        self.senha = senha
        self.autorizador = autorizador

    def assinar(self, xml):
        """Efetua a assinatura da nota"""
        pass


# site de validacao de assinaturas: https://servicos.receita.fazenda.gov.br/servicos/assinadoc/ValidadorAssinaturas.app/valida.aspx
class AssinaturaA1(Assinatura):

    def __init__(self, certificado, senha, raw_cert=False):
        self.key, self.cert = CertificadoA1(certificado, raw_cert).separar_arquivo(senha)

    def assinar(self, strXML, retorna_string=False, nome_atrib_id='Id', certificado_lote=False,
                certificado_rpslote=False):
        xml = etree.fromstring(strXML)

        # busca tag que tem id(reference_uri), logo nao importa se tem namespace
        element_id = xml.find(".//*[@" + nome_atrib_id + "]")
        if certificado_rpslote:
            element_id = element_id.find(".//*[@" + nome_atrib_id + "]")
            method = signxml.methods.detached
        else:
            method = signxml.methods.enveloped
        reference = element_id.attrib[nome_atrib_id]

        strXML = etree.tostring(xml, encoding="utf-8", pretty_print=False).decode("utf-8")
        xml = etree.fromstring(strXML)

        signer = XMLSigner(
            method=method, signature_algorithm="rsa-sha1",
            digest_algorithm='sha1',
            c14n_algorithm='http://www.w3.org/TR/2001/REC-xml-c14n-20010315')

        ns = {None: signer.namespaces['ds']}
        signer.namespaces = ns

        ref_uri = ('#%s' % reference) if reference else None
        signed_root = signer.sign(xml, key=self.key, cert=self.cert, reference_uri=ref_uri)

        ns = {'ns': NAMESPACE_SIG}
        # coloca o certificado na tag X509Data/X509Certificate
        tagX509Data = signed_root.find('.//ns:X509Data', namespaces=ns)
        if certificado_lote:
            tagX509Data = signed_root.findall('.//ns:X509Data', namespaces=ns)[1]
        etree.SubElement(tagX509Data, 'X509Certificate').text = self.cert
        if retorna_string:
            return etree.tostring(signed_root, encoding="utf-8", pretty_print=False).decode("utf-8")
        else:
            return signed_root

    def assinar_elemento(self, strXML, field: str, attrib_id='Id', prolog=False):
        root: ElementTree = etree.fromstring(strXML)

        # busca tag que tem id(reference_uri), logo nao importa se tem namespace
        element: ElementTree = root.find('.//{*}' + field)
        reference = element.attrib[attrib_id]
        method = signxml.methods.enveloped

        parent = element.find('..')
        relative_root = parent.find('..')

        is_root = True
        if relative_root is not None:
            relative_root.remove(parent)
            is_root = False

        signer = XMLSigner(
            method=method, signature_algorithm="rsa-sha1",
            digest_algorithm='sha1',
            c14n_algorithm='http://www.w3.org/TR/2001/REC-xml-c14n-20010315')

        ns = {None: signer.namespaces['ds']}
        signer.namespaces = ns

        ref_uri = ('#%s' % reference) if reference else None
        signed_root = signer.sign(parent, key=self.key, cert=self.cert, reference_uri=ref_uri)

        tagX509Data = signed_root.find('.//{*}X509Data', namespaces=ns)
        etree.SubElement(tagX509Data, 'X509Certificate').text = self.cert

        if is_root:
            root = signed_root
        else:
            relative_root.append(signed_root)

        return etree.tostring(root, encoding="utf-8", xml_declaration=prolog).decode("utf-8")

    def assinar_elementos(self, xml, tag_name: str, attrib_id='Id', id_value=None, prolog=False,
                          apply_sign_ns=True):

        def get_sign_namespaces(node: ElementTree):
            final_ns = {}
            while apply_sign_ns:
                node = node.getparent()

                if node is None:
                    break

                final_ns = {**final_ns, **node.nsmap}

            if not final_ns:
                return {None: signxml.namespaces.ds}
            else:
                return final_ns

        parser = etree.XMLParser(remove_blank_text=True)
        root: ElementTree = etree.fromstring(xml, parser)

        if id_value:
            elements: ElementTree = root.findall(f'.//{{*}}{tag_name}[@{attrib_id}=\'{id_value}\']')
        else:
            elements: ElementTree = root.findall(f'.//{{*}}{tag_name}')

        signer = XMLSigner(
            c14n_algorithm='http://www.w3.org/TR/2001/REC-xml-c14n-20010315',
            signature_algorithm="rsa-sha1",
            digest_algorithm="sha1",
            method=signxml.methods.detached
        )
        signer.excise_empty_xmlns_declarations = True

        for element in elements:
            reference = element.attrib[attrib_id]
            parent = element.getparent()
            signer.namespaces = get_sign_namespaces(element)

            ref_uri = ('#%s' % reference) if reference else None
            sign = signer.sign(parent, key=self.key, cert=self.cert, reference_uri=ref_uri)

            certs: List[ElementTree] = sign.findall('.//{*}X509Certificate')
            if not certs:
                x509_data = sign.find('.//{*}X509Data')
                etree.SubElement(x509_data, 'X509Certificate').text = self.cert.replace('\n', '')
            else:
                cert = certs[0]
                cert.text = cert.text.replace('\n', '')

            parent.append(sign)

        return etree.tostring(root, encoding=str, xml_declaration=prolog)

    def assinarStr(self, strSign):
        hash = SHA.new(strSign.encode())
        pkey = RSA.importKey(self.key)
        strSign = PKCS1_v1_5.new(pkey).sign(hash)
        strSign = base64.b64encode(strSign).decode()
        return strSign


def validateSchema(strXML, pathSchema):
    try:
        schema = xmlschema.XMLSchema(pathSchema)
        schema.validate(strXML)
        return ''
    except Exception as e:
        erros = 'Erro de Validacao de XML: ' + e.elem.tag + ' => ' + str(e.obj)
        return erros


def dict_to_xml(dictionary: dict, root: str = None, indent: bool = False, prolog: bool = False):
    xml_string = StringIO()

    def append_tuple(tp: tuple):
        xml_string.write(''.join(tp))

    def parse(target: Any, base, level=0, list_item='item'):
        type_ = type(target)

        before = ''
        if indent:
            before = ''.ljust(level, '\t')

        if target is None:
            append_tuple((before, '<', base, '/', end))
            return
        elif type_ is not tuple or type(target[0]) is not list:
            append_tuple((before, '<', base))

        if (type_ is tuple) and (type(target[1]) is dict):
            if target[1].get('cdata') is True:
                append_tuple((end, before, ('\t' if indent else ''), '<![CDATA[', target[0], ']]', end))
            else:
                attr = ''.join(f' {k}="{v}"' for k, v in target[1].get('attr', {}).items())

                if type_ is not tuple or type(target[0]) is not list:
                    append_tuple((attr, end))

                if type(target[0]) is dict:
                    for k, v in target[0].items():
                        parse(v, str(k), level + 1)
                elif type(target[0]) is str:
                    xml_string.write(target[0])
                else:
                    parse(target[0], base, level + 1, target[1].get('list_item', 'item'))
                    return
        elif type_ in [list, set]:
            xml_string.write(end)
            for v in target:
                parse(v, list_item, level + 1)
        elif type_ is dict:
            xml_string.write(end)
            for k, v in target.items():
                parse(v, str(k), level + 1)
        else:
            append_tuple(('>', str(target), '</', base, end))
            return

        append_tuple((before, '</', base, end))

    end = '>\n' if indent else '>'
    if prolog:
        append_tuple(('<?xml version="1.0" encoding="utf-8" ?', end))

    if len(dictionary.keys()) == 1 and not root:
        fist = next(iter(dictionary.items()))
        parse(fist[1], fist[0])
    else:
        root = root.strip() or 'root'
        parse(dictionary, root)

    return xml_string.getvalue()


def xml_from_dict(dictionary: dict, wrap: str = None, indent: bool = False, prolog: bool = False, escape: bool = False,
    indent_with_space = False, indent_space_size = 4):
    xml_string = StringIO()
    path_pattern = re.compile(r"(?<!\\)\.")
    is_first = True

    if indent_with_space:
        indent_block = ' ' * indent_space_size
    else:
        indent_block = '/t'

    def append_tuple(tuple_: tuple):
        xml_string.write(''.join(tuple_))

    def parse(value: Any, root: str, namespace='', level=0):
        if type(root) is tuple:
            namespace = root[1] + ':'
            root = root[0]
        items_key = 'itens'
        append_root = True
        if root.startswith(('@', '#')):
            if root.startswith('#items'):
                items_key = root.split('>')[1]
                append_root = False
                level = level - 1
            else:
                return

        type_ = type(value)

        attr = ''
        if type_ == dict:
            attr = ['='.join((str(k[1:]), f'"{v}"'))
                    for k, v in value.items()
                    if type(k) is str and k.startswith('@')
                    ] or ''

            if attr:
                attr = ' ' + ' '.join(attr)

            if '#ns' in value:
                namespace = value['#ns'] + ':'

            if '#value' in value:
                value = value['#value']
                type_ = type(value)

            # if '#items' in value:
            #     value = value['#items']
            #     type_ = type(value)

        indent_str = ''
        nonlocal is_first
        if indent:
            indent_str = '' if is_first else '\n' + indent_block * level

        keys: List[str] = path_pattern.split(root)
        if len(keys) > 1:
            parse({'.'.join(keys[1:]): value}, keys[0], namespace, level)
            return

        root = (root + '>' + items_key).rsplit('>')
        tag = (namespace + root[0]).replace('\\', '')
        if value is None:
            append_tuple((indent_str, '<', tag, attr, '/>'))
            return
        if append_root:
            append_tuple((indent_str, '<', tag, attr, '>'))

        if indent and is_first:
            indent_str = '\n' + indent_str
            is_first = False

        if type_ == dict:
            for k, v in value.items():
                parse(v, k, namespace, level + 1)
        elif type_ in [list, set, tuple]:
            for v in value:
                parse(v, root[1], namespace, level + 1)
        elif type_ is bytes:
            append_tuple(('<![CDATA[', str(value, 'utf-8'), ']]>'))
            indent_str = ''
        elif type_ is float:
            xml_string.write('{:.2f}'.format(round_by_abnt(value)))
            indent_str = ''
        else:
            xml_string.write(str(value))
            indent_str = ''
        if append_root:
            append_tuple((indent_str, '</', tag, '>'))

        is_first = False

    if prolog:
        append_tuple(('<?xml version="1.0" encoding="utf-8" ?>',))
        is_first = False

    if len(dictionary.keys()) == 1:
        wrap = list(dictionary.keys())[0]
        dictionary = dictionary[wrap]
    else:
        wrap = wrap or 'root'

    parse(dictionary, wrap)

    if escape:
        return saxutils.escape(xml_string.getvalue())
    else:
        return xml_string.getvalue()


def mount_xml_response(data: Union[dict, list, str], error=False, prolog=False, url='') -> str:
    """
        Retorna o XML de retorno contendo o JSON carregado a partir do
        dicionario informado no parâmetro data

        :param error: bool
        :param data: dict
        :param prolog: (Opcional) bool. Adiciona a linha de prolog do XML
        :param url: (Opcional) str. Utilizado para retorno completo de url
        :return: XML String with JSON from data input
    """
    return xml_from_dict({
        'resp': {
            'erro': 't' if error else 'f',
            'json': escape(dumps(data, ensure_ascii=False)),
            'url': url
        }
    }, prolog=prolog)
