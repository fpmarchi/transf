import json
import logging
from datetime import datetime
from enum import Enum
from functools import wraps
from string import Template
from typing import Tuple

from requests import Response

from ActionProcessor import ActionProcessor, Callable_cfg, handle_exception_factory
from geral import conditional_key
from geralxml import mount_xml_response

_log = logging.getLogger(__name__)


# Creating enumerations using class
class HttpMethod(Enum):
    DELETE = 0
    GET = 1
    POST = 2


# Creating custom exception
class PolisoftwareException(Exception):
    pass


# Classe principal para configuração da ActionProcessor
class Polisoftware(ActionProcessor):
    # Supplies
    CONFIRM_CAPTURED_SUPPLY = 3750
    CONSULT_SUPPLIES = 3751
    CONSULT_SUPPLY_BY_PERIOD = 3752
    # Entities
    ADD_ENTITY_PLATE = 3753
    CONSULT_ENTITY = 3754
    CONSULT_ENTITY_PLATE = 3755
    INACTIVATE_ENTITY = 3756
    ADD_OR_UPDATE_ENTITY = 3757
    REMOVE_ENTITY_PLATE = 3758
    # Drivers
    CONSULT_DRIVER = 3759
    INACTIVATE_DRIVER = 3760
    ADD_OR_UPDATE_DRIVER = 3761
    # License Plates/Vehicles
    CONSULT_PLATE = 3762
    INACTIVATE_PLATE = 3763
    ADD_OR_UPDATE_PLATE = 3764
    # Nozzle
    CONSULT_NOZZLE = 3766
    # Utils
    SYNCHRONIZE_BASES = 3765

    def __init__(self, min_action: int, max_action: int):
        self.MIN_ACTION = min_action
        self.MAX_ACTION = max_action

        self.add_callable_records('url', {
            # Supplies
            self.CONFIRM_CAPTURED_SUPPLY: _confirm_captured_supply_url,
            self.CONSULT_SUPPLIES: _consult_supplies_url,
            self.CONSULT_SUPPLY_BY_PERIOD: _consult_supply_by_period_url,
            # Entities
            self.ADD_ENTITY_PLATE: _add_entity_plate_url,
            self.CONSULT_ENTITY_PLATE: _consult_entity_plate_url,
            self.REMOVE_ENTITY_PLATE: _remove_entity_plate_url,
            self.CONSULT_ENTITY: (_entity_with_id_url, {'method': HttpMethod.GET}),
            self.INACTIVATE_ENTITY: (_entity_with_id_url, {'method': HttpMethod.DELETE}),
            self.ADD_OR_UPDATE_ENTITY: lambda context: (
                context.get('url') + '/datasnap/rest/TDSEntidade/Entidade', HttpMethod.POST.name
            ),
            # Drivers
            self.CONSULT_DRIVER: (_driver_with_id_url, {'method': HttpMethod.GET}),
            self.INACTIVATE_DRIVER: (_driver_with_id_url, {'method': HttpMethod.DELETE}),
            self.ADD_OR_UPDATE_DRIVER: lambda context: (
                context.get('url') + '/datasnap/rest/TDSMotorista/Motorista', HttpMethod.POST.name
            ),
            # License Plates/Vehicles
            self.CONSULT_PLATE: (_plate_with_id_url, {'method': HttpMethod.GET}),
            self.INACTIVATE_PLATE: (_plate_with_id_url, {'method': HttpMethod.DELETE}),
            self.ADD_OR_UPDATE_PLATE: lambda context: (
                context.get('url') + '/datasnap/rest/TDSPlaca/Placa', HttpMethod.POST.name
            ),
            # Nozzle
            self.CONSULT_NOZZLE: (_nozzle_with_id_url, {'method': HttpMethod.GET}),
            # Utils
            self.SYNCHRONIZE_BASES: lambda context: (
                context.get('url') + '/datasnap/rest/TDSUtils/Sincroniza', HttpMethod.GET.name
            )
        })

        request_builders: Callable_cfg = {
            self.ADD_OR_UPDATE_ENTITY: _add_or_update_entity_body,
            self.ADD_OR_UPDATE_DRIVER: _add_or_update_driver_body,
            self.ADD_OR_UPDATE_PLATE: _add_or_update_plate_body,
            self.DEFAULT_FUNCTION: lambda data: (None, '')
        }

        response_parsers: Callable_cfg = {
            self.DEFAULT_FUNCTION: _receive_reply
        }

        super().__init__(request_builders, response_parsers)


# Decorators (Devem ser declarados antes do uso)
def _polisoftware_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a Polisoftware'


_handle_exception = handle_exception_factory(
    PolisoftwareException,
    _polisoftware_exception_callback,
    any_exception_callback
)


def _endpoint(path_template: str, http_method=HttpMethod.GET, ):
    def decorator(func):
        t = Template('$host/datasnap/rest' + path_template)

        @wraps(func)
        def _wrapper(*args, **kwargs):
            data = func(*args, **kwargs)

            return t.substitute(data), data.get('method', http_method).name

        return _wrapper

    return decorator


# Funções para criação do corpo da requisição
@_handle_exception
def _add_or_update_entity_body(req: dict) -> Tuple[str, str]:
    result = []

    for entity in req:
        result.append({
            **conditional_key('id_entidade', entity.get('id_entidade')),
            'nome': entity.get('nome', ''),
            'codbarra': entity.get('cod_barras'),
            'validarplaca': entity.get('valida_placas', True),
            'ativo': entity.get('ativo', True),
            'cpfcnpj': entity.get('cgccpf', '')
        })

    return json.dumps(result), ''


@_handle_exception
def _add_or_update_driver_body(req: dict) -> Tuple[str, str]:
    result = []

    for driver in req:
        result.append({
            **conditional_key('codmotorista', driver.get('cod_mot')),
            'codbarra': driver.get('cod_barras', ''),
            'senha': driver.get('senha_mot', ''),
            'nomemotorista': driver.get('nome_mot', ''),
            'ativo': driver.get('ativo', True)
        })

    return json.dumps(result), ''


@_handle_exception
def _add_or_update_plate_body(req: dict) -> Tuple[str, str]:
    result = []

    for veic in req:
        result.append({
                **conditional_key('codplaca', veic.get('cod_veic')),
                'codbarra': veic.get('cod_barras', ''),
                'tag_rfid': veic.get('rfid', ''),
                'placa': veic.get('placa', ''),
                'veiculo': veic.get('descricao', ''),
                'tipoodometro': 1,
                'ativo': True,
                'tp_veiculo': veic.get('propriedade', 'P'),
                'arla': veic.get('usa_arla', False),
                'codmotorista': veic.get('polisoftware_motorista', 0),
                'id_entidade': veic.get('polisoftware_entidade', 0),
                'km_max': veic.get('autonomia_km', 0),
                'km_atual': veic.get('km_atual', 0),
                'hr_atual': veic.get('hora_atual', 0),
                'hr_max': veic.get('autonomia_hora', 0),
                'id_produto': 0,
                'validacombustivel': False
            })

    return json.dumps(result), ''


# Funções para criação da URL
# Abastecimento
@_handle_exception
@_endpoint('/TDSAbastecida/Capturada/$supply_id')
def _confirm_captured_supply_url(req: dict, url: str) -> dict:
    return {
        'host': url,
        'supply_id': req.get('ui_abastecida', 0),
    }


@_handle_exception
@_endpoint('/TDSAbastecida/Abastecida/$supply_id/$captured/$limit/$offset')
def _consult_supplies_url(req: dict, url: str) -> dict:
    return {
        'host': url,
        'supply_id': req.get('ui_abastecida', 0),
        'captured': req.get('capturada', 2),
        'limit': req.get('limit', 20),
        'offset': req.get('offset', 0)
    }


@_handle_exception
@_endpoint('/TDSAbastecida/AbastecidaPorPeriodo/$start_date/$end_date')
def _consult_supply_by_period_url(req: dict, url: str) -> dict:
    return {
        'host': url,
        'start_date': datetime.strptime(req.get('datainicial', ''), '%d/%m/%Y').strftime('%d.%m.%Y'),
        'end_date': datetime.strptime(req.get('datafinal', ''), '%d/%m/%Y').strftime('%d.%m.%Y')
    }


# Entidade
@_handle_exception
@_endpoint('/TDSEntidade/IncluiPlaca/$entity_id/$plate_cod')
def _add_entity_plate_url(req: dict, url: str) -> dict:
    return {
        'host': url,
        'entity_id': req.get('id_entidade', 0),
        'plate_cod': req.get('codplaca', 0)
    }


@_handle_exception
@_endpoint('/TDSEntidade/Entidade/$entity_id')
def _entity_with_id_url(req: dict, url: str, method: HttpMethod) -> dict:
    return {
        'host': url,
        'entity_id': req.get('id_entidade', 0),
        'method': method
    }


@_handle_exception
@_endpoint('/TDSEntidade/Placas/$entity_id')
def _consult_entity_plate_url(req: dict, url: str) -> dict:
    return {
        'host': url,
        'entity_id': req.get('id_entidade', 0)
    }


@_handle_exception
@_endpoint('/TDSEntidade/RemovePlaca/$entity_id/$plate_cod')
def _remove_entity_plate_url(req: dict, url: str) -> dict:
    return {
        'host': url,
        'entity_id': req.get('id_entidade', 0),
        'plate_cod': req.get('codplaca', 0)
    }


# Driver
@_handle_exception
@_endpoint('/TDSMotorista/Motorista/$driver_id')
def _driver_with_id_url(req: dict, url: str, method: HttpMethod) -> dict:
    return {
        'host': url,
        'driver_id': req.get('cod_motorista', 0),
        'method': method
    }


# License Plates/Vehicles
@_handle_exception
@_endpoint('/TDSPlaca/Placa/$plate_cod')
def _plate_with_id_url(req: dict, url: str, method: HttpMethod) -> dict:
    return {
        'host': url,
        'plate_cod': req.get('cod_placa', 0),
        'method': method
    }


# Nozzle
@_handle_exception
@_endpoint('/TDSBico/Bico/$cod_nozzle')
def _nozzle_with_id_url(req: dict, url: str, method: HttpMethod) -> dict:
    return {
        'host': url,
        'cod_nozzle': req.get('cod_bico', 0),
        'method': method
    }


# Funções para tratamento de retorno
@_handle_exception
def _receive_reply(resp: Response):
    ret = resp.json() or []
    return mount_xml_response(ret), ''
