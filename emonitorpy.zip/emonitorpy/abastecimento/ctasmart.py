import logging
from enum import Enum
from typing import Tuple

from requests import Response

from ActionProcessor import Callable_cfg
from geralxml import mount_xml_response

from ActionProcessor import ActionProcessor

_log = logging.getLogger(__name__)


class HttpMethod(Enum):
    DELETE = 0
    GET = 1
    POST = 2


# Creating custom exception
class CtasmartException(Exception):
    pass


# Classe principal para configuração da ActionProcessor
class Ctasmart(ActionProcessor):
    # method
    SYNC_SUPPLY = 3900

    def __init__(self, min_action: int, max_action: int):
        self.MIN_ACTION = min_action
        self.MAX_ACTION = max_action

        self.add_callable_records('url', {
            self.SYNC_SUPPLY: url_sync_supply,
        })

        request_builders: Callable_cfg = {
            self.SYNC_SUPPLY: _sync_supply,
        }

        response_parsers: Callable_cfg = {
            self.SYNC_SUPPLY: _sync_supply_response,
        }
        super().__init__(request_builders, response_parsers)


def url_sync_supply(url: str):
    return url, ''


# Decorators (Devem ser declarados antes do uso)
def _ctasmart_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback() -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a Ctasmart'


def _sync_supply() -> Tuple[None, str]:
    return None, ''


def _sync_supply_response(resp: Response):
    resp_json = resp.json()
    success = resp.status_code in [200, 201, 204]
    resp_body = {'sucesso': success}
    if success:
        resp_body['conteudo'] = resp_json
    elif 'error' in resp_json or len(resp_json) == 0:
        resp_body['sucesso'] = False
        resp_body[
            'msg_erro'] = 'O cadastro ainda não foi realizado, é necessário cadastrar antes para buscar informações'
    else:
        raise CtasmartException('Não foi possível encontrar um retorno conhecido da CtaSmart')
    return mount_xml_response(resp_body), ''
