#!/bin/sh

PYTHONPATH="${PYTHONPATH}:$(find "$(pwd)" -type d ! -path '**/venv*' ! -path '**/__pycache__*' ! -path '**/.*' -printf '%p:')"

export PYTHONPATH
exec /usr/local/bin/gunicorn --bind 0.0.0.0:5000 $@
