import requests
import base64
import gzip
import xml.dom.minidom as mdom
import sys
import os
import shutil
import geral
from createLinks import createLinks


dirss='/sistemas/sitesat2-is/'

args = sys.argv[1:]
if args is None or len(args) == 0 or args[0] != '2':
    ativo = ''
else:
    ativo = '2' # se ativo=2 entao contingencia

response = requests.get('http://websaf.intersite.com.br:8082/emonitorws/webresources/ws/lcis').content.decode()
xml = gzip.decompress(base64.b64decode(response)).decode()
lista = mdom.parseString(xml)
insts = lista.getElementsByTagName('i')
strIndex = geral.filetostr('index.html')
shutil.rmtree(dirss)
os.mkdir(dirss)
for inst in insts:
    servidor = inst.childNodes[0].childNodes[0].data.lower()
    nomeReduz = inst.childNodes[1].childNodes[0].data.lower()
    print('Processando ' + servidor + ' - ' + nomeReduz + ' ...')
    #
    createLinks(servidor, nomeReduz, ativo, dirss, strIndex)



