import base64
import os
import json
import decimal, datetime
import geral
from flask import jsonify
from metadata import getConnPG
from ParametroEmpresaDAO import getValorByDescricao
from sqlalchemy import text


# https://codeandlife.com/2014/12/07/sqlalchemy-results-to-json-the-easy-way/
def alchemyencoder(obj):
    """JSON encoder function for SQLAlchemy special classes."""
    if isinstance(obj, datetime.date):
        return obj.isoformat()
    elif isinstance(obj, decimal.Decimal):
        return float(obj)


def getQuery(engine,request):
    responseJSON = {}
    try:
        with getConnPG(engine) as conn:
            #
            schema = request.args.get('db')
            conn.execute(text('set schema \'' + schema + '\''))
            #
            token = request.args.get('t')
            tokenBD = getValorByDescricao(conn,'WSGetQueryToken')
            if token != tokenBD:
                responseJSON['erro'] = 'Token invalido para acesso.'
                return json.dumps(responseJSON)
            #
            sql = base64.b64decode(request.data.decode()).decode()
            # arqtmp = '/sistemas/emonitorpy/tmp/' + schema + '.sql'
            # cmd = 'echo \'' + request.data.decode() + '\' | base64 -d > ' + arqtmp
            # os.system(cmd)
            # sql = geral.filetostr(arqtmp)
            #
            if not sql.lower().startswith('select'):
                responseJSON['erro'] = 'Somente comandos iniciando com SELECT sao permitidos.'
                return json.dumps(responseJSON)
            #
            rs = conn.execute(text(sql))
        #
        return json.dumps([dict(r) for r in rs.mappings()], default=alchemyencoder)
    except Exception as e:
        geral.printdh('Erro Interno em processqueries.getQuery')
        print(e)
        responseJSON['erro'] = str(e)
        return json.dumps(responseJSON)


def getQueryBI(engine,request):
    responseJSON = {}
    try:
        with getConnPG(engine) as conn:
            #
            schema = request.args.get('db')
            conn.execute(text('set schema \'' + schema + '\''))
            #
            token = request.args.get('t')
            tokenBD = getValorByDescricao(conn,'WSGetQueryTokenBI')
            if token != tokenBD:
                responseJSON['erro'] = 'Token invalido para acesso.'
                return json.dumps(responseJSON)
            #
            sql = base64.b64decode(request.data.decode()).decode()
            # arqtmp = '/sistemas/emonitorpy/tmp/' + schema + '.sql'
            # cmd = 'echo \'' + request.data.decode() + '\' | base64 -d > ' + arqtmp
            # os.system(cmd)
            # sql = geral.filetostr(arqtmp)
            #
            if not sql.lower().startswith('with ') and not sql.lower().startswith('select'):
                responseJSON['erro'] = 'Somente comandos iniciando com WITH ou SELECT sao permitidos.'
                return json.dumps(responseJSON)
            #
            rs = conn.execute(text(sql))
        #
        return json.dumps([dict(r) for r in rs.mappings()], default=alchemyencoder)
    except Exception as e:
        geral.printdh('Erro Interno em processqueries.getQueryBI')
        print(e)
        responseJSON['erro'] = str(e)
        return json.dumps(responseJSON)

