import pandas as pd
from pandas import DataFrame, Series
from IPython.display import display
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.ensemble import RandomForestRegressor
from sklearn import metrics
import numpy as np
from surprise import KNNWithMeans, Dataset, accuracy, Reader
from surprise.model_selection import train_test_split
from sklearn.decomposition import TruncatedSVD
import os
#import tensorflow as tf
import sweetviz as sv


#df = pd.read_csv('/sistemas/sitesat2/build/web/tmp/pemm_conhec1.csv')
df = pd.read_csv('/home/edilmar/Downloads/transmrs_conhec1.csv')


# my_report = sv.analyze(df,"margemFrete")
# my_report.show_html()
# exit(0)

# apenas mostrar os dados
#display(df)

# grafico de pares
#sns.pairplot(df)
#plt.show()

# grafico de correlacao
# sns.heatmap(df.corr(), annot =True, cmap="Wistia")
# plt.show()
# exit(0)

##########################
# IA
'''
https://scikit-learn.org/stable/tutorial/basic/tutorial.html
https://www.tutorialspoint.com/scikit_learn/index.htm
https://www.tutorialspoint.com/python_data_science/python_pandas.htm
https://openclass.idp.edu.br/courses/48
https://www.udemy.com/course/aprenda-machine-learning-em-python-com-scikit-learn/
https://minerandodados.com.br/previsao-de-vendas-com-machine-learning/
https://realpython.com/tutorials/data-science/
https://cloud.google.com/ai-platform/prediction/docs/custom-prediction-routine-scikit-learn?hl=pt-br
https://www.tensorflow.org/?hl=pt-br
https://pytorch.org/
'''
##########################

# https://medium.com/data-hackers/criando-sistemas-de-recomenda%C3%A7%C3%A3o-em-python-ef350f601e3d
# reader = Reader()
# data = Dataset.load_from_df(df,reader)
# trainset, testset = train_test_split(data, test_size=0.3,random_state=10)
# algo = KNNWithMeans(k=5, sim_options={'user_based': False})
# algo.fit(trainset)
# test_pred = algo.test(testset)
# print("Item-based Model : Test Set")
# accuracy.rmse(test_pred, verbose=True)
# exit(0)

# treinamento
x = df.drop('MargemFrete',axis=1)
y = df['MargemFrete']
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.3,random_state=1)
# IA Regressao Linear
lin_reg = LinearRegression()
lin_reg.fit(x_train, y_train)
# IA Arvore de Decisao
rf_reg = RandomForestRegressor()
rf_reg.fit(x_train, y_train)

# teste/geracao de suposicoes de valores
test_pred_lin = lin_reg.predict(x_test)
test_pred_rf = rf_reg.predict(x_test)

# coeficientes
predicts = x_train.columns
# lin_reg_coef = DataFrame(predicts)
# lin_reg_coef['Coeficientes'] = Series(lin_reg.coef_)
# display(lin_reg_coef)
# coef = Series(lin_reg.coef_, predicts).sort_values()
# plt.figure(figsize=(15, 10))
# coef.plot(kind='bar', title='Coeficientes Modais')
# plt.show()

# ridgeReg = Ridge(alpha=0.05, normalize=True)
# ridgeReg.fit(x_train,y_train)
# test_pred_ridge = ridgeReg.predict(x_test)
# mse = np.mean((test_pred_ridge - y_test) ** 2)
# print(mse)
# print(ridgeReg.score(x_test,y_test))
# coef = Series(ridgeReg.coef_, predicts).sort_values()
# print(coef)
# coef.plot(kind='bar', title='Ridge Coefficients')
# plt.show()

# lassoReg = Lasso(alpha=0.05, normalize=True)
# lassoReg.fit(x_train,y_train)
# test_pred_lasso = lassoReg.predict(x_test)
# mse = np.mean((test_pred_lasso - y_test)**2)
# print(mse)
# print(lassoReg.score(x_test,y_test))
# coef = Series(lassoReg.coef_, predicts).sort_values()
# print(coef)
# coef.plot(kind='bar', title='Lasso Coefficients')
# plt.show()

ENreg = ElasticNet(alpha=1, l1_ratio=0.5, normalize=False)
ENreg.fit(x_train,y_train)
test_pred_en = ENreg.predict(x_test)
mse = np.mean((test_pred_en - y_test)**2)
print(mse)
# print(ENreg.score(x_test,y_test))
# coef = Series(ENreg.coef_, predicts).sort_values()
# print(coef)
# coef.plot(kind='bar', title='ElasticNet Coefficients')
# plt.show()

#exit(0)

# indicadores de analise de confiabilidade dos testes
# mse_lin = np.mean((test_pred_lin-y_test)**2)
# mse_rf = np.mean((test_pred_rf-y_test)**2)
# print(f"MSE da Regressão Linear: {mse_lin}")
# print(f"MSE da Arvore de Decisao: {mse_rf}")
r2_lin = metrics.r2_score(y_test, test_pred_lin)
mse_lin = metrics.mean_squared_error(y_test, test_pred_lin)
print(f"R² da Regressão Linear: {r2_lin}")
print(f"MSE da Regressão Linear: {mse_lin}")
r2_rf= metrics.r2_score(y_test, test_pred_rf)
mse_rf = metrics.mean_squared_error(y_test, test_pred_rf)
print(f"R² da Arvore de Decisao: {r2_rf}")
print(f"MSE da Arvore de Decisao: {mse_rf}")
#exit(0)

# comparacao dos testes com os indicadores
df_resultado = pd.DataFrame()
df_resultado['y_teste'] = y_test
df_resultado['y_previsao_rf'] = test_pred_rf
df_resultado['y_previsao_lin'] = test_pred_lin
df_resultado['y_previsao_en'] = test_pred_en
display(df_resultado)
plt.figure(figsize=(15, 10))
sns.lineplot(data=df_resultado)
plt.show()

# importancia do modelo
#sns.barplot(x=x_train.columns, y=rf_reg.feature_importances_)
#plt.show()

# filtragem colaborativa baseada em modelo