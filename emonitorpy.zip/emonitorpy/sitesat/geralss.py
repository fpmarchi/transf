from sqlalchemy.sql import *

import geral
from metadata import getConnPG


# retorna a lista de nomes reduzidos da pasta docroot do Payara/SS, em uma string separada por virgula
def listNomeReduz():
    l = geral.dirlist(dirname='/sistemas/payara/glassfish/domains/domain1/docroot',onlydirs=True)
    s = ''.join([d+',' for d in l if d not in ['css','fonts','js','img','mrtg','stat']])
    return s[0:len(s)-1]


def getSSUsuariosAtivosBySchema(engineSitesat, request):
    try:
        nome_reduzido = request.args.get('db')
        with getConnPG(engineSitesat) as connPG:
            sql = text('SELECT COUNT(*) FROM ' + nome_reduzido + '.usuario WHERE statususuario = \'A\'')
            rs = connPG.execute(sql)
            return str(rs.fetchone()[0])
    except Exception as e:
        print('Erro em getSSUsuariosAtivosBySchema')
        print(e)
        return str(-1)



