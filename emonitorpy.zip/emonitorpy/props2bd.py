from metadata import getEnginePG, getConnPG
from geralsis import *
import dao


conn = getConnPG(getEnginePG(prop,'EMonitor'))

# print(dao.getOutrasInstalacoes(conn))
# exit(0)
# print(dao.getDistInstalacoes(conn,'nfe'))
# print(dao.getDistInstalacoes(conn,'cte'))
# print(dao.getDistInstalacoes(conn,'mdfe'))
# exit(0)

prop = loadProperties()
OutrasInstalacoes = prop['OutrasInstalacoes'].data
listInstalacoes = getInstalacoesDist(OutrasInstalacoes)

dao.delInstEmp(conn)
for instalacao in listInstalacoes:
    inst, emp = getCamposInst(instalacao)
    #
    try:
        email = prop['EndDestEMailSair'+instalacao].data
    except:
        email = 'servidor@intersite.com.br'
    try:
        nomearq = prop['nomeArqCertifCliente'+instalacao].data
        senha = prop['senhaCertifCliente'+instalacao].data
    except:
        print('instalacao ' + instalacao + ' com properties bichado')
        continue
    try:
        checkexp = prop['checkExpCertifCliente'+instalacao].data
    except:
        checkexp = 'S'
        #
    if not dao.hasInstEmp(conn, inst, emp):
        print('Inserindo instemp... '+ instalacao)
        dao.insInstEmp(conn, inst, emp, email, nomearq, senha, checkexp)
    else:
        print('Duplicacao de instemp... ' + instalacao)

exit(0)

# codigo abaixo apenas no EMP

NFeDistInstalacoes = prop['NFeDistInstalacoes'].data
CTeDistInstalacoes = prop['CTeDistInstalacoes'].data
MDFeDistInstalacoes = prop['MDFeDistInstalacoes'].data
listNFeInstalacoes = getInstalacoesDist(NFeDistInstalacoes)
listCTeInstalacoes = getInstalacoesDist(CTeDistInstalacoes)
listMDFeInstalacoes = getInstalacoesDist(MDFeDistInstalacoes)

dao.delInstEmpFil(conn)
for instalacao in listNFeInstalacoes:
    inst, emp, cnpjcpf, numuf = getCamposInstDist(instalacao)
    #
    if not dao.hasInstEmpFil(conn, inst, emp, cnpjcpf, numuf):
        print('Inserindo instempfil/NFe... '+ instalacao)
        dao.insInstEmpFil(conn, inst, emp, cnpjcpf, numuf, 'nfedist', 'S')
    else:
        print('Duplicacao de instempfil/NFe... ' + instalacao)
for instalacao in listCTeInstalacoes:
    inst, emp, cnpjcpf, numuf = getCamposInstDist(instalacao)
    #
    if not dao.hasInstEmpFil(conn, inst, emp, cnpjcpf, numuf):
        print('Inserindo instempfil/CTe... '+ instalacao)
        dao.insInstEmpFil(conn, inst, emp, cnpjcpf, numuf, 'ctedist', 'S')
    else:
        print('Atualizando instempfil/CTe... '+ instalacao)
        dao.updInstEmpFil(conn, inst, emp, cnpjcpf, numuf, 'ctedist', 'S')
for instalacao in listMDFeInstalacoes:
    inst, emp, cnpjcpf, numuf = getCamposInstDist(instalacao)
    #
    if not dao.hasInstEmpFil(conn, inst, emp, cnpjcpf, numuf):
        print('Inserindo instempfil/MDFe... '+ instalacao)
        dao.insInstEmpFil(conn, inst, emp, cnpjcpf, numuf, 'mdfedist', 'S')
    else:
        print('Atualizando instempfil/MDFe... '+ instalacao)
        dao.updInstEmpFil(conn, inst, emp, cnpjcpf, numuf, 'mdfedist', 'S')





