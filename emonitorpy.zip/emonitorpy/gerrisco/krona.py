import json
from string import Template
from typing import Tuple

from requests import Response

from ActionProcessor import ActionProcessor, parse_props, HttpMethod, handle_exception_factory
from geral import *
from geralxml import mount_xml_response


class KronaException(Exception):
    pass


# Classe base
class Krona(ActionProcessor):
    # INSTANCIAS
    HOST = 'http://k1.grupokrona.com.br'
    TEST_HOST = 'http://k1.grupokrona.com.br'
    BASE_PATH = '/API'

    ADD_DRIVER = 4050
    ADD_CAR = 4051
    ADD_REFERENCE = 4052
    ADD_SEARCH = 4053
    CONSULT_RELEASE = 4054
    ADD_AMOUNT_TRAVEL = 4055
    ADD_DOCUMENT = 4056

    def __init__(self):
        # self.add_callable_records('url', {
        #     self.ADD_DRIVER: (_make_url, _make_defaults('/cadastro_motorista')),
        #     self.ADD_CAR: (_make_url, _make_defaults('/cadastro_carro')),
        #     self.ADD_REFERENCE: (_make_url, _make_defaults('/cadastro_referencia')),
        #     self.ADD_SEARCH: (_make_url, _make_defaults('/cadastro_pesquisa')),
        #     self.CONSULT_RELEASE: (_make_url, _make_defaults('/consulta_liberado')),
        #     self.ADD_AMOUNT_TRAVEL: (_make_url, _make_defaults('/quantidade_viagens')),
        #     self.ADD_DOCUMENT: (_make_url, _make_defaults('/copia_imagem')),
        # })
        super().__init__()

        self.add_callable_records('url', {
            self.ADD_DRIVER: self.make_url_assembler(
                '/cadastro_motorista',
                extract_host=True,
                use_template=True
            ),
            self.ADD_CAR: self.make_url_assembler(
                '/cadastro_carro',
                extract_host=True,
                use_template=True
            ),
            self.ADD_REFERENCE: self.make_url_assembler(
                '/cadastro_referencia',
                extract_host=True,
                use_template=True
            ),
            self.ADD_SEARCH: self.make_url_assembler(
                '/cadastro_pesquisa$postfix',
                extract_host=True,
                use_template=True
            ),
            self.CONSULT_RELEASE: self.make_url_assembler(
                '/consulta_liberado$postfix',
                extract_host=True,
                use_template=True
            ),
            self.ADD_AMOUNT_TRAVEL: self.make_url_assembler(
                '/quantidade_viagens',
                extract_host=True,
                use_template=True
            ),
            self.ADD_DOCUMENT: self.make_url_assembler(
                '/copia_imagem',
                extract_host=True,
                use_template=True
            ),
        })


    def before_make_url(self):
        props = self.context.get('props')
        req = self.context.get('req')
        if not props:
            return

        environment = props.get('ws_ambiente', '').strip()
        if environment == '0':
            req['postfix'] = '_alteracao'
        else:
            req['postfix'] = ''



    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        props = context_req.get('props')
        user = props.get('usuario')
        password = props.get('senha')

        return {
                   'Content-type': 'application/json',
                   'senha': password,
                   'usuario': user,
               }, ''


#
#   Códigos independentes de instancia
#
def _krona_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a Krona:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    KronaException,
    _krona_exception_callback,
    any_exception_callback
)


# Funções para obtenção de URLs
@_handle_exception
def _make_defaults(path: str, method: HttpMethod = HttpMethod.POST, use_template: bool = None) -> dict:
    return {
        'path': path,
        **conditional_key('method', method),
        **conditional_key('use_template', use_template)
    }


@_handle_exception
def _make_url(path: str, method: HttpMethod = HttpMethod.GET, use_template: bool = False,
              req: dict = None, url: str = '', props: dict = None) -> Tuple[str, str]:
    if props is None:
        props = {}

    ambiente = 0
    try:
        ambiente = int(props.get('ws_ambiente'))
    except (Exception,):
        pass

    base = url.strip().rstrip('/') or (Krona.BASE_URL if ambiente == 1 else Krona.BASE_URL_TEST)
    if use_template:
        t = Template(path)
        url = base + t.substitute(req)
    else:
        url = base + path

    return url, method.name


@_handle_exception
def _make_defaults(path: str, method: HttpMethod = HttpMethod.POST, use_template: bool = None) -> dict:
    return {
        'path': path,
        **conditional_key('method', method),
        **conditional_key('use_template', use_template)
    }


#
#   Instancia limpa e sem configuração
#
_krona = Krona()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = _krona.link_to_factory('request')
_link_to_response = _krona.link_to_factory('response')


@_link_to_request(_krona.ADD_DRIVER)
@_handle_exception
def _add_driver(req: dict) -> Tuple[str, str]:
    mot_datanasc = _date_ddmmyy(req.get('mot_datanasc', ''))

    if req.get('mot_funcionario', '') == 'S':
        vinculo = 'FROTA'
    elif req.get('mot_funcionario', '') == 'N':
        vinculo = 'CARRETEIRO'
    else:
        vinculo = 'AGREGADO'
    data = {
        "nome": req.get('mot_nome', ''),
        "cpf": req.get('mot_cpf', ''),
        "rg": req.get('mot_rg', ''),
        "ufrg": req.get('mot_orgaorguf', ''),
        "orgao_emissor": req.get('mot_orgaorguf', ''),
        "cidadenascimento": req.get('mot_nomecidnascimento', ''),
        "uf_nascimento": req.get('mot_ufcidnascimento', ''),
        "data_nascimento": mot_datanasc,
        "nome_mae": req.get('mot_nomemae', ''),
        "nome_pai": req.get('mot_nomepai', ''),
        "estado_civil": req.get('mot_estadocivil', ''),
        "escolaridade": req.get('mot_escolaridade', ''),
        "numregistro": req.get('mot_cnh', ''),
        "cnh_numero": req.get('mot_numsegcnh', ''),
        "cnh_categoria": req.get('mot_catcnh', ''),
        "cedulacnh": req.get('mot_cnhformulario', ''),
        "cnh_vencimento": req.get('mot_datavalidcnh', ''),
        "ufcnh": req.get('mot_ufcnh', ''),
        "end_rua": req.get('mot_endereco', ''),
        "end_numero": req.get('mot_numero', ''),
        "end_complemento": req.get('mot_complemento', ''),
        "end_bairro": req.get('mot_bairro', ''),
        "end_cidade": req.get('mot_nomecidendereco', ''),
        "end_uf": req.get('mot_ufcidendereco', ''),
        "end_cep": req.get('mot_cep', ''),
        "tel_fixo": req.get('mot_foneddd', '') + req.get('mot_fonenumero', ''),
        "tel_celular": req.get('mot_celularddd', '') + req.get('mot_celularnumero', ''),
        "nextel": req.get('mot_nextel', ''),
        "mopp": '',
        "aso": '',
        "cdd": '',
        "capacitacao": '',
        "vinculo": vinculo
    }

    return json.dumps(data), ''


@_link_to_request(_krona.ADD_CAR)
@_handle_exception
def _add_cart(req: dict) -> Tuple[str, str]:
    _verif_propriedade(req.get('veic_propriedade', ''))

    data = {
        "placa": req.get('veic_placa', ''),
        "renavam": req.get('veic_renavam', ''),
        "chassi": req.get('veic_chassi', ''),
        "marca": req.get('veic_marca', ''),
        "modelo": req.get('veic_modelo', ''),
        "cor": req.get('veic_cor', ''),
        "ano": req.get('veic_anofab', ''),
        "tipo": req.get('veic_tipoveic', ''),
        "capacidade": req.get('veic_capkg', ''),
        "numero_antt": req.get('veic_rntrc', ''),
        "validade_antt": req.get('veic_validaderntrc', ''),
        "proprietario": req.get('prop_nome', ''),
        "proprietario_cpfcnpj": req.get('prop_cnpjcpf', ''),
        "detrancpfcnpj": req.get('detrancpfcnpj', ''),
        "detrannomeproprietario": req.get('detrannomeproprietario', ''),
        "uf_placa": req.get('veic_uf', ''),

        **conditional_keys(
            len(req.get('detrancpfcnpj')) > 11,
            {
                'tipopessoadetran': 'cnpj'
            },
            {
                'tipopessoadetran': 'cpf'
            }
        ),

        "fone": req.get('prop_foneddd', '') + req.get('prop_fonenumero', ''),
        "celular": req.get('prop_celularddd', '') + req.get('prop_celularnumero', ''),
        "tipopessoa": 'CPF' if len(req.get('prop_cnpjcpf', '')) < 14 else 'CNPJ',
        "end_rua": req.get('prop_endereco', ''),
        "end_numero": req.get('prop_numero', '0'),
        "end_complemento": req.get('prop_complemento', ''),
        "end_bairro": req.get('prop_bairro', ''),
        "end_cidade": req.get('prop_cidade', ''),
        "end_uf": req.get('prop_uf', ''),
        "end_cep": req.get('prop_cep', ''),
        "tecnologia": 'NÃO TEM' if req.get('veic_tiporastreador', '') == '' else req.get('veic_tiporastreador', ''),
        "id_rastreador": req.get('id_rastreador1', ''),  # req.get('id_rastreador2', ''), ################ NÃO TEM
        "comunicacao": 'NÃO TEM',
        "tecnologia_sec": 'NÃO TEM' if req.get('veic_tiporastreador', '') == '' else req.get('veic_tiporastreador', ''),
        "id_rastreador_sec": '',
        "comunicacao_sec": 'NÃO TEM',
        "fixo": 'NÃO',
        "tipovinculo": _verif_propriedade(req.get('veic_propriedade', '')),
    }
    return json.dumps(data), ''


@_link_to_request(_krona.ADD_REFERENCE)
@_handle_exception
def _add_cart(req: dict) -> Tuple[str, str]:
    if len(req.get('mot_referencia_celular', '')) > 11:
        telefone_ref = req.get('mot_referencia_celular', '')[1:]
    else:
        telefone_ref = req.get('mot_referencia_celular', '')
    data = {
        "cpfcnpjmotorista": req.get('mot_cpf', ''),
        "cpfcnpjreferencia": req.get('mot_cpf', ''),
        "cidade": req.get('mot_referencia_cidade', ''),
        "uf": req.get('mot_referencia_uf', ''),
        "endereco": req.get('mot_referencia_endereco', ''),
        "nome": req.get('mot_referencia_nome', ''),
        "fone": telefone_ref,
        "contato": req.get('mot_referencia_nomecontato', ''),
    }
    return json.dumps(data), ''


@_link_to_request(_krona.ADD_SEARCH)
@_handle_exception
def _add_cart(req: dict, props: dict) -> Tuple[str, str]:

    data = {
        "cpfcnpj": req.get('mot_cpf', ''),
        "placacarro": req.get('veic_placa', ''),
        "placareboque": req.get('car1_placa', ''),
        "placasemireboque": req.get('car2_placa', ''),
        "placaterceiroreboque": req.get('car3_placa', ''),
        "tipovinculo": _verif_propriedade(req.get('veic_propriedade', '')),
        "validadepesquisa": req.get('data_validade_inicio', ''),
        "validadeconsulta": req.get('data_validade_fim', '')
    }
    return json.dumps(data), ''


@_link_to_request(_krona.CONSULT_RELEASE)
@_handle_exception
def _add_cart(req: dict, props: dict) -> Tuple[str, str]:

    data = {
        "cpf": req.get('mot_cpf', ''),
        "placacarro": req.get('veic_placa', ''),
        "placareboque": req.get('car1_placa', ''),
        "placasemireboque": req.get('car2_placa', ''),
        "placaterceiroreboque": req.get('car3_placa', '')
    }
    return json.dumps(data), ''


@_link_to_request(_krona.ADD_AMOUNT_TRAVEL)
@_handle_exception
def _add_cart(req: dict) -> Tuple[str, str]:
    data = {
        "placa": req.get('veic_placa', ''),
        "cpfCnpj": req.get('cpf_cnpj', ''),
        "qtdviagem": req.get('quant_viagem', ''),
        **conditional_keys(
            len(req.get('cpf_cnpj', '')) > 11,
            {
                "tipopessoa": 'cnpj',
            },
            {
                "tipopessoa": 'cpf',
            },
        ),
    }
    return json.dumps(data), ''


@_link_to_request(_krona.ADD_DOCUMENT)
@_handle_exception
def _add_cart(req: dict) -> Tuple[str, str]:
    data = {
        "placa": req.get('veic_placa', ''),
        "cpfCnpj": req.get('cpf_cnpj', ''),
        **conditional_keys(
            len(req.get('cpf_cnpj', '')) > 11,
            {
                "tipopessoa": 'cnpj',
            },
            {
                "tipopessoa": 'cpf',
            },
        ),
        'tipodoc': req.get('tipo_doc', ''),
        **conditional_key("nomedoc", req.get('nome_doc', ''), not not req.get('nome_doc')),
        "copiaimagem": req.get('copia_imagem', '')
    }
    return json.dumps(data), ''

@_link_to_response(_krona.ADD_DRIVER, _krona.ADD_CAR, _krona.ADD_REFERENCE, _krona.ADD_SEARCH, _krona.CONSULT_RELEASE, _krona.ADD_AMOUNT_TRAVEL, _krona.ADD_DOCUMENT)
@_handle_exception
def _find_resultado_consulta(resp: Response) -> Tuple[str, str]:
    try:
        resp_json = resp.json()
        url = resp.url
        resp_body = {}
    except (Exception,):
        raise KronaException('Erro no retorno fora de padrão pela Krona: \nDicas: Por favor verifique se a url está correta')
    resp_body = {'sucesso': 'false'}
    resp_body['msg_erro'] = resp_json
    if 'resposta' in resp_json:
        resp_body = {
            'sucesso': 'false',
            'erros': [
                {
                    'campo': deep_get(erro, 'erro.objeto') or '',
                    'descricao': deep_get(erro, 'erro.mensagem') or ''
                }
                for erro in resp_json.get('resposta', [])
            ]
        }
    elif 'retorno' in resp_json:
        try:
            resp_json = resp_json.get('retorno')
            if resp_json.get('status') == None and resp_json.get('pacote') == None:
                resp_body = {'sucesso': 'false'}
                resp_body['msg_erro'] = 'A Krona retornou os dados vazios, por favor entre em contato com suporte da Krona'
            elif resp_json.get('status') == 'TRUE':
                if 'Nao foi possivel efetuar gravacao' in resp_json.get('obs'):
                    resp_body = {'sucesso': 'false'}
                    resp_body['msg_erro'] = resp_json
                else:
                    resp_body = {'sucesso': 'true'}
                    resp_body['conteudo'] = resp_json
            elif 'com sucesso'  in resp_json.get('obs'):
                resp_body = {'sucesso': 'true'}
                resp_body['conteudo'] = resp_json
            elif 'incorreto' in resp_json.get('obs'):
                resp_body = {'sucesso': 'false'}
                resp_body['msg_erro'] = resp_json
            elif 'cadastrada com sucesso' in resp_json.get('status'):
                resp_body = {'sucesso': 'true'}
                resp_body['conteudo'] = resp_json
            elif resp_json.get('status') == 'FALSE':
                resp_body = {'sucesso': 'false'}
                resp_body['msg_erro'] = resp_json
            elif resp_json.get('pacote') != None:
                resp_body = {'sucesso': 'True'}
                resp_body['conteudo'] = resp_json
            elif resp_json.get('status') == None:
                resp_body = {'sucesso': 'false'}
                resp_body['msg_erro'] = resp_json
        except (Exception,):
            resp_body = {'sucesso': 'false'}
            resp_body['msg_erro'] = resp_json
    elif 'Resposta' in resp_json:
        resp_body = {'sucesso': 'true'}
        resp_body['conteudo'] = resp_json.get('Resposta')
    else:
        raise KronaException('Não foi possível encontrar um retorno conhecido da Krona')
    return mount_xml_response(resp_body, url=url), ''


#
# CONVERTE 19/02/2000 PARA 2000-02-19
def _date_ddmmyy(s: str) -> str:
    try:
        return datetime.strptime(s, "%Y-%m-%d").strftime("%d/%m/%Y")
    except (Exception,):
        return ''


def _verif_propriedade(tipo_vinculo: str) -> str:
    if tipo_vinculo in 'SFRO':
        return 'FUNCIONARIO'
    elif tipo_vinculo in 'AG':
        return 'AGREGADO'
    elif tipo_vinculo in 'M':
        return 'AUXAGREGADO'
    else:
        return 'AUTONOMO'


def is_homologation(props: dict) -> bool:

    environment = props.get('ws_ambiente', '').strip()

    if environment == '0':
        return True
    else:
        return False