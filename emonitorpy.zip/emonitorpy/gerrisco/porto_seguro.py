import base64
import json
from functools import lru_cache
from io import BytesIO
from typing import Tuple
from xml.sax.saxutils import escape

import requests
import xmltodict
from requests import Response

from ActionProcessor import ActionProcessor, parse_props, handle_exception_factory
from geral import *
from geralxml import mount_xml_response, xml_from_dict


class PortoSeguroException(Exception):
    pass


# Classe base
class PortoSeguro(ActionProcessor):
    # INSTANCIAS
    HOST = 'https://apis.averbeporto.com.br'
    TEST_HOST = 'https://apis.averbeporto.com.br'
    BASE_PATH = '/php/conn.php'

    SEND_XML_FILE = 4500

    def __init__(self):
        self.add_callable_records('url', {
            self.DEFAULT_FUNCTION: self.make_url_assembler()
        })

        super().__init__()
        self.self_managed = True

    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        return {
            'Content-type': 'text/html; charset=UTF-8',
            'set-cookie': ''
        }, ''


#
#   Códigos independentes de instancia
#
def _porto_seguro_exception_callback(data: dict) -> Tuple[str, str, str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;('), '', ''


def any_exception_callback(data: dict) -> Tuple[str, str, str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a Porto Seguro:\n' + data['ex_message'], '', ''


_handle_exception = handle_exception_factory(
    PortoSeguroException,
    _porto_seguro_exception_callback,
    any_exception_callback
)

#
#   Instancia limpa e sem configuração
#
_porto_seguro = PortoSeguro()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = _porto_seguro.link_to_factory('request')
_link_to_response = _porto_seguro.link_to_factory('response')


@_link_to_request(_porto_seguro.SEND_XML_FILE)
@_handle_exception
def _register_cte(req: dict, props: dict, arq_req: str, arq_resp: str) -> Tuple[str, str, str, str]:
    request_steps = []
    response_steps = []

    def add_steep(response: Response):
        request = resp.request
        request_steps.append({
            'url': request.url,
            'method': request.method,
            'headers': dict(request.headers),
            'body': str(request.body)
        })

        response_steps.append({
            'code': response.status_code,
            'headers': dict(response.headers),
            'cookies': dict(response.cookies),
            'body': response.text
        })

    uri = _porto_seguro.dispatch(_porto_seguro.DEFAULT_FUNCTION, {'props': props}, 'url')[0]
    payload = {
        'mod': 'login',
        'comp': 5,
        'user': props.get('usuario'),
        'pass': props.get('senha')
    }

    #  Precisamos verificar erros durante os passos
    s = requests.Session()
    resp = s.post(uri, data=payload)
    add_steep(resp)

    payload = {
        'mod': 'Upload',
        'comp': 5,
        'path': 'eguarda/php/',
        'recipient': 'T'
    }

    decoded = base64.b64decode(req.get('xml_porto_seguro', ''))
    files = {
        'file': ('file.xml', BytesIO(decoded))
    }
    resp = s.post(uri, data=payload, files=files)
    add_steep(resp)

    ret = _porto_seguro.parse_response({'resp': resp}, _porto_seguro.SEND_XML_FILE)

    strtofile(arq_req, escape(json.dumps(request_steps, indent=4)))
    strtofile(arq_resp, escape(json.dumps(response_steps, indent=4)))

    return ret, '', arq_req, arq_resp


@_link_to_response(_porto_seguro.SEND_XML_FILE)
@_handle_exception
def _in_register_cte(resp: Response) -> str:
    ret = resp.json()

    success = resp.status_code == 200 and ret.get('success') == 1
    resp_data = {
        'sucesso': success
    }

    if success:
        if 'error' in ret:
            error = ret.get('error')
            resp_data['sucesso'] = False
            resp_data['msg_erro'] = f'{error.get("code")}{error.get("msg")}'
        else:
            s = ret.get('S')
            status = get_status(s)

            if status not in ['P', 'D']:
                raise PortoSeguroException(f'Status: {status} - {get_status_description(status)}')

            resp_data['conteudo'] = {
                'status': status,
                'status_description': get_status_description(status),
                'protocol': ret.get('prot')
            }
    else:
        resp_data['msg_erro'] = 'Erro desconhecido ao comunicar com a Porto Seguro'

    return mount_xml_response(resp_data)


def get_status(status_set: dict) -> str:
    for k, v in status_set.items():
        if v == 1:
            return k

    return 'Indefinido'


@lru_cache(maxsize=5)
def get_status_description(status: str) -> str:
    description = {
        'P': 'Processado(xml guardado com sucesso)',
        'D': 'Duplicado(xml pré-existente)',
        'R': 'Rejeitado(xml não parece ser do tipo certo)',
        'N': 'Negado(Não é xml ou zip)'
    }

    return description.get(status, 'Desconhecido')
