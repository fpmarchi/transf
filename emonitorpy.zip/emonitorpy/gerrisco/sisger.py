from string import Template
from typing import Tuple

from requests import Response

from ActionProcessor import ActionProcessor, parse_props, HttpMethod, handle_exception_factory
from geral import *
from geralxml import mount_xml_response

import time
from typing import Tuple
from urllib.parse import urlparse, urlunparse

from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Util.Padding import unpad, pad
from requests import post, Response

from ActionProcessor import ActionProcessor, parse_props, handle_exception_factory
from dispacher.action_processor import HttpMethod
from geral import conditional_key
from geralxml import mount_xml_response


class SisgerException(Exception):
    pass


# Classe base
class Sisger(ActionProcessor):
    # INSTANCIAS
    BASE_URL = 'https://api.plataformasisger.com.br'
    BASE_URL_TEST = 'https://api.plataformasisger.com.br'

    AUTHENTICATE_USER = 4200
    ADD_SEARCH_AGGREGATE = 4201
    ADD_SEARCH_AUTONOMOUS = 4202
    ADD_SEARCH_SHIPPING = 4203
    ADD_VEHICLE_AGGREGATE = 4204
    ADD_VEHICLE_AUTONOMOUS = 4205
    ADD_CART1_AGGREGATE = 4206
    ADD_CART1_AUTONOMOUS = 4207
    ADD_CART2_AGGREGATE = 4208
    ADD_CART2_AUTONOMOUS = 4209
    ADD_CART3_AGGREGATE = 4210
    ADD_CART3_AUTONOMOUS = 4211
    ADD_FINISH_AGGREGATE = 4212
    ADD_FINISH_AUTONOMOUS = 4213
    ADD_FINISH_SHIPPING = 4214
    GET_TYPES_MATERIALS = 4215
    GET_VALUE_MERCHANDISE_AGGREGATE = 4216
    GET_VALUE_MERCHANDISE_AUTONOMOUS = 4217
    GET_VALUE_MERCHANDISE_SHIPPING = 4218
    GET_BRAND = 4219
    GET_MODEL = 4220
    GET_QUERY_SEARCH = 4221
    GET_QUERY_SEARCH_CPF = 4222
    REQUEST_CONSULTATION = 4223
    GET_QUERY_CONSULT = 4224
    SEND_LICENSE_BASE64_AGGREGATE = 4225
    SEND_LICENSE_BASE64_AUTONOMOUS = 4226
    SEND_LICENSE_BASE64_SHIPPING = 4227
    SEND_RESIDENCE_BASE64_AGGREGATE = 4228
    SEND_RESIDENCE_BASE64_AUTONOMOUS = 4229
    SEND_RESIDENCE_BASE64_SHIPPING = 4230
    SEND_VEHICLE_BASE64_AGGREGATE = 4231
    SEND_VEHICLE_BASE64_AUTONOMOUS = 4232
    SEND_CART1_BASE64_AGGREGATE = 4233
    SEND_CART1_BASE64_AUTONOMOUS = 4234
    SEND_CART2_BASE64_AGGREGATE = 4235
    SEND_CART2_BASE64_AUTONOMOUS = 4236
    SEND_CART3_BASE64_AGGREGATE = 4237
    SEND_CART3_BASE64_AUTONOMOUS = 4238
    GET_CARGO_VALUE_AUTONOMOUS = 4239


    def __init__(self):
        self.add_callable_records('url', {
            self.AUTHENTICATE_USER: (_make_url, _make_defaults('/auth/login')),
            self.ADD_SEARCH_AGGREGATE: (_make_url, _make_defaults('/pesquisas/agregado')),
            self.ADD_SEARCH_AUTONOMOUS: (_make_url, _make_defaults('/pesquisas/autonomo')),
            self.ADD_SEARCH_SHIPPING: (_make_url, _make_defaults('/pesquisas/frota')),
            self.ADD_VEHICLE_AGGREGATE: (_make_url, _make_defaults('/pesquisas/agregado/veiculo')),
            self.ADD_VEHICLE_AUTONOMOUS: (_make_url, _make_defaults('/pesquisas/autonomo/veiculo')),
            self.ADD_CART1_AGGREGATE: (_make_url, _make_defaults('/pesquisas/agregado/reboque')),
            self.ADD_CART1_AUTONOMOUS: (_make_url, _make_defaults('/pesquisas/autonomo/reboque')),
            self.ADD_CART2_AGGREGATE: (_make_url, _make_defaults('/pesquisas/agregado/reboque-dois')),
            self.ADD_CART2_AUTONOMOUS: (_make_url, _make_defaults('/pesquisas/autonomo/reboque-dois')),
            self.ADD_CART3_AGGREGATE: (_make_url, _make_defaults('/pesquisas/agregado/reboque-tres')),
            self.ADD_CART3_AUTONOMOUS: (_make_url, _make_defaults('/pesquisas/autonomo/reboque-tres')),
            self.ADD_FINISH_AGGREGATE: (_make_url, _make_defaults('/pesquisas/agregado/informacoes-complementares')),
            self.ADD_FINISH_AUTONOMOUS: (_make_url, _make_defaults('/pesquisas/autonomo/informacoes-complementares')),
            self.ADD_FINISH_SHIPPING: (_make_url, _make_defaults('/pesquisas/frota/informacoes-complementares')),
            self.GET_TYPES_MATERIALS: (_make_url, _make_defaults('/materiais', HttpMethod.GET)),
            self.GET_VALUE_MERCHANDISE_AGGREGATE: (
                _make_url, _make_defaults('/valores-mercadorias-agregado', HttpMethod.GET)),
            self.GET_VALUE_MERCHANDISE_AUTONOMOUS: (
                _make_url, _make_defaults('/valores-mercadorias-autonomo', HttpMethod.GET)),
            self.GET_VALUE_MERCHANDISE_SHIPPING: (
                _make_url, _make_defaults('/valores-mercadorias-frota', HttpMethod.GET)),
            self.GET_BRAND: (_make_url, _make_defaults('/veiculos/marcas', HttpMethod.GET)),
            self.GET_MODEL: (_make_url, _make_defaults('/veiculos/modelos/$id_marca_sisger', HttpMethod.GET, use_template=True)),
            self.GET_QUERY_SEARCH: (
            _make_url, _make_defaults('/pesquisas/$sisger_pesquisa_id', HttpMethod.GET, use_template=True)),
            self.GET_QUERY_SEARCH_CPF: (
            _make_url, _make_defaults('/pesquisas/cpf/$mot_cpf', HttpMethod.GET, use_template=True)),
            self.REQUEST_CONSULTATION: (_make_url, _make_defaults('/consultas/solicitar')),
            self.GET_QUERY_CONSULT: (
                _make_url, _make_defaults('/consultas/$sisger_consulta_id', HttpMethod.GET, use_template=True)),
            self.SEND_LICENSE_BASE64_AGGREGATE: (_make_url, _make_defaults('/pesquisas/agregado/documentacao/habilitacao-base64')),
            self.SEND_LICENSE_BASE64_AUTONOMOUS: (_make_url, _make_defaults('/pesquisas/autonomo/documentacao/habilitacao-base64')),
            self.SEND_LICENSE_BASE64_SHIPPING: (_make_url, _make_defaults('/pesquisas/frota/documentacao/habilitacao-base64')),
            self.SEND_RESIDENCE_BASE64_AGGREGATE: (_make_url, _make_defaults('/pesquisas/agregado/documentacao/comprovante-de-residencia-base64')),
            self.SEND_RESIDENCE_BASE64_AUTONOMOUS: (_make_url, _make_defaults('/pesquisas/autonomo/documentacao/comprovante-de-residencia-base64')),
            self.SEND_RESIDENCE_BASE64_SHIPPING: (_make_url, _make_defaults('/pesquisas/frota/documentacao/comprovante-de-residencia-base64')),
            self.SEND_VEHICLE_BASE64_AGGREGATE: (_make_url, _make_defaults('/pesquisas/agregado/documentacao/veiculo-renavam-base64')),
            self.SEND_VEHICLE_BASE64_AUTONOMOUS: (_make_url, _make_defaults('/pesquisas/autonomo/documentacao/veiculo-renavam-base64')),
            self.SEND_CART1_BASE64_AGGREGATE: (_make_url, _make_defaults('/pesquisas/agregado/documentacao/reboque-renavam-base64')),
            self.SEND_CART1_BASE64_AUTONOMOUS: (_make_url, _make_defaults('/pesquisas/autonomo/documentacao/reboque-renavam-base64')),
            self.SEND_CART2_BASE64_AGGREGATE: (_make_url, _make_defaults('/pesquisas/agregado/documentacao/reboque-2-renavam-base64')),
            self.SEND_CART2_BASE64_AUTONOMOUS: (_make_url, _make_defaults('/pesquisas/autonomo/documentacao/reboque-2-renavam-base64')),
            self.SEND_CART3_BASE64_AGGREGATE: (_make_url, _make_defaults('/pesquisas/agregado/documentacao/reboque-3-renavam-base64')),
            self.SEND_CART3_BASE64_AUTONOMOUS: (_make_url, _make_defaults('/pesquisas/autonomo/documentacao/reboque-3-renavam-base64')),
            self.GET_CARGO_VALUE_AUTONOMOUS: (_make_url, _make_defaults('/valores-de-cargas/autonomo', HttpMethod.GET)),
        })

        super().__init__()

    __token_cache: dict = {}

    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        props = context_req.get('props', {})
        email = props.get('usuario', '')
        token_api = props.get('token', '')

        if not email or not token_api:
            raise Exception('O e-mail ou token não foram informados.')

        aes_key = PBKDF2(token_api, email, 32, count=500, hmac_hash_module=SHA256)
        cipher = AES.new(aes_key, AES.MODE_ECB)

        email_hash = hash(email)
        (token, gen_time) = self.__token_cache.get(email_hash, (bytearray(), 0))

        # if token and (time.time() - gen_time) < 20000:
        #     token = cipher.decrypt(token)
        #
        #     return {
        #         'Authorization': 'Bearer ' + unpad(token, cipher.block_size).decode('UTF-8')
        #     }, ''
        # return unpad(token, cipher.block_size).decode('UTF-8')

        # Se não existir token em memória transitória, tentar solicitar pela Api da SigaGr
        try:
            auth_request = {
                'email': email,
                'token_api': token_api
            }

            uri = self.context.get('url')
            parsed_uri = list(urlparse(uri))
            parsed_uri[2] = ''

            local_ctx = {
                'url': urlunparse(parsed_uri),
            }
            uri = self.dispatch(self.AUTHENTICATE_USER, local_ctx, 'url')[0]
            resp = post(uri, data=auth_request)
        except Exception as e:
            raise Exception('Erro ao buscar token de autorização pa SigaGr!\n' + str(e))

        if resp.status_code == 200:
            resp_json = resp.json()
            token = resp_json.get('access_token')
            encrypt_token = cipher.encrypt(pad(token.encode('UTF-8'), cipher.block_size))

            self.__token_cache[email_hash] = (encrypt_token, time.time())

            return {
                'Content': 'multipart/form-data',
                'Authorization': 'Bearer ' + token
            }, ''

        elif resp.status_code == 401:
            raise Exception('Por favor verifique as credenciais de acesso para SigaGr!')
        else:
            raise Exception(resp.content.decode('utf-8'))


#
#   Códigos independentes de instancia
#
def _sisger_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a Sisger:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    SisgerException,
    _sisger_exception_callback,
    any_exception_callback
)


# Funções para obtenção de URLs
@_handle_exception
def _make_defaults(path: str, method: HttpMethod = HttpMethod.POST, use_template: bool = None) -> dict:
    return {
        'path': path,
        **conditional_key('method', method),
        **conditional_key('use_template', use_template)
    }


@_handle_exception
def _make_url(path: str, method: HttpMethod = HttpMethod.GET, use_template: bool = False,
              req: dict = None, url: str = '', props: dict = None) -> Tuple[str, str]:
    if props is None:
        props = {}

    ambiente = 0
    try:
        ambiente = int(props.get('ws_ambiente'))
    except (Exception,):
        pass

    base = url.strip().rstrip('/') or (Sisger.BASE_URL if ambiente == 1 else Sisger.BASE_URL_TEST)
    if use_template:
        t = Template(path)
        url = base + t.substitute(req)
    else:
        url = base + path

    return url, method.name


@_handle_exception
def _make_defaults(path: str, method: HttpMethod = HttpMethod.POST, use_template: bool = None) -> dict:
    return {
        'path': path,
        **conditional_key('method', method),
        **conditional_key('use_template', use_template)
    }


#
#   Instancia limpa e sem configuração
#
_sisger = Sisger()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = _sisger.link_to_factory('request')
_link_to_response = _sisger.link_to_factory('response')


@_link_to_request(_sisger.AUTHENTICATE_USER)
@_handle_exception
def _out_authenticate_user(req: dict, props: dict):
    data = {
        "email": props.get('usuario'),
        "token_api": props.get('senha')  # enviado como senha, pois terá o token Bearer depois para autenticação
    }

    return data, ''


@_link_to_request(_sisger.ADD_SEARCH_AGGREGATE, _sisger.ADD_SEARCH_AUTONOMOUS, _sisger.ADD_SEARCH_SHIPPING)
@_handle_exception
def _out_search(req: dict, props: dict, acao: int):
    data = {
        "usuario": req.get('id_usuario_sisger'),
        **conditional_keys(
            _sisger.ADD_SEARCH_AUTONOMOUS == acao,
            {'consulta': req.get('id_consulta_sisger', ''),},
        ),
        "padrao_pesquisa": req.get('id_padrao_pesquisa_sisger'),
        "funcao": 'embarcador',
        "nome_completo": req.get('mot_nome'),
        "data_nascimento": req.get('mot_datanasc', ''),
        "rntc": req.get('veic_rntrc', ''),
        "cpf": req.get('mot_cpf', ''),
        "rg": req.get('mot_rg', ''),
        "rg_data_emissao": req.get('mot_datarg', ''),
        "rg_estado": req.get('mot_orgaorguf', ''),
        "cnh": req.get('mot_cnh', ''),
        "cnh_categoria": req.get('mot_catcnh', ''),
        "cnh_vencimento": _date_yymmmdd(req.get('mot_datavalidcnh')),
        "cnh_orgao_emissor": req.get('mot_cnhemissao', ''),
        "cnh_cidade": req.get('mot_cnhcidadenome', ''),
        "cnh_estado": req.get('mot_ufcnh', ''),
        "cnh_primeira_habilitacao": _date_yymmmdd(req.get('mot_dataprimcnh')),
        "pai": req.get('mot_nomepai', ''),
        "mae": req.get('mot_nomemae', ''),
        "cep": req.get('mot_cep', ''),
        "logradouro": req.get('mot_endereco', ''),
        "numero": req.get('mot_numero', ''),
        "complemento": req.get('mot_complemento', ''),
        "bairro": req.get('mot_bairro', ''),
        "cidade": req.get('mot_nomecidendereco', ''),
        "estado": req.get('mot_ufcidendereco', ''),
        "telefone_residencial": req.get('mot_celularddd', '') + req.get('mot_celularnumero', ''),
        "telefone_residencial_contato": req.get('mot_nome', ''),
        "telefone_comercial": req.get('mot_foneddd', '') + req.get('mot_fonenumero', ''),
        "telefone_comercial_contato": req.get('mot_nome', ''),
        "telefone_referencia": req.get('mot_referencia_celular', ''),
        "telefone_referencia_contato": req.get('mot_referencia_nomecontato', ''),
        "email_retorno2": req.get('mot_email', ''),
    }

    return data, ''


@_link_to_request(_sisger.ADD_VEHICLE_AGGREGATE, _sisger.ADD_VEHICLE_AUTONOMOUS)
@_handle_exception
def _out_add_vehicle(req: dict, props: dict):
    data = {
        "pesquisa": req.get('pesquisa', ''),
        "proprietario_nome": req.get('prop_nome', ''),
        "proprietario_rntc": req.get('prop_rntrc'),
        **conditional_keys(
            len(req.get('prop_cnpjcpf', '')) > 14,
            {
                "tipo_documento_proprietario": 'cnpj',
            },
            {
                "tipo_documento_proprietario": 'cpf',
            },
        ),
        "proprietario_cpf_cnpj": req.get('prop_cnpjcpf', ''),
        "proprietario_cep": req.get('prop_cep', ''),
        "proprietario_logradouro": req.get('prop_endereco', ''),
        "proprietario_numero": req.get('prop_numero', '0'),
        "proprietario_complemento": req.get('prop_complemento', ''),
        "proprietario_bairro": req.get('prop_bairro', ''),
        "proprietario_cidade": req.get('prop_cidade', ''),
        "proprietario_estado": req.get('prop_uf', ''),
        "proprietario_telefone_residencial": req.get('prop_celularddd', '') + req.get('prop_celularnumero', ''),
        "proprietario_telefone_residencial_contato": req.get('prop_nome', ''),
        "proprietario_telefone_comercial": req.get('prop_foneddd', '') + req.get('prop_fonenumero', ''),
        "proprietario_telefone_comercial_contato": req.get('prop_nome', ''),
        "veiculo_placa": req.get('veic_placa', ''),
        "veiculo_cidade_emplacamento": req.get('veic_nomecidade'),
        "veiculo_estado_emplacamento": req.get('veic_uf', ''),
        "veiculo_renavam": req.get('veic_renavam', ''),
        "veiculo_marca": req.get('veic_marca', ''),
        "veiculo_modelo": req.get('veic_modelo', ''),
        "veiculo_chassi": req.get('veic_chassi', ''),
        "veiculo_ano": req.get('veic_anofab', ''),
        "veiculo_cor": req.get('veic_cor', ''),
    }

    return data, ''


@_link_to_request(_sisger.ADD_CART1_AGGREGATE, _sisger.ADD_CART1_AUTONOMOUS)
@_handle_exception
def _out_add_cart1(req: dict, props: dict):
    data = {
        "pesquisa": req.get('pesquisa', ''),
        "proprietario_nome": req.get('prop_nome', ''),
        "proprietario_rntc": req.get('prop_rntrc'),
        **conditional_keys(
            len(req.get('prop_cnpjcpf', '')) > 14,
            {
                "tipo_documento_proprietario": 'cnpj',
            },
            {
                "tipo_documento_proprietario": 'cpf',
            },
        ),
        "proprietario_cpf_cnpj": req.get('prop_cnpjcpf', ''),
        "proprietario_cep": req.get('prop_cep', ''),
        "proprietario_logradouro": req.get('prop_endereco', ''),
        "proprietario_numero": req.get('prop_numero', '0'),
        "proprietario_complemento": req.get('prop_complemento', ''),
        "proprietario_bairro": req.get('prop_bairro', ''),
        "proprietario_cidade": req.get('prop_cidade', ''),
        "proprietario_estado": req.get('prop_uf', ''),
        "proprietario_telefone_residencial": req.get('prop_celularddd', '') + req.get('prop_celularnumero', ''),
        "proprietario_telefone_residencial_contato": req.get('prop_nome', ''),
        "proprietario_telefone_comercial": req.get('prop_foneddd', '') + req.get('prop_fonenumero', ''),
        "proprietario_telefone_comercial_contato": req.get('prop_nome', ''),
        "reboque_placa": req.get('veic_placa', ''),
        "reboque_cidade_emplacamento": req.get('veic_nomecidade'),
        "reboque_estado_emplacamento": req.get('veic_uf', ''),
        "reboque_renavam": req.get('veic_renavam', ''),
        "reboque_marca": req.get('veic_marca', ''),
        "reboque_modelo": req.get('veic_modelo', ''),
        "reboque_chassi": req.get('veic_chassi', ''),
        "reboque_ano": req.get('veic_anofab', ''),
        "reboque_cor": req.get('veic_cor', ''),
    }

    return data, ''


@_link_to_request(_sisger.ADD_CART2_AGGREGATE, _sisger.ADD_CART2_AUTONOMOUS)
@_handle_exception
def _out_add_cart2(req: dict, props: dict):
    data = {
        "pesquisa": req.get('pesquisa', ''),
        "proprietario_nome": req.get('prop_nome', ''),
        "proprietario_rntc": req.get('prop_rntrc'),
        **conditional_keys(
            len(req.get('prop_cnpjcpf', '')) > 14,
            {
                "tipo_documento_proprietario": 'cnpj',
            },
            {
                "tipo_documento_proprietario": 'cpf',
            },
        ),
        "proprietario_cpf_cnpj": req.get('prop_cnpjcpf', ''),
        "proprietario_cep": req.get('prop_cep', ''),
        "proprietario_logradouro": req.get('prop_endereco', ''),
        "proprietario_numero": req.get('prop_numero', '0'),
        "proprietario_complemento": req.get('prop_complemento', ''),
        "proprietario_bairro": req.get('prop_bairro', ''),
        "proprietario_cidade": req.get('prop_cidade', ''),
        "proprietario_estado": req.get('prop_uf', ''),
        "proprietario_telefone_residencial": req.get('prop_celularddd', '') + req.get('prop_celularnumero', ''),
        "proprietario_telefone_residencial_contato": req.get('prop_nome', ''),
        "proprietario_telefone_comercial": req.get('prop_foneddd', '') + req.get('prop_fonenumero', ''),
        "proprietario_telefone_comercial_contato": req.get('prop_nome', ''),
        "reboque_2_placa": req.get('veic_placa', ''),
        "reboque_2_cidade_emplacamento": req.get('veic_nomecidade'),
        "reboque_2_estado_emplacamento": req.get('veic_uf', ''),
        "reboque_2_renavam": req.get('veic_renavam', ''),
        "reboque_2_marca": req.get('veic_marca', ''),
        "reboque_2_modelo": req.get('veic_modelo', ''),
        "reboque_2_chassi": req.get('veic_chassi', ''),
        "reboque_2_ano": req.get('veic_anofab', ''),
        "reboque_2_cor": req.get('veic_cor', ''),
    }

    return data, ''


@_link_to_request(_sisger.ADD_CART3_AGGREGATE, _sisger.ADD_CART3_AUTONOMOUS)
@_handle_exception
def _out_add_cart3(req: dict, props: dict):
    data = {
        "pesquisa": req.get('pesquisa', ''),
        "proprietario_nome": req.get('prop_nome', ''),
        "proprietario_rntc": req.get('prop_rntrc'),
        **conditional_keys(
            len(req.get('prop_cnpjcpf', '')) > 14,
            {
                "tipo_documento_proprietario": 'cnpj',
            },
            {
                "tipo_documento_proprietario": 'cpf',
            },
        ),
        "proprietario_cpf_cnpj": req.get('prop_cnpjcpf', ''),
        "proprietario_cep": req.get('prop_cep', ''),
        "proprietario_logradouro": req.get('prop_endereco', ''),
        "proprietario_numero": req.get('prop_numero', '0'),
        "proprietario_complemento": req.get('prop_complemento', ''),
        "proprietario_bairro": req.get('prop_bairro', ''),
        "proprietario_cidade": req.get('prop_cidade', ''),
        "proprietario_estado": req.get('prop_uf', ''),
        "proprietario_telefone_residencial": req.get('prop_celularddd', '') + req.get('prop_celularnumero', ''),
        "proprietario_telefone_residencial_contato": req.get('prop_nome', ''),
        "proprietario_telefone_comercial": req.get('prop_foneddd', '') + req.get('prop_fonenumero', ''),
        "proprietario_telefone_comercial_contato": req.get('prop_nome', ''),
        "reboque_3_placa": req.get('veic_placa', ''),
        "reboque_3_cidade_emplacamento": req.get('veic_nomecidade'),
        "reboque_3_estado_emplacamento": req.get('veic_uf', ''),
        "reboque_3_renavam": req.get('veic_renavam', ''),
        "reboque_3_marca": req.get('veic_marca', ''),
        "reboque_3_modelo": req.get('veic_modelo', ''),
        "reboque_3_chassi": req.get('veic_chassi', ''),
        "reboque_3_ano": req.get('veic_anofab', ''),
        "reboque_3_cor": req.get('veic_cor', ''),
    }

    return data, ''


@_link_to_request(_sisger.ADD_FINISH_AGGREGATE, _sisger.ADD_FINISH_SHIPPING)
@_handle_exception
def _out_finish(req: dict, props: dict):

    data = {
        "pesquisa": req.get('pesquisa', ''),
        "observacoes": req.get('veic_obs', '')
    }

    return data, ''


@_link_to_request(_sisger.ADD_FINISH_AUTONOMOUS)
@_handle_exception
def _out_finish_autonomous(req: dict, props: dict):

    data = {
        "pesquisa": req.get('pesquisa', ''),
        "valor": req.get('id_valor_carga', ''),
        "observacoes": req.get('veic_obs', '')
    }

    return data, ''


@_link_to_request(_sisger.GET_TYPES_MATERIALS, _sisger.GET_VALUE_MERCHANDISE_AGGREGATE,
                  _sisger.GET_VALUE_MERCHANDISE_AUTONOMOUS, _sisger.GET_VALUE_MERCHANDISE_SHIPPING, _sisger.GET_BRAND,
                  _sisger.GET_MODEL, _sisger.GET_QUERY_SEARCH, _sisger.GET_QUERY_SEARCH_CPF, _sisger.GET_CARGO_VALUE_AUTONOMOUS)
@_handle_exception
def _out_get_generic(req: dict, props: dict):
    data = {}
    return data, ''


@_link_to_request(_sisger.REQUEST_CONSULTATION)
@_handle_exception
def _out_request_consult(req: dict, props: dict):
    data = {
        "cpf_motorista": req.get('mot_cpf', ''),
        "veiculo_placa": req.get('veic_placa', ''),
        **conditional_keys(
            len(req.get('prop_cnpjcpf', '')) > 14,
            {
                "tipo_documento_proprietario_veiculo": 'cnpj',
            },
            {
                "tipo_documento_proprietario_veiculo": 'cpf',
            },
        ),
        "veiculo_cpf_cnpj_proprietario": req.get('prop_cnpjcpf', ''),
        "reboque_placa": req.get('car1_placa', ''),

        **conditional_keys(
            len(req.get('car1_prop_cnpjcpf', '')) > 14,
            {
                "tipo_documento_proprietario_reboque": 'cnpj',
            },
            {
                "tipo_documento_proprietario_reboque": 'cpf',
            },
        ),

        "reboque_cpf_cnpj_proprietario": req.get('car1_prop_cnpjcpf', ''),
        "reboque_2_placa": req.get('car2_placa', ''),

        **conditional_keys(
            len(req.get('car2_prop_cnpjcpf', '')) > 14,
            {
                "tipo_documento_proprietario_reboque_2": 'cnpj',
            },
            {
                "tipo_documento_proprietario_reboque_2": 'cpf',
            },
        ),

        "reboque_2_cpf_cnpj_proprietario": req.get('car2_prop_cnpjcpf', ''),
        "reboque_3_placa": req.get('car3_placa', ''),

        **conditional_keys(
            len(req.get('car3_prop_cnpjcpf', '')) > 14,
            {
                "tipo_documento_proprietario_reboque_3": 'cnpj',
            },
            {
                "tipo_documento_proprietario_reboque_3": 'cpf',
            },
        ),

        "reboque_3_cpf_cnpj_proprietario": req.get('car3_prop_cnpjcpf', ''),

        "origem_carga_cep": 'NÃO TEM',
        "origem_carga_cidade": 'NÃO TEM',
        "origem_carga_estado": 'NÃO TEM',
        "destino_carga_cep": 'NÃO TEM',
        "destino_carga_cidade": 'NÃO TEM',
        "destino_carga_estado": 'NÃO TEM',
        "tipo_mercadoria_material": req.get('id_mercadoria_material', ''),
        "valor": req.get('id_valor_carga', 'NÃO TEM'),
        "usuario": req.get('id_usuario_sisger', ''),
    }

    return data, ''

@_link_to_request(_sisger.SEND_LICENSE_BASE64_AUTONOMOUS, _sisger.SEND_LICENSE_BASE64_AGGREGATE,
                  _sisger.SEND_LICENSE_BASE64_SHIPPING)
@_handle_exception
def _out_request_license_base64(req: dict, props: dict):
    data = {
        "pesquisa": req.get('pesquisa', ''),
        "motorista_habilitacao": req.get('doc_base64', '')
    }

    return data, ''

@_link_to_request(_sisger.SEND_RESIDENCE_BASE64_AUTONOMOUS, _sisger.SEND_RESIDENCE_BASE64_AGGREGATE, _sisger.SEND_RESIDENCE_BASE64_SHIPPING)
@_handle_exception
def _out_request_residence_base64(req: dict, props: dict):
    data = {
        "pesquisa": req.get('pesquisa', ''),
        "motorista_comprovante_residencia": req.get('doc_base64', '')
    }

    return data, ''

@_link_to_request(_sisger.SEND_VEHICLE_BASE64_AUTONOMOUS, _sisger.SEND_VEHICLE_BASE64_AGGREGATE)
@_handle_exception
def _out_request_vehicle_base64(req: dict, props: dict):
    data = {
        "pesquisa": req.get('pesquisa', ''),
        "veiculo_renavam": req.get('doc_base64', '')
    }

    return data, ''

@_link_to_request(_sisger.SEND_CART1_BASE64_AUTONOMOUS, _sisger.SEND_CART1_BASE64_AGGREGATE)
@_handle_exception
def _out_request_cart1_base64(req: dict, props: dict):
    data = {
        "pesquisa": req.get('pesquisa', ''),
        "reboque_renavam": req.get('doc_base64', '')
    }

    return data, ''

@_link_to_request(_sisger.SEND_CART2_BASE64_AUTONOMOUS, _sisger.SEND_CART2_BASE64_AGGREGATE)
@_handle_exception
def _out_request_cart2_base64(req: dict, props: dict):
    data = {
        "pesquisa": req.get('pesquisa', ''),
        "reboque_2_renavam": req.get('doc_base64', '')
    }

    return data, ''

@_link_to_request(_sisger.SEND_CART3_BASE64_AUTONOMOUS, _sisger.SEND_CART3_BASE64_AGGREGATE)
@_handle_exception
def _out_request_cart3_base64(req: dict, props: dict):
    data = {
        "pesquisa": req.get('pesquisa', ''),
        "reboque_3_renavam": req.get('doc_base64', '')
    }

    return data, ''

@_link_to_response(_sisger.ADD_SEARCH_SHIPPING)
def _in_authenticate_user(resp: Response) -> Tuple[str, str]:
    ret = resp.json()
    retcode = resp.status_code

    if retcode in [200, 203, 240]:
        resp_data = {
            'sucesso': True,
            'conteudo': {
                'access_token': ret.get('access_token'),
                'token_type': ret.get('token_type'),
                'expires_in': ret.get('expires_in')
            }
        }
    else:
        resp_data = {
            'sucesso': False,
            'msg_erro': ret.get('Mensagem')
        }

    return mount_xml_response(resp_data), ''

@_link_to_response(_sisger.SEND_LICENSE_BASE64_AGGREGATE, _sisger.SEND_LICENSE_BASE64_AUTONOMOUS, _sisger.SEND_LICENSE_BASE64_SHIPPING,
                   _sisger.SEND_RESIDENCE_BASE64_AGGREGATE, _sisger.SEND_RESIDENCE_BASE64_AUTONOMOUS, _sisger.SEND_RESIDENCE_BASE64_SHIPPING,
                   _sisger.SEND_VEHICLE_BASE64_AGGREGATE, _sisger.SEND_VEHICLE_BASE64_AUTONOMOUS,
                   _sisger.SEND_CART1_BASE64_AGGREGATE, _sisger.SEND_CART1_BASE64_AUTONOMOUS,
                   _sisger.SEND_CART2_BASE64_AGGREGATE, _sisger.SEND_CART2_BASE64_AUTONOMOUS,
                   _sisger.SEND_CART3_BASE64_AGGREGATE, _sisger.SEND_CART3_BASE64_AUTONOMOUS)
def _in_send_document(resp: Response) -> Tuple[str, str]:
    ret = resp.json()
    retcode = resp.status_code

    if retcode in [200, 203, 240]:
        if ret.get('erro'):
            resp_data = {
                'sucesso': False,
                'msg_erro': deep_get(ret, 'erro.msg')
            }
        else:
            resp_data = {
                'sucesso': True,
                'conteudo': {
                    'pesquisa': ret.get('pesquisa'),
                    'msg': ret.get('msg')
                }
            }
    else:
        resp_data = {
            'sucesso': False,
            'msg_erro': ret.get('message')
        }

    return mount_xml_response(resp_data), ''


@_link_to_response(_sisger.ADD_SEARCH_AGGREGATE, _sisger.ADD_SEARCH_AUTONOMOUS, _sisger.ADD_SEARCH_SHIPPING,
                   _sisger.ADD_FINISH_AGGREGATE, _sisger.ADD_FINISH_AUTONOMOUS, _sisger.ADD_FINISH_SHIPPING)
def _in_add_vehicle_aggregate(resp: Response) -> Tuple[str, str]:
    ret = resp.json()
    retcode = resp.status_code
    resp_data = ''

    if retcode in [200, 203, 240]:
        if ret.get('status') == 'Authorization Token not found' or ret.get('status') == 'Token is Expired':
            resp_data = {
                'sucesso': False,
                'msg_erro': ret.get('status'),
            }
        elif ret.get('error') and ret.get('message'):
            resp_data = {
                'sucesso': False,
                'msg_erro': ret.get('message'),
            }
        elif ret.get('error'):
            resp_data = {
                'sucesso': False,
                'erros': [
                    {
                        'campo': k or '',
                        'descricao': '\n'.join(v) or ''
                    }
                    for k, v in ret.get('error', {}).items()
                ]
            }
        elif ret.get('msg'):
            resp_data = {
                'sucesso': True,
                'conteudo': {
                    'msg': ret.get('msg'),
                    'pesquisa': ret.get('pesquisa'),
                }
            }
        elif retcode == 203:
            resp_data = {
                'sucesso': True,
                'conteudo': {
                    'conteudo': deep_get(ret, 'erro.msg'),
                }
            }
    else:
        resp_data = {
            'sucesso': False,
            'msg_erro': 'Não foi possivel recuperar o erro'
        }

    return mount_xml_response(resp_data), ''


@_link_to_response(_sisger.ADD_VEHICLE_AGGREGATE, _sisger.ADD_VEHICLE_AUTONOMOUS, _sisger.ADD_CART1_AGGREGATE,
                   _sisger.ADD_CART1_AUTONOMOUS, _sisger.ADD_CART2_AGGREGATE, _sisger.ADD_CART2_AUTONOMOUS,
                   _sisger.ADD_CART3_AGGREGATE, _sisger.ADD_CART3_AUTONOMOUS)
def _in_add_vehicle_aggregate(resp: Response) -> Tuple[str, str]:
    ret = resp.json()
    retcode = resp.status_code
    resp_data = ''

    if retcode in [200, 203, 240]:
        if ret.get('status') == 'Authorization Token not found' or ret.get('status') == 'Token is Expired':
            resp_data = {
                'sucesso': False,
                'msg_erro': ret.get('status'),
            }
        elif ret.get('error'):
            resp_data = {
                'sucesso': False,
                'erros': [
                    {
                        'campo': k or '',
                        'descricao': '\n'.join(v) or ''
                    }
                    for k, v in ret.get('error', {}).items()
                ]
            }

        elif ret.get('message'):
            resp_data = {
                'sucesso': True,
                'conteudo': {
                    'conteudo': ret.get('message'),
                }
            }

    elif retcode in [401]:

        resp_data = {
            'sucesso': False,
            'msg_erro': ret.get('message'),
        }
    elif retcode in [403]:

        resp_data = {
            'sucesso': True,
            'conteudo': {
                'conteudo': ret.get('message'),
            }
        }
    else:
        resp_data = {
            'sucesso': False,
            'msg_erro': 'Não foi possivel recuperar o erro'
        }

    return mount_xml_response(resp_data), ''


@_link_to_response(_sisger.GET_TYPES_MATERIALS, _sisger.GET_VALUE_MERCHANDISE_AGGREGATE,
                   _sisger.GET_VALUE_MERCHANDISE_AUTONOMOUS, _sisger.GET_VALUE_MERCHANDISE_SHIPPING, _sisger.GET_BRAND,
                   _sisger.GET_MODEL, _sisger.GET_QUERY_SEARCH, _sisger.GET_QUERY_SEARCH_CPF, _sisger.GET_CARGO_VALUE_AUTONOMOUS)
def _in_get_generic(resp: Response) -> Tuple[str, str]:
    ret = resp.json()
    retcode = resp.status_code
    resp_data = ''

    if retcode in [200, 203, 240]:
        if 'erro' in ret:
            resp_data = {
                'sucesso': False,
                'conteudo': {
                    'msg_erro': deep_get(ret, 'erro.msg')
                }
            }
        elif deep_get(ret, 'principal'):
            resp_data = {
                'sucesso': True,
                'conteudo': {
                    'conteudo': deep_get(ret, 'principal.status'),
                }
            }
        else:
            resp_data = {
                'sucesso': True,
                'conteudo': {
                    'conteudo': ret,
                }
            }
    else:
        resp_data = {
            'sucesso': False,
            'msg_erro': 'Não foi possivel recuperar o erro'
        }

    return mount_xml_response(resp_data), ''


@_link_to_response(_sisger.REQUEST_CONSULTATION)
def _in_get_generic(resp: Response) -> Tuple[str, str]:
    ret = resp.json()
    retcode = resp.status_code
    resp_data = ''

    if retcode in [200]:
        resp_data = {
            'sucesso': True,
            'conteudo': {
                'complemento': deep_get(ret, 'complement'),
                'documento': deep_get(ret, 'documento'),
                'conteudo': deep_get(ret, 'consulta')
            }
        }
    else:
        resp_data = {
            'sucesso': False,
            'msg_erro': 'Não foi possivel recuperar o erro'
        }

    return mount_xml_response(resp_data), ''
#
# CONVERTE 19/02/2000 PARA 2000-02-19
def _date_yymmmdd(s: str) -> str:
    try:
        return datetime.strptime(s, "%d/%m/%Y").strftime("%Y-%m-%d")
    except (Exception,):
        return ''
