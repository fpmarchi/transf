from functools import lru_cache
from typing import Tuple

import xmltodict
from requests import Response

from dispacher import ActionProcessor
from dispacher.decorators import parse_props, handle_exception_factory
from geral import *
from geralxml import mount_xml_response, xml_from_dict


class FFGrException(Exception):
    pass


# Classe base
class FFGr(ActionProcessor):
    # INSTANCIAS
    HOST = 'http://gr.ffmonitoramento.com.br'
    TEST_HOST = HOST
    BASE_PATH = '/SITX9WebService/IntegraGR.wso'

    ADD_VEHICLE = 4150
    ADD_DRIVER = 4151
    ADD_SM = 4152
    CONSULT_VEHICLE_MODELS = 4153
    ADD_CHECKLIST = 4154
    REQUEST_INSURANCE_PROFILE = 4155
    CONSULT_INSURANCE_PROFILE = 4156

    content_length: int = None

    def __init__(self):
        self.add_callable_records('url', {
            self.DEFAULT_FUNCTION: self.make_url_assembler('')
        })

        super().__init__()

    @parse_props
    def get_headers(self) -> Tuple[dict, str]:
        return \
            {
                'Content-Type': 'text/xml',
            }, ''


#
#   Códigos independentes de instancia
#
def _ffgr_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a FFGr:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    FFGrException,
    _ffgr_exception_callback,
    any_exception_callback
)

#
#   Instancia limpa e sem configuração
#
_ffgr = FFGr()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = _ffgr.link_to_factory('request')
_link_to_response = _ffgr.link_to_factory('response')


def _mount_soap(data: Any):
    soap: dict = {
        'soap:Envelope': {
            '@xmlns:soap': 'http://www.w3.org/2003/05/soap-envelope',
            '@xmlns:tem': 'http://tempuri.org/',
            'soap:Header': '',
            'soap:Body': data
        }
    }
    # xml_mount = xml_from_dict(soap, prolog=True, indent=True)
    # _ffgr.content_length = len(normalize('NFD', xml_mount))
    return soap


@_link_to_request(_ffgr.ADD_VEHICLE)
@_handle_exception
def _add_vehicle(req: dict, props) -> Tuple[str, str]:
    type_vehicle = _type_veic(req.get('veic_cavalo', ''))

    cache = {}
    cache_wrapper = cache_wrapper_factory(cache)

    renavam_vehicle = req.get('veic_renavam', '').rjust(11, '0')

    data: dict = {
        'Set_AlteraVeiculoV2': {
            '#ns': 'tem',
            'Login': {
                'sUserName': props.get('usuario', ''),
                'sPassWord': props.get('senha', ''),
                'sToken': props.get('token', ''),
            },
            'DadosAV': {
                # 'sCd_CnpjUnidNeg': '29315151000110',
                'sCd_CnpjUnidNeg': req.get('veic_unidadeembarque', req.get('conh_filial_cnpjcpf', '')),
                'sCd_Placa': _place_format(req.get('veic_placa', '')),
                'sTp_Veiculo': type_vehicle,
                'sId_AutoInclusao': 'S',
                'DadosVeiculo': {
                    'sCd_ExclusivoCliente': '',
                    'iCd_Renavam': renavam_vehicle,
                    'sCd_Chassi': req.get('veic_chassi', ''),
                    'sNm_Cor': req.get('veic_cor', ''),
                    'iAa_Fabricacao': req.get('veic_anofab', ''),
                    'iAa_Modelo': req.get('veic_anomod', ''),
                    'iCd_Carroceria': req.get('veic_tipo'),
                    'sCd_ModeloVeiculo':
                        req.get('veic_modelo', '')
                        if type_vehicle in ['1', '2']
                        else None,
                    'sCd_MarcaVeiCarga':
                        req.get('veic_marca')
                        if type_vehicle == '3'
                        else None,
                    'sId_VeiculoCarga':
                        req.get('veic_tipo', '')
                        if type_vehicle == '3'
                        else None,
                    'sId_VincVeiculo': _type_bond(req.get('veic_propriedade', '')),
                    'sCd_MunLicenc': req.get('veic_codibge', ''),
                    'dDt_Aquisicao': '',
                    'dDt_Venda': '',
                    'sId_Ativo': 'A',
                    'sDc_Obs>': '',
                    'sCd_ANTT': req.get('veic_rntrc', ''),
                    'dDt_ValidadeANTT': _date_ddmmyy(req.get('veic_validaderntrc', '')),
                },
                'DadosFaturamento>': {
                    'sTp_Faturamento': 'A',
                    'sId_FormaFixo': '',
                },
                'DadosProprietario': {
                    'sCd_CnpjPropVeiculo': req.get('prop_cnpjcpf', ''),
                    'sNm_PropVeiculo': req.get('prop_nome', ''),
                    'sNo_FonePropVeiculo': req.get('prop_foneddd', '') + req.get('prop_fonenumero', ''),
                },
                'DadosSerial':
                    {
                        'iCd_Tecnologia': req.get('veic_tecnologia_rastreador', '1'),
                        'sCd_ModRastreador': cache_wrapper(
                            'mod_rastreador',
                            req.get('veic_modelo_rastreador', '')
                        ),
                        'sCd_SerialRastreador':
                            req.get('veic_numeromct') or 'EMPTY'
                            if cache.get('mod_rastreador') and cache.get('mod_rastreador') != '9999'
                            else 'EMPTY'
                    }
                    if type_vehicle in ['1', '2']
                    else None,
                'DadosFormacaoPadrao': {
                    'sId_FormPadrao': '99',  # Não tem trator
                    'sCd_PlacaCarreta>string': [
                        _place_format(req.get('car1_placa', '')),
                        _place_format(req.get('car2_placa', '')),
                        _place_format(req.get('car3_placa', '')),
                    ]
                },
                'DadosCondutorPadrao': {
                    'sNo_CpfCondutor': req.get('mot_cpf', ''),
                    'DadosPerfSecCondutor': {
                        'iCd_FornecPerfSec': '',  # 99
                        'sId_VincCondutorPS': _type_conductor(req.get('prop_agregado', '')),
                        'sCd_PesquisaPS': '',
                        'dDt_PesquisaPS': '',
                        'dDt_ValidadePS': '',
                    }
                },
                'DadosTransSinal': {
                    'sId_IncExcSinal': '',
                    'sCd_CnpjEmpDet': '',
                    'sNm_EmpDet': '',
                    'sNm_FantasiaEmpDet': '',
                    'sCd_AutotracID': '',
                    'sCd_AutotracUA': '',
                    'sNo_TelefEmpDet': '',
                    'sNm_ContatoEmpDet': '',
                    'sDc_EmailCntEmpDet': '',
                    'sNo_TelefCntEmpDet': '',
                },
            }
        }
    }

    return remove_accents(xml_from_dict(_mount_soap(data), indent=True, prolog=True)), ''
    # return xml_from_dict(_mount_soap(data), indent=True, prolog=True).encode().decode(), ''

    # return _mount_soap(data), ''


@_link_to_request(_ffgr.ADD_DRIVER)
@_handle_exception
def _add_driver(req: dict, props) -> Tuple[str, str]:
    cat_cnh = req.get('mot_catcnh', '').strip()

    if len(req.get('mot_senha', '')) > 8:
        raise FFGrException('A senha do motorista não pode ter mais de 8 caracteres')

    data: dict = {
        'Set_AlteraCondutor': {
            '#ns': 'tem',
            'Login': {
                'sUserName': props.get('usuario', ''),
                'sPassWord': props.get('senha', ''),
                'sToken': props.get('token', ''),
            },
            'DadosAC': {
                # 'sCd_CnpjUnidNeg': '29315151000110',
                'sCd_CnpjUnidNeg': req.get('mot_uniembarque', ''),
                'sNo_CpfCondutor': req.get('mot_cpf', ''),
                'sId_AutoInclusao': 'S',
                'DadosCondutor': {
                    'sNm_Condutor': req.get('mot_nome', ''),
                    'sAb_Condutor': req.get('mot_nome', '').split(" ")[0],
                    'sNo_CNH': req.get('mot_cnh', '').rjust(11, '0'),
                    'dDt_ValidadeCNH': _date_ddmmyy(req.get('mot_datavalidcnh', '')),
                    'sId_CategoriaCNH': cat_cnh if len(cat_cnh) <= 1 else cat_cnh[0] + '/' + cat_cnh[1],
                    'sTp_Identidade': 'RG',
                    'sNo_Identidade': req.get('mot_rg', ''),
                    'sSg_OrgaoExpedIdentidade': req.get('mot_orgaorguf', ''),
                    'dDt_EmissaoIdentidade': req.get('mot_datarg', ''),
                    'sId_VinculoEmpreg': _type_conductor(req.get('mot_funcionario', '')),
                    'iCd_CEP': req.get('mot_cep', ''),
                    'sNm_Logradouro': req.get('mot_endereco', ''),
                    'sNo_Logradouro': req.get('mot_numero', ''),
                    'sCp_Logradouro': req.get('mot_complemento', ''),
                    'sNm_Bairro': req.get('mot_bairro', ''),
                    'sCd_Municipio': req.get('mot_codibge', ''),
                    'sCd_Latitude': '',
                    'sCd_Longitude': '',
                    'sDc_Obs': req.get('mot_obsgerais', ''),
                    'dDt_InterrupAtivid': '',
                    'sCd_SegCentralMonit': req.get('mot_senha', ''),
                    'sNm_Mae': req.get('mot_nomemae', ''),
                    'sNm_Pai': req.get('mot_nomepai', ''),
                    'dDt_Nascimento': req.get('mot_datanasc', ''),
                    'sCd_MunNatural': req.get('mot_ibgecidnascimento', ''),
                    'sId_EstadoCivil': _marital_status(req.get('mot_estadocivil', '')),
                    'sId_Sexo': req.get('mot_sexo', ''),
                    'sCd_SegurancaCNH': req.get('mot_cnhformulario', '').rjust(11, '0'),
                    'sUF_SegurancaCNH': req.get('mot_ufcnh', ''),
                },
                'DadosCondutorCnt': {
                    'stDadosCondutorCnt': {
                        'iCd_DDD': req.get('mot_celularddd', '').rjust(3, '0'),
                        'sNo_TelContato': req.get('mot_celularnumero', '')[0:5] + '-' + req.get('mot_celularnumero',
                                                                                                '')[5:10],
                        'sId_TipoTelefone': 'Cel',
                        'sId_Propriedade': 'P',
                        'iCd_OperTelefonia': '99',
                        'sNm_PessoaCnt': '',
                    }
                },
                'DadosPerfSecCondutor': {
                    'iCd_FornecPerfSec': '',
                    'sId_VincCondutorPS': '',
                    'sCd_PesquisaPS': '',
                    'dDt_PesquisaPS': '',
                    'dDt_ValidadePS': '',
                },
            }
        }
    }

    return remove_accents(xml_from_dict(_mount_soap(data), indent=True, prolog=True)), ''


@_link_to_request(_ffgr.ADD_SM)
@_handle_exception
def _add_driver(req: dict, props) -> Tuple[str, str]:
    data: dict = {
        'Set_SolicitaMonitoramento': {
            '#ns': 'tem',
            'Login': {
                'sUserName': props.get('usuario', ''),
                'sPassWord': props.get('senha', ''),
                'sToken': props.get('token', ''),
            },
            'DadosSM': {
                # 'sCd_CnpjUnidNeg': '29315151000110',
                'sCd_CnpjUnidNeg': req.get('conh_filial_cnpjcpf', ''),
                'sCd_Placa': _place_format(req.get('conh_veic_placa', '')),
                'ControleAgendamento': {
                    'sId_AutorizaCklNeg': 'S',
                    'sId_UtilizaFormPadrao': 'S',
                    'sId_UtilizaCondPadrao': 'S',
                    'sId_CtrlCarga': 'N',
                    'sId_CtrlDescarga': 'N',
                },

                'ConjuntoViagem': {
                    'iId_FormacaoCVC': '4',  # Verificar
                    'sCd_PlacaCarretaCV>string': [
                        _place_format(req.get('conh_veic_placacarreta1', '')),
                        _place_format(req.get('conh_veic_placacarreta2', '')),
                        _place_format(req.get('conh_veic_placacarreta3', '')),
                    ],
                },
                'CondutoresViagem': {
                    'sNo_CpfCondutorPrinc': req.get('conh_mot_cpf', ''),
                    'sNo_CpfCondutorAux': '',
                },
                'DadosAjudantes': {
                    'iQt_Ajudantes': 'N',
                    'sNo_CpfAjudante': {
                        'string'
                        'string'
                    },
                },
                'ControleDDR': {
                    'sId_Ddr': 'N',
                    'iCd_SeguradoraDdr': '',
                    'sCd_CnpjEmbarcDdr': '',
                },
                'DadosViagem': {
                    'sCd_Rota': 'S',
                    'sCd_MunicipioOrigem': req.get('conh_codibgeorig', ''),
                    'sCd_MunicipioDestino': req.get('conh_codibgedest', ''),
                    'dDh_PrevInicio': req.get('conh_dataini', ''),
                    'dDh_PrevFim': req.get('conh_dataprevisaodescarga', ''),
                    'sId_OperTransp': 'C',
                    'nVl_Carga': req.get('conh_valormerc', ''),
                    'sCd_CnpjEmbarcViagem': req.get('conh_cliente_cnpjcpf', ''),
                    'EnderecoOrigem': {
                        'sCEP': req.get('conh_ceporig', ''),
                        'sNm_Endereco': req.get('conh_rem_endereco', ''),
                        'sNo_Endereco': req.get('conh_rem_numero', ''),
                        'sNm_Bairro': req.get('conh_rem_bairro', ''),
                    },
                    'EnderecoDestino': {
                        'sCEP': req.get('conh_cepdest', ''),
                        'sNm_Endereco': req.get('conh_dest_endereco', ''),
                        'sNo_Endereco': req.get('conh_dest_numero', ''),
                        'sNm_Bairro': req.get('conh_dest_bairro', ''),
                    },
                    'DadosObsViagem': {
                        'sDc_ObsGEN': '',
                        'sDc_ObsOGR': '',
                        'sDc_ObsOFV': '',
                    },
                    'DadosTranspTerceiro': {
                        'sId_TranspTerceiro': 'N',
                        'sCd_CnpjTransp': 'N',
                    },
                    'SequenciaOperacao.stSequenciaOperacao': {
                        'sId_Operacao': 'C',
                        'sCd_MunicipioOper': req.get('conh_rem_codibge', ''),
                        'sDc_LocalOperacao': req.get('conh_rem_pais', ''),
                        'sCd_CnpjEmbarcCliente': req.get('conh_cliente_cnpjcpf', ''),
                        'sCEP': req.get('conh_rem_cep', ''),
                        'sNm_Endereco': req.get('conh_rem_endereco', ''),
                        'sNo_Endereco': req.get('conh_rem_numero', ''),
                        'sNm_Bairro': req.get('conh_rem_bairro', ''),
                        'sCd_Produto': req.get('conh_descmerc', ''),
                        'nVl_Produto': req.get('conh_valormerc', ''),
                        'dDh_PrevisaoChegada': req.get('conh_dataprevisaodescarga', ''),
                        'sId_DetNF': 'N',
                        'iNo_NotaFiscal': {
                            'int',
                        },
                    },
                    # 'stSequenciaOperacao': {
                    #     'sId_Operacao': 'S',
                    #     'sCd_MunicipioOper': 'S',
                    #     'sDc_LocalOperacao': 'S',
                    #     'sCd_CnpjEmbarcCliente': 'S',
                    #     'sCEP': 'S',
                    #     'sNm_Endereco': 'S',
                    #     'sNo_Endereco': 'S',
                    #     'sNm_Bairro': 'S',
                    #     'sCd_Produto': 'S',
                    #     'nVl_Produto': 'S',
                    #     'dDh_PrevisaoChegada': 'S',
                    #     'sId_DetNF': 'S',
                    #     'iNo_NotaFiscal': {
                    #         'int',
                    #         'int',
                    #     },
                    # },

                },
                'DadosEscolta': {
                    'sId_PossuiEscolta': 'N',
                    'sCd_CnpjEmpEscolta': '',
                    'sCd_PlacaEscolta': '',
                    'sCd_CpfAgenteEscolta': {
                        'string': '',
                        # 'string': '',
                    },
                },
                'RastreadorAuxiliar': {
                    'sId_UtilizaRLAux': 'N',
                    'Rastreadores': {
                        'stRastreadores': {
                            'sTp_InstRastrLoc': '',
                            'iCd_TecnologiaRLAux': '',
                            'iCd_ModRLAux': '',
                            'sCd_SerialRLAux': ''

                        },
                        # 'stRastreadores': {
                        #     'sTp_InstRastrLoc': '',
                        #     'iCd_TecnologiaRLAux': '',
                        #     'iCd_ModRLAux': '',
                        #     'sCd_SerialRLAux': '',
                        #
                        # },
                    },
                },
                'FaixasTemperatura': {
                    'sId_CtrlTemperatura': 'N',
                    'nFx_TemperMin': '',
                    'nFx_TemperMax': '',
                },
                'sNm_UserCliente': req.get('conh_usuario_autenticado', ''),
            }
        }
    }

    return remove_accents(xml_from_dict(_mount_soap(data), indent=True, prolog=True)), ''


@_link_to_request(_ffgr.CONSULT_VEHICLE_MODELS)
@_handle_exception
def _add_driver(props) -> Tuple[str, str]:
    data: dict = {
        'Get_ConsultaModelo': {
            '#ns': 'tem',
            'Login': {
                'sUserName': props.get('usuario', ''),
                'sPassWord': props.get('senha', ''),
                'sToken': props.get('token', ''),
            },
        }
    }

    return remove_accents(xml_from_dict(_mount_soap(data), indent=True, prolog=True)), ''


@_link_to_request(_ffgr.ADD_CHECKLIST)
@_handle_exception
def _add_checklist(req: dict, props) -> Tuple[str, str]:
    data: dict = {
        'Set_SolicitaChecklist': {
            '#ns': 'tem',
            'Login': {
                'sUserName': props.get('usuario', ''),
                'sPassWord': props.get('senha', ''),
                'sToken': props.get('token', ''),
            },
            'DadosCK': {
                # 'sCd_CnpjUnidNeg': '29315151000110',
                'sCd_CnpjUnidNeg': req.get('veic_uniembarque', ''),
                'sSolicitaCheckList': req.get('senha', ''),
                'sCd_Placa': _place_format(req.get('veic_placa', '')),
                'sCd_PlacaCarreta>string': [
                    _place_format(req.get('car1_placa', '')),
                    _place_format(req.get('car2_placa', '')),
                    _place_format(req.get('car3_placa', '')),
                ],
            }
        }
    }

    return remove_accents(xml_from_dict(_mount_soap(data), indent=True, prolog=True)), ''


@_link_to_request(_ffgr.REQUEST_INSURANCE_PROFILE)
@_handle_exception
def _out_insurance_profile(req: dict, props: dict) -> Tuple[str, str]:
    data: dict = {
        'Set_SolicitaPerfSecuritario': {
            '#ns': 'tem',
            'Login': {
                'sUserName': props.get('usuario', ''),
                'sPassWord': props.get('senha', ''),
                'sToken': props.get('token', '')
            },
            'DadosPerfSecur': {
                # 'sCd_CnpjUnidNeg': '29315151000110',
                'sCd_CnpjUnidNeg': req.get('veic_uniembarque', ''),
                'sSolicitaPerfSec': 'S',
                'iCd_Registro': None,
                'sTipoCPF': 'MOTORISTA',
                'sCPF': req.get('mot_cpf', ''),
                'DocsCPF': None,
                'sReferenciasCPF': '',
                'sCd_Placa': _place_format(req.get('veic_placa', '')),
                'DocsVeiculo': None,
                'sCd_PlacaCarreta1': _place_format(req.get('car1_placa', '')) if props.get('gamb') != '000' else None,
                'DocsCarreta1': None,
                'sCd_PlacaCarreta2': _place_format(req.get('car2_placa', '')) if props.get('gamb') != '000' else None,
                'DocsCarreta2': None,
                'sCd_PlacaCarreta3': _place_format(req.get('car3_placa', '')) if props.get('gamb') != '000' else None,
                'DocsCarreta3': None,
                'InfoViagem': {
                    'sCd_MunicipioOrigem': req.get('origem', ''),
                    'sCd_MunicipioDestino': req.get('destino', ''),
                    'sNm_Produto': req.get('mercadoria', ''),
                    'nVl_Carga': req.get('valor_mercadoria', '')
                }
            }
        }
    }

    return remove_accents(
        xml_from_dict(_mount_soap(data), indent=True, prolog=True)
    ), ''


@_link_to_request(_ffgr.CONSULT_INSURANCE_PROFILE)
@_handle_exception
def _consult_insurance_profile_out(req: dict, props: dict) -> Tuple[str, str]:
    data: dict = {
        'Set_SolicitaPerfSecuritario': {
            '#ns': 'tem',
            'Login': {
                'sUserName': props.get('usuario', ''),
                'sPassWord': props.get('senha', ''),
                'sToken': props.get('token', '')
            },
            'DadosPerfSecur': {
                # 'sCd_CnpjUnidNeg': '29315151000110',
                'sCd_CnpjUnidNeg': req.get('veic_uniembarque'),
                'sSolicitaPerfSec': 'N',
                'iCd_Registro': req.get('protocolo'),
                'sTipoCPF': None,
                'sCPF': None,
                'DocsCPF': None,
                'sReferenciasCPF': None,
                'sCd_Placa': None,
                'DocsVeiculo': None,
                'sCd_PlacaCarreta1': None,
                'DocsCarreta1': None,
                'sCd_PlacaCarreta2': None,
                'DocsCarreta2': None,
                'sCd_PlacaCarreta3': None,
                'DocsCarreta3': None,
                'InfoViagem': None
            }
        }
    }

    return xml_from_dict(_mount_soap(data), indent=True, prolog=True), ''


@_link_to_response(_ffgr.CONSULT_VEHICLE_MODELS)
@_handle_exception
def _in_consult_vehicle_models(resp: Response) -> Tuple[str, str]:
    json_ret = _extract_json_response(resp)

    erros = deep_get(json_ret, 'm:Get_ConsultaModeloResponse.m:Get_ConsultaModeloResult', ())
    if type(erros) is not list:  # false
        erros = [erros]

    marcas = deep_get(erros[0], 'm:Marcas.m:stMarcas', ())
    modelos = deep_get(erros[0], 'm:Modelos.m:stModelos', ())
    categorias = deep_get(erros[0], 'm:Categorias.m:stCategorias', ())
    resp_body = {
        'sucesso': 'true',
        'marcas': [
            {
                'id': marca.get('m:iCd_Marca') or '',
                'nome': marca.get('m:sNm_Marca') or ''
            }
            for marca in marcas
        ],
        'modelos': [
            {
                'id_modelo': modelo.get('m:iCd_Modelo') or '',
                'nome_modelo': modelo.get('m:sNm_Modelo') or '',
                'id_marca': modelo.get('m:iCd_Marca') or '',
                'id_categoria': modelo.get('m:iCd_Categoria') or '',
                'id_veic_trator': modelo.get('m:sId_VeicTrator') or ''
            }
            for modelo in modelos
        ],
        'categorias': [
            {
                'id': categoria.get('m:iCd_Categoria') or '',
                'nome': categoria.get('m:sNm_Categoria') or ''
            }
            for categoria in categorias
        ],
    }

    return mount_xml_response(resp_body), ''


@_link_to_response(_ffgr.REQUEST_INSURANCE_PROFILE, _ffgr.CONSULT_INSURANCE_PROFILE)
@_handle_exception
def _consult_insurance_profile_int(resp: Response) -> Tuple[str, str]:
    json_ret = _extract_json_response(resp)
    json_ret = deep_get(json_ret, 'm:Set_SolicitaPerfSecuritarioResponse.m:Set_SolicitaPerfSecuritarioResult')

    result = deep_get(json_ret, 'm:Retorno.m:stResult')
    if type(result) is not list:
        result = [result]

    msg_erro = ''
    for rets in result:
        code = rets.get('m:sCode', 'ER')
        msg = rets.get('m:sResult', 'Não foi possível obter a mensagem de erro')

        if code.startswith('ER'):
            msg_erro += msg + '\n'

    if msg_erro.strip():
        resp_body = {
            'sucesso': False,
            'msg_erro': msg_erro
        }

        return mount_xml_response(resp_body), ''

    content = {}
    resp_body = {
        'sucesso': True,
        'conteudo': content
    }

    status_ff = safe_cast(json_ret.get('m:sStatus'), int)
    content.update({
        'protocolo': json_ret.get('m:iCd_Registro'),
        'cod_status': _get_status_code(status_ff),
        'cod_situacao': _get_situation_code(status_ff),
        'descricao_situacao': _get_situation_text(status_ff),
        'validade': json_ret.get('m:dtValidade') if status_ff == 5 else None,
        'observacoes': None
    })

    if status_ff == 5:
        content['descricao_situacao'] = content['descricao_situacao'] + '. Num. Liberação: ' + json_ret.get('m:sCd_PerfSecur')

    for rets in result:
        code = rets.get('m:sCode', '')
        msg = rets.get('m:sResult', '')

        if code.startswith('WA'):
            content['observacoes'].append({
                'item': code,
                'msg': msg
            })

    if 'm:stItensPerfSecur' in (json_ret.get('m:ItensPerfSecur') or {}):
        items = deep_get(json_ret, 'm:ItensPerfSecur.m:stItensPerfSecur')

        if type(items) is not list:
            items = [items]

        if content['observacoes'] is None:
            content['observacoes'] = []

        content['observacoes'].extend(
            [{
                'item': item.get('m:sItem') or '',
                'msg': item.get('m:sResultado') or ''
            } for item in items]
        )

    return mount_xml_response(resp_body), ''


@_link_to_response(_ffgr.DEFAULT_FUNCTION)
@_handle_exception
def _in_default(resp: Response, callable_key: int) -> Tuple[str, str]:
    json_ret = _extract_json_response(resp)

    if callable_key == _ffgr.ADD_VEHICLE:
        result = deep_get(
            json_ret, 'm:Set_AlteraVeiculoV2Response.m:Set_AlteraVeiculoV2Result.m:Retorno.m:stResult'
        )
    elif callable_key == _ffgr.ADD_DRIVER:
        result = deep_get(
            json_ret, 'm:Set_AlteraCondutorResponse.m:Set_AlteraCondutorResult.m:Retorno.m:stResult'
        )
    elif callable_key == _ffgr.ADD_SM:
        result = deep_get(
            json_ret,
            'm:Set_SolicitaMonitoramentoResponse.m:Set_SolicitaMonitoramentoResult.m:Retorno.m:stResult'
        )
    elif callable_key == _ffgr.ADD_CHECKLIST:
        result = deep_get(
            json_ret,
            'm:Set_SolicitaChecklistResponse.m:Set_SolicitaChecklistResult.m:Retorno.m:stResult'
        )
    elif callable_key == _ffgr.CONSULT_VEHICLE_MODELS:
        result = deep_get(
            json_ret,
            'm:Set_SolicitaChecklistResponse.m:Set_SolicitaChecklistResult.m:Retorno.m:stResult'
        )
    elif callable_key == _ffgr.REQUEST_INSURANCE_PROFILE:
        result = deep_get(
            json_ret,
            'm:Set_SolicitaPerfSecuritarioResponse.m:Set_SolicitaPerfSecuritarioResult.m:Retorno.m:stResult'
        )
    else:
        raise Exception('Não foi possível identificar o tratamento de retorno para essa operação.')

    if not result:
        raise Exception('Não foi possível obter o retorno dessa operação.')

    if type(result) is not list:
        result = [result]

    conteudo = []
    msg_erro = ''
    success = False
    for rets in result:
        code = rets.get('m:sCode', '')
        msg = rets.get('m:sResult', '')

        success = code.startswith('OK') or code.startswith('WA')
        if success:
            conteudo.append({
                'codigo': code,
                'msg': msg
            })
        else:
            msg_erro += msg + '\n'

    resp_body = {
        'sucesso': success,
        'msg_erro': msg_erro.strip()
    }

    if conteudo:
        resp_body['conteudo'] = conteudo
        del resp_body['msg_erro']

    return mount_xml_response(resp_body), ''


#
# CONVERTE 19/02/2000 PARA 2000-02-19
def _date_ddmmyy(s: str) -> str:
    try:
        return datetime.strptime(s, "%d/%m/%Y").strftime("%Y-%m-%d")
        # return datetime.strptime(s, "%Y-%m-%d").strftime("%d/%m/%Y")
    except (Exception,):
        return ''


def _type_veic(type_) -> str:
    if type_ == 'S':
        return '1'
    elif type_ == 'N':
        return '3'
    elif type_ == 'F':
        return '2'


def _type_bond(type_bond: str) -> str:
    if type_bond in 'SFRO':
        return 'P'
    elif type_bond in 'N':
        return 'T'
    elif type_bond in 'AMG':
        return 'A'
    else:
        return 'D'


# def _cart_brand(type_cart: str) -> str:

def _type_conductor(type_conductor: str) -> str:
    if type_conductor in 'SGM':
        return 'A'
    elif type_conductor == 'P':
        return 'C'
    elif type_conductor in 'N':
        return 'T'
    else:
        return ''


def _marital_status(marital_status: str) -> str:
    if marital_status == '1':
        return 'S'
    elif marital_status == '2':
        return 'C'
    elif marital_status == '4':
        return 'D'
    elif marital_status == '5':
        return 'V'
    else:
        return 'O'


def _place_format(place: str) -> str:
    if place:
        return place[0:3] + '-' + place[3:7]
    else:
        return ''


def _extract_json_response(resp: Response) -> dict:
    raw_resp = resp.text
    raw_resp = raw_resp[raw_resp.find('<?xml'):]

    json_ret = deep_get(xmltodict.parse(raw_resp), 'soap:Envelope.soap:Body')

    ret_code = resp.status_code
    if ret_code == 500:
        raise Exception(deep_get(json_ret, 'soap:Fault.faultstring'))

    return json_ret

# Status FFGr
# 1 - Em Processo de análise
# 2 - Solicitação consulta cancelada
# 3 - Pendente de documentação (Entre em contato com a GR)
# 4 - Processo encerrado sem êxito! Mais de 48 horas pendente de documentação.
# 5 - Consulta efetivada


@lru_cache(maxsize=6)
def _get_status_code(cod_status_ff: int):
    # SAT: PENDENTE = 1, EM_PROCESSAMENTO = 2, PROCESSADA = 3, CANCELADA = 4
    relationship = {
        1: 2,
        2: 4,
        3: 1,
        4: 3,
        5: 3
    }
    return relationship.get(cod_status_ff)


@lru_cache(maxsize=6)
def _get_situation_code(cod_status_ff: int):
    # SAT: INDEFINIDA = 1, LIBERADO = 2, BLOQUEADO = 3
    relationship = {
        1: 1,
        2: 3,
        3: 1,
        4: 3,
        5: 2
    }
    return relationship.get(cod_status_ff)


@lru_cache(maxsize=6)
def _get_situation_text(cod_status_ff: int):
    # SAT: INDEFINIDA = 1, LIBERADO = 2, BLOQUEADO = 3
    relationship = {
        1: 'Em Processo de análise',
        2: 'Consulta cancelada',
        3: 'Pendente de documentação (Entre em contato com a GR)',
        4: 'Processo encerrado sem êxito! Mais de 48 horas pendentes de documentação.',
        5: 'Consulta efetivada'
    }
    return relationship.get(cod_status_ff, '')
