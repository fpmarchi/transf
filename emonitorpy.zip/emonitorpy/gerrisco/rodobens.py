ACAO_RODOBENS_INICIO = 3350
ACAO_RODOBENS_CADASTRARVEICULO = 3351
ACAO_RODOBENS_CADASTRARPROPRIETARIO = 3352
ACAO_RODOBENS_CADASTRARMOTORISTA = 3353
ACAO_RODOBENS_SOLICITARMONITORAMENTO = 3354
ACAO_RODOBENS_FIM = 3399

from xmltodict import unparse
from geraljson import getJSON
import xml.dom.minidom as mdom
import geralxml
import json
from geral import *

def conteudoTag(conteudo, tipoConteudo='xsd:string'):
    tag = {}
    tag['@xsi:type'] = tipoConteudo
    tag['#text'] = conteudo
    return tag


def requestRodobensSalvaVeiculo(reqJSON, properties):
    try:
        salvaVeiculo = {}
        salvaVeiculo['id_cliente'] = conteudoTag(properties['idCliente'], 'xsd:int')
        salvaVeiculo['id_chave'] = conteudoTag(properties['chave'])
        salvaVeiculo['id_placa'] = conteudoTag(getJSON(reqJSON, 'veic_placa'))
        salvaVeiculo['si_uf_placa'] = conteudoTag(getJSON(reqJSON, 'veic_uf'))
        salvaVeiculo['nm_cidade_placa'] = conteudoTag(getJSON(reqJSON, 'veic_nomecidade'))
        salvaVeiculo['id_chassi'] = conteudoTag(getJSON(reqJSON, 'veic_chassi'))
        salvaVeiculo['id_renavam'] = conteudoTag(getJSON(reqJSON, 'veic_renavam'))
        salvaVeiculo['ds_tipo_veiculo'] = conteudoTag(getJSON(reqJSON, 'veic_tipoveic'))
        salvaVeiculo['ds_tipo_carroc'] = conteudoTag(getJSON(reqJSON, 'veic_tipocarr'))
        salvaVeiculo['ds_fabrica'] = conteudoTag('') # nao obrigatoria
        salvaVeiculo['ds_marca'] = conteudoTag(getJSON(reqJSON, 'veic_marca'))
        salvaVeiculo['ds_modelo'] = conteudoTag(getJSON(reqJSON, 'veic_modelo'))
        salvaVeiculo['id_ano_fab'] = conteudoTag(getJSON(reqJSON, 'veic_anofab'))
        salvaVeiculo['id_ano_mod'] = conteudoTag(getJSON(reqJSON, 'veic_anomod'))
        salvaVeiculo['ds_cor'] = conteudoTag(getJSON(reqJSON, 'veic_cor'))
        salvaVeiculo['ds_tipo_comb'] = conteudoTag(getJSON(reqJSON, 'veic_tipocombustivel')) #
        salvaVeiculo['id_mes_licenc'] = conteudoTag(getJSON(reqJSON, 'veic_documento')) # mes licenciamento do veiculo #o que é o id mes licenc?
        salvaVeiculo['dt_ult_licenc'] = conteudoTag(getJSON(reqJSON, 'veic_datavencdocumento')) # mes licenciamento do veiculo #o que é o dt ult licenc?
        tipoProprietario = getJSON(reqJSON, 'prop_agregado')
        salvaVeiculo['id_tipo_proprietario'] = conteudoTag(getTipoProprietario(tipoProprietario)) #agregado, #frota propria, #carreteiro
        salvaVeiculo['nr_cnpjcpf_proprietario'] = conteudoTag(getJSON(reqJSON, 'prop_cnpjcpf'))
        salvaVeiculo['id_rastreado_rodobens'] = conteudoTag('N') #S ou #N # se será rastreado pela rodobens ou não
        salvaVeiculo['ds_tipo_rastr'] = conteudoTag(getJSON(reqJSON, 'veic_tiporastreador')) #sascar/onixsat
        salvaVeiculo['nr_equipamento'] = conteudoTag(getJSON(reqJSON, 'veic_numeromct')) # nr rastreador
        #esporadico ou mensal, vou tentar nao mandar a tag por enquanto
        salvaVeiculo['id_modalidade_rastreamento'] = conteudoTag('')
        salvaVeiculo['@soapenv:encodingStyle'] = 'http://schemas.xmlsoap.org/soap/encoding/'
        body = {}
        body['urn:salvaVeiculo'] = salvaVeiculo
        envelope = {}
        envelope['@xmlns:xsi'] = 'http://www.w3.org/2001/XMLSchema-instance'
        envelope['@xmlns:xsd'] = 'http://www.w3.org/2001/XMLSchema'
        envelope['@xmlns:soapenv'] = 'http://schemas.xmlsoap.org/soap/envelope/'
        envelope['@xmlns:urn'] = 'urn:rodobensGerenciamentoRisco'
        envelope['soapenv:Header'] = ''
        envelope['soapenv:Body'] = body
        raiz = {}
        raiz['soapenv:Envelope'] = envelope
        xml = unparse(raiz, pretty=True)
        return xml, ''
    except Exception as e:
        print('Erro em requestRodobensSalvaVeiculo')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO'


def responseRodobensSalvaVeiculo(ret):
    try:
        document = mdom.parseString(ret)
        faultstring = document.getElementsByTagName('faultstring')
        if faultstring:
            raise ValueError
        salvaVeiculoResponse = document.getElementsByTagName('ns1:salvaVeiculoResponse')
        mensagem = geralxml.findChildNodeByName(salvaVeiculoResponse, 'ds_retorno')
        if 'ja cadastrad' in mensagem:
            mensagem = 'Veículo já cadastrado com sucesso !'
        if 'sucesso' in mensagem:
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + mensagem + '</msg></resp>', ''
        else:
            return '', mensagem
    except Exception as e:
        print('Erro em responseRodobensSalvaVeiculo')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRodobensSalvaPessoaFisica(reqJSON, properties, pessoa):
    try:
        if pessoa == 'prop':
            prefixTag = 'prop_'
            cargo = getTipoPessoaProp(getJSON(reqJSON, 'prop_agregado'))
            cpf = getJSON(reqJSON, 'prop_cnpjcpf')
            cidade = getJSON(reqJSON, prefixTag + 'cidade')
            uf = getJSON(reqJSON, prefixTag + 'uf')
            numeroCnh = ''
            catCnh = ''
            corPele = ''
            corCabelo = ''
            tipoCabelo = ''
            corOlhos = ''
            altura = ''
            peso = ''
            refPessoal1Nome = ''
            refPessoal1DDD = ''
            refPessoal1fone = ''
            refPessoal2Nome = ''
            refPessoal2DDD = ''
            refPessoal2fone = ''
            refComercial1Nome = ''
            refComercial1DDD = ''
            refComercial1fone = ''
            refComercial2Nome = ''
            refComercial2DDD = ''
            refComercial2fone = ''
            refComercial3Nome = ''
            refComercial3DDD = ''
            refComercial3fone = ''
        elif pessoa == 'mot':
            prefixTag = 'mot_'
            cargo = getTipoPessoaMot(getJSON(reqJSON, 'mot_funcionario'))
            cpf = getJSON(reqJSON, 'mot_cpf')
            numeroCnh = getJSON(reqJSON, 'mot_cnh')
            catCnh = getJSON(reqJSON, 'mot_catcnh')
            cidade = getJSON(reqJSON, 'mot_nomecidendereco')
            uf = getJSON(reqJSON, 'mot_ufcidendereco')
            corPele = ''
            corCabelo = ''
            tipoCabelo = ''
            corOlhos = ''
            altura = ''
            peso = ''
            refPessoal1Nome = getJSON(reqJSON, 'mot_referencia_pessoal1_nome')
            refPessoal1DDD = getJSON(reqJSON, 'mot_referencia_pessoal1_ddd')
            refPessoal1fone = getJSON(reqJSON, 'mot_referencia_pessoal1_numero')
            refPessoal2Nome = getJSON(reqJSON, 'mot_referencia_pessoal2_nome')
            refPessoal2DDD = getJSON(reqJSON, 'mot_referencia_pessoal2_ddd')
            refPessoal2fone = getJSON(reqJSON, 'mot_referencia_pessoal2_numero')
            refComercial1Nome = getJSON(reqJSON, 'mot_referencia_profissional1_nome')
            refComercial1DDD = getJSON(reqJSON, 'mot_referencia_profissional1_ddd')
            refComercial1fone = getJSON(reqJSON, 'mot_referencia_profissional1_numero')
            refComercial2Nome = getJSON(reqJSON, 'mot_referencia_profissional2_nome')
            refComercial2DDD = getJSON(reqJSON, 'mot_referencia_profissional2_ddd')
            refComercial2fone = getJSON(reqJSON, 'mot_referencia_profissional2_numero')
            refComercial3Nome = getJSON(reqJSON, 'mot_referencia_profissional3_nome')
            refComercial3DDD = getJSON(reqJSON, 'mot_referencia_profissional3_ddd')
            refComercial3fone = getJSON(reqJSON, 'mot_referencia_profissional3_numero')

        nome = getJSON(reqJSON, prefixTag + 'nome')
        apelido = ''
        rua = getJSON(reqJSON, prefixTag + 'endereco')
        numero = getJSON(reqJSON, prefixTag + 'numero')
        complemento = getJSON(reqJSON, prefixTag + 'complemento')
        bairro = getJSON(reqJSON, prefixTag + 'bairro')
        cep = getJSON(reqJSON, prefixTag + 'cep')
        email = getJSON(reqJSON, prefixTag + 'email')
        dddFone = getJSON(reqJSON, prefixTag + 'foneddd')
        numeroFone = getJSON(reqJSON, prefixTag + 'fonenumero')
        dddCelular = getJSON(reqJSON, prefixTag + 'celularddd')
        numeroCelular = getJSON(reqJSON, prefixTag + 'celularnumero')
        dddFax = getJSON(reqJSON, prefixTag + 'faxddd')
        numeroFax = getJSON(reqJSON, prefixTag +'faxnumero')
        rg = getJSON(reqJSON, prefixTag + 'rg')
        orgaoRgCompleto = getJSON(reqJSON, prefixTag + 'orgaorg')
        orgaoRg = orgaoRgCompleto[:(len(orgaoRgCompleto) - 2)]
        ufRg = orgaoRgCompleto[(len(orgaoRgCompleto) - 2):]
        nomeMae = getJSON(reqJSON, prefixTag + 'nomemae')
        nomePai = getJSON(reqJSON, prefixTag + 'nomepai')
        sexo = getSexo(getJSON(reqJSON, prefixTag + 'sexo'))
        dataNascimento = getJSON(reqJSON, prefixTag + 'datanasc')

        salvaPessoaFisica = {}
        salvaPessoaFisica['id_cliente'] = conteudoTag(properties['idCliente'], 'xsd:int')
        salvaPessoaFisica['id_chave'] = conteudoTag(properties['chave'])
        salvaPessoaFisica['nm_pessoa'] = conteudoTag(nome)
        salvaPessoaFisica['nm_apelido'] = conteudoTag(apelido)
        salvaPessoaFisica['cd_cargo'] = conteudoTag(cargo)
        salvaPessoaFisica['nm_endereco'] = conteudoTag(rua)
        salvaPessoaFisica['nr_endereco'] = conteudoTag(numero)
        salvaPessoaFisica['ds_compl_end'] = conteudoTag(complemento)
        salvaPessoaFisica['nm_bairro'] = conteudoTag(bairro)
        salvaPessoaFisica['nm_cidade'] = conteudoTag(cidade)
        salvaPessoaFisica['si_uf'] = conteudoTag(uf)
        salvaPessoaFisica['cd_cep'] = conteudoTag(cep)
        salvaPessoaFisica['nm_email'] = conteudoTag(email)
        salvaPessoaFisica['nr_ddd_fone'] = conteudoTag(dddFone)
        salvaPessoaFisica['nr_fone'] = conteudoTag(numeroFone)
        salvaPessoaFisica['nr_ddd_fax'] = conteudoTag(dddFax)
        salvaPessoaFisica['nr_fax'] = conteudoTag(numeroFax)
        salvaPessoaFisica['nr_ddd_celular'] = conteudoTag(dddCelular)
        salvaPessoaFisica['nr_celular'] = conteudoTag(numeroCelular)
        salvaPessoaFisica['nr_cpf'] = conteudoTag(cpf)
        salvaPessoaFisica['nr_rg'] = conteudoTag(rg)
        salvaPessoaFisica['si_orgao_exped'] = conteudoTag(orgaoRg)
        salvaPessoaFisica['si_uf_exped'] = conteudoTag(ufRg)
        salvaPessoaFisica['nm_mae'] = conteudoTag(nomeMae)
        salvaPessoaFisica['nm_pai'] = conteudoTag(nomePai)
        salvaPessoaFisica['id_sexo'] = conteudoTag(sexo)
        salvaPessoaFisica['dt_nascimento'] = conteudoTag(dataNascimento)
        ## daqui pra baixo só motorista hein, vamo ve
        salvaPessoaFisica['nm_cart_habil'] = conteudoTag(numeroCnh)
        salvaPessoaFisica['id_categ_habil'] = conteudoTag(catCnh)
        salvaPessoaFisica['ds_cor_pele'] = conteudoTag(corPele)
        salvaPessoaFisica['ds_cor_cabelo'] = conteudoTag(corCabelo)
        salvaPessoaFisica['ds_tipo_cabelo'] = conteudoTag(tipoCabelo)
        salvaPessoaFisica['ds_cor_olhos'] = conteudoTag(corOlhos)
        salvaPessoaFisica['vl_altura'] = conteudoTag(altura)  #casas decimais: ponto
        salvaPessoaFisica['vl_peso'] = conteudoTag(peso)
        salvaPessoaFisica['nm_ref_pess1'] = conteudoTag(refPessoal1Nome)
        salvaPessoaFisica['nr_ddd_pess1'] = conteudoTag(refPessoal1DDD)
        salvaPessoaFisica['nr_fone_pess1'] = conteudoTag(refPessoal1fone)
        salvaPessoaFisica['nm_ref_pess2'] = conteudoTag(refPessoal2Nome)
        salvaPessoaFisica['nr_ddd_pess2'] = conteudoTag(refPessoal2DDD)
        salvaPessoaFisica['nr_fone_pess2'] = conteudoTag(refPessoal2fone)
        salvaPessoaFisica['nm_ref_com1'] = conteudoTag(refComercial1Nome)
        salvaPessoaFisica['nr_ddd_com1'] = conteudoTag(refComercial1DDD)
        salvaPessoaFisica['nr_fone_com1'] = conteudoTag(refComercial1fone)
        salvaPessoaFisica['nm_ref_com2'] = conteudoTag(refComercial2Nome)
        salvaPessoaFisica['nr_ddd_com2'] = conteudoTag(refComercial2DDD)
        salvaPessoaFisica['nr_fone_com2'] = conteudoTag(refComercial2fone)
        salvaPessoaFisica['nm_ref_com3'] = conteudoTag(refComercial3Nome)
        salvaPessoaFisica['nr_ddd_com3'] = conteudoTag(refComercial3DDD)
        salvaPessoaFisica['nr_fone_com3'] = conteudoTag(refComercial3fone)
        salvaPessoaFisica['@soapenv:encodingStyle'] = 'http://schemas.xmlsoap.org/soap/encoding/'
        body = {}
        body['urn:salvaPessoaFisica'] = salvaPessoaFisica
        envelope = {}
        envelope['@xmlns:xsi'] = 'http://www.w3.org/2001/XMLSchema-instance'
        envelope['@xmlns:xsd'] = 'http://www.w3.org/2001/XMLSchema'
        envelope['@xmlns:soapenv'] = 'http://schemas.xmlsoap.org/soap/envelope/'
        envelope['@xmlns:urn'] = 'urn:rodobensGerenciamentoRisco'
        envelope['soapenv:Header'] = ''
        envelope['soapenv:Body'] = body
        raiz = {}
        raiz['soapenv:Envelope'] = envelope
        xml = unparse(raiz, pretty=True)
        return xml, ''
    except Exception as e:
        print('Erro em requestRodobensSalvaPessoaFisica')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO'


def responseRodobensSalvaPessoaFisica(ret):
    try:
        document = mdom.parseString(ret)
        faultstring = document.getElementsByTagName('faultstring')
        if faultstring:
            raise ValueError
        salvaVeiculoResponse = document.getElementsByTagName('ns1:salvaPessoaFisicaResponse')
        mensagem = geralxml.findChildNodeByName(salvaVeiculoResponse, 'ds_retorno')
        if 'ja cadastrad' in mensagem:
            mensagem = 'Pessoa já cadastrada com sucesso !'
        if 'sucesso' in mensagem:
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + mensagem + '</msg></resp>', ''
        else:
            return '', mensagem
    except Exception as e:
        print('Erro em responseRodobensSalvaPessoaFisica')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRodobensSalvaPessoaJuridica(reqJSON, properties):
    try:
        salvaPessoaJuridica = {}
        salvaPessoaJuridica['id_cliente'] = conteudoTag(properties['idCliente'], 'xsd:int')
        salvaPessoaJuridica['id_chave'] = conteudoTag(properties['chave'])
        salvaPessoaJuridica['nr_cnpj'] = conteudoTag(getJSON(reqJSON, 'prop_cnpjcpf'))
        salvaPessoaJuridica['nm_pessoa'] = conteudoTag(getJSON(reqJSON, 'prop_nome'))
        salvaPessoaJuridica['nm_endereco'] = conteudoTag(getJSON(reqJSON, 'prop_endereco'))
        salvaPessoaJuridica['nr_endereco'] = conteudoTag(getJSON(reqJSON, 'prop_numero'))
        salvaPessoaJuridica['ds_compl_end'] = conteudoTag(getJSON(reqJSON, 'prop_complemento'))
        salvaPessoaJuridica['nm_bairro'] = conteudoTag(getJSON(reqJSON, 'prop_bairro'))
        salvaPessoaJuridica['nm_cidade'] = conteudoTag(getJSON(reqJSON, 'prop_cidade'))
        salvaPessoaJuridica['si_uf'] = conteudoTag(getJSON(reqJSON, 'prop_uf'))
        salvaPessoaJuridica['cd_cep'] = conteudoTag(getJSON(reqJSON, 'prop_cep'))
        salvaPessoaJuridica['nm_email'] = conteudoTag(getJSON(reqJSON, 'prop_email'))
        salvaPessoaJuridica['nr_ddd_fone'] = conteudoTag(getJSON(reqJSON, 'prop_foneddd'))
        salvaPessoaJuridica['nr_fone'] = conteudoTag(getJSON(reqJSON, 'prop_fonenumero'))
        salvaPessoaJuridica['nr_ddd_fax'] = conteudoTag(getJSON(reqJSON, 'prop_faxddd'))
        salvaPessoaJuridica['nr_fax'] = conteudoTag(getJSON(reqJSON, 'prop_faxnumero'))
        salvaPessoaJuridica['@soapenv:encodingStyle'] = 'http://schemas.xmlsoap.org/soap/encoding/'
        body = {}
        body['urn:salvaPessoaJuridica'] = salvaPessoaJuridica
        envelope = {}
        envelope['@xmlns:xsi'] = 'http://www.w3.org/2001/XMLSchema-instance'
        envelope['@xmlns:xsd'] = 'http://www.w3.org/2001/XMLSchema'
        envelope['@xmlns:soapenv'] = 'http://schemas.xmlsoap.org/soap/envelope/'
        envelope['@xmlns:urn'] = 'urn:rodobensGerenciamentoRisco'
        envelope['soapenv:Header'] = ''
        envelope['soapenv:Body'] = body
        raiz = {}
        raiz['soapenv:Envelope'] = envelope
        xml = unparse(raiz, pretty=True)
        return xml, ''
    except Exception as e:
        print('Erro em requestRodobensSalvaPessoaJuridica')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO'


def responseRodobensSalvaPessoaJuridica(ret):
    try:
        document = mdom.parseString(ret)
        faultstring = document.getElementsByTagName('faultstring')
        if faultstring:
            raise ValueError
        salvaVeiculoResponse = document.getElementsByTagName('ns1:salvaPessoaJuridicaResponse')
        mensagem = geralxml.findChildNodeByName(salvaVeiculoResponse, 'ds_retorno')
        if 'ja cadastrad' in mensagem:
            mensagem = 'Pessoa já cadastrada com sucesso !'
        if 'sucesso' in mensagem:
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + mensagem + '</msg></resp>', ''
        else:
            return '', mensagem
    except Exception as e:
        print('Erro em responseRodobensSalvaPessoaJuridica')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRodobensCadastrarPessoa(reqJSON, properties, codEMonitorAcao):
    try:
        if codEMonitorAcao == ACAO_RODOBENS_CADASTRARPROPRIETARIO:
            isPF = len(getJSON(reqJSON, 'prop_cnpjcpf')) == 11
            if isPF:
                return requestRodobensSalvaPessoaFisica(reqJSON, properties, 'prop')
            else:
                return requestRodobensSalvaPessoaJuridica(reqJSON, properties)
        elif codEMonitorAcao == ACAO_RODOBENS_CADASTRARMOTORISTA:
            return requestRodobensSalvaPessoaFisica(reqJSON, properties, 'mot')
    except Exception as e:
        print('Erro em requestRodobensCadastrarPessoa')
        print(e)
        return '', 'Erro em requestRodobensCadastrarPessoa: '


def responseRodobensCadastrarPessoa(ret, codEMonitorAcao, req):
    try:
        req = req.replace('\\"', '"')
        reqJSON = ''
        if req:
            reqJSON = json.loads(req)
    except Exception as e:
        print('Erro em processRequestOpCartao.3')
        print(e)
        return '', 'ERRO DE PROCESSAMENTO DE JSON INVALIDO: ' + req
    try:
        if codEMonitorAcao == ACAO_RODOBENS_CADASTRARPROPRIETARIO:
            isPF = len(getJSON(reqJSON, 'prop_cnpjcpf')) == 11
            if isPF:
                return responseRodobensSalvaPessoaFisica(ret)
            else:
                return responseRodobensSalvaPessoaJuridica(ret)
        elif codEMonitorAcao == ACAO_RODOBENS_CADASTRARMOTORISTA:
            return responseRodobensSalvaPessoaFisica(ret)
    except Exception as e:
        print('Erro em responseRodobensCadastrarPessoa.3')
        print(e)
        return '', 'ERRO DE PROCESSAMENTO DE JSON INVALIDO: ' + req


def requestRodobensSalvaSM(reqJSON, properties):
    try:
        dataIni = getJSON(reqJSON, 'conh_dataini')
        dataHoraEmissao = getJSON(reqJSON, 'conh_datahoraemissao')
        if dataIni != '':
            dataHoraSaida = dataIni
        else:
            dataHoraSaida = dataHoraEmissao
        if 'T' in dataHoraSaida:
            dataHoraSaidaDate = datetime.strptime(dataHoraSaida, '%Y-%m-%dT%H:%M:%S')
        else:
            dataHoraSaidaDate = datetime.strptime(dataHoraSaida, '%Y-%m-%d %H:%M:%S')
        dataHoraSaida = datetimetostr(dataHoraSaidaDate)
        #dtSaida = ''
        #hrSaida = dataHoraSaida[:16]
        dtSaida = dataHoraSaida[:10]
        hrSaida = dataHoraSaida[11:16]
        dataFim = getJSON(reqJSON, 'conh_datafim')
        dataPrevDescarga = getJSON(reqJSON, 'conh_dataprevisaodescarga')
        if dataFim != '':
            dataHoraChegada = dataFim
        elif dataPrevDescarga != '':
            dataHoraChegada = dataPrevDescarga
        else:
            dataHoraChegada = datetime.fromordinal(dataHoraSaidaDate.toordinal() + 30)
            dataHoraChegada = dbdatetimetostr(dataHoraChegada)
        if 'T' in dataHoraChegada:
            dataHoraChegada = datetime.strptime(dataHoraChegada, '%Y-%m-%dT%H:%M:%S')
        else:
            dataHoraChegada = datetimetostr(datetime.strptime(dataHoraChegada, '%Y-%m-%d %H:%M:%S'))
        #dtChegada = ''
        #hrChegada = dataHoraChegada[:16]
        dtChegada = dataHoraSaida[:10]
        hrChegada = dataHoraChegada[11:16]
        salvaSM = {}
        salvaSM['id_cliente'] = conteudoTag(properties['idCliente'], 'xsd:int')
        salvaSM['id_chave'] = conteudoTag(properties['chave'])
        salvaSM['nr_cpf'] = conteudoTag(getJSON(reqJSON, 'conh_mot_cpf'))
        salvaSM['nr_cpf_ajudante'] = ''
        salvaSM['id_placa'] = conteudoTag(getJSON(reqJSON, 'conh_veic_placa'))
        salvaSM['id_placa_carreta'] = ''
        salvaSM['dt_saida_prevista'] = conteudoTag(dtSaida)
        salvaSM['hr_saida_prevista'] = conteudoTag(hrSaida)
        salvaSM['dt_chegada_prevista'] = conteudoTag(dtChegada)
        salvaSM['hr_chegada_prevista'] = conteudoTag(hrChegada)
        salvaSM['nm_endereco_origem'] = conteudoTag(getJSON(reqJSON, 'conh_rem_endereco'))
        salvaSM['nr_endereco_origem'] = conteudoTag(getJSON(reqJSON, 'conh_rem_numero'))
        salvaSM['ds_complemento_origem'] = conteudoTag(getJSON(reqJSON, 'conh_rem_complemento'))
        salvaSM['si_uf_origem'] = conteudoTag(getJSON(reqJSON, 'conh_rem_ufcid'))
        salvaSM['cd_cidade_origem'] = conteudoTag(getJSON(reqJSON, 'conh_rem_nomecid'))
        salvaSM['cd_cep_origem'] = conteudoTag(getJSON(reqJSON, 'conh_rem_cep'))
        salvaSM['nm_endereco_dest'] = conteudoTag(getJSON(reqJSON, 'conh_dest_endereco'))
        salvaSM['nr_endereco_dest'] = conteudoTag(getJSON(reqJSON, 'conh_dest_numero'))
        salvaSM['ds_complemento_dest'] = conteudoTag(getJSON(reqJSON, 'conh_dest_complemento'))
        salvaSM['si_uf_dest'] = conteudoTag(getJSON(reqJSON, 'conh_dest_ufcid'))
        salvaSM['cd_cidade_dest'] = conteudoTag(getJSON(reqJSON, 'conh_dest_nomecid'))
        salvaSM['cd_cep_dest'] = conteudoTag(getJSON(reqJSON, 'conh_dest_cep'))
        salvaSM['ds_cargas'] = conteudoTag(getJSON(reqJSON, 'conh_descmerc'))
        salvaSM['ds_observacoes'] = ''
        salvaSM['vl_viagem'] = conteudoTag(getJSON(reqJSON, 'conh_valormerc'))
        salvaSM['@soapenv:encodingStyle'] = 'http://schemas.xmlsoap.org/soap/encoding/'
        body = {}
        body['urn:salvaSM'] = salvaSM
        envelope = {}
        envelope['@xmlns:xsi'] = 'http://www.w3.org/2001/XMLSchema-instance'
        envelope['@xmlns:xsd'] = 'http://www.w3.org/2001/XMLSchema'
        envelope['@xmlns:soapenv'] = 'http://schemas.xmlsoap.org/soap/envelope/'
        envelope['@xmlns:urn'] = 'urn:rodobensGerenciamentoRisco'
        envelope['soapenv:Header'] = ''
        envelope['soapenv:Body'] = body
        raiz = {}
        raiz['soapenv:Envelope'] = envelope
        xml = unparse(raiz, pretty=True)
        return xml, ''
    except Exception as e:
        print('Erro em requestRodobensSalvaSM')
        print(e)
        return '', 'Erro em requestRodobensSalvaSM: '


def responseRodobensSalvaSM(ret):
    try:
        document = mdom.parseString(ret)
        faultstring = document.getElementsByTagName('faultstring')
        if faultstring:
            raise ValueError
        salvaSMResponse = document.getElementsByTagName('ns1:salvaSMResponse')
        mensagem = geralxml.findChildNodeByName(salvaSMResponse, 'ds_retorno')
        numAutGerRisco = ''
        if mensagem.isdigit():
            numAutGerRisco = '<NumAutGerRisco>' + mensagem + '</NumAutGerRisco>'
            mensagem = '[RODOBENS] Solicitacao de Monitoramento realizada com sucesso! '
        if 'sucesso' in mensagem:
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + mensagem + '</msg>' + numAutGerRisco + '</resp>', ''
        else:
            return '', mensagem
    except Exception as e:
        print('Erro em responseRodobensSalvaPessoaJuridica')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def getTipoProprietario(tipo):
    # TIPOS DO SOR
    #Agregado - S
    #Agregado Misto - M
    #Terceiro - N
    #Próprio - P
    #Agreg.(Ger.Como Terc.)-G
    # agregado, #frota propria, #carreteiro
    switcher = {
        "S": "AGREGADO",
        "M": "AGREGADO",
        "N": "CARRETEIRO",
        "P": "FROTA PROPRIA",
        "G": "AGREGADO"
    }
    return switcher.get(tipo)


def getTipoPessoaProp(tipo):
    # TIPOS DO SOR
    #Agregado - S
    #Agregado Misto - M
    #Terceiro - N
    #Próprio - P
    #Agreg.(Ger.Como Terc.)-G
    # agregado, #carreteiro, #funcionario
    switcher = {
        "S": "AGREGADO",
        "M": "AGREGADO",
        "N": "CARRETEIRO",
        "P": "FUNCIONARIO",
        "G": "AGREGADO"
    }
    return switcher.get(tipo)


def getTipoPessoaMot(tipo):
    # TIPOS DO SOR
    #Funcionario: S ou N
    # agregado, #carreteiro, #funcionario
    switcher = {
        "S": "FUNCIONARIO",
        "N": "CARRETEIRO",
    }
    return switcher.get(tipo)

def getSexo(tipo):
    # TIPOS DO SOR
    #Masculino - M
    #Feminino - F
    #1 - masculino, 2 - feminino
    switcher = {
        "M": "1",
        "F": "2"
    }
    return switcher.get(tipo)


