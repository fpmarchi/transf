import json
import geralxml
from geraljson import *

ACAO_TRANSSAT_INICIO = 2100
ACAO_TRANSSAT_SOLICITAR_MONITORAMENTO = 2101
ACAO_TRANSSAT_FIM = 2149


def preProcessRequestPropertiesTransSat(headers,requestProperties):
    entry = requestProperties.split('=')
    token = entry[1]
    headers['Authorization'] = 'Bearer ' + token
    return headers, ''


def requestTransSatSolMonitoramento(reqJSON):
    req = {}
    conjunto = {}
    cliente = {}
    viagem = {}
    veiculo = {}
    motoristaTelefone = {}
    ajudanteTelefone = {}
    carga = {}
    planejamento = {}
    escolta = {}
    isca = {}

    cliente['SOLICITANTE:'] = getJSON(reqJSON, 'solicitante')
    cliente['EMAIL_RETORNO:'] = getJSON(reqJSON, 'emailretorno')

    viagem['LOCAL_ORIGEM:'] = getJSON(reqJSON, 'cidadeorigem')
    viagem['LOCAL_DESTINO:'] = getJSON(reqJSON, 'cidadedestino')
    viagem['ENDERECO_ORIGEM:'] = getJSON(reqJSON, '')
    viagem['ENDERECO_DESTINO:'] = getJSON(reqJSON, '')
    viagem['DATA_INICIO:'] = getJSON(reqJSON, 'datainicio')
    viagem['HORA_INICIO:'] = getJSON(reqJSON, 'horainicio')
    viagem['DATA_FIM:'] = getJSON(reqJSON, 'datafim')
    viagem['HORA_FIM:'] = getJSON(reqJSON, 'horafim')
    viagem['NF:'] = getJSON(reqJSON, '')

    veiculo['PLACA:'] = getJSON(reqJSON, 'placa')
    veiculo['PLACA_CARRETA:'] = getJSON(reqJSON, 'placacarreta')
    veiculo['MOTORISTA_CPF:'] = getJSON(reqJSON, 'motoristacpf')
    veiculo['AJUDANTE_CPF:'] = getJSON(reqJSON, '')

    motoristaTelefone['tel:'] = getJSON(reqJSON, 'motoristatelefone')
    motoristaTelefone['tipo:'] = getJSON(reqJSON, '')
    motoristaTelefone['contato:'] = getJSON(reqJSON, '')

    ajudanteTelefone['tel:'] = getJSON(reqJSON, '')
    ajudanteTelefone['tipo:'] = getJSON(reqJSON, '')
    ajudanteTelefone['contato:'] = getJSON(reqJSON, '')

    veiculo['MOTORISTA_TELEFONE:'] = motoristaTelefone
    veiculo['AJUDANTE_TELEFONE:'] = ajudanteTelefone

    carga['DATA:'] = getJSON(reqJSON, 'data')
    carga['VALOR:'] = getJSON(reqJSON, 'valor')
    carga['TIPO:'] = getJSON(reqJSON, 'tipo')
    carga['COD_TIPO:'] = getJSON(reqJSON, '')
    carga['PESO:'] = getJSON(reqJSON, 'pesosaida')
    carga['TEMPERATURA:'] = getJSON(reqJSON, '')

    planejamento['ROTEIRO:'] = getJSON(reqJSON, '')
    planejamento['ROTA:'] = getJSON(reqJSON, '')

    escolta['AGENTE1:'] = getJSON(reqJSON, '')
    escolta['AGENTE2:'] = getJSON(reqJSON, '')
    escolta['TELEFONE:'] = getJSON(reqJSON, '')
    escolta['NOME_EMPRESA:'] = getJSON(reqJSON, '')
    escolta['CONTATO_EMPRESA:'] = getJSON(reqJSON, '')
    escolta['NUMERO_EQUIPAMENTO:'] = getJSON(reqJSON, '')
    escolta['PLACA:'] = getJSON(reqJSON, '')
    escolta['SISTEMA_EQUIPAMENTO:'] = getJSON(reqJSON, '')

    isca['NUMERO_EQUIPAMENTO:'] = getJSON(reqJSON, '')
    isca['TECNOLOGIA:'] = getJSON(reqJSON, '')
    isca['MARCA_EQUIPAMENTO:'] = getJSON(reqJSON, '')
    isca['OBS:'] = getJSON(reqJSON, '')
    isca['MANTER_SINAL:'] = getJSON(reqJSON, '')

    conjunto['CLIENTE'] = cliente
    conjunto['VIAGEM'] = viagem
    conjunto['VEICULO:'] = veiculo
    conjunto['CARGA:'] = carga
    conjunto['PLANEJAMENTO:'] = planejamento
    conjunto['ESCOLTA:'] = escolta
    conjunto['ISCA:'] = isca

    req['sm'] = conjunto

    return json.dumps(req), ''


def responseTransSatSolicitaMonitoramento(resp):
    return responseTransSatGeral(resp)


def responseTransSatGeral(resp):
    try:
        ret = resp.content.decode('utf-8')
        retcode = resp.status_code
        root = json.loads(ret)
        isSucesso = getJSON(root, 'STATUS')
        if isSucesso:
            numero = getJSON(root, 'NUMERO')
            ret = geralxml.createtag('numero', numero)
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg></msg>' + ret + '</resp>', ''
        else:
            return getMensagemErroPadrao(resp)
    except Exception as e:
        print('Erro em responsePagBemCadastrarGeral')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA GER. RISCO'


def getMensagemErroPadrao(resp):
    ret = resp.content.decode('utf-8')
    retcode = resp.status_code
    root = json.loads(ret)
    errors = getJSON(root, 'erros')
    msgResp = ''
    for error in errors:
        msgResp += ' - ' + error['mensagem'] + ' (' + str(error['codigo']) + ')'
    if msgResp is None or msgResp == '':
        msgResp = 'MENSAGEM DE ERRO DA GER. RISCO NÃO ENCONTRADA (' + str(retcode) + ')'

    return '', msgResp
