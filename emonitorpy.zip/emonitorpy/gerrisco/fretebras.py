import json
import time
from string import Template
from typing import Tuple, List

import requests
from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Util.Padding import unpad, pad
from requests import post, Response

from ActionProcessor import ActionProcessor, handle_exception_factory, HttpMethod, parse_props
from geral import conditional_key, remove_accents, safe_cast, deep_get
from geralxml import mount_xml_response


# Exceção customizada
class FreteBrasException(Exception):
    pass


# Classe base
class FreteBras(ActionProcessor):
    BASE_URL = 'https://openapi.fretebras.dev.br'
    BASE_URL_TEST = 'https://ccf719eb-517e-4af5-ab03-1ced278383dc.mock.pstmn.io'

    ADD_SHIPPING = 3650
    UPDATE_SHIPPING = 3659
    ACTIVATE_SHIPPING = 3651
    DEACTIVATE_SHIPPING = 3652

    # O método de cache em memoria não é o ideal, pois o EMPY é multithreading.
    # Uma boa opção seria utilizar uma ferramenta de cache como o Redis.
    __token_cache = None
    common_cache = {}

    def __init__(self):
        self.__token_cache = {}

        self.add_callable_records('url', {
            self.ADD_SHIPPING: (_make_url, _make_defaults('/api/v1/', HttpMethod.POST)),
            self.UPDATE_SHIPPING: (_make_url, _make_defaults('/api/v1/$id', HttpMethod.PUT, True)),
            self.ACTIVATE_SHIPPING: (_make_url, _make_defaults('/api/v1/$id/active', HttpMethod.PUT, True)),
            self.DEACTIVATE_SHIPPING: (_make_url, _make_defaults('/api/v1/$id/disable', HttpMethod.PUT, True)),
        })

        super().__init__()

    @parse_props
    def get_headers(self, context_req: dict, acao) -> Tuple[dict, str]:
        props = context_req.get('props')
        ambiente = safe_cast(props.get('ws_ambiente'), int, 0)
        base = context_req.get('url', '').strip().rstrip('/') or (
            self.BASE_URL if ambiente == 1 else self.BASE_URL_TEST)

        print(context_req.get('url'))
        headers = {'Content-type': 'application/json'}
        # if acao == FreteBras.ADD_SHIPPING:
        #   headers['x-mock-response-code'] = '201'

        token = _get_token(base + '/oauth/token', props, self.__token_cache)
        headers['Authorization'] = f'Bearer {token}'
        return headers, ''


#
#   Códigos independentes de instancia
#
def _fretebras_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a FreteBras:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    FreteBrasException,
    _fretebras_exception_callback,
    any_exception_callback
)


# Funções para obtenção de URLs
def _make_defaults(path: str, method: HttpMethod = None, use_template: bool = None) -> dict:
    return {
        'path': path,
        **conditional_key('method', method),
        **conditional_key('use_template', use_template)
    }


@_handle_exception
def _make_url(path: str, method: HttpMethod = HttpMethod.GET, use_template: bool = False,
              req: dict = None, url: str = '', props: dict = None) -> Tuple[str, str]:
    if props is None:
        props = {}

    ambiente = 0
    try:
        ambiente = int(props.get('ws_ambiente'))
    except (Exception,):
        pass

    base = url.strip().rstrip('/') or (FreteBras.BASE_URL if ambiente == 1 else FreteBras.BASE_URL_TEST)
    if use_template:
        t = Template(path)
        url = base + t.substitute(req)
    else:
        url = base + path

    return url, method.name


#
#   Instancia limpa e sem configuração
#
fretebras = FreteBras()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = fretebras.link_to_factory('request')
_link_to_response = fretebras.link_to_factory('response')


# Funções para obtenção de envios
@_link_to_request(fretebras.ADD_SHIPPING, fretebras.UPDATE_SHIPPING)
@_handle_exception
def _add_shipping_body(req: dict, props: dict) -> Tuple[str, str]:
    erro_msg = ''

    vehicle_types = req.get('tipos_veiculo', '').split(',')
    if not vehicle_types[0]:
        erro_msg += 'Pelo menos um tipo de veículo deve ser informado\n'

    body_types = req.get('tipos_carroceria', '').split(',')
    if not body_types[0]:
        erro_msg += 'Pelo menos um tipo de carroceria deve ser informado\n'

    payment_methods = req.get('metodos_pag', '').split(',')
    if not payment_methods[0]:
        erro_msg += 'Pelo menos uma forma de pagamento deve ser informada\n'

    if erro_msg:
        return '', erro_msg

    body = {
        'branch_id': req.get('branch_id', None),
        'collection_date': req.get('ped_datacoleta'),
        'delivery_date': req.get('ped_dataentrega'),
        'owners': [
            {
                'email': props.get('usuario2')
            }
        ],
        'cargo': {
            'product': req.get('ped_mercadoria'),
            'product_ncm': req.get('ped_ncm_mercadoria'),
            'kind': req.get('especie_merc'),
            'measurements': {
                'volume': {
                    'quantity': req.get('quant_merc'),
                    'cubic': req.get('ped_merc_vol_cubic', '')
                },
                'weight': {
                    'total': req.get('peso', ''),
                    'unit': req.get('peso_unidade'),
                    'cubic': req.get('ped_merc_peso_cubic', '')
                }
            }
        },
        # provavelmente existe uma forma confiável de saber isso automaticamente através da origem/destino
        'is_national': req.get('nacional'),
        'vehicles': {
            'types': vehicle_types,
            'bodies': body_types
        },
        'origin': {
            'address': {
                'uf': req.get('ped_uf_cid_coleta'),
                'street': req.get('ped_endereco_coleta') + ' - ' + req.get('ped_numero_coleta'),
                'city': req.get('ped_nome_cid_coleta'),
                'state': _verif_state(req.get('ped_uf_cid_coleta')) + ' - ' + req.get('ped_uf_cid_coleta'),
                **conditional_key('postal_code', req.get('ped_cep_coleta')),
                **conditional_key('ibge_code', req.get('ped_cid_orig_codibge')),
                **conditional_key('lat', safe_cast(req.get('ped_lat_coleta'), float)),
                **conditional_key('lon', safe_cast(req.get('ped_lon_coleta'), float))
            },
            **conditional_key('observations', req.get('ped_cid_col_obs'))
        },
        'destination': {
            'address': {
                'uf': req.get('ped_uf_cid_entrega'),
                'street': req.get('ped_endereco_entrega') + ' - ' + req.get('ped_numero_entrega'),
                'city': req.get('ped_nome_cid_entrega'),
                'state': _verif_state(req.get('ped_uf_cid_entrega')) + ' - ' + req.get('ped_uf_cid_entrega'),
                **conditional_key('postal_code', req.get('ped_cep_entrega')),
                **conditional_key('ibge_code', req.get('ped_cid_dest_codibge')),
                **conditional_key('lat', safe_cast(req.get('ped_lat_entrega'), float)),
                **conditional_key('lon', safe_cast(req.get('ped_lon_entrega'), float))
            },
            **conditional_key('observations', req.get('ped_cid_ent_obs'))
        },
        'pricing': {
            'value': safe_cast(req.get('valor'), int) or None,
            'toll_included': req.get('ped_pedagio_emb_frete_mot') == 'S',
            'unit': req.get('valor_unidade')
        },
        'payment': {
            'advance_percentage': req.get('ped_pag_perc_adt'),
            'methods': payment_methods
        }
    }

    return json.dumps(body), ''


@_link_to_request(fretebras.DEFAULT_FUNCTION)
@_handle_exception
def _default_body() -> Tuple[None, str]:
    return None, ''


# Funções para tratamento de retorno
@_link_to_response(fretebras.ADD_SHIPPING, fretebras.UPDATE_SHIPPING)
@_handle_exception
def _add_shipping_resp(resp: Response) -> Tuple[str, str]:
    resp_json = resp.json()

    success = resp.status_code in [200, 201, 204]
    status_code = resp.status_code
    resp_body = {'sucesso': success}
    if success:
        resp_body['conteudo'] = {'frete_id': deep_get(resp.json(), 'data.freight.id')}
    elif status_code == 422:

        if resp_json.get('errors', '') == []:
            resp_body = {
                'sucesso': False,
                'msg_erro': resp_json.get('message', '')
            }
        else:
            resp_body = {
                'sucesso': False,
                'erros': [
                    {
                        'campo': k or '-',
                        'descricao': '\n'.join(v)
                    }
                    for k, v in resp_json.get('errors', {}).items()
                ]
            }
    else:
        raise FreteBrasException('Não foi possível encontrar um retorno conhecido da FreteBras')

    return mount_xml_response(resp_body), ''


@_link_to_response(fretebras.DEFAULT_FUNCTION)
@_handle_exception
def _default_resp(resp: Response) -> Tuple[str, str]:
    return mount_xml_response(resp.json().get('data', {})), ''


@_handle_exception
# Funções utilitárias
def _get_token(url: str, data: dict, cache: dict) -> str:
    client_id = data.get('id_cliente', '')
    email = data.get('usuario', '')
    senha = data.get('senha', '')
    secret = data.get('segredo', '')

    if not email or not senha or not secret:
        raise Exception('O e-mail, senha ou segredo não foram informados.')

    aes_key = PBKDF2(senha, email, 32, count=500, hmac_hash_module=SHA256)
    cipher = AES.new(aes_key, AES.MODE_ECB)

    email_hash = hash(email)
    (token, gen_time) = cache.get(email_hash, (bytearray(), 0))

    if token and (time.time() - gen_time) < 31531000:  # Se a idade for menor que 55 minutos
        token = cipher.decrypt(token)
        return unpad(token, cipher.block_size).decode('UTF-8')

    # Se não existir token em cache, tentar solicitar pela Api da SigaGr
    if not url:
        raise FreteBrasException('Não foi possível obter a URL de para requisitar o token.')

    try:
        auth_request = {
            'grant_type': 'password',
            'client_id': client_id,
            'client_secret': secret,
            'username': email,
            'password': senha,
            # 'scope': 'central-assinante'
        }

        resp = post(url, json=auth_request)
    except Exception as e:
        raise FreteBrasException('Erro ao buscar token de autorização na FreteBras!\n' + str(e))

    if resp.status_code == 200:
        token = resp.json().get('access_token', '')
        encrypt_token = cipher.encrypt(pad(token.encode('UTF-8'), cipher.block_size))

        cache[email_hash] = (encrypt_token, time.time())

        return token
    else:
        raise FreteBrasException('Erro ao obter token: ' + resp.content.decode('utf-8'))


def _verif_state(uf: str) -> str:
    if uf == 'AC':
        state = 'Acre'
    elif uf == 'AL':
        state = 'Alagoas'
    elif uf == 'AP':
        state = 'Amapa'
    elif uf == 'AM':
        state = 'Amazonas'
    elif uf == 'BA':
        state = 'Bahia'
    elif uf == 'CE':
        state = 'Ceara'
    elif uf == 'ES':
        state = 'Espirito Santo'
    elif uf == 'GO':
        state = 'Goias'
    elif uf == 'MA':
        state = 'Maranhao'
    elif uf == 'MT':
        state = 'Mato Grosso'
    elif uf == 'MT':
        state = 'Mato Grosso do Sul'
    elif uf == 'MS':
        state = 'Minas Gerais'
    elif uf == 'PA':
        state = 'Para'
    elif uf == 'PB':
        state = 'Paraiba'
    elif uf == 'PR':
        state = 'Parana'
    elif uf == 'PE':
        state = 'Pernambuco'
    elif uf == 'PI':
        state = 'Piaui'
    elif uf == 'RJ':
        state = 'Rio de Janeiro'
    elif uf == 'RN':
        state = 'Rio Grande do Norte'
    elif uf == 'RS':
        state = 'Rio Grande do Sul'
    elif uf == 'RO':
        state = 'Rondonia'
    elif uf == 'RR':
        state = 'Roraima'
    elif uf == 'SC':
        state = 'Santa Catarina'
    elif uf == 'SP':
        state = 'Sao Paulo'
    elif uf == 'SE':
        state = 'Sergipe'
    elif uf == 'TO':
        state = 'Tocantins'
    elif uf == 'DF':
        state = 'Distrito Federal'
    else:
        state = ''
    return state