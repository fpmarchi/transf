from carguero import Carguero
from emprotege import EmProtege
from fretebras import FreteBras
from fretebrastrucker import FreteBrasTrucker
from m3risk import M3risk
from porto_seguro import PortoSeguro
from raster import Raster
from rondonline import Rondonline
from sigagr import SigaGr
from trafegus import Trafegus
from krona import Krona
from ffgr import FFGr
from sisger import Sisger
from smartload import SmartLoad
from senig import Senig
from angellira import Angellira


trafegus = Trafegus.get_instance(min_action=3100, max_action=3150)
raster = Raster.get_instance(min_action=3300, max_action=3349)
m3risk = M3risk.get_instance(min_action=3400, max_action=3449)
sigagr = SigaGr.get_instance(min_action=3600, max_action=3649)
fretebras = FreteBras.get_instance(min_action=3650, max_action=3679)
fretebrastrucker = FreteBrasTrucker.get_instance(min_action=3680, max_action=3699)
carguero = Carguero.get_instance(min_action=3800, max_action=3849)
rondonline = Rondonline.get_instance(min_action=3850, max_action=3899)
emprotege: EmProtege = EmProtege.get_instance(min_action=3950, max_action=3999)
krona = Krona.get_instance(min_action=4050, max_action=4099)
ffgr = FFGr.get_instance(min_action=4150, max_action=4199)
sisger = Sisger.get_instance(min_action=4200, max_action=4249)
smartload = SmartLoad.get_instance(min_action=4300, max_action=4349)
senig = Senig.get_instance(min_action=4350, max_action=4399)
angellira = Angellira.get_instance(min_action=4450, max_action=4499)
porto_seguro = PortoSeguro.get_instance(min_action=4500, max_action=4549)

