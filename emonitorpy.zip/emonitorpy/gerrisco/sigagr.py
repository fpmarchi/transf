import base64
import json
import logging
import sys
import time
from io import BytesIO, StringIO
from typing import Tuple
from urllib.parse import urlparse, urlunparse

from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Util.Padding import unpad, pad
from requests import post, Response

from ActionProcessor import ActionProcessor, Callable_cfg, parse_props, handle_exception_factory
from dispacher.action_processor import HttpMethod
from geral import conditional_key, remove_accents
from geralxml import mount_xml_response

# Numero de carretas por tipo de veículo
_vehicle_types = {
    'BAU': ('Baú', 1),
    'BICACAMBA': ('BI-Caçamba', 2),
    'BITREM': ('BI-Trem', 2),
    'CONTAINER': ('Container', 1),
    'LS': ('LS', 1),
    'RODOTREM': ('Rodotrem', 3),
    'SIDER': ('Sider', 1),
    'TANQUE': ('Tanque', 1),
    'TRUCK': ('Truck', 0),
    'VANDERLEIA': ('Vanderléia', 1)
}

_analysis_states = {
    'draft': ('Esboço', 1),
    'awaiting_analysis': ('Aguardando análise', 2),
    'under_analysis': ('Sob análise', 3),
    'pending': ('Pendente', 4),
    'awaiting_reanalysis': ('Aguardando reanálise', 5),
    'approved': ('Aprovado', 6),
    'authorized_by_manager': ('Autorizado pelo gerente', 7),
    'denied': ('Não recomendado', 8)
}

_denial_reason = {
    'references_issue': ('Problema com referencias', 1),
    'expired_docs': ('Documentos Expirados', 2),
    'vehicle_issue': ('Problema com o veículo', 3),
    'driver_license': ('Problemas na licença do motorista', 4),
    'inactivity': ('Mais de 15 dias sem retorno', 5),
    'other': ('Motivo desconhecido', 6)
}


def _format_cnpj_cpf(inp: str) -> str:
    if inp and len(inp) == 14:
        inp = f'{inp[:2]}.{inp[2:5]}.{inp[5:8]}/{inp[8:12]}-{inp[12:]}'
    elif inp and len(inp) == 11:
        inp = f'{inp[:3]}.{inp[3:6]}.{inp[6:9]}-{inp[9:]}'
    return inp


def _format_cell_phone(cell: str) -> str:
    if cell:
        cell = f'({cell[1:3]}) {cell[3:8]}-{cell[8:]}'
    return cell


def _format_phone(phone: str) -> str:
    if phone:
        phone = f'({phone[1:3]}) {phone[3:7]}-{phone[7:]}'
    return phone


def _send_document_out(req: dict) -> Tuple[dict, str, dict]:
    try:
        arquivo = req.get('arq_nome')
        conteudo = req.get('arq_conteudo')

        if not arquivo:
            return {}, 'Arquivo não informado', {}

        if not conteudo:
            return {}, 'O conteúdo do arquivo está vazio', {}

        file_size = sys.getsizeof(conteudo) / 4 * 3

        if file_size > 5 * pow(10, 6):
            return {}, 'O arquivo informado é maior que o limite de 5MB', {}

        file = {
            'file': (arquivo, BytesIO(base64.b64decode(conteudo)))
        }

        return {}, '', file
    except Exception as e:
        logging.warning('SigaGr |> Erro ao criar requisição para envio de documentos: ')
        print(e)
        return {}, 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e), {}


@handle_exception_factory()
def _create_analysis_out(req: dict) -> Tuple[str, str]:
    cpf_mot = req.get('mot_cpf', '')
    if cpf_mot:
        cpf_mot = f'{cpf_mot[:3]}.{cpf_mot[3:6]}.{cpf_mot[6:9]}-{cpf_mot[9:]}'

    analysis = {
        'product_name': 'siga_plus',
        'requester_email': req.get('embarcador_email', ''),
        'driver_personal_document': cpf_mot,
        'truck_license_plate': req.get('veic_placa', ''),
    }

    trailer_count = 0
    if req.get('car1_placa'):
        trailer_count += 1
        analysis['trailer_1_license_plate'] = req.get('car1_placa', '')
    if req.get('car2_placa'):
        trailer_count += 1
        analysis['trailer_2_license_plate'] = req.get('car2_placa', '')
    if req.get('car3_placa'):
        trailer_count += 1
        analysis['trailer_3_license_plate'] = req.get('car3_placa', '')

    vehicle_type = _find_veicle_type(req.get('veic_tipoveic'))
    if not vehicle_type:
        vehicle_type = 'Truck'
        for type_, count in _vehicle_types.values():
            if count == trailer_count:
                vehicle_type = type_
                break

    analysis['vehicle_type'] = vehicle_type

    return json.dumps({'analysis': analysis}), ''


@handle_exception_factory()
def _update_analysis_out(req: dict):
    driver = req.get('motorista')
    trucker = req.get('veiculo')

    cep_mot = driver.get('cep', '')
    if cep_mot:
        cep_mot = f'{cep_mot[:5]}-{cep_mot[5:]}'

    if driver.get('cidade_cnh'):
        cidade_cnh_mot = driver.get('cidade_cnh', '') + ' - ' + driver.get('uf_cidade_cnh', '')
    else:
        cidade_cnh_mot = driver.get('cidade', '') + ' - ' + driver.get('uf', '')

    trailers = []
    analysis = {
        'goods_type': req.get('mercadoria', ''),
        'load_cost': req.get('valor_mercadoria', ''),
        'hirer': req.get('contratante', ''),
        'origin': req.get('origem', '') + '-' + req.get('uf_origem', ''),
        'destination': req.get('destino', '') + ' - ' + req.get('uf_destino', ''),
        'driver': {
            'fullname': driver.get('nome', ''),
            'national_id_number': driver.get('rg', ''),
            'national_id_issuer': driver.get('rg_orgao', '')[-2:],
            'birthdate': driver.get('data_nascimento', ''),
            'mother': driver.get('nome_mae', ''),
            **conditional_key('license_file', driver.get('arq_cnh_token')),
            'license_number': driver.get('cnh', ''),
            'license_security_code': driver.get('seguranca_cnh', ''),
            'license_issued_location': cidade_cnh_mot,
            'professional_license': False,  # ----------------------------
            'street': driver.get('rua', ''),
            'street_number': driver.get('numero', ''),
            'building': driver.get('complemento', ''),
            'district': driver.get('bairro', ''),
            'city': driver.get('cidade', ''),
            'state': driver.get('uf', ''),
            'zipcode': cep_mot,
            'phone': _format_cell_phone(driver.get('celular', ''))
        },
        'truck': {
            'license_number': trucker.get('renavem', ''),
            'owner_name': trucker.get('prop_nome', ''),
            'owner_document': _format_cnpj_cpf(trucker.get('prop_cpfcnpj', '')),
            **conditional_key('license_file', trucker.get('arq_renavam_token')),
            'owner_phone': _format_phone(trucker.get('prop_fone', '')),
            'another_antt_owner': False,
            'antt_owner_document': _format_cnpj_cpf(trucker.get('prop_cpfcnpj', '')),
            'trailers': trailers,
            **conditional_key('photo', trucker.get('foto_cavalo_token')),
            **conditional_key('tractor_trailer_photo', trucker.get('foto_conjunto_token'))
        },
        **conditional_key('driver_history', req.get('historico', ''), req.get('historico', '') != 'Proprio'),
        'professional_references': []
    }

    for i in ['1', '2', '3']:
        if trucker.get('car' + i + '_placa'):
            trailers.append(
                {
                    'license_plate': trucker.get(f'car{i}_placa', ''),
                    'license_number': trucker.get(f'car{i}_renavam', ''),
                    **conditional_key('license_file', trucker.get(f'car{i}_renavam_token')),
                    'another_owner': False,
                    'owner_name': trucker.get(f'car{i}_prop', ''),
                    'owner_document': _format_cnpj_cpf(trucker.get(f'car{i}_prop_cpfcnpj', '')),
                    'owner_phone': _format_phone(trucker.get(f'car{i}_prop_fone', '')),
                    'position': i,
                    'another_antt_owner': False,
                    'antt_owner_document': _format_cnpj_cpf(trucker.get(f'car{i}_prop_cpfcnpj', ''))
                }
            )

    for ref in req.get('referencias', []):
        gr_ref = {
            'name': ref.get('nome', '')
        }

        if ref.get('celular', '').strip():
            gr_ref['phone'] = _format_cell_phone(ref.get('celular', ''))
        elif ref.get('fone', '').strip():
            gr_ref['phone'] = _format_phone(ref.get('fone', ''))
        else:
            gr_ref['phone'] = ''

        analysis['professional_references'].append(gr_ref)

    return json.dumps({'analysis': analysis}), ''


@handle_exception_factory()
def _send_document_in(resp: Response):
    resp = resp.json()

    parsed_resp = {
        'resumido': {
            'token': resp.get('blob', {}).get('token', '')
        },
        'original': resp
    }

    return mount_xml_response(parsed_resp), ''


@handle_exception_factory()
def _analysis_in(resp: Response):
    resp: dict = resp.json()

    if 'errors_details' in resp:
        errors = StringIO()
        errors.write('Erros de validação pela SigaGr:')

        err: dict
        for err in reversed(resp.get('errors_details', [])):
            errors.write(
                f'\n- Contexto: {err.get("entity_label", "")} -> {err.get("attribute_label", "")}'
                f'\n  Detalhe: {err.get("message", "")}'
            )

        return '', errors.getvalue()

    if 'errors' in resp:
        errors = ''.join(
            f'- {err[0]}: {",".join(err[1])}.\n'
            for err
            in resp.get('errors', {}).items())
        return '', 'Erros de validação pela SigaGr:\n' + errors

    analysis = resp.get('analysis', {})

    parsed_resp = {
        'resumido': {
            'num_processo': analysis.get('process_number', ''),
            'situacao': _analysis_states.get(analysis.get('state'), 'Desconhecido')[0],
            'cod_situacao': _analysis_states.get(analysis.get('state'), 0)[1],
            'data': analysis.get('requested_at', ''),
            'data_envio': analysis.get('created_at', ''),
            'data_ini': analysis.get('last_event_at', ''),
            'data_fim': analysis.get('expires_at', '')
        },
        'original': resp
    }

    if analysis.get('denial_reason'):
        reason = {
            'motivo_situacao': _denial_reason.get(analysis.get('denial_reason'), _denial_reason.get('other'))[0],
            'cod_motivo_situacao': _denial_reason.get(analysis.get('denial_reason'), _denial_reason.get('other'))[1]
        }

        parsed_resp['resumido'].update(reason)

    return mount_xml_response(parsed_resp), ''


def _find_veicle_type(type_name: str):
    if not type_name:
        return ''

    name = remove_accents(type_name).replace('-', '').replace(' ', '').strip()
    return _vehicle_types.get(name.upper(), (None, None))[0]


class SigaGr(ActionProcessor):
    HOST = 'https://api.sigagr.com.br'
    TEST_HOST = 'https://api.staging.sigagr.com.br'
    BASE_PATH = '/v1'

    SEND_DOCUMENT = 3601  # ACAO_SIGAGR_ENVIAR_DOCUMENTO
    CREATE_ANALYSIS = 3602  # ACAO_SIGAGR_CRIAR_ANALISE
    VIEW_ANALYSIS = 3603  # ACAO_SIGAGR_EXIBIR_ANALISE
    UPDATE_ANALYSIS = 3604  # ACAO_SIGAGR_ATUALIZAR_ANALISE
    # Ação interna
    AUTH = -1

    # Memória transitória criptografado com os tokens de autorização dos clientes.
    __token_cache: dict = {}

    def __init__(self):

        request_builders: Callable_cfg = {
            self.SEND_DOCUMENT: _send_document_out,
            self.CREATE_ANALYSIS: _create_analysis_out,
            self.VIEW_ANALYSIS: lambda: ('true', ''),
            self.UPDATE_ANALYSIS: _update_analysis_out
        }

        response_parsers: Callable_cfg = {
            self.SEND_DOCUMENT: _send_document_in,
            self.DEFAULT_FUNCTION: _analysis_in
        }
        self.add_callable_records('url', {
            self.SEND_DOCUMENT: self.make_url_assembler('/uploads'),
            self.CREATE_ANALYSIS: self.make_url_assembler('/analyses'),
            self.VIEW_ANALYSIS: self.make_url_assembler('/analyses/$protocolo', HttpMethod.GET, use_template=True),
            self.UPDATE_ANALYSIS: self.make_url_assembler('/analyses/$protocolo', HttpMethod.PUT, use_template=True),
            self.AUTH: self.make_url_assembler('/auth/sign_in')
        })

        super().__init__(request_builders, response_parsers)

    def get_headers(self, dict_with_props: dict, acao: int):
        try:
            token = self.get_token(dict_with_props)
            headers = {'Authorization': token}

            if not acao == self.SEND_DOCUMENT:
                headers['Content-Type'] = 'application/json'

            return headers, ''
        except Exception as e:
            return '', 'Erro ao obter o token de acesso.\nDetalhes: ' + str(e)

    @parse_props
    def get_token(self, context_req: dict) -> str:
        props = context_req.get('props', {})
        email = props.get('usuario', '')
        senha = props.get('senha', '')

        if not email or not senha:
            raise Exception('O e-mail ou senha não foram informados.')

        aes_key = PBKDF2(senha, email, 32, count=500, hmac_hash_module=SHA256)
        cipher = AES.new(aes_key, AES.MODE_ECB)

        # Memória transitória em variável do sigleton da integração. Por ser um sistema multithread, pode não ser
        # muito eficiente, mas ajuda. O ideal seria o uso de um banco de memória transitória como Redis.
        email_hash = hash(email)
        (token, gen_time) = self.__token_cache.get(email_hash, (bytearray(), 0))

        if token and (time.time() - gen_time) < 2700:  # Se a idade for menor que 45 minutos
            token = cipher.decrypt(token)
            return unpad(token, cipher.block_size).decode('UTF-8')

        # Se não existir token em memória transitória, tentar solicitar pela Api da SigaGr
        try:
            auth_request = {
                'application_key': {
                    'email': email,
                    'password': senha
                }
            }

            uri = self.context.get('url')
            parsed_uri = list(urlparse(uri))
            parsed_uri[2] = ''

            local_ctx = {
                'url': urlunparse(parsed_uri),
            }
            uri = self.dispatch(self.AUTH, local_ctx, 'url')[0]
            resp = post(uri, json=auth_request)
        except Exception as e:
            raise Exception('Erro ao buscar token de autorização pa SigaGr!\n' + str(e))

        if resp.status_code == 200:
            token = resp.headers.get('Authorization', '')
            encrypt_token = cipher.encrypt(pad(token.encode('UTF-8'), cipher.block_size))

            self.__token_cache[email_hash] = (encrypt_token, time.time())

            return token
        elif resp.status_code == 401:
            raise Exception('Por favor verifique as credenciais de acesso para SigaGr!')
        else:
            raise Exception(resp.content.decode('utf-8'))
