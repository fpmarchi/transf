import json
import time
from string import Template
from typing import Tuple

import requests
from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Util.Padding import unpad, pad
from requests import post, Response

from ActionProcessor import ActionProcessor, handle_exception_factory, HttpMethod, parse_props
from geral import deep_get, conditional_key, set_context, safe_cast, datetime_from_iso
from geralxml import mount_xml_response


# Exceção customizada
class CargueroException(Exception):
    pass


#   Códigos independentes de instancia
#
def _carguero_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def _any_exception_callback(data: dict) -> Tuple[str, str]:
    raise data['ex']


_handle_exception = handle_exception_factory(
    CargueroException,
    _carguero_exception_callback,
    _any_exception_callback
)


# Classe base
class Carguero(ActionProcessor):
    BASE_URL = 'https://api-integration.carguero.com.br'
    BASE_URL_TEST = 'https://homolog-api-integration.carguero.com.br'

    ADD_BATCH_SHIPPER = 3800
    GET_TRIP = 3801
    APPROVE_TRIP = 3802
    REJECT_TRIP = 3803
    PERFORM_LOADING = 3804
    GET_TRIPS_AWAITING_ACTION = 3805
    GET_TRIPS = 3806
    FIND_PRODUCTS = 3807

    # O método de cache em memoria não é o ideal, pois o EMPY é multithreading.
    # Uma boa opção seria utilizar uma ferramenta de cache como o Redis.
    __token_cache = None
    species_cache = {}
    price_type_cache = {}
    vehicle_cache = {}
    bodywork_cache = {}

    def __init__(self):
        self.__token_cache = {}

        self.add_callable_records('url', {
            self.ADD_BATCH_SHIPPER: (_make_url, _make_defaults('/lotes-embarcadores', HttpMethod.POST)),
            self.GET_TRIP: (_make_url, _make_defaults('/viagens/$id', use_template=True)),
            self.APPROVE_TRIP: (_make_url, _make_defaults('/viagens/$id/aprovar', HttpMethod.PUT, True)),
            self.REJECT_TRIP: (_make_url, _make_defaults('/viagens/$id/rejeitar', HttpMethod.PUT, True)),
            self.PERFORM_LOADING: (_make_url, _make_defaults('/viagens/$id/carregamento', HttpMethod.POST, True)),
            self.GET_TRIPS_AWAITING_ACTION: (_make_url, _make_defaults('/viagens/aguardando-acao')),
            self.GET_TRIPS: (_make_url, _make_defaults('/viagens/aguardando-acao')),
            self.FIND_PRODUCTS: (_make_url, _make_defaults('/products?nome=$merc_nome', use_template=True))
        })

        super().__init__()

    @_handle_exception
    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        props = context_req.get('props')
        ambiente = props.get('ws_ambiente', 0)
        base = 'https://acc.carguero.com.br' if ambiente == 1 else 'https://homolog-acc.carguero.com.br'

        token = _get_token(base + '/connect/token', props, self.__token_cache)
        return {
                   'Authorization': f'Bearer {token}',
                   'Content-type': 'application/json'
               }, ''


# Funções para obtenção de URLs
def _make_defaults(path: str, method: HttpMethod = None, use_template: bool = None) -> dict:
    return {
        'path': path,
        **conditional_key('method', method),
        **conditional_key('use_template', use_template)
    }


@_handle_exception
def _make_url(path: str, method: HttpMethod = HttpMethod.GET, use_template: bool = False,
              req: dict = None, url: str = None, props=None) -> Tuple[str, str]:
    if props is None:
        props = {}

    ambiente = props.get('ws_ambiente', 0)

    base = url.strip().rstrip('/') or Carguero.BASE_URL if ambiente == 1 else Carguero.BASE_URL_TEST
    if use_template:
        t = Template(path)
        url = base + t.substitute(req)
    else:
        url = base + path

    return url, method.name


#
#   Instancia limpa e sem configuração
#
carguero = Carguero()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = carguero.link_to_factory('request')
_link_to_response = carguero.link_to_factory('response')

# Funções para obtenção de envios

unidades = {
    1: 'kg',
    5: 't'
}


@_link_to_request(carguero.ADD_BATCH_SHIPPER)
@_handle_exception
def _add_batch_shipper_body(req: dict, props: dict) -> Tuple[str, str]:
    context = {}

    body = {
        'referencia_integracao': req.get('referencia', ''),
        'unidade_organizacional': props.get('unidade'),
        set_context('remetente', context, req.get('remetente', {})): {
            'referencia_integracao': str(context.get('codigo', '')),
            'tipo_parceiro': 'J' if len(context.get('cpfcnpj', '')) > 11 else 'F',
            'cpf_cnpj': context.get('cpfcnpj', ''),
            'nome_fantasia': context.get('nome_fantasia', ''),
            'nome_razao_social': context.get('nome', ''),
            'endereco': {
                'referencia_integracao': str(context.get('codigo', '')),
                'inscricao_estadual': context.get('ie'),
                'cep': context.get('cep', ''),
                'uf': context.get('uf', ''),
                'codigo_municipio_ibge': context.get('cidade_codibge', ''),
                'logradouro': context.get('endereco', ''),
                'numero': context.get('numero', ''),
                'bairro': context.get('bairro', ''),
            }
        },
        set_context('destinatario', context, req.get('destinatario', {})): {
            'referencia_integracao': str(context.get('codigo', '')),
            'tipo_parceiro': 'J' if len(context.get('cpfcnpj', '')) > 11 else 'F',
            'cpf_cnpj': context.get('cpfcnpj', ''),
            'nome_fantasia': context.get('nome_fantasia', ''),
            'nome_razao_social': context.get('nome', ''),
            'endereco': {
                'referencia_integracao': str(context.get('codigo', '')),
                'inscricao_estadual': context.get('ie'),
                'cep': context.get('cep', ''),
                'uf': context.get('uf', ''),
                'codigo_municipio_ibge': context.get('cidade_codibge', ''),
                'logradouro': context.get('endereco', ''),
                'numero': context.get('numero', ''),
                'bairro': context.get('bairro', ''),
            }
        },
        set_context('local_coleta', context, req.get('coleta', {})): {
            'referencia_integracao': str(context.get('referencia', '')),
            'nome': context.get('nome', ''),
            'endereco': {
                'referencia_integracao': str(context.get('referencia', '')),
                'cep': context.get('cep', ''),
                'uf': context.get('uf', ''),
                'codigo_municipio_ibge': context.get('cod_mun_ibge', 0),
                'logradouro': context.get('endereco', ''),
                'numero': context.get('numero', ''),
                'bairro': context.get('bairro', '')
            },
            set_context('parceiro', context, req.get('remetente', {})): {
                'referencia_integracao': str(context.get('codigo', '')),
                'tipo_parceiro': 'J' if len(context.get('cpfcnpj', '')) > 11 else 'F',
                'cpf_cnpj': context.get('cpfcnpj', ''),
                'nome_fantasia': context.get('nome_fantasia', ''),
                'nome_razao_social': context.get('nome', ''),
                'endereco': {
                    'referencia_integracao': str(context.get('codigo', '')),
                    'inscricao_estadual': context.get('ie'),
                    'cep': context.get('cep', ''),
                    'uf': context.get('uf', ''),
                    'codigo_municipio_ibge': context.get('cidade_codibge', ''),
                    'logradouro': context.get('endereco', ''),
                    'numero': context.get('numero', ''),
                    'bairro': context.get('bairro', ''),
                }
            }
        },
        set_context('local_descarga', context, req.get('entrega', {})): {
            'referencia_integracao': str(context.get('referencia', '')),
            'nome': context.get('nome', ''),
            'endereco': {
                'referencia_integracao': str(context.get('referencia', '')),
                'cep': context.get('cep', ''),
                'uf': context.get('uf', ''),
                'codigo_municipio_ibge': context.get('cod_mun_ibge', 0),
                'logradouro': context.get('endereco', ''),
                'numero': context.get('numero', ''),
                'bairro': context.get('bairro', '')
            },
            set_context('parceiro', context, req.get('destinatario', {})): {
                'referencia_integracao': str(context.get('codigo', '')),
                'tipo_parceiro': 'J' if len(context.get('cpfcnpj', '')) > 11 else 'F',
                'cpf_cnpj': context.get('cpfcnpj', ''),
                'nome_fantasia': context.get('nome_fantasia', ''),
                'nome_razao_social': context.get('nome', ''),
                'endereco': {
                    'referencia_integracao': str(context.get('codigo', '')),
                    'inscricao_estadual': context.get('ie'),
                    'cep': context.get('cep', ''),
                    'uf': context.get('uf', ''),
                    'codigo_municipio_ibge': context.get('cidade_codibge', ''),
                    'logradouro': context.get('endereco', ''),
                    'numero': context.get('numero', ''),
                    'bairro': context.get('bairro', ''),
                }
            }
        },
        'volume': {
            'unidade_medida': unidades.get(req.get('unidade_medida', 5)),
            'quantidade': req.get('quantidade', 0)
        },
        'produto': safe_cast(req.get('cod_produto'), int, 0)
    }

    return json.dumps(body), ''


# Funções para obtenção de envios
@_link_to_request(carguero.APPROVE_TRIP)
@_handle_exception
def _approve_trip_body(req: dict) -> Tuple[str, str]:
    body = {
        'ordem_carregamento': {
            'numero': req.get('cod_ordemcar', 0),
            'documento_url': req.get('documento_url', '')
        }
    }

    return json.dumps(body), ''


# Funções para obtenção de envios
@_link_to_request(carguero.REJECT_TRIP)
@_handle_exception
def _reject_trip_body(req: dict) -> Tuple[str, str]:
    body = {
        'motivo': req.get('motivo', ''),
        'motivo_rejeicao_suporte': req.get('motivo_complemento', '')
    }

    return json.dumps(body), ''


# Funções para obtenção de envios
@_link_to_request(carguero.PERFORM_LOADING)
@_handle_exception
def _add_shipping_body(req: dict) -> Tuple[str, str]:
    context = {}

    body = {
        'data_carregamento': datetime_from_iso(req.get('data')).isoformat(),
        set_context('peso_tara', context, req.get('peso_tara', {})): {
            'unidade_medida': unidades.get(context.get('unidade', ''), ''),
            'quantidade': context.get('quantidade', 0),
        },
        set_context('peso_liquido', context, req.get('peso_liquido', {})): {
            'unidade_medida': unidades.get(context.get('unidade', ''), ''),
            'quantidade': context.get('quantidade', 0),
        },
        set_context('nota_fiscal', context, req.get('nota', {})): {
            'chave_acesso': context.get('chave', ''),
            'data_emissao': datetime_from_iso(context.get('data', '')).isoformat(),
            'quantidade_faturada': context.get('quantidade', 0),
            'url_documento': context.get('documento', ''),
            'numero': context.get('numero', ''),
            'serie': context.get('serie', ''),
        }
    }

    return json.dumps(body), ''


@_link_to_request(carguero.DEFAULT_FUNCTION)
def _default_body() -> Tuple[None, str]:
    return None, ''


#
# Processamento de respostas
#
@_link_to_response(carguero.ADD_BATCH_SHIPPER)
@_handle_exception
def _id_resp(resp: Response) -> Tuple[str, str]:
    success = resp.status_code in [200, 201]
    resp_json = resp.json()

    resp_body = {'sucesso': success}
    if success:
        resp_body['conteudo'] = {'lote_id': str(resp_json.get('id', ''))}
    elif 'error' in resp_json:
        resp_body['msg_erro'] = deep_get(resp_json, 'error.message')
    else:
        raise CargueroException('Não foi possível encontrar um retorno conhecido da Carguero!')

    return mount_xml_response(resp_body), ''


@_link_to_response(Carguero.GET_TRIPS_AWAITING_ACTION)
@_handle_exception
def _get_trips_resp(resp: Response) -> Tuple[str, str]:
    success = resp.status_code in [200]
    resp_json = resp.json()

    resp_body = {'sucesso': success}
    if success:
        resp_body['conteudo'] = resp_json
        return mount_xml_response(resp_body), ''
    elif 'error' in resp_json:
        resp_body['msg_erro'] = resp_json.get('message', '')
    else:
        resp_body['msg_erro'] = 'Não foi possível identificar o retorno da Carguero'

    return mount_xml_response(resp_body), ''


@_link_to_response(Carguero.GET_TRIPS)
@_handle_exception
def _get_trips_resp(resp: Response) -> Tuple[str, str]:
    success = resp.status_code in [200]

    try:
        resp_json = resp.json()
    except (Exception,):
        resp_json = {}

    resp_body = {'sucesso': success}
    if not success:
        if 'error' in resp_json:
            resp_body['msg_erro'] = resp_json.get('message', '')
        else:
            resp_body['msg_erro'] = 'Não foi possível identificar o retorno da Carguero'

        return mount_xml_response(resp_body), ''

    trips = []
    headers, _ = carguero.get_headers(carguero.context)
    for trip in resp_json:
        url, _ = carguero.dispatch(Carguero.GET_TRIP, {'req': {'id': trip.get('viagem_id')}}, 'url')
        res = requests.get(url, headers=headers)

        if res.status_code == 200:
            trips.append({
                'sucesso': True,
                'id': trip.get('viagem_id'),
                'conteudo': res.json()
            })
        else:
            trips.append({
                'sucesso': False,
                'id': trip.get('viagem_id'),
                'msg_erro': 'Não foi possível obter os dados da viagem'
            })

    resp_body['conteudo'] = trips

    return mount_xml_response(resp_body), ''


@_link_to_response(Carguero.FIND_PRODUCTS)
@_handle_exception
def _default_resp(resp: Response, req_in: str) -> Tuple[str, str]:
    success = resp.status_code in [200]

    try:
        resp_json = resp.json()
    except (Exception,):
        resp_json = {}

    resp_body = {'sucesso': success}
    if not success:
        if 'error' in resp_json:
            resp_body['msg_erro'] = resp_json.get('message', '')
        else:
            resp_body['msg_erro'] = 'Não foi possível identificar o retorno da Carguero'

        return mount_xml_response(resp_body), ''

    base_req = json.loads(req_in)
    resp_body['conteudo'] = [
        p for p in resp_json
        if (not base_req.get('ncm', '')) or (p['ncm_code'].strip() == base_req['ncm'].strip())
    ]

    return mount_xml_response(resp_body), ''


@_link_to_response(Carguero.DEFAULT_FUNCTION)
@_handle_exception
def _default_resp(resp: Response) -> Tuple[str, str]:
    success = resp.status_code in [200]
    resp_json = resp.json()

    resp_body = {'sucesso': success}
    if success:
        resp_body['conteudo'] = resp_json
    elif 'error' in resp_json:
        resp_json = resp_json.get('error', {})
        resp_body['msg_erro'] = resp_json.get('message', '')

        if 'errors' in resp_json:
            resp_body['erros'] = []

            for key, value in resp_json.get('erros', {}):
                resp_body['erros'].append({
                    'campo': key or 'Não identificado',
                    'descricao': '\n'.join(value)
                })
    else:
        raise CargueroException('Não foi possível encontrar um retorno conhecido da Carguero!')

    return mount_xml_response(resp_body), ''


#
# Funções utilitárias
#

def _get_token(url: str, data: dict, cache: dict) -> str:
    token_id = data.get('token', '')
    senha = data.get('senha', '')

    if not token_id or not senha:
        raise CargueroException('O token, senha ou segredo não foram informados.')

    aes_key = PBKDF2(senha, token_id, 32, count=500, hmac_hash_module=SHA256)
    cipher = AES.new(aes_key, AES.MODE_ECB)

    email_hash = hash(token_id)
    (token, gen_time) = cache.get(email_hash, (bytearray(), 0))

    if token and (time.time() - gen_time) < 3595:  # Se a idade for menor que 55 minutos
        token = cipher.decrypt(token)
        return unpad(token, cipher.block_size).decode('UTF-8')

    # Se não existir token em cache, tentar solicitar pela Api da SigaGr
    if not url:
        raise CargueroException('Não foi possível obter a URL de para requisitar o token.')

    try:
        auth_request = {
            'client_secret': senha,
            'grant_type': 'client_credentials',
            'scopes': 'public_api',
            'client_id': token_id
        }

        resp = post(url, json=auth_request)
    except Exception as e:
        raise CargueroException('Erro ao buscar token de autorização para a Carguero!\n' + str(e))

    if resp.status_code == 200:
        token = resp.json().get('access_token', '')
        encrypt_token = cipher.encrypt(pad(token.encode('UTF-8'), cipher.block_size))

        cache[email_hash] = (encrypt_token, time.time())

        return token
    else:
        raise CargueroException('Erro ao obter token: ' + resp.content.decode('utf-8'))
