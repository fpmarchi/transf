import json
from typing import Tuple, List

import requests
from requests import Response

from ActionProcessor import ActionProcessor, handle_exception_factory
from geral import *
from geraljson import *
from geralxml import mount_xml_response

ACAO_RASTER_INICIO = 3300
ACAO_RASTER_GETCIDADES = 3301
ACAO_RASTER_SETCONJUNTO = 3302
ACAO_RASTER_SETSOLICITACAOPESQUISACONSULTA = 3303
ACAO_RASTER_GETRESULTADOPESQUISACONSULTA = 3304
ACAO_RASTER_GETDOCUMENTOPESQUISACONSULTA = 3305
ACAO_RASTER_SETSOLICITACAOPESQUISACONSULTACONJUNTO = 3306
ACAO_RASTER_GETRESULTADOPESQUISACONSULTACONJUNTO = 3307
ACAO_RASTER_FIM = 3349


# Exceção customizada
class RasterException(Exception):
    pass


# Classe base
class Raster(ActionProcessor):
    GET_CITIES = 3301
    SET_SET = 3302
    SET_REQUEST_SEARCH_CONSULTATION = 3303
    GET_RESULT_SEARCH_QUERY = 3304
    GET_QUERY_SEARCH_DOCUMENT = 3305
    SET_SEARCH_REQUEST_CONSULTATION_SET = 3306
    GET_SEARCH_RESULT_QUERY_SET = 3307
    # Monitoramento de risco
    GET_CUSTOMER = 3300
    SET_CUSTOMER = 3308
    GET_ROUTES = 3309
    SET_PRESM = 3310
    EFFECTIVE_PRESM = 3311
    CANCEL_PRESM = 3312
    GET_TABLE = 3313


#
#   Códigos independentes de instancia
#
def _raster_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a Raster:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    RasterException,
    _raster_exception_callback,
    any_exception_callback
)

#
#   Instancia limpa e sem configuração
#
raster = Raster()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = raster.link_to_factory('request')
_link_to_response = raster.link_to_factory('response')


@_link_to_request(Raster.GET_CUSTOMER)
@_handle_exception
def _out_find_client(req: dict, props: dict) -> Tuple[str, str]:
    req = {
        'Ambiente': props['Ambiente'],
        'Login': props['Login'],
        'Senha': props['Senha'],
        'TipoRetorno': 'JSON',
        'CNPJ': req.get('cliente_cnpjcpf')
    }

    return json.dumps(req), ''


@_link_to_request(Raster.SET_CUSTOMER)
@_handle_exception
def _out_send_client(req: dict, props: dict) -> Tuple[str, str]:
    req = {
        'Ambiente': props['Ambiente'],
        'Login': props['Login'],
        'Senha': props['Senha'],
        'TipoRetorno': 'JSON',
        'Cliente': {
            'CodigoCliente': safe_cast(req.get('cliente_codigo', 0), int, 0),
            'Razao': req.get('cliente_nome', ''),
            **conditional_key('Fantasia', req.get('cliente_nomefantasia')),
            'CNPJ': req.get('cliente_cnpjcpf', ''),
            'Endereco': req.get('cliente_endereco', ''),
            'Numero': req.get('cliente_numero', ''),
            **conditional_key('Complemento', req.get('cliente_complemento')),
            'Bairro': req.get('cliente_bairro', ''),
            **conditional_key('CodIBGECidade', int(req.get('cliente_codibge', 0))),
            'CEP': req.get('cliente_cep', ''),
            'Telefone': req.get('cliente_tell', ''),
            'Email': req.get('cliente_email', ''),
            'Latitude': req.get('cliente_lat', 0),
            'Longitude': req.get('cliente_lon', 0)
        }
    }

    return json.dumps(req), ''


@_link_to_request(Raster.GET_ROUTES)
@_handle_exception
def _out_find_routes(req: dict, props: dict) -> Tuple[str, str]:
    req = {
        'Ambiente': props['Ambiente'],
        'Login': props['Login'],
        'Senha': props['Senha'],
        'TipoRetorno': 'JSON',
        **conditional_key('CodIBGECidadeOrigem', safe_cast(req.get('rot_codibgeorig'), int, 0)),
        **conditional_key('CodIBGECidadeDestino', safe_cast(req.get('rot_codibgedest', 0), int, 0)),
        'DevolverKML': req.get('rot_retorna_kml', 'N'),
        'DetalharRota': 'S'
    }

    return json.dumps(req), ''


@_link_to_request(Raster.SET_PRESM)
@_handle_exception
def _out_send_presm(req: dict, props: dict) -> Tuple[str, str]:
    prod_docs = []
    req_body = {
        'Ambiente': props['Ambiente'],
        'Login': props['Login'],
        'Senha': props['Senha'],
        'TipoRetorno': 'JSON',
        'PreSM': {
            **conditional_key('Codigo', req.get('raster_cod_presm', 0)),
            'Engate': {
                'CodFilial': _get_branch(req.get('conh_filial_cnpjcpf')),
                'PlacaVeiculo': _format_plate(req.get('conh_veic_placa', '')),
                'VincVeiculo': _get_bond(req.get('conh_veic_propriedade', '')),
                'CodPerfilSeguranca': req.get('raster_perfil_seg', 0),
                'CPFMotorista1': req.get('conh_mot_cpf', 0),
                'VincMotorista1': 'F' if req.get('conh_mot_funcionario') == 'S' else 'T',
                **conditional_key('PlacaCarreta1', _format_plate(req.get('conh_veic_placacarreta1'))),
                **conditional_key('VincCarreta1', _get_bond(req.get('conh_veic_propriedadecarreta1'))),
                **conditional_key('PlacaCarreta2', _format_plate(req.get('conh_veic_placacarreta2'))),
                **conditional_key('VincCarreta2', _get_bond(req.get('conh_veic_propriedadecarreta2'))),
                **conditional_key('PlacaCarreta3', _format_plate(req.get('conh_veic_placacarreta3'))),
                **conditional_key('VincCarreta3', _get_bond(req.get('conh_veic_propriedadecarreta3')))
            },
            'Detalhamento': {
                'ColetasEntregas': [
                    {
                        'Tipo': 'COLETA',
                        'CodIBGECidade': safe_cast(req.get('conh_rem_codibge', 0), int, 0),
                        'DataHoraChegada': req.get('conh_datafimcarregamento', ''),
                        'DataHoraSaida': req.get('conh_datafimcarregamento', ''),
                        'Cliente': {
                            'CodigoCliente': safe_cast(req.get('conh_rem_codigo', 0), int, 0),
                            'Razao': req.get('conh_rem_nome', ''),
                            **conditional_key('Fantasia', req.get('conh_rem_nomefantasia')),
                            'CNPJ': req.get('conh_rem_cnpjcpf', ''),
                            'Endereco': req.get('conh_rem_endereco', ''),
                            'Numero': req.get('conh_rem_numero', ''),
                            **conditional_key('Complemento', req.get('conh_rem_complemento')),
                            'Bairro': req.get('conh_rem_bairro', ''),
                            **conditional_key('CodIBGECidade', int(req.get('conh_rem_codibge', 0))),
                            'CEP': req.get('conh_rem_cep', ''),
                            'Telefone': req.get('conh_rem_tell', ''),
                            'Email': req.get('conh_rem_email', ''),
                            **conditional_key('Latitude', _get_bond(req.get('conh_rem_lat'))),
                            **conditional_key('Longitude', _get_bond(req.get('conh_rem_lon')))
                        },
                        'Produtos': [
                            {
                                'NCMProduto': req.get('conh_ncm', ''),
                                'Valor': req.get('conh_valormerc', 0),
                                'Documentos': prod_docs
                            }
                        ]
                    },
                    {
                        'Tipo': 'ENTREGA',
                        'CodIBGECidade': safe_cast(req.get('conh_dest_codibge', 0), int, 0),
                        'DataHoraChegada': req.get('conh_datafimdescarga', ''),
                        'DataHoraSaida': req.get('conh_datafimdescarga', ''),
                        'Cliente': {
                            'CodigoCliente': safe_cast(req.get('conh_rem_codigo', 0), int, 0),
                            'Razao': req.get('conh_dest_nome', ''),
                            **conditional_key('Fantasia', req.get('conh_dest_nomefantasia')),
                            'CNPJ': req.get('conh_dest_cnpjcpf', ''),
                            'Endereco': req.get('conh_dest_endereco', ''),
                            'Numero': req.get('conh_dest_numero', ''),
                            **conditional_key('Complemento', req.get('conh_dest_complemento')),
                            'Bairro': req.get('conh_dest_bairro', ''),
                            **conditional_key('CodIBGECidade', int(req.get('conh_dest_codibge', 0))),
                            'CEP': req.get('conh_dest_cep', ''),
                            'Telefone': req.get('conh_dest_tell', ''),
                            'Email': req.get('conh_dest_email', ''),
                            **conditional_key('Latitude', _get_bond(req.get('conh_dest_lat'))),
                            **conditional_key('Longitude', _get_bond(req.get('conh_dest_lon')))
                        }
                    }
                ]
            },
            'Rota': {
                'CodRota': safe_cast(req.get('raster_codrota', 0), int, 0)
            },
            **conditional_key('LiberacaoEngate', {'SolicitarPesquisa': 'NORMAL'},
                              req.get('raster_veic_solicitarpesquisa') == 'S')
        }
    }

    index = 1
    while req.get('conh_numnf' + str(index)):
        postfix = str(index)
        prod_docs.append(
            {
                'Tipo': 'NOTAFISCAL',
                'Numero': req.get('conh_numnf' + postfix, ''),
                'Valor': req.get('conh_valornf' + postfix, )
            }
        )

        index += 1

    return json.dumps(req_body), ''


@_link_to_request(Raster.EFFECTIVE_PRESM)
@_handle_exception
def _out_effective_presm(req: dict, props: dict) -> Tuple[str, str]:
    req = {
        'Ambiente': props['Ambiente'],
        'Login': props['Login'],
        'Senha': props['Senha'],
        'TipoRetorno': 'JSON',
        'CodPreSolicitacao': safe_cast(req.get('raster_codpresm', 0), int, 0),
        'JaPassouRaioOrigem': req.get('raster_passou_raio_origem', 'N')
    }

    return json.dumps(req), ''


@_link_to_request(Raster.CANCEL_PRESM)
@_handle_exception
def _out_cancel_presm(req: dict, props: dict) -> Tuple[str, str]:
    req = {
        'Ambiente': props['Ambiente'],
        'Login': props['Login'],
        'Senha': props['Senha'],
        'TipoRetorno': 'JSON',
        'CodSolicitacao': safe_cast(req.get('raster_codpresm', 0), int, 0),
        'Motivo': safe_cast(req.get('raster_motivo_cancelamento', 0), int, 0)
    }

    return json.dumps(req), ''


@_link_to_request(Raster.GET_TABLE)
@_handle_exception
def _out_get_table(req: dict, props: dict) -> Tuple[str, str]:
    req = {
        'Ambiente': props['Ambiente'],
        'Login': props['Login'],
        'Senha': props['Senha'],
        'TipoRetorno': 'JSON',
        'NomeTabela': req.get('raster_tabela', '')
    }

    return json.dumps(req), ''


#
# Tratamentos de retorno
#
@_link_to_response(Raster.GET_CUSTOMER, Raster.SET_CUSTOMER)
@_handle_exception
def _in_customer(resp: Response) -> Tuple[str, str]:
    ret = resp.json().get('result')[0]

    sucesso = ret.get('CodErro') == 0

    result = {
        'sucesso': sucesso
    }

    if not sucesso:
        result['msg_erro'] = str(ret.get('CodErro')) + \
                             ('-' + ret.get('MsgErro') or 'Um erro foi retornado pela comunicação com a Raster')
        return mount_xml_response(result), ''

    ret = ret.get('Cliente', {})
    result['conteudo'] = {
        'cod_cliente': ret.get('Codigo')
    }

    return mount_xml_response(result), ''


@_link_to_response(Raster.GET_ROUTES)
@_handle_exception
def _in_cancel_presm(resp: Response) -> Tuple[str, str]:
    ret = resp.json().get('result')[0]

    sucesso = ret.get('CodErro') == 0

    result = {
        'sucesso': sucesso
    }

    if not sucesso:
        result['msg_erro'] = str(ret.get('CodErro')) + \
                             ('-' + ret.get('MsgErro') or 'Um erro foi retornado pela comunicação com a Raster')
        return mount_xml_response(result), ''

    result['conteudo'] = []
    for rota in ret.get('Rotas', []):
        result['conteudo'].append({
            'cod_rota': rota.get('Codigo', 0),
            'descricao': rota.get('Descricao', ''),
            'distancia_km': rota.get('KMDistancia', 0.0),
            'cidades': [
                {
                    'cod_ibge': cid.get('CodIBGE', 0),
                    'nome': cid.get('Cidade', ''),
                    'estado': cid.get('Estado', ''),
                    'uf': cid.get('UF', ''),
                    'pais': cid.get('Pais', ''),
                } for cid in rota.get('Cidades', [])
            ],
            'perfis_seg': [
                {
                    'codigo': cid.get('Codigo', 0),
                    'descricao': cid.get('Descricao', '')
                } for cid in rota.get('PerfisSeguranca', [])
            ],
            **conditional_key('rodovias', [rod.get('Nome') for rod in rota.get('Rodovias', [])]),
            **conditional_key('kml', rota.get('KML'))
        })

    return mount_xml_response(result), ''


@_link_to_response(Raster.SET_PRESM)
@_handle_exception
def _in_send_presm(resp: Response) -> Tuple[str, str]:
    ret = resp.json().get('result')[0]

    sucesso = ret.get('CodErro') == 0

    result = {
        'sucesso': sucesso
    }

    if not sucesso:
        result['msg_erro'] = str(ret.get('CodErro')) + \
                             ('-' + ret.get('MsgErro') or 'Um erro foi retornado pela comunicação com a Raster')
        return mount_xml_response(result), ''

    ret = ret.get('PreSM', {})
    sucesso = not ret.get('Inconsistencias')

    result = {
        'sucesso': sucesso,
        'conteudo': {
            'cod_presm': ret.get('Codigo', 0),
            'inconsistencias': [
                {
                    'guia': ic.get('Guia', ''),
                    'tipo': ic.get('Tipo', ''),
                    'identificacao': ic.get('Identificacao', ''),
                    'descricao': ic.get('Descricao', ''),
                    'cod_alerta': ic.get('CodAlerta', 0),
                    'msg_alerta': ic.get('MsgAlerta', '')
                } for ic in ret.get('Inconsistencias', [])
            ]
        }
    }

    return mount_xml_response(result), ''


@_link_to_response(Raster.EFFECTIVE_PRESM, Raster.CANCEL_PRESM)
@_handle_exception
def _in_sm(resp: Response) -> Tuple[str, str]:
    ret = resp.json().get('result')[0]

    sucesso = ret.get('CodErro') == 0

    result = {
        'sucesso': sucesso
    }

    if not sucesso:
        result['msg_erro'] = str(ret.get('CodErro')) + \
                             ('-' + ret.get('MsgErro') or 'Um erro foi retornado pela comunicação com a Raster')
        return mount_xml_response(result), ''

    result['conteudo'] = {
        'cod_presm': ret.get('CodPreSolicitacao', 0),
        **conditional_key('cod_sm', ret.get('CodSolicitacao')),
        **conditional_key('cancelada', ret.get('Cancelou'))
    }

    return mount_xml_response(result), ''


@_link_to_response(Raster.GET_TABLE)
@_handle_exception
def _in_get_table(resp: Response) -> Tuple[str, str]:
    ret = resp.json().get('result')[0]

    sucesso = ret.get('CodErro') == 0

    result = {
        'sucesso': sucesso
    }

    if not sucesso:
        result['msg_erro'] = str(ret.get('CodErro')) + \
                             ('-' + ret.get('MsgErro') or 'Um erro foi retornado pela comunicação com a Raster')
        return mount_xml_response(result), ''

    result['conteudo'] = ret.get('Linhas', [])

    return mount_xml_response(result), ''


#
# Funções utilitárias
#
def _format_plate(text: str) -> str:
    if not text:
        return ''

    return text[:3] + '-' + text[3:]


@static_vars(bonds={
    'S': 'F',
    'F': 'F',
    'R': 'F',
    'O': 'F',
    'N': 'T',
    'A': 'A',
    'M': 'A',
    'G': 'A'
})
def _get_bond(in_sat: str) -> str:
    return _get_bond.bonds.get(in_sat, '')


def _get_branch(cnpj: str) -> str:
    if not cnpj:
        return '0'

    url = raster.context.get('url', '')
    url = url[:url.rfind('/')] + '/"getTabela"'

    raster.context.get('req')['raster_tabela'] = 'FILIAIS'
    req, _ = raster.dispatch(Raster.GET_TABLE, raster.context, 'request')

    resp = requests.post(url, json=json.loads(req))

    if resp.status_code != 200:
        raise Exception('Erro ao buscar filiais na Raster')

    ret = resp.json().get('result')[0]
    sucesso = ret.get('CodErro') == 0

    if not sucesso:
        raise Exception(str(ret.get('CodErro')) + ' - ' + (ret.get('MsgErro') or
                                                           'Erro ao buscar filiais na Raster'))

    branches: List[dict] = ret.get('Linhas', [])

    if len(branches) < 1:
        return '0'

    cod_bound = next((
        b.get('Codigo', 0)
        for b in branches
        if cnpj in b.get('Descricao', '')
    ), None)

    if not cod_bound:
        cod_bound = branches[0].get('Codigo', '0')

    return cod_bound


#
# Implementação não migrada
#
@_handle_exception
def request_raster_get_cidades(reqJSON, properties):
    req = {
        'Ambiente': properties['Ambiente'],
        'Login': properties['Login'],
        'Senha': properties['Senha'],
        'TipoRetorno': 'JSON'
    }
    return json.dumps(req), ''


@_handle_exception
def request_raster_set_conjunto(reqJSON, properties):
    req = {}
    req['Ambiente'] = properties['Ambiente']
    req['Login'] = properties['Login']
    req['Senha'] = properties['Senha']
    req['TipoRetorno'] = 'JSON'
    conjunto = {}
    motorista = {}
    motorista['CPF'] = getJSON(reqJSON, 'mot_cpf')
    motorista['Nome'] = getJSON(reqJSON, 'mot_nome')
    ##motorista['Apelido'] = getJSON(reqJSON, '') nao é obrigatório
    motorista['Sexo'] = getJSON(reqJSON, 'mot_sexo')
    motorista['RG'] = getJSON(reqJSON, 'mot_rg')
    motorista['OrgaoEmissRG'] = getJSON(reqJSON, 'mot_orgaorg')
    date = ''
    if getJSON(reqJSON, 'mot_datarg') != '':
        date = datetime.strptime(getJSON(reqJSON, 'mot_datarg'), '%d/%m/%Y').date()
    motorista['DataEmissRG'] = str(date)
    motorista['CodProfissao'] = 30
    cnhFormulario = getJSON(reqJSON, 'mot_cnhformulario')
    if cnhFormulario != '':
        motorista['NumFormCNH'] = int(cnhFormulario)
    mot_cnh = getJSON(reqJSON, 'mot_cnh')
    if mot_cnh != '':
        motorista['NumRegCNH'] = int(mot_cnh)
    cnhseguranca = getJSON(reqJSON, 'mot_numsegcnh')
    motorista['NumSegurCNH'] = cnhseguranca[:11]
    motorista['NumRenachCNH'] = getJSON(reqJSON, 'mot_renach')
    motorista['UFEmissCNH'] = getJSON(reqJSON, 'mot_ufcnh')
    if getJSON(reqJSON, 'mot_cnhemissao') != '':
        date = datetime.strptime(getJSON(reqJSON, 'mot_cnhemissao'), '%d/%m/%Y').date()
    motorista['DataEmissCNH'] = str(date)
    if getJSON(reqJSON, 'mot_datavalidcnh') != '':
        date = datetime.strptime(getJSON(reqJSON, 'mot_datavalidcnh'), '%d/%m/%Y').date()
    motorista['DataVencCNH'] = str(date)
    motorista['CategoriaCNH'] = getJSON(reqJSON, 'mot_catcnh')
    if getJSON(reqJSON, 'mot_dataprimcnh') != '':
        date = datetime.strptime(getJSON(reqJSON, 'mot_dataprimcnh'), '%d/%m/%Y').date()
    motorista['DtPrimEmissCNH'] = str(date)
    motorista['PossuiMOPP'] = 'N'
    # motorista['DtVencMOPP'] = getJSON(reqJSON, '') nao é obrigatorio
    ibgecidnascimento = getJSON(reqJSON, 'mot_ibgecidnascimento')
    if ibgecidnascimento != '':
        motorista['CodIBGECidadeNatal'] = int(ibgecidnascimento)
    if getJSON(reqJSON, 'mot_datanasc') != '':
        date = datetime.strptime(getJSON(reqJSON, 'mot_datanasc'), '%Y-%m-%d').date()
    motorista['DataNascimento'] = str(date)
    motorista['NomeMae'] = getJSON(reqJSON, 'mot_nomemae')
    motorista['Endereco'] = getJSON(reqJSON, 'mot_endereco')
    motorista['Numero'] = getJSON(reqJSON, 'mot_numero')
    motorista['Complemento'] = getJSON(reqJSON, 'mot_complemento')
    motorista['Bairro'] = getJSON(reqJSON, 'mot_bairro')
    codibge = getJSON(reqJSON, 'mot_codibge')
    if codibge != '':
        motorista['CodIBGECidade'] = int(codibge)
    motorista['CEP'] = getJSON(reqJSON, 'mot_cep')
    motorista['Telefone'] = getJSON(reqJSON, 'mot_foneddd') + getJSON(reqJSON, 'mot_fonenumero')
    motorista['Celular'] = getJSON(reqJSON, 'mot_celularddd') + getJSON(reqJSON, 'mot_celularnumero')
    # motorista['Radio'] = getJSON(reqJSON, '') não é obrigatório
    # motorista['SenhaMotorista'] = getJSON(reqJSON, '') não é obrigatório
    arrayDocumentosMot = []
    fotoMot1 = getJSON(reqJSON, 'mot_foto1')
    fotoMot2 = getJSON(reqJSON, 'mot_foto2')
    if fotoMot1 != '':
        objDocumento = {}
        objDocumento['Descricao'] = 'foto1'
        objDocumento['Extensao'] = 'JPG'
        objDocumento['Documento'] = fotoMot1
        arrayDocumentosMot.append(objDocumento)
    if fotoMot2 != '':
        objDocumento = {}
        objDocumento['Descricao'] = 'foto2'
        objDocumento['Extensao'] = 'JPG'
        objDocumento['Documento'] = fotoMot2
        arrayDocumentosMot.append(objDocumento)
    qtdeDocsMot = getJSON(reqJSON, 'mot_qtdedocs')
    if qtdeDocsMot != '':
        qtdeDocsMot = int(qtdeDocsMot)
        for i in range(1, qtdeDocsMot + 1, 1):
            objDocumento = {}
            objDocumento['Descricao'] = getJSON(reqJSON, 'mot_doc' + str(i) + '_nome')
            objDocumento['Extensao'] = getJSON(reqJSON, 'mot_doc' + str(i) + '_extensao')
            objDocumento['Documento'] = getJSON(reqJSON, 'mot_doc' + str(i) + '_arq')
            arrayDocumentosMot.append(objDocumento)
    motorista['Documentos'] = arrayDocumentosMot
    veiculo = {}
    placa = getJSON(reqJSON, 'veic_placa')
    if placa[5].isdigit():
        placa = placa[:3] + '-' + placa[3:]
    veiculo['Placa'] = placa
    veiculo['CodIBGECidade'] = safe_cast(getJSON(reqJSON, 'veic_codibge'), int)
    veiculo['Cidade'] = getJSON(reqJSON, 'veic_nomecidade')
    veiculo['UF'] = getJSON(reqJSON, 'veic_uf')
    paisAux = getJSON(reqJSON, 'veic_pais')

    pais = ''
    if paisAux.upper() == 'BRASIL':
        pais = 'BRA'
    veiculo['Pais'] = pais
    veiculo['Renavam'] = getJSON(reqJSON, 'veic_renavam')
    veiculo['Chassi'] = getJSON(reqJSON, 'veic_chassi')
    # veiculo['DataEmissao'] = getJSON(reqJSON, '') não é obrigatório
    veiculo['NumeroANTT'] = getJSON(reqJSON, 'veic_rntrc')
    # veiculo['NumeroFrota'] = getJSON(reqJSON, '') não é obrigatório
    veiculo['CodTipoVeiculo'] = get_tipo_veic(getJSON(reqJSON, 'veic_tipoveic'))
    # veiculo['CodTipoCarreta'] = get_tipo_carreta(getJSON(reqJSON, 'veic_tipocarr')) não é obrigatório
    veiculo['CodMarca'] = get_cod_marca(getJSON(reqJSON, 'veic_marca'))
    veiculo['CodCor'] = get_cod_cor(getJSON(reqJSON, 'veic_cor'))
    veiculo['AnoFabricacao'] = int(getJSON(reqJSON, 'veic_anofab'))
    veiculo['AnoModelo'] = int(getJSON(reqJSON, 'veic_anomod'))
    if getJSON(reqJSON, 'veic_tiporastreador') != '':
        veiculo['PossuiRastreador'] = 'S'
        veiculo['TermiRasPrincipal'] = reqJSON.get('numeromct') or '01'
        veiculo['ModelRasPrincipal'] = safe_cast(getJSON(reqJSON, 'raster_codmodelo_rastreador'), int, '')
        veiculo['TecnoRasPrincipal'] = safe_cast(getJSON(reqJSON, 'raster_codtecnologia_rastreador'), int, '')
    else:
        veiculo['PossuiRastreador'] = 'N'
    # veiculo['Cidade"'] = getJSON(reqJSON, 'veic_nomecidade') no manual não tem essa tag
    # veiculo['UF'] = getJSON(reqJSON, 'veic_uf') no manual não tem essa tag
    # veiculo['Pais'] = getJSON(reqJSON, '')"BRA", no manual não tem essa tag

    proprietario = {}
    isPf = len(getJSON(reqJSON, 'prop_cnpjcpf')) == 11
    proprietario['CNPJ'] = getJSON(reqJSON, 'prop_cnpjcpf')
    proprietario['Razao'] = getJSON(reqJSON, 'prop_nome')
    # proprietario['Fantasia'] = "Fulano" #nao é obrigatorio
    if not isPf:
        proprietario['IE'] = getJSON(reqJSON, 'prop_ie')
    else:
        proprietario['RG'] = getJSON(reqJSON, 'prop_rg')
        proprietario['OrgaoEmissRG'] = getJSON(reqJSON, 'prop_orgaorg')
    proprietario['Endereco'] = getJSON(reqJSON, 'prop_endereco')
    proprietario['Numero'] = getJSON(reqJSON, 'prop_numero')
    if getJSON(reqJSON, 'prop_complemento') != '':
        proprietario['Complemento'] = getJSON(reqJSON, 'prop_complemento')
    proprietario['Bairro'] = getJSON(reqJSON, 'prop_bairro')
    proprietario['CodIBGECidade'] = int(getJSON(reqJSON, 'prop_codibge'))
    proprietario['CEP'] = getJSON(reqJSON, 'prop_cep')
    proprietario['Telefone'] = getJSON(reqJSON, 'prop_foneddd') + getJSON(reqJSON, 'prop_fonenumero')
    if getJSON(reqJSON, 'prop_email') != '':
        proprietario['Email'] = getJSON(reqJSON, 'prop_email')
    veiculo['Proprietario'] = proprietario
    arrayDocumentosVeic = []
    foto1Veic = getJSON(reqJSON, 'veic_foto1')
    foto2Veic = getJSON(reqJSON, 'veic_foto2')
    if foto1Veic != '':
        objDocumento = {}
        objDocumento['Descricao'] = 'foto1Veic'
        objDocumento['Extensao'] = 'JPG'
        objDocumento['Documento'] = foto1Veic
        arrayDocumentosVeic.append(objDocumento)
    if foto2Veic != '':
        objDocumento = {}
        objDocumento['Descricao'] = 'foto2Veic'
        objDocumento['Extensao'] = 'JPG'
        objDocumento['Documento'] = foto2Veic
        arrayDocumentosVeic.append(objDocumento)
    qtdeDocsVeic = getJSON(reqJSON, 'veic_qtdedocs')
    if qtdeDocsVeic != '':
        qtdeDocsVeic = int(qtdeDocsVeic)
        for i in range(1, qtdeDocsVeic + 1, 1):
            objDocumento = {}
            objDocumento['Descricao'] = getJSON(reqJSON, 'veic_doc' + str(i) + '_nome')
            objDocumento['Extensao'] = getJSON(reqJSON, 'veic_doc' + str(i) + '_extensao')
            objDocumento['Documento'] = getJSON(reqJSON, 'veic_doc' + str(i) + '_arq')
            arrayDocumentosVeic.append(objDocumento)
    qtdeDocsPropVeic = getJSON(reqJSON, 'prop_qtdedocs')
    if qtdeDocsPropVeic != '':
        qtdeDocsPropVeic = int(qtdeDocsPropVeic)

        for i in range(1, qtdeDocsPropVeic + 1, 1):
            objDocumento = {}
            objDocumento['Descricao'] = getJSON(reqJSON, 'prop_doc' + str(i) + '_nome')
            objDocumento['Extensao'] = getJSON(reqJSON, 'prop_doc' + str(i) + '_extensao')
            objDocumento['Documento'] = getJSON(reqJSON, 'prop_doc' + str(i) + '_arq')
            arrayDocumentosVeic.append(objDocumento)
    veiculo['Documentos'] = arrayDocumentosVeic
    carreta1 = {}
    placa = getJSON(reqJSON, 'car1_placa')
    if placa != '':
        if placa[5].isdigit():
            placa = placa[:3] + '-' + placa[3:]
        carreta1['Placa'] = placa
        carreta1['CodIBGECidade'] = int(getJSON(reqJSON, 'car1_codibge'))
        carreta1['Renavam'] = getJSON(reqJSON, 'car1_renavam')
        carreta1['Chassi'] = getJSON(reqJSON, 'car1_chassi')
        # veiculo['DataEmissao'] = getJSON(reqJSON, '') não é obrigatório
        carreta1['NumeroANTT'] = getJSON(reqJSON, 'car1_rntrc')
        # veiculo['NumeroFrota'] = getJSON(reqJSON, '') não é obrigatório
        carreta1['CodTipoCarreta'] = get_tipo_carreta(getJSON(reqJSON, 'car1_tipocarr'))
        # veiculo['CodMarca'] = getCodMarca(getJSON(reqJSON, 'veic_marca'))
        carreta1['CodCor'] = get_cod_cor(getJSON(reqJSON, 'car1_cor'))
        carreta1['AnoFabricacao'] = int(getJSON(reqJSON, 'car1_anofab'))
        carreta1['AnoModelo'] = int(getJSON(reqJSON, 'car1_anomod'))
        if getJSON(reqJSON, 'veic_tiporastreador') != '':
            carreta1['PossuiRastreador'] = 'S'
        else:
            carreta1['PossuiRastreador'] = 'N'
        proprietariocar1 = {}
        isPf = len(getJSON(reqJSON, 'car1_prop_cnpjcpf')) == 11
        proprietariocar1['CNPJ'] = getJSON(reqJSON, 'car1_prop_cnpjcpf')
        proprietariocar1['Razao'] = getJSON(reqJSON, 'car1_prop_nome')
        # proprietario['Fantasia'] = "Fulano" #nao é obrigatorio
        if not isPf:
            proprietariocar1['IE'] = getJSON(reqJSON, 'car1_prop_ie')
        else:
            proprietariocar1['RG'] = getJSON(reqJSON, 'car1_prop_rg')
            proprietariocar1['OrgaoEmissRG'] = getJSON(reqJSON, 'car1_prop_orgaorg')
        proprietariocar1['Endereco'] = getJSON(reqJSON, 'car1_prop_endereco')
        proprietariocar1['Numero'] = getJSON(reqJSON, 'car1_prop_numero')
        if getJSON(reqJSON, 'prop_complemento') != '':
            proprietariocar1['Complemento'] = getJSON(reqJSON, 'car1_prop_complemento')
        proprietariocar1['Bairro'] = getJSON(reqJSON, 'car1_prop_bairro')
        proprietariocar1['CodIBGECidade'] = int(getJSON(reqJSON, 'car1_prop_codibge'))
        proprietariocar1['CEP'] = getJSON(reqJSON, 'car1_prop_cep')
        proprietariocar1['Telefone'] = getJSON(reqJSON, 'car1_prop_foneddd') + getJSON(reqJSON,
                                                                                       'car1_prop_fonenumero')
        if getJSON(reqJSON, 'car1_prop_email') != '':
            proprietariocar1['Email'] = getJSON(reqJSON, 'car1_prop_email')
        carreta1['Proprietario'] = proprietariocar1
        arrayDocumentosCarreta = []
        foto1Car1 = getJSON(reqJSON, 'car1_foto1')
        foto2Car1 = getJSON(reqJSON, 'car1_foto2')
        if foto1Car1 != '':
            objDocumento = {}
            objDocumento['Descricao'] = 'foto1Car1'
            objDocumento['Extensao'] = 'JPG'
            objDocumento['Documento'] = foto1Car1
            arrayDocumentosCarreta.append(objDocumento)
        if foto2Car1 != '':
            objDocumento = {}
            objDocumento['Descricao'] = 'foto2Car2'
            objDocumento['Extensao'] = 'JPG'
            objDocumento['Documento'] = foto2Car1
            arrayDocumentosCarreta.append(objDocumento)
        qtdeDocsPropCar1 = getJSON(reqJSON, 'car1_prop_qtdedocs')
        if qtdeDocsPropCar1 != '':
            qtdeDocsPropCar1 = int(qtdeDocsPropCar1)
            for i in range(1, qtdeDocsPropCar1 + 1, 1):
                objDocumento = {}
                objDocumento['Descricao'] = getJSON(reqJSON, 'car1_prop_doc' + str(i) + '_nome')
                objDocumento['Extensao'] = getJSON(reqJSON, 'car1_prop_doc' + str(i) + '_extensao')
                objDocumento['Documento'] = getJSON(reqJSON, 'car1_prop_doc' + str(i) + '_arq')
                arrayDocumentosCarreta.append(objDocumento)
        carreta1['Documentos'] = arrayDocumentosCarreta
    carreta2 = {}
    placaCar2 = getJSON(reqJSON, 'car2_placa')
    if placaCar2 != '':
        if placaCar2[5].isdigit():
            placaCar2 = placaCar2[:3] + '-' + placaCar2[3:]
        carreta2['Placa'] = placaCar2
        carreta2['CodIBGECidade'] = int(getJSON(reqJSON, 'car2_codibge'))
        carreta2['Renavam'] = getJSON(reqJSON, 'car2_renavam')
        carreta2['Chassi'] = getJSON(reqJSON, 'car2_chassi')
        # veiculo['DataEmissao'] = getJSON(reqJSON, '') não é obrigatório
        carreta2['NumeroANTT'] = getJSON(reqJSON, 'car2_rntrc')
        # veiculo['NumeroFrota'] = getJSON(reqJSON, '') não é obrigatório
        carreta2['CodTipoCarreta'] = get_tipo_carreta(getJSON(reqJSON, 'car2_tipocarr'))
        # veiculo['CodMarca'] = getCodMarca(getJSON(reqJSON, 'veic_marca'))
        carreta2['CodCor'] = get_cod_cor(getJSON(reqJSON, 'car2_cor'))
        carreta2['AnoFabricacao'] = int(getJSON(reqJSON, 'car2_anofab'))
        carreta2['AnoModelo'] = int(getJSON(reqJSON, 'car2_anomod'))
        if getJSON(reqJSON, 'veic_tiporastreador') != '':
            carreta2['PossuiRastreador'] = 'S'
        else:
            carreta2['PossuiRastreador'] = 'N'
        proprietariocar2 = {}
        isPf = len(getJSON(reqJSON, 'car2_prop_cnpjcpf')) == 11
        proprietariocar2['CNPJ'] = getJSON(reqJSON, 'car2_prop_cnpjcpf')
        proprietariocar2['Razao'] = getJSON(reqJSON, 'car2_prop_nome')
        # proprietario['Fantasia'] = "Fulano" #nao é obrigatorio
        if not isPf:
            proprietariocar2['IE'] = getJSON(reqJSON, 'car2_prop_ie')
        else:
            proprietariocar2['RG'] = getJSON(reqJSON, 'car2_prop_rg')
            proprietariocar2['OrgaoEmissRG'] = getJSON(reqJSON, 'car2_prop_orgaorg')
        proprietariocar2['Endereco'] = getJSON(reqJSON, 'car2_prop_endereco')
        proprietariocar2['Numero'] = getJSON(reqJSON, 'car2_prop_numero')
        if getJSON(reqJSON, 'prop_complemento') != '':
            proprietariocar2['Complemento'] = getJSON(reqJSON, 'car1_prop_complemento')
        proprietariocar2['Bairro'] = getJSON(reqJSON, 'car2_prop_bairro')
        proprietariocar2['CodIBGECidade'] = int(getJSON(reqJSON, 'car2_prop_codibge'))
        proprietariocar2['CEP'] = getJSON(reqJSON, 'car2_prop_cep')
        proprietariocar2['Telefone'] = getJSON(reqJSON, 'car2_prop_foneddd') + getJSON(reqJSON,
                                                                                       'car2_prop_fonenumero')
        if getJSON(reqJSON, 'car2_prop_email') != '':
            proprietariocar2['Email'] = getJSON(reqJSON, 'car2_prop_email')
        carreta2['Proprietario'] = proprietariocar2
        arrayDocumentosCarreta2 = []
        foto1Car2 = getJSON(reqJSON, 'car1_foto1')
        foto2Car2 = getJSON(reqJSON, 'car1_foto2')
        if foto1Car2 != '':
            objDocumento = {}
            objDocumento['Descricao'] = 'foto1Car2'
            objDocumento['Extensao'] = 'JPG'
            objDocumento['Documento'] = foto1Car2
            arrayDocumentosCarreta2.append(objDocumento)
        if foto2Car2 != '':
            objDocumento = {}
            objDocumento['Descricao'] = 'foto2Car2'
            objDocumento['Extensao'] = 'JPG'
            objDocumento['Documento'] = foto2Car2
            arrayDocumentosCarreta2.append(objDocumento)
        qtdeDocsPropCar2 = getJSON(reqJSON, 'car2_prop_qtdedocs')
        if qtdeDocsPropCar2 != '':
            qtdeDocsPropCar2 = int(qtdeDocsPropCar2)
            for i in range(1, qtdeDocsPropCar2 + 1, 1):
                objDocumento = {}
                objDocumento['Descricao'] = getJSON(reqJSON, 'car2_prop_doc' + str(i) + '_nome')
                objDocumento['Extensao'] = getJSON(reqJSON, 'car2_prop_doc' + str(i) + '_extensao')
                objDocumento['Documento'] = getJSON(reqJSON, 'car2_prop_doc' + str(i) + '_arq')
                arrayDocumentosCarreta2.append(objDocumento)
        carreta2['Documentos'] = arrayDocumentosCarreta2
    conjunto['Motorista'] = motorista
    conjunto['Veiculo'] = veiculo
    conjunto['Carreta1'] = carreta1
    if placaCar2 != '':
        conjunto['Carreta2'] = carreta2
    req['Conjunto'] = conjunto

    return json.dumps(req), ''


@_handle_exception
def response_raster_set_conjunto(resp):
    retcode = resp.status_code
    ret = resp.content.decode('utf-8')
    root = json.loads(ret)
    result = getJSON(root, 'result')
    msgFinalErro = ''
    codErro = 0
    for obj in result:
        codErro = getJSON(obj, 'CodErro')
        if codErro > 0:
            msgErro = getJSON(obj, 'MsgErro')
            msgFinalErro += str(codErro) + ' ' + msgErro
    if codErro == 0:
        msgFinalSucesso = 'Conjunto Cadastrado com sucesso!'
        return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msgFinalSucesso + '</msg></resp>', ''
    else:
        return '', msgFinalErro


@_handle_exception
def request_raster_set_solicitacao_pesquisa_consulta(reqJSON, properties):
    try:
        req = {}
        req['Ambiente'] = properties['Ambiente']
        req['Login'] = properties['Login']
        req['Senha'] = properties['Senha']
        req['TipoRetorno'] = 'JSON'
        req['CodFilial'] = int(getJSON(reqJSON, 'filial'))
        tipoPesquisa = getJSON(reqJSON, 'tipopesquisa')
        req['TipoIdentificacao'] = get_tipo_identificacao(tipoPesquisa)
        if tipoPesquisa != 'M':
            placa = get_identificacao(reqJSON, tipoPesquisa)
            if placa[5].isdigit():
                placa = placa[:3] + '-' + placa[3:]
            req['Identificacao'] = placa
        else:
            req['Identificacao'] = get_identificacao(reqJSON, tipoPesquisa)
        req['Vinculo'] = get_vinculo(reqJSON, tipoPesquisa)
        req['Expressa'] = getJSON(reqJSON, 'pesquisaexpressa')
        return json.dumps(req), ''
    except Exception as e:
        print('Erro em requestRasterSetSolicitaoPesquisaConsulta')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO', []


@_handle_exception
def response_raster_set_solicitacao_pesquisa_consulta(resp):
    retcode = resp.status_code
    ret = resp.content.decode('utf-8')
    root = json.loads(ret)
    result = getJSON(root, 'result')
    msgFinalErro = ''
    codErro = 0

    tipo = ''
    situacao = ''
    codigo = ''
    for obj in result:
        codErro = getJSON(obj, 'CodErro')
        tipo = getJSON(obj, 'Tipo')
        codigo = getJSON(obj, 'Codigo')
        situacao = getJSON(obj, 'Situacao')
        if codErro > 0:
            msgErro = getJSON(obj, 'MsgErro')
            msgFinalErro += '(' + str(codErro) + ') ' + msgErro
    if codErro == 0:
        msgFinalSucesso = 'Solicitação de análise realizada sucesso! Aguarde alguns instantes e utiliza a opção Consultar Análise'
        return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msgFinalSucesso + '</msg><tipo>' + get_tipo_pesquisa(
            tipo) + '</tipo><codigo>' + str(codigo) + '</codigo><situacao>' + get_situacao(
            situacao) + '</situacao></resp>', ''
    else:
        return '', msgFinalErro


@_handle_exception
def request_raster_get_resultado_pesquisa_consulta(reqJSON, properties):
    req = {}
    req['Ambiente'] = properties['Ambiente']
    req['Login'] = properties['Login']
    req['Senha'] = properties['Senha']
    req['TipoRetorno'] = 'JSON'
    req['CodFilial'] = int(getJSON(reqJSON, 'filial'))
    tipoPesquisa = getJSON(reqJSON, 'tipopesquisa')
    req['TipoIdentificacao'] = get_tipo_identificacao(tipoPesquisa)
    if tipoPesquisa != 'M':
        placa = get_identificacao(reqJSON, tipoPesquisa)
        if placa[5].isdigit():
            placa = placa[:3] + '-' + placa[3:]
        req['Identificacao'] = placa
    else:
        req['Identificacao'] = get_identificacao(reqJSON, tipoPesquisa)
    req['Vinculo'] = get_vinculo(reqJSON, tipoPesquisa)
    return json.dumps(req), ''


@_handle_exception
def response_raster_get_resultado_pesquisa_consulta(resp):
    retcode = resp.status_code
    ret = resp.content.decode('utf-8')
    root = json.loads(ret)
    result = getJSON(root, 'result')
    msgFinalErro = ''
    codErro = 0
    tipo = ''
    situacao = ''
    senha = ''
    dataExpiracao = ''
    justificativasStr = ''
    for obj in result:
        codErro = getJSON(obj, 'CodErro')
        tipo = getJSON(obj, 'Tipo')
        codigo = getJSON(obj, 'Codigo')
        situacao = getJSON(obj, 'Situacao')
        dataExpiracao = getJSON(obj, 'DataExpiracao')
        senha = getJSON(obj, 'Senha')
        justificativas = getJSON(obj, 'Justificativas')
        justificativasStr = ''
        for justificativa in justificativas:
            justificativasStr += getJSON(justificativa, 'Codigo') + ' - ' + getJSON(justificativa, 'Descricao') + ' | '
        if codErro > 0:
            msgErro = getJSON(obj, 'MsgErro')
            msgFinalErro += '(' + str(codErro) + ') ' + msgErro
    if codErro == 0:
        msgFinalSucesso = 'Análise obtida.'
        return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msgFinalSucesso + '</msg><tipo>' + get_tipo_pesquisa(
            tipo) + '</tipo>' + \
               '<codigo>' + str() + '</codigo><situacao>' + get_situacao(
            situacao) + '</situacao><dataexpiracao>' + dataExpiracao + '</dataexpiracao>' + \
               '<senha>' + senha + '</senha><justificativas>' + justificativasStr + '</justificativas></resp>', ''
    else:
        return '', msgFinalErro


@_handle_exception
def request_raster_get_documento_pesquisa_consulta(reqJSON, properties):
    try:
        req = {
            'Ambiente': properties['Ambiente'],
            'Login': properties['Login'],
            'Senha': properties['Senha'],
            'TipoRetorno': 'JSON'
        }
        tipoPesquisa = getJSON(reqJSON, 'tipopesquisa')
        req['CodigoPesquisa'] = get_codigo_pesquisa(reqJSON, tipoPesquisa)
        return json.dumps(req), ''
    except Exception as e:
        print('Erro em requestRasterGetResultadoPesquisaConsulta')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO', []


@_handle_exception
def response_raster_get_documento_pesquisa_consulta(resp):
    retcode = resp.status_code
    ret = resp.content.decode('utf-8')
    root = json.loads(ret)
    result = getJSON(root, 'result')
    msgFinalErro = ''
    codErro = 0

    msgFinalSucesso = ''
    conteudo = ''
    for obj in result:
        codErro = getJSON(obj, 'CodErro')
        gerou = getJSON(obj, 'Gerou')
        conteudo = getJSON(obj, 'Conteudo')
        if codErro > 0:
            msgErro = getJSON(obj, 'MsgErro')
            msgFinalErro += '(' + str(codErro) + ') ' + msgErro
    if codErro == 0:
        if gerou == 'S':
            msgFinalSucesso = 'PDF gerado com sucesso'
        elif gerou == 'N':
            msgFinalSucesso = 'PDF não gerado'
        return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msgFinalSucesso + '</msg><conteudo>' + conteudo + '</conteudo></resp>', ''
    else:
        return '', msgFinalErro


@_handle_exception
def request_raster_set_solicitacao_pesquisa_consulta_conjunto(reqJSON, properties):
    try:
        req = {}
        req['Ambiente'] = properties['Ambiente']
        req['Login'] = properties['Login']
        req['Senha'] = properties['Senha']
        req['TipoRetorno'] = 'JSON'
        req['CodFilial'] = int(getJSON(reqJSON, 'filial'))
        req['CPFMotorista'] = getJSON(reqJSON, 'mot_cpf')
        req['VinculoMotorista'] = get_vinculo(reqJSON, 'M')
        req['PlacaVeiculo'] = getJSON(reqJSON, 'veic_placa')
        req['VinculoVeiculo'] = get_vinculo(reqJSON, 'V')
        placaCar1 = getJSON(reqJSON, 'car1_placa')
        if placaCar1 != '':
            req['PlacaCarreta1'] = placaCar1
            req['VinculoCarreta1'] = get_vinculo(reqJSON, 'C1')
        placaCar2 = getJSON(reqJSON, 'car2_placa')
        if placaCar2 != '':
            req['PlacaCarreta2'] = placaCar2
            req['VinculoCarreta2'] = get_vinculo(reqJSON, 'C2')
        req['Expressa'] = getJSON(reqJSON, 'pesquisaexpressa')
        return json.dumps(req), ''
    except Exception as e:
        print('Erro em requestRasterGetResultadoPesquisaConsulta')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO', []


@_handle_exception
def response_raster_set_solicitacao_pesquisa_consulta_conjunto(resp):
    retcode = resp.status_code
    ret = resp.content.decode('utf-8')
    root = json.loads(ret)
    result = getJSON(root, 'result')
    msgFinalErro = ''
    codErro = 0
    for obj in result:
        codErro = getJSON(obj, 'CodErro')
        tipoMot = getJSON(obj, 'TipoResultadoMotorista')
        codigoMot = getJSON(obj, 'CodigoPesqMotorista')
        situacaoMot = getJSON(obj, 'SituacaoMotorista')
        tipoVeic = getJSON(obj, 'TipoResultadoVeiculo')
        codigoVeic = getJSON(obj, 'CodigoPesqVeiculo')
        situacaoVeic = getJSON(obj, 'SituacaoVeiculo')
        tipoCar1 = getJSON(obj, 'TipoResultadoCarreta1')
        codigoCar1 = getJSON(obj, 'CodigoPesqCarreta1')
        situacaoCar1 = getJSON(obj, 'SituacaoCarreta1')
        tipoCar2 = getJSON(obj, 'TipoResultadoCarreta2')
        codigoCar2 = getJSON(obj, 'CodigoPesqCarreta2')
        situacaoCar2 = getJSON(obj, 'SituacaoCarreta2')
        if codErro > 0:
            msgErro = getJSON(obj, 'MsgErro')
            msgFinalErro += '(' + str(codErro) + ') ' + msgErro
    if codErro == 0:
        msgFinalSucesso = 'Solicitação de análise realizada sucesso! Aguarde alguns instantes e utiliza a opção Consultar Análise'
        retornoFinal = '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msgFinalSucesso + '</msg>' + \
                       '<tipoMot>' + get_tipo_pesquisa(tipoMot) + '</tipoMot><codigoMot>' + numtostr(codigoMot,
                                                                                                     '0') + '</codigoMot><situacaoMot>' + get_situacao(
            situacaoMot) + '</situacaoMot>' + \
                       '<tipoVeic>' + get_tipo_pesquisa(tipoVeic) + '</tipoVeic><codigoVeic>' + numtostr(codigoVeic,
                                                                                                         '0') + '</codigoVeic><situacaoVeic>' + get_situacao(
            situacaoVeic) + '</situacaoVeic>' + \
                       '<tipoCar1>' + get_tipo_pesquisa(tipoCar1) + '</tipoCar1><codigoCar1>' + numtostr(codigoCar1,
                                                                                                         '0') + '</codigoCar1><situacaoCar1>' + get_situacao(
            situacaoCar1) + '</situacaoCar1>' + \
                       '<tipoCar2>' + get_tipo_pesquisa(tipoCar2) + '</tipoCar2><codigoCar2>' + numtostr(codigoCar2,
                                                                                                         '0') + '</codigoCar2><situacaoCar2>' + get_situacao(
            situacaoCar2) + '</situacaoCar2>' + \
                       '</resp>'
        return retornoFinal, ''
    else:
        return '', msgFinalErro


@_handle_exception
def request_raster_get_resultado_pesquisa_consulta_conjunto(reqJSON, properties):
    try:
        req = {}
        req['Ambiente'] = properties['Ambiente']
        req['Login'] = properties['Login']
        req['Senha'] = properties['Senha']
        req['TipoRetorno'] = 'JSON'
        req['CodFilial'] = int(getJSON(reqJSON, 'filial'))
        req['CPFMotorista'] = getJSON(reqJSON, 'mot_cpf')
        req['VinculoMotorista'] = get_vinculo(reqJSON, 'M')
        req['PlacaVeiculo'] = getJSON(reqJSON, 'veic_placa')
        req['VinculoVeiculo'] = get_vinculo(reqJSON, 'V')
        placaCar1 = getJSON(reqJSON, 'car1_placa')
        if placaCar1 != '':
            req['PlacaCarreta1'] = placaCar1
            req['VinculoCarreta1'] = get_vinculo(reqJSON, 'C1')
        placaCar2 = getJSON(reqJSON, 'car2_placa')
        if placaCar2 != '':
            req['PlacaCarreta2'] = placaCar2
            req['VinculoCarreta2'] = get_vinculo(reqJSON, 'C2')
        return json.dumps(req), ''
    except Exception as e:
        print('Erro em requestRasterGetResultadoPesquisaConsultaConjunto')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO', []


@_handle_exception
def response_raster_get_resultado_pesquisa_consulta_conjunto(resp):
    retcode = resp.status_code
    ret = resp.content.decode('utf-8')
    root = json.loads(ret)
    result = getJSON(root, 'result')
    msgFinalErro = ''
    codErro = 0
    for obj in result:
        codErro = getJSON(obj, 'CodErro')
        tipoMot = getJSON(obj, 'TipoResultadoMotorista')
        codigoMot = getJSON(obj, 'CodigoPesqMotorista')
        situacaoMot = getJSON(obj, 'SituacaoMotorista')
        dataExpiracaoMot = getJSON(obj, 'DataExpPesqMotorista')
        senhaMot = getJSON(obj, 'SenhaPesqMotorista')
        tipoVeic = getJSON(obj, 'TipoResultadoVeiculo')
        codigoVeic = getJSON(obj, 'CodigoPesqVeiculo')
        situacaoVeic = getJSON(obj, 'SituacaoVeiculo')
        dataExpiracaoVeic = getJSON(obj, 'DataExpPesqVeiculo')
        senhaVeic = getJSON(obj, 'SenhaPesqVeiculo')
        tipoCar1 = getJSON(obj, 'TipoResultadoCarreta1')
        codigoCar1 = getJSON(obj, 'CodigoPesqCarreta1')
        situacaoCar1 = getJSON(obj, 'SituacaoCarreta1')
        dataExpiracaoCar1 = getJSON(obj, 'DataExpPesqCarreta1')
        senhaCar1 = getJSON(obj, 'SenhaPesqCarreta1')
        tipoCar2 = getJSON(obj, 'TipoResultadoCarreta2')
        codigoCar2 = getJSON(obj, 'CodigoPesqCarreta2')
        situacaoCar2 = getJSON(obj, 'SituacaoCarreta2')
        dataExpiracaoCar2 = getJSON(obj, 'DataExpPesqCarreta2')
        senhaCar2 = getJSON(obj, 'SenhaPesqCarreta2')
        # justificativas = getJSON(obj, 'Justificativas')
        # justificativasStr = ''
        # for justificativa in justificativas:
        # justificativasStr += getJSON(justificativa, 'Codigo') + ' - ' + getJSON(justificativa, 'Descricao') + ' | '
        if codErro > 0:
            msgErro = getJSON(obj, 'MsgErro')
            msgFinalErro += '(' + str(codErro) + ') ' + msgErro
    if codErro == 0:
        msgFinalSucesso = 'Análise obtida.'
        retornoFinal = '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msgFinalSucesso + '</msg>' + \
                       '<tipoMot>' + get_tipo_pesquisa(tipoMot) + '</tipoMot><codigoMot>' + numtostr(codigoMot,
                                                                                                     '0') + '</codigoMot><situacaoMot>' + get_situacao(
            situacaoMot) + '</situacaoMot>' + \
                       '<dataExpiracaoMot>' + dataExpiracaoMot + '</dataExpiracaoMot><senhaMot>' + senhaMot + '</senhaMot>' + \
                       '<tipoVeic>' + get_tipo_pesquisa(tipoVeic) + '</tipoVeic><codigoVeic>' + numtostr(codigoVeic,
                                                                                                         '0') + '</codigoVeic><situacaoVeic>' + get_situacao(
            situacaoVeic) + '</situacaoVeic>' + \
                       '<dataExpiracaoVeic>' + dataExpiracaoVeic + '</dataExpiracaoVeic><senhaVeic>' + senhaVeic + '</senhaVeic>' + \
                       '<tipoCar1>' + get_tipo_pesquisa(tipoCar1) + '</tipoCar1><codigoCar1>' + numtostr(codigoCar1,
                                                                                                         '0') + '</codigoCar1><situacaoCar1>' + get_situacao(
            situacaoCar1) + '</situacaoCar1>' + \
                       '<dataExpiracaoCar1>' + dataExpiracaoCar1 + '</dataExpiracaoCar1><senhaCar1>' + senhaCar1 + '</senhaCar1>' + \
                       '<tipoCar2>' + get_tipo_pesquisa(tipoCar2) + '</tipoCar2><codigoCar2>' + numtostr(codigoCar2,
                                                                                                         '0') + '</codigoCar2><situacaoCar2>' + get_situacao(
            situacaoCar2) + '</situacaoCar2>' + \
                       '<dataExpiracaoCar2>' + dataExpiracaoCar2 + '</dataExpiracaoCar2><senhaCar2>' + senhaCar2 + '</senhaCar2>' + \
                       '</resp>'
        return retornoFinal, ''
    else:
        return '', msgFinalErro


def get_tipo_veic(tipo):
    if tipo in ['CAMINHÃO TRATOR', 'CAVALO', 'CAMINHAO TRATOR']:
        return 1
    elif tipo in ['CAMINHÃO', 'BITREM', 'CAMINHAO']:
        return 2
    elif tipo == 'MOTOCICLETA':
        return 4
    elif tipo == 'AUTOMÓVEL':
        return 5
    elif tipo == 'MICROÔNIBUS':
        return 6
    elif tipo == 'ÔNIBUS':
        return 7
    elif tipo == 'UTILITARIO':
        return 8
    elif tipo == 'CAMINHONETE':
        return 9
    elif tipo == 'CAMIONETA':
        return 10
    else:
        return 0


def get_tipo_carreta(tipo):
    if tipo == 'GRANELEIRO':
        return 1
    elif tipo == 'CARGA SECA':
        return 2
    elif tipo == 'TANQUE':
        return 3
    elif tipo == 'CANAVIEIRO':
        return 4
    elif tipo == 'BASCULANTE':
        return 5
    elif tipo == 'FURGAO' or tipo == 'BAU SECO' or tipo == 'FURGAO / BAU SECO':
        return 6
    elif tipo == 'SIDER PLANA':
        return 7
    elif tipo == 'SIDER REBAIXADA':
        return 8
    elif tipo == 'FRIGORIFICO':
        return 9
    elif tipo == 'FLORESTAL / FUEIRO' or tipo == 'FLORESTAL' or tipo == tipo == 'FUEIRO':
        return 10
    elif tipo == 'PORTA CONTAINER 20 PES':
        return 11
    elif tipo == 'PORTA CONTAINER 40 PES':
        return 12
    elif tipo == 'PRANCHA / PLATAFORMA' or tipo == 'PRANCHA' or tipo == 'PLATAFORMA':
        return 13
    elif tipo == 'SILO':
        return 14
    elif tipo == 'ASA DELTA':
        return 15
    elif tipo == 'CEGONHEIRA':
        return 16
    elif tipo == 'DOLLY':
        return 17
    elif tipo == 'ROLL-ON  ROLL-OFF ':
        return 25
    elif tipo == 'CARRETA REBAIXADA - (GRANELEIRA COM REBAIXE)':
        return 27
    elif tipo == 'CARRETA GRANELEIESPECIAL - (MEDIDAS DIFERENCIADAS)':
        return 28
    elif tipo == 'PRANCHA 03 EIXOS':
        return 29
    elif tipo == 'PRANCHA 04 EIXOS':
        return 30
    elif tipo == 'PRANCHA PESCOÇO REMOVIVEL':
        return 31
    elif tipo == 'CARRETA GRANALEIRA ESPECIAL (LARGA)':
        return 33
    elif tipo == 'CARRETA GRANELEIRA ESPECIAL (ABRE O PEITO)':
        return 34
    elif tipo == 'CARRETA REBAIXADA/ABRE O PEITO':
        return 35
    elif tipo == 'PRANCHA ESPECIAL - FRENTE REMOVIVIEL':
        return 36
    elif tipo == 'CARRETA GRANELEIRA ESPECIAL (VANDERLEIA)':
        return 37
    elif tipo == 'PRANCHA OMEGA':
        return 38
    elif tipo == 'PRANCHA COM ASA DELTA':
        return 39
    elif tipo == 'PRANCHA REBAIXADA':
        return 40
    elif tipo == 'PRANCHA 4 EIXOS (DOLLY)':
        return 42
    elif tipo == 'DOLLY RODOVIÁRIO 2 EIXOS':
        return 43
    else:  # INDEFINIDA
        return 0


def get_cod_marca(marca):
    switcher = {
        'INDEFINIDA': 0,
        'AGRALE': 1,
        'CHEVROLET': 2,
        'CICCOBUS': 3,
        'EFFA-JMC': 4,
        'FIAT': 5,
        'FORD': 6,
        'FOTON': 7,
        'HYUNDAI': 8,
        'IVECO': 9,
        'JAC': 10,
        'MAN': 11,
        'MARCOPOLO': 12,
        'MERCEDES-BENZ': 13,
        'NAVISTAR': 14,
        'NEOBUS': 15,
        'PUMA-ALFA': 16,
        'SAAB-SCANIA': 17,
        'SCANIA': 18,
        'SINOTRUK': 19,
        'VOLKSWAGEN': 20,
        'VOLVO': 21,
        'WALKBUS': 22,
        'RENAULT': 23,
        'KIA MOTORS': 24,
        'TOYOTA': 25,
        'HOVO': 59,
        'INTERNATIONAL': 61,
        'DAF': 64,
        'PEUGEOT': 65,
        'CITROEN': 71,
        'FNM': 75,
        'HONDA': 77,
        'GMC': 87,
        'SHACMAN': 88,
        'DIMEX': 92,
        'DODGE': 93,
        'FREIGHTLINER': 96,
        'GURGEL': 100,
        'SHAANXISMAN': 101,
        'KAMAZ': 102,
        'KENWVORTH': 103,
        'LIAZ': 104,
        'MACK': 105,
        'PEGASO': 108,
        'PETERBILT': 109,
        'SKODA': 111
    }
    return switcher.get(marca, 0)


def get_cod_cor(cor):
    switcher = {
        'INDEFINIDA': 0,
        'AMARELA': 1,
        'AZUL': 2,
        'BEGE': 3,
        'BRANCA': 4,
        'CINZA': 5,
        'DOURADA': 6,
        'GRENA': 7,
        'LARANJA': 8,
        'MARROM': 9,
        'PRATA': 10,
        'PRETA': 11,
        'ROSA': 12,
        'ROXA': 13,
        'VERDE': 14,
        'VERMELHA': 15,
        'FANTASIA': 16
    }
    return switcher.get(cor, 0)


def get_tipo_identificacao(tipo):
    switcher = {
        'V': 'V',  # veiculo principal
        'C1': 'C',  # carreta 1
        'C2': 'C',  # carreta 2
        'C3': 'C',  # carreta 3
        'M': 'P',  # motoritsa
    }
    return switcher.get(tipo)


def get_identificacao(reqJSON, tipo):
    switcher = {
        'V': getJSON(reqJSON, 'veic_placa'),  # veiculo principal
        'C1': getJSON(reqJSON, 'car1_placa'),  # carreta 1
        'C2': getJSON(reqJSON, 'car2_placa'),  # carreta 2
        'C3': getJSON(reqJSON, 'car3_placa'),  # carreta 3
        'M': getJSON(reqJSON, 'mot_cpf'),  # motoritsa
    }
    return switcher.get(tipo)


def get_vinculo(reqJSON, tipo):
    switcher = {
        'V': get_vinculo_raster(getJSON(reqJSON, 'veic_propriedade')),  # veiculo principal
        'C1': get_vinculo_raster(getJSON(reqJSON, 'car1_propriedade')),  # carreta 1
        'C2': get_vinculo_raster(getJSON(reqJSON, 'car2_propriedade')),  # carreta 2
        'C3': get_vinculo_raster(getJSON(reqJSON, 'car3_propriedade')),  # carreta 3
        'M': get_vinculo_raster(getJSON(reqJSON, 'veic_propriedade')),  # motoritsa
    }
    return switcher.get(tipo)


def get_vinculo_raster(tipo):
    # Próprio Produtivo - S
    # Próprio Apoio Frota - F
    # Próprio Apoio Frete - R
    # Próprio Oficina(Comércio) - O
    # Terceiros - N
    # Agregado - A
    # Agregado Misto - M
    # Agregado(ger.como terceiro)-G
    switcher = {
        'S': 'F',
        'F': 'F',
        'R': 'F',
        'O': 'F',
        'N': 'T',
        'A': 'A',
        'M': 'A',
        'G': 'A',
    }
    return switcher.get(tipo)


def get_situacao(tipo):
    switcher = {
        'EP': 'Em Pesquisa',
        'AP': 'Aguardando Pesquisa',
        'NA': 'Não Adequado ao Risco',
        'AD': 'Adequado ao Risco',
        'EX': 'Expirado',
        'AC': 'A Consultar',
        '': ''
    }
    return switcher.get(tipo)


def get_tipo_pesquisa(tipo):
    switcher = {
        'P': 'Pesquisa',
        'C': 'Consulta',
        '': '',
    }
    return switcher.get(tipo)


def get_codigo_pesquisa(reqJSON, tipo):
    switcher = {
        'V': getJSON(reqJSON, 'veic_codexterno'),  # veiculo principal
        'C1': getJSON(reqJSON, 'car1_codexterno'),  # carreta 1
        'C2': getJSON(reqJSON, 'car2_codexterno'),  # carreta 2
        'C3': getJSON(reqJSON, 'car3_codexterno'),  # carreta 3
        'M': getJSON(reqJSON, 'mot_codexterno'),  # motoritsa
    }
    return switcher.get(tipo)
