from geraljson import getJSON
from datetime import datetime
import geralxml
import xml.dom.minidom as mdom

ACAO_GRLOG_INICIO = 3250
ACAO_GRLOG_CADASTRARPROPRIETARIO = 3251
ACAO_GRLOG_CADASTRARMOTORISTA = 3252
ACAO_GRLOG_CADASTRARVEICULO = 3253
ACAO_GRLOG_CADASTRARCARRETA = 3254
ACAO_GRLOG_CADASTRARCARRETA2 = 3255
ACAO_GRLOG_CADASTRARCARRETA3 = 3256
ACAO_GRLOG_CONSULTARAPIDA = 3257
ACAO_GRLOG_PESQUISACONJUNTO = 3258
ACAO_GRLOG_CONSULTACONJUNTO = 3259
ACAO_GRLOG_GET_TIPO_CARROCERIA = 3260
ACAO_GRLOG_CADASTRARVEICULOCOMP = 3261
ACAO_GLOG_FIM = 3299

def requestGrLogCadastrarMotorista(reqJSON, reqProps):
    reqXML = \
        '<urn:InserirMotorista soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">' +\
            '<oMotoristaInsert xsi:type="urn:MotoristaInsert" xmlns:urn="urn:IntegraViagensIntf">' + \
                geralxml.createtag2('CodigoCliente', ' xsi:type="xsd:int"',
                                    getJSON(reqProps, 'empcom_campoaux1') or getJSON(reqJSON, 'empcom_campoaux1')) + \
                geralxml.createtag2('Nome', ' xsi:type="xsd:string"', getJSON(reqJSON, 'mot_nome')) + \
                geralxml.createtag2('CPF', ' xsi:type="xsd:string"', getJSON(reqJSON, 'mot_cpf')) + \
                geralxml.createtag2('RG', ' xsi:type="xsd:string"', getJSON(reqJSON, 'mot_rg')) + \
                geralxml.createtag2('ExpedicaoRG', ' xsi:type="xsd:string"', normaliseStringDateFormat(
                    getJSON(reqJSON, 'mot_datarg')
                )) + \
                geralxml.createtag2('NomeMae', ' xsi:type="xsd:string"', getJSON(reqJSON, 'mot_nomemae')) + \
                geralxml.createtag2('NomePai', ' xsi:type="xsd:string"', getJSON(reqJSON, 'mot_nomepai')) + \
                geralxml.createtag2('DataNascimento', ' xsi:type="xsd:dateTime"', getJSON(reqJSON, 'mot_datanasc')) + \
                geralxml.createtag2('CNH', ' xsi:type="xsd:string"', getJSON(reqJSON, 'mot_cnh')) + \
                geralxml.createtag2('DataVencimentoCNH', ' xsi:type="xsd:dateTime"', normaliseStringDateFormat(
                    getJSON(reqJSON, 'mot_datavalidcnh')
                )) + \
                geralxml.createtag2('DataPrimeiraCNH', ' xsi:type="xsd:dateTime"', normaliseStringDateFormat(
                    getJSON(reqJSON, 'mot_dataprimcnh')
                )) + \
                geralxml.createtag2('CategoriaCNH', ' xsi:type="xsd:string"', getJSON(reqJSON, 'mot_catcnh')) + \
                geralxml.createtag2('UFRG', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('UFCNH', ' xsi:type="xsd:string"', getJSON(reqJSON, 'mot_ufcnh')) + \
                geralxml.createtag2('AdicionarPesquisa', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('DataValidadePesquisa', ' xsi:type="xsd:string"', normaliseStringDateFormat(
                    getJSON(reqJSON, 'mot_datavalidadepesquisa')
                ) or datetime.today().strftime('%Y-%m-%d')) + \
                geralxml.createtag2('SenhaPesquisa', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('CNPJ', ' xsi:type="xsd:string"',
                                    getJSON(reqProps, 'emp_cnpjtransp') or getJSON(reqJSON, 'emp_cnpjtransp')) + \
                geralxml.createtag2('Telefone', ' xsi:type="xsd:string"', getJSON(reqJSON, 'mot_foneddd') + getJSON(reqJSON, 'mot_fonenumero')) + \
                geralxml.createtag2('Celular', ' xsi:type="xsd:string"', getJSON(reqJSON, 'mot_celularddd') + getJSON(reqJSON, 'mot_celularnumero')) + \
                geralxml.createtag2('Validacao', ' xsi:type="xsd:string"',
                                    getJSON(reqProps, 'empcom_senha') or getJSON(reqJSON, 'empcom_senha')) + \
                geralxml.createtag2('EnderecoCodigoIBGECidade', ' xsi:type="xsd:int"', getJSON(reqJSON, 'mot_codibge')) + \
                geralxml.createtag2('EnderecoNumero', ' xsi:type="xsd:string"', getJSON(reqJSON, 'mot_numero')) + \
                geralxml.createtag2('EnderecoLogradouro', ' xsi:type="xsd:string"', getJSON(reqJSON, 'mot_endereco')) + \
                geralxml.createtag2('EnderecoComplemento', ' xsi:type="xsd:string"', getJSON(reqJSON, 'mot_complemento')) + \
                geralxml.createtag2('EnderecoBairro', ' xsi:type="xsd:string"', getJSON(reqJSON, 'mot_bairro')) + \
                geralxml.createtag2('EnderecoCep', ' xsi:type="xsd:string"', getJSON(reqJSON, 'mot_cep')) + \
                geralxml.createtag2('NumeroRegistroCNH', ' xsi:type="xsd:string"', getJSON(reqJSON, 'mot_cnh')) + \
                geralxml.createtag2('NumeroSegurancaCNH', ' xsi:type="xsd:string"', getJSON(reqJSON, 'mot_numsegcnh')) + \
                geralxml.createtag2('UsuarioFilial', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('UFNascimento', ' xsi:type="xsd:string"', getJSON(reqJSON, 'mot_ufnasc')) + \
                geralxml.createtag2('Perfil', ' xsi:type="xsd:int"', '0') + \
                geralxml.createtag2('UrlFotoMotorista', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('UrlFotoCNH', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('TipoRef1', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('ReferenciaRef1', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('TelefoneRef1', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('DataRef1', ' xsi:type="xsd:dateTime"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('ObservacaoRef1', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('TipoRef2', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('ReferenciaRef2', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('TelefoneRef2', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('DataRef2', ' xsi:type="xsd:dateTime"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('ObservacaoRef2', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('TipoRef3', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('ReferenciaRef3', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('TelefoneRef3', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('DataRef3', ' xsi:type="xsd:dateTime"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('ObservacaoRef3', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('TipoRef4', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('ReferenciaRef4', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('TelefoneRef4', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('DataRef4', ' xsi:type="xsd:dateTime"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('ObservacaoRef4', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('TipoRef5', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('ReferenciaRef5', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('TelefoneRef5', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('DataRef5', ' xsi:type="xsd:dateTime"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('ObservacaoRef5', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('TipoRef6', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('ReferenciaRef6', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('TelefoneRef6', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('DataRef6', ' xsi:type="xsd:dateTime"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('ObservacaoRef6', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('TipoRef7', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('ReferenciaRef7', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('TelefoneRef7', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('DataRef7', ' xsi:type="xsd:dateTime"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('ObservacaoRef7', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
            '</oMotoristaInsert>' \
        '</urn:InserirMotorista>'
    reqXML = requestGrLogXmlEnvio(reqXML)
    return reqXML, ''

def requestGrLogCadastrarVeiculo(reqJSON, reqProps):
    reqXML = \
        '<urn:InserirVeiculo soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">' \
        '<oVeiculoInsert xmlns:urn="urn:IntegraViagensIntf" xsi:type="urn:VeiculoInsert">' + \
        geralxml.createtag2('CodigoCliente', ' xsi:type="xsd:int"',
                            getJSON(reqProps, 'empcom_campoaux1') or getJSON(reqJSON, 'empcom_campoaux1')) + \
        geralxml.createtag2('Placa', ' xsi:type="xsd:string"', getJSON(reqJSON, 'veic_placa')) + \
        geralxml.createtag2('Id', ' xsi:type="xsd:int"', '0') + \
        geralxml.createtag2('Tecnologia', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        geralxml.createtag2('Chassi', ' xsi:type="xsd:string"', getJSON(reqJSON, 'veic_chassi')) + \
        geralxml.createtag2('Renavan', ' xsi:type="xsd:string"', getJSON(reqJSON, 'veic_renavam')) + \
        geralxml.createtag2('CodigoIBGE', ' xsi:type="xsd:string"', getJSON(reqJSON, 'veic_codibge')) + \
        geralxml.createtag2('TipoVeiculo', ' xsi:type="xsd:string"', tipoVeicCavalo(reqJSON)) + \
        geralxml.createtag2('AdicionarPesquisa', ' xsi:type="xsd:string"', '1') + \
        geralxml.createtag2('SenhaPesquisa', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        geralxml.createtag2('CNPJ', ' xsi:type="xsd:string"',
                            getJSON(reqProps, 'emp_cnpjtransp') or getJSON(reqJSON, 'emp_cnpjtransp')) + \
        geralxml.createtag2('Validacao', ' xsi:type="xsd:string"',
                            getJSON(reqProps, 'empcom_senha') or getJSON(reqJSON, 'empcom_senha'))
    if len(getJSON(reqJSON, 'prop_cnpjcpf')) == 11:
        reqXML += \
            geralxml.createtag2('TipoProprietario', ' xsi:type="xsd:int"', '2')
    else:
        reqXML += \
            geralxml.createtag2('TipoProprietario', ' xsi:type="xsd:int"', '1')
    if len(getJSON(reqJSON, 'prop_cnpjcpf')) == 11:
        reqXML += \
            geralxml.createtag2('CPFProprietarioPF', ' xsi:type="xsd:string"', getJSON(reqJSON, 'prop_cnpjcpf')) + \
            geralxml.createtag2('NomeProprietarioPF', ' xsi:type="xsd:string"', getJSON(reqJSON, 'prop_nome')) + \
            geralxml.createtag2('NomeMaePF', ' xsi:type="xsd:string"', getJSON(reqJSON, 'prop_nomemae'))
    else:
        reqXML += \
            geralxml.createtag2('CPFProprietarioPF', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
            geralxml.createtag2('NomeProprietarioPF', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
            geralxml.createtag2('NomeMaePF', ' xsi:type="xsd:string"', getJSON(reqJSON, ''))
    reqXML += \
        geralxml.createtag2('UsuarioFilial', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        geralxml.createtag2('Modelo', ' xsi:type="xsd:string"', getJSON(reqJSON, 'veic_modelo')) + \
        geralxml.createtag2('Marca', ' xsi:type="xsd:string"', getJSON(reqJSON, 'veic_marca')) + \
        geralxml.createtag2('Cor', ' xsi:type="xsd:string"', getJSON(reqJSON, 'veic_cor')) + \
        geralxml.createtag2('AnoFabricacao', ' xsi:type="xsd:int"', getJSON(reqJSON, 'veic_anofab')) + \
        geralxml.createtag2('AnoModelo', ' xsi:type="xsd:int"', getJSON(reqJSON, 'veic_anomod'))
    if len(getJSON(reqJSON, 'prop_cnpjcpf')) == 14:
        reqXML += \
            geralxml.createtag2('CNPJProprietarioPJ', ' xsi:type="xsd:string"', getJSON(reqJSON, 'prop_cnpjcpf')) + \
            geralxml.createtag2('NomeProprietarioPJ', ' xsi:type="xsd:string"', getJSON(reqJSON, 'prop_nome'))
    else:
        reqXML += \
            geralxml.createtag2('CNPJProprietarioPJ', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
            geralxml.createtag2('NomeProprietarioPJ', ' xsi:type="xsd:string"', getJSON(reqJSON, ''))
    reqXML += \
        geralxml.createtag2('UrlFotoVeiculo', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        geralxml.createtag2('UrlFotoCRV', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        geralxml.createtag2('UrlFotoCRLV', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        geralxml.createtag2('UrlFotoANTT', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        geralxml.createtag2('Dispositivo', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        geralxml.createtag2('NomePosse', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        geralxml.createtag2('CpfCnpjPosse', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        geralxml.createtag2('NumeroContrato', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        geralxml.createtag2('Ativo', ' xsi:type="xsd:string"', '1') + \
        '</oVeiculoInsert>' + \
        '</urn:InserirVeiculo>'
    reqXML = requestGrLogXmlEnvio(reqXML)
    return reqXML, ''






def requestGrLogCadastrarCarreta(reqJSON, reqProps, codEMonitorAcao):
    if codEMonitorAcao == ACAO_GRLOG_CADASTRARCARRETA:
        prefixTag = 'car1_'
    elif codEMonitorAcao == ACAO_GRLOG_CADASTRARCARRETA2:
        prefixTag = 'car2_'
    elif codEMonitorAcao == ACAO_GRLOG_CADASTRARCARRETA3:
        prefixTag = 'car3_'

    codigotipocarroceria = getJSON(reqJSON, prefixTag + 'codigotipocarroceria');
    if codigotipocarroceria == '':
        codigotipocarroceria = tipoCarretaCod(getJSON(reqJSON, prefixTag + 'tipocarroceria'));

    reqXML = \
        '<urn:InserirCarreta soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">' \
            '<oCarretaInsert xmlns:urn="urn:IntegraViagensIntf" xsi:type="urn:CarretaInsert">' + \
                geralxml.createtag2('CodigoCliente', ' xsi:type="xsd:string"',
                                    getJSON(reqProps, 'empcom_campoaux1') or getJSON(reqJSON, 'empcom_campoaux1')) + \
                geralxml.createtag2('Placa', ' xsi:type="xsd:string"', getJSON(reqJSON, prefixTag + 'placa')) + \
                geralxml.createtag2('Id', ' xsi:type="xsd:int"', '0') + \
                geralxml.createtag2('Chassi', ' xsi:type="xsd:string"', getJSON(reqJSON, prefixTag + 'chassi')) + \
                geralxml.createtag2('Renavan', ' xsi:type="xsd:string"', getJSON(reqJSON, prefixTag + 'renavam')) + \
                geralxml.createtag2('CodigoIBGE', ' xsi:type="xsd:int"', getJSON(reqJSON, prefixTag + 'codibge')) + \
                geralxml.createtag2('NumeroANTT', ' xsi:type="xsd:string"', getJSON(reqJSON, prefixTag + 'rntrc')) + \
                geralxml.createtag2('CodigoTipoCarroceria', ' xsi:type="xsd:int"', codigotipocarroceria) + \
                geralxml.createtag2('AdicionarPesquisa', ' xsi:type="xsd:string"', '1') + \
                geralxml.createtag2('DataValidadePesquisa', ' xsi:type="xsd:string"', normaliseStringDateFormat(
                    getJSON(reqJSON, prefixTag + 'datavalidadepesquisa')
                ) or datetime.today().strftime('%Y-%m-%d')) + \
                geralxml.createtag2('SenhaPesquisa', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
                geralxml.createtag2('CNPJ', ' xsi:type="xsd:string"',
                                    getJSON(reqProps, 'emp_cnpjtransp') or getJSON(reqJSON, 'emp_cnpjtransp')) + \
                geralxml.createtag2('Validacao', ' xsi:type="xsd:string"',
                                    getJSON(reqProps, 'empcom_senha') or getJSON(reqJSON, 'empcom_senha'))
    if len(getJSON(reqJSON, 'prop_cnpjcpf')) == 11:
        reqXML += \
            geralxml.createtag2('TipoProprietario', ' xsi:type="xsd:int"', '2') + \
            geralxml.createtag2('CPFProprietarioPF', ' xsi:type="xsd:string"', getJSON(reqJSON, 'prop_cnpjcpf')) + \
            geralxml.createtag2('NomeProprietarioPF', ' xsi:type="xsd:string"', getJSON(reqJSON, 'prop_nome')) + \
            geralxml.createtag2('NomeMaePF', ' xsi:type="xsd:string"', getJSON(reqJSON, 'prop_nomemae'))
    else:
        reqXML += \
            geralxml.createtag2('TipoProprietario', ' xsi:type="xsd:int"', '1') + \
            geralxml.createtag2('CPFProprietarioPF', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
            geralxml.createtag2('NomeProprietarioPF', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
            geralxml.createtag2('NomeMaePF', ' xsi:type="xsd:string"', getJSON(reqJSON, ''))
    reqXML += \
        geralxml.createtag2('UsuarioFilial', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        geralxml.createtag2('Marca', ' xsi:type="xsd:string"', getJSON(reqJSON, prefixTag + 'marca')) + \
        geralxml.createtag2('Cor', ' xsi:type="xsd:string"', getJSON(reqJSON, prefixTag + 'cor')) + \
        geralxml.createtag2('AnoFabricacao', ' xsi:type="xsd:int"', getJSON(reqJSON, prefixTag + 'anofab')) + \
        geralxml.createtag2('AnoModelo', ' xsi:type="xsd:int"', getJSON(reqJSON, prefixTag + 'anomod')) + \
        geralxml.createtag2('TipoCarroceria', ' xsi:type="xsd:string"', tipoCarretaDesc(getJSON(reqJSON, prefixTag + 'tipocarroceria')))
    if len(getJSON(reqJSON, 'prop_cnpjcpf')) == 14:
        reqXML += \
            geralxml.createtag2('CNPJProprietarioPJ', ' xsi:type="xsd:string"', getJSON(reqJSON, 'prop_cnpjcpf')) + \
            geralxml.createtag2('NomeProprietarioPJ', ' xsi:type="xsd:string"', getJSON(reqJSON, 'prop_nome'))
    else:
        reqXML += \
            geralxml.createtag2('CNPJProprietarioPJ', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
            geralxml.createtag2('NomeProprietarioPJ', ' xsi:type="xsd:string"', getJSON(reqJSON, ''))
    reqXML += \
        geralxml.createtag2('UrlFotoCarreta', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        geralxml.createtag2('UrlFotoCRV', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        geralxml.createtag2('UrlFotoCRLV', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        geralxml.createtag2('UrlFotoANTT', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        geralxml.createtag2('Dispositivo', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        geralxml.createtag2('NomePosse', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        geralxml.createtag2('CpfCnpjPosse', ' xsi:type="xsd:string"', getJSON(reqJSON, '')) + \
        '</oCarretaInsert>' + \
        '</urn:InserirCarreta>'
    reqXML = requestGrLogXmlEnvio(reqXML)
    return reqXML, ''

def requestGrLogConsultaRapida(reqJSON, reqProps):
    reqXML = \
        '<urn:ConsultaRapida soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">'\
            '<parameters xmlns:urn="urn:IntegraViagensIntf" xsi:type="urn:PesquisaRapida">' + \
                geralxml.createtag2('CNPJCliente', ' xsi:type="xsd:string"',
                                    getJSON(reqProps, 'emp_cnpjtransp') or getJSON(reqJSON, 'emp_cnpjtransp')) + \
                geralxml.createtag2('Liberacao', ' xsi:type="xsd:string"',
                                    getJSON(reqProps, 'empcom_senha') or getJSON(reqJSON, 'empcom_senha')) + \
                geralxml.createtag2('PlacaVeiculo', ' xsi:type="xsd:string"',  getJSON(reqJSON, 'veic_placa')) + \
                geralxml.createtag2('PlacaCarreta1', ' xsi:type="xsd:string"',  getJSON(reqJSON, 'car1_placa')) + \
                geralxml.createtag2('PlacaCarreta2', ' xsi:type="xsd:string"',  getJSON(reqJSON, 'car2_placa')) + \
                geralxml.createtag2('PlacaCarreta3', ' xsi:type="xsd:string"',  getJSON(reqJSON, 'car3_placa')) + \
                geralxml.createtag2('CPFMotorista1', ' xsi:type="xsd:string"',  getJSON(reqJSON, 'mot_cpf')) + \
                '<CPFMotorista2 xsi:type="xsd:string"/>' + \
                geralxml.createtag2('Produto', ' xsi:type="xsd:string"',  getJSON(reqJSON, 'merc_desc')) + \
        '</parameters>' + \
         '</urn:ConsultaRapida>'
    reqXML = requestGrLogXmlEnvio(reqXML)
    return reqXML, ''

def requestGrLogPesquisaConjunto(reqJSON, reqProps):
    reqXML = \
        '<urn:PesquisaConjunto soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">'\
            '<parameters xmlns:urn="urn:IntegraViagensIntf" xsi:type="urn:PesquisaConjunto">' + \
                geralxml.createtag2('CNPJCliente', ' xsi:type="xsd:string"',
                                    getJSON(reqProps, 'emp_cnpjtransp') or getJSON(reqJSON, 'emp_cnpjtransp')) + \
                geralxml.createtag2('Liberacao', ' xsi:type="xsd:string"',
                                    getJSON(reqProps, 'empcom_senha') or getJSON(reqJSON, 'empcom_senha')) + \
                geralxml.createtag2('PlacaVeiculo', ' xsi:type="xsd:string"',  getJSON(reqJSON, 'veic_placa')) + \
                geralxml.createtag2('PlacaCarreta1', ' xsi:type="xsd:string"',  getJSON(reqJSON, 'car1_placa')) + \
                geralxml.createtag2('PlacaCarreta2', ' xsi:type="xsd:string"',  getJSON(reqJSON, 'car2_placa')) + \
                geralxml.createtag2('PlacaCarreta3', ' xsi:type="xsd:string"',  getJSON(reqJSON, 'car3_placa')) + \
                geralxml.createtag2('CPFMotorista1', ' xsi:type="xsd:string"',  getJSON(reqJSON, 'mot_cpf')) + \
                geralxml.createtag2('Produto', ' xsi:type="xsd:string"',  getJSON(reqJSON, 'merc_desc')) + \
                geralxml.createtag2('ValorCarga', ' xsi:type="xsd:double"', getJSON(reqJSON, 'veic_valorcarga')) + \
                '<UsuarioFilial xsi:type="xsd:string"/>' + \
        '</parameters>' + \
         '</urn:PesquisaConjunto>'
    reqXML = requestGrLogXmlEnvio(reqXML)
    return reqXML, ''


def requestGrLogConsultaConjunto(reqJSON, reqProps):
    reqXML = \
        '<urn:ConsultaConjunto soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">'\
            '<parameters xmlns:urn="urn:IntegraViagensIntf" xsi:type="urn:ConsultaConjunto">' + \
        geralxml.createtag2('CNPJCliente', ' xsi:type="xsd:string"',
                            getJSON(reqProps, 'emp_cnpjtransp') or getJSON(reqJSON, 'emp_cnpjtransp')) + \
        geralxml.createtag2('Liberacao', ' xsi:type="xsd:string"',
                            getJSON(reqProps, 'empcom_senha') or getJSON(reqJSON, 'empcom_senha')) + \
        geralxml.createtag2('CodigoConjunto', ' xsi:type="xsd:int"',  getJSON(reqJSON, 'veic_codconjunto')) + \
        '</parameters>' + \
         '</urn:ConsultaConjunto>'
    reqXML = requestGrLogXmlEnvio(reqXML)
    return reqXML, ''

def requestGrLogGetTipoCarroceria():
    reqXML = \
        '<urn:GetTipoCarrocerias soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"/>'
    reqXML = requestGrLogXmlEnvio(reqXML)
    return reqXML, ''

def requestGrLogXmlEnvio(reqXMLConteudo):
    reqXML = \
        '<?xml version="1.0" encoding="UTF-8"?>' \
        '<soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ' \
        'xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" ' \
        'xmlns:urn="urn:IntegraViagensIntf-IIntegraViagens">' \
        '<soapenv:Header/>' \
            '<soapenv:Body>' \
                + reqXMLConteudo + \
            '</soapenv:Body>' \
        '</soapenv:Envelope>'
    return reqXML

def tipoVeicCavalo(reqJSON):
    # <!--  1-Cavalo Mecanico 2-Truck 3-Furgão 4-3/4 5-Toco 6-Container 7-Bitren 8-Sider 9-Basculante 10-Caminhonete 11-Prancha 12-Tanque 13-Bitruck 14-carro 15-moto    -->
    tipo = getJSON(reqJSON, 'veic_tipoveic')
    cavalo = getJSON(reqJSON, 'veic_cavalo')
    if 'CAVALO' in tipo or cavalo == 'S':
        return '1'
    elif 'FURG' in tipo:#FURGÃO
        return '3'
    elif '3/4' in tipo:
        return '4'
    elif 'TOCO' in tipo:
        return '5'
    elif 'CONTAI' in tipo: #CONTAINER
        return '6'
    elif 'BITRE' in tipo:#BITREN
        return '7'
    elif 'SIDER' in tipo:
        return '8'
    elif 'BASCU' in tipo:#BASCULANTE
        return '9'
    elif 'CAMIN' in tipo: #CAMINHONETE
        return '10'
    elif 'PRANC' in tipo:#PRANCHA
        return '11'
    elif 'TANQUE' in tipo:
        return '12'
    elif 'BITRU' in tipo: #BITRUCK
        return '13'
    elif 'TRU' in tipo:#TRUCK
        return '2'
    elif 'CARRO' in tipo:
        return '14'
    elif 'MOTO' in tipo:
        return '15'
    return '1'

def tipoCarretaDesc(tipo):
    # 1-basculante 2-bau seco 3-camara fria 4-container 5-graneleira 6-prancha 7-rodotrem 8-cegonha 9-sider 10-tanque 11-carga seca 12-car aberta 13-reb 26 14-sr/26  15-sao pedro
    codigo = tipoCarretaCod(tipo)
    if codigo == '1':
        return 'basculante'
    elif codigo == '2':
        return 'bau seco'
    elif codigo == '3':
        return 'camara fria'
    elif codigo == '4':
        return 'container'
    elif codigo == '5':
        return 'graneleira'
    elif codigo == '6':
        return 'prancha'
    elif codigo == '7':
        return 'rodotrem'
    elif codigo == '8':
        return 'cegonha'
    elif codigo == '9':
        return 'sider'
    elif codigo == '10':
        return 'tanque'
    elif codigo == '11':
        return 'carga seca'
    elif codigo == '12':
        return 'car aberta'
    elif codigo == '13':
        return 'reb 26'
    elif codigo == '14':
        return 'sr/26'
    elif codigo == '15':
        return 'sao pedro'
    return ''

def tipoCarretaCod(tipo):
    #1-basculante 2-bau seco 3-camara fria 4-container 5-graneleira 6-prancha 7-rodotrem 8-cegonha 9-sider 10-tanque 11-carga seca 12-car aberta 13-reb 26 14-sr/26  15-sao pedro
    if 'BASC' in tipo:#BASCULANTE
        return '1'
    elif 'BAU' or 'BAÚ' in tipo:
        return '2'
    elif 'CAMA' in tipo:#CAMARA
        return '3'
    elif 'CONTAI' in tipo:#CONTAINER
        return '4'
    elif 'GRANE' in tipo:#GRANELEIRA
        return '5'
    elif 'PRAN' in tipo:#PRANCHA
        return '6'
    elif 'RODO' in tipo:#RODOTREM
        return '7'
    elif 'CEGONHA' in tipo:
        return '8'
    elif 'SIDER' in tipo:
        return '9'
    elif 'TANQUE' in tipo:
        return '10'
    elif 'SECA' in tipo:#CARGA SECA
        return '11'
    elif 'ABERTA' in tipo:#CAR ABERTA
        return '12'
    elif 'REB' in tipo:#REB26
        return '13'
    elif 'SR/26' in tipo:
        return '14'
    elif 'PEDRO' in tipo:#SAO PEDRO
        return '15'
    return ''

def tipoCar(tipo):
    return ''

def responseGrLogCadastrarMotorista(ret):
    return responseGrLogGeral(ret, ACAO_GRLOG_CADASTRARMOTORISTA)

def responseGrLogCadastrarVeiculo(ret):
    return responseGrLogGeral(ret, ACAO_GRLOG_CADASTRARVEICULO)

def responseGrLogConsultaRapida(ret):
    return responseGrLogGeral(ret, ACAO_GRLOG_CONSULTARAPIDA)

def responseGrLogPesquisaConjunto(ret):
    return responseGrLogGeral(ret, ACAO_GRLOG_PESQUISACONJUNTO)

def responseGrLogConsultaConjunto(ret):
    return responseGrLogGeral(ret, ACAO_GRLOG_CONSULTACONJUNTO)

def responseGrLogCadastrarCarreta(ret, acao):
    return responseGrLogGeral(ret, acao)

def responseGrLogGetTipoCarroceria(ret):
    try:
        document = mdom.parseString(ret)
        faultstring = document.getElementsByTagName('faultstring')
        if faultstring:
            raise ValueError
        tagTipoCarroceria = document.getElementsByTagName("TipoCarroceria")
        ret = ''
        for tag in tagTipoCarroceria:
            if tag.childNodes:
                codigo = tag.getElementsByTagName("CodigoTipoCarroceria")[0]
                nome = tag.getElementsByTagName("Nome")[0]
                ret += \
                    '<tipoCarroceria>' + \
                        geralxml.createtag('codigo', geralxml.getText(codigo.childNodes)) + \
                        geralxml.createtag('nome', geralxml.getText(nome.childNodes)) + \
                    '</tipoCarroceria>'
        return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + 'CONSULTA REALIZADA COM SUCESSO' + '</msg> ' + ret + ' </resp>', ''
    except Exception as e:
        print('Erro em responseGrLogGetTipoCarroceria')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA GERENCIADORA DE RISCO'

def responseGrLogGeral(ret, acao):
    try:
        document = mdom.parseString(ret)
        faultstring = document.getElementsByTagName('faultstring')
        if faultstring:
            raise ValueError
        tagret = document.getElementsByTagName('return')
        codigo = geralxml.findChildNodeByName(tagret, 'Codigo')
        descricao = geralxml.findChildNodeByName(tagret, 'Descricao')
        msg = ''
        if codigo == '-1':
            return responseGrLogGeralErro(tagret)
        else:
            if acao == ACAO_GRLOG_CADASTRARMOTORISTA or \
               acao == ACAO_GRLOG_CADASTRARVEICULO or \
               acao == ACAO_GRLOG_CADASTRARCARRETA or \
               acao == ACAO_GRLOG_CADASTRARCARRETA2 or \
               acao == ACAO_GRLOG_CADASTRARCARRETA3:
                    msg = 'CADASTRO REALIZADO COM SUCESSO'
            elif acao == ACAO_GRLOG_CONSULTARAPIDA or \
                 acao == ACAO_GRLOG_CONSULTACONJUNTO:
                msg = 'SITUAÇÃO: ' + descricao
                mensagemValidacao = geralxml.findChildNodeByName(tagret, 'MensagemValidacao')
                if mensagemValidacao is not None:
                    msg = msg + ' - ' + mensagemValidacao
                mensagemValidacaoManual = geralxml.findChildNodeByName(tagret, 'MensagemValidacaoManual')
                if mensagemValidacaoManual is not None:
                    msg = msg + ' - ' + mensagemValidacaoManual
                if len(msg) > 200:
                    msg = msg[0:200]
            elif acao == ACAO_GRLOG_PESQUISACONJUNTO:
                msg = codigo
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msg + '</msg></resp>', ''
    except Exception as e:
        print('Erro em responseGrLogGeral')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA GERENCIADORA DE RISCO'


def responseGrLogGeralErro(tag):
    descricao = geralxml.findChildNodeByName(tag, 'Descricao')
    motivo = geralxml.findChildNodeByName(tag, 'Motivo')
    modulo = geralxml.findChildNodeByName(tag, 'Modulo')
    msg = 'Descrição do erro: ' + descricao
    if motivo:
        msg += ' - Motivo: ' + motivo
    if modulo:
        msg += ' - Módulo: ' + modulo

    return '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><msg>' + msg + '</msg></resp>', ''

def normaliseStringDateFormat(dateString):
    try:
        return datetime \
            .strptime(dateString, '%d/%m/%Y') \
            .strftime('%Y-%m-%d')
    except:
        return dateString






