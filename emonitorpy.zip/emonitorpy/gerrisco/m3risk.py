import base64
import json
import logging
from string import Template
from typing import Tuple

from numpy.core.defchararray import upper
from requests import Response
from scipy.stats import moment

from ActionProcessor import ActionProcessor, parse_props, HttpMethod, handle_exception_factory
from GetJson import GetJson
from geral import *
from geralxml import mount_xml_response


class M3riskException(Exception):
    pass


# Classe base
class M3risk(ActionProcessor):
    # INSTANCIAS
    BASE_URL = 'http://sandbox.m3risk.com.br/api/v2'
    BASE_URL_TEST = 'http://sandbox.m3risk.com.br/api/v2'

    ADD_VEHICLES = 3400
    ADD_CARTS1 = 3401
    ADD_DRIVERS = 3402
    REQUEST_SEARCH_VEHICLES = 3403
    REQUEST_SEARCH_CARTS = 3404
    REQUEST_SEARCH_DRIVERS = 3405
    LIST_ROUTES = 3406
    CANCEL_SM = 3407
    ADD_SM = 3408
    ADD_CARTS2 = 3409
    def __init__(self):
        self.add_callable_records('url', {
            self.ADD_VEHICLES: (_make_url, _make_defaults('/vehicles/addvehicle')),
            self.ADD_CARTS1: (_make_url, _make_defaults('/carts/addcart')),
            self.ADD_DRIVERS: (_make_url, _make_defaults('/drivers/adddriver')),
            self.REQUEST_SEARCH_VEHICLES: (_make_url, _make_defaults('/vehicles/search/$placa', HttpMethod.GET, True)),
            self.REQUEST_SEARCH_CARTS: (_make_url, _make_defaults('/carts/search/$placa', HttpMethod.GET, True)),
            self.REQUEST_SEARCH_DRIVERS: (_make_url, _make_defaults('/drivers/search/$cpf', HttpMethod.GET, True)),
            self.LIST_ROUTES: (_make_url, _make_defaults('/routes/listroutes', HttpMethod.GET, True)),
            self.CANCEL_SM: (_make_url, _make_defaults('/sms/cancelsm')),
            self.ADD_SM: (_make_url, _make_defaults('/sms/addsm')),
            self.ADD_CARTS2: (_make_url, _make_defaults('/carts/addcart')),
        })

        super().__init__()

    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        props = context_req.get('props')
        user = props.get('usuario')
        password = props.get('senha')
        token = props.get('token')

        return {
                'Content-type': 'application/json',
                'x-api-key': token,
                'Authorization': user+password,
               }, ''

#
#   Códigos independentes de instancia
#
def _m3risk_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a M3Risk:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    M3riskException,
    _m3risk_exception_callback,
    any_exception_callback
)

# Funções para obtenção de URLs
@_handle_exception
def _make_defaults(path: str, method: HttpMethod = HttpMethod.POST, use_template: bool = None) -> dict:
    return {
        'path': path,
        **conditional_key('method', method),
        **conditional_key('use_template', use_template)
    }

@_handle_exception
def _make_url(path: str, method: HttpMethod = HttpMethod.GET, use_template: bool = False,
              req: dict = None, url: str = '', props: dict = None) -> Tuple[str, str]:
    if props is None:
        props = {}

    ambiente = 0
    try:
        ambiente = int(props.get('ws_ambiente'))
    except (Exception,):
        pass

    base = url.strip().rstrip('/') or (M3risk.BASE_URL if ambiente == 1 else M3risk.BASE_URL_TEST)
    if use_template:
        t = Template(path)
        url = base + t.substitute(req)
    else:
        url = base + path

    return url, method.name

@_handle_exception
def _make_defaults(path: str, method: HttpMethod = HttpMethod.POST, use_template: bool = None) -> dict:
    return {
        'path': path,
        **conditional_key('method', method),
        **conditional_key('use_template', use_template)
    }

#
#   Instancia limpa e sem configuração
#
_m3risk = M3risk()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = _m3risk.link_to_factory('request')
_link_to_response = _m3risk.link_to_factory('response')

@_link_to_request(_m3risk.ADD_VEHICLES)
@_handle_exception
def _add_vehicle(req: dict) -> Tuple[str, str]:
    contract_id = req.get('veic_propriedade', '')
    if contract_id in 'N':
        contract_id = 1
    elif contract_id in 'SFRO':
        contract_id = 2
    elif contract_id in 'AMG':
        contract_id = 3

    state_id = estado_ibge(req.get('veic_uf',''))

    type_owner = req.get('prop_cnpjcpf', '')

    if len(type_owner) == 14:
        type_owner = 'J'
    elif len(type_owner) == 11:
        type_owner = 'F'

    cor_id = tabela_cores(req.get('veic_cor', ''))

    data = {
        "plate": req.get('veic_placa', ''),
        "contract_id": contract_id,
        "state_id": state_id,
        "city_id": req.get('veic_codibge', ''),
        "year": req.get('veic_anofab', ''),
        "chassi": req.get('veic_chassi', ''),
        "frota": '',#req.get('veic_placa', ''),
        "renavam": req.get('veic_renavam', ''),
        "technology_id":'', #req.get('veic_tiporastreador', ''), # "5", #"req.get('', ''),
        "serial": "",
        "brand_id": req.get('', ''), #Não tem como enviar
        "model_id": req.get('', ''), #Não tem como enviar
        "rntrc": req.get('veic_rntrc', ''),
        "licensing": req.get('veic_datavencdocumento', ''),
        "owner": req.get('prop_nome', ''),
        "document": req.get('prop_cnpjcpf', ''),
        "type": type_owner,
        "color_id": cor_id,
    }

    return json.dumps({'data':[data]}), ''

@_link_to_request(_m3risk.ADD_CARTS1)
@_handle_exception
def _add_cart(req: dict) -> Tuple[str, str]:
    state_id = estado_ibge(req.get('car1_uf',''))
    data = {
        "plate": req.get('car1_placa', ''),
        "state_id": state_id,
        "city_id": req.get('car1_codibge', ''),
        "year": req.get('car1_anofab', ''),
        "chassi": req.get('car1_chassi', ''),
        "renavam": req.get('car1_renavam', ''),
    }
    return json.dumps({'data':[data]}), ''

@_link_to_request(_m3risk.ADD_CARTS2)
@_handle_exception
def _add_cart(req: dict) -> Tuple[str, str]:
    state_id = estado_ibge(req.get('car2_uf', ''))
    data = {
        "plate": req.get('car2_placa', ''),
        "state_id":state_id,
        "city_id": req.get('car2_codibge', ''),
        "year": req.get('car2_anofab', ''),
        "chassi": req.get('car2_chassi', ''),
        "renavam": req.get('car2_renavam', ''),
    }
    return json.dumps({'data':[data]}), ''


@_link_to_request(_m3risk.ADD_DRIVERS)
@_handle_exception
def _add_driver(req: dict) -> Tuple[str, str]:
    state_id = estado_ibge(req.get('mot_ufcidendereco', ''))

    try:
        estado_rg = req.get("mot_orgaorg", '')[-2] + req.get("mot_orgaorg", '')[-1]
    except:
        estado_rg = ''

    cnd_validate = req.get('mot_datavalidcnh', '')
    cnh_validate_format = _date_ddmmyy(cnd_validate),
    data = {
        "name": req.get('mot_nome', ''),
        "cpf": req.get('mot_cpf', ''),
        "rg": req.get('mot_rg', ''),
        "cnh": req.get('mot_cnh', ''),
        "cnh_validate": cnh_validate_format[0],
        "state_id": state_id,
        "city_id": req.get('mot_codibge', ''),
        "address": req.get('mot_endereco', ''),
        "zipcode": req.get('mot_cep', ''),
        "suburb": req.get('mot_bairro', ''),
        "telephone": req.get('mot_foneddd', '') + req.get('mot_fonenumero', ''),
        "celular": req.get('mot_celularddd', '') + req.get('mot_celularnumero', ''),
        "birthday": req.get('mot_datanasc', ''),
        "drivertype_id": '',#req.get('veic_anofab', ''),
        "password": req.get("mot_senha", ''),
        "rg_dispatcher": req.get("mot_orgaorg", ''),
        "rg_state": estado_rg,
        "gender": req.get("mot_sexo", ''),
        "cnh_category": req.get("mot_catcnh", ''),
    }
    return json.dumps({'data':[data]}), ''

@_link_to_request(_m3risk.ADD_SM)
@_handle_exception
def _add_sm(req: dict) -> Tuple[str, str]:
    notas = req.get('notas', [])
    charges = []

    data = {
        "vehicle_id": req.get('vehicle_id', ''), # '66950',#req.get('conh_veic_codexternosx', ''),
        "cart1_id": req.get('cart1_id', ''), #  '2',# req.get('conh_car1_codexterno', ''),
        "cart2_id": req.get('cart2_id', ''), # '2',#req.get('conh_car2_codexterno', ''), #req.get('', ''),
        "driver1_id": req.get('driver1_id', ''), # '2',#req.get('conh_car1_codexterno', ''),
        "driver2_id": req.get('driver2_id', ''), # '2',#req.get('conh_car2_codexterno', ''),
        "transportationtype_id": req.get('transportationtype_id', ''), # '1',#req.get('conh_tipocarga', ''),
        "startdatetime": req.get('startdatetime', ''), # '2018-10-10 11:00:00',#req.get('conh_dataini', ''),
        "enddatetime": req.get('enddatetime', ''), # '2018-10-10 18:00:00',#req.get('conh_datafim', ''),
        "consultnumber": req.get('consultnumber', ''), # '',#req.get('mot_cep', ''),
        "consultvalidity": req.get('consultvalidity', ''), # '', #req.get('mot_bairro', ''),
        "escorted": req.get('escorted', ''),
        "escortcompany": req.get('escortcompany', ''), # '',#req.get('conh_dest_nome', ''),
        "escortplate": req.get('escortplate', ''), # '',# req.get('mot_datanasc', ''),
        "escorttrackingtecnology": req.get('escorttrackingtecnology', ''), # "", #"#req.get('veic_anofab', ''),
        "escorttrackingserial": req.get('escorttrackingserial', ''), # "",  # "#req.get('veic_anofab', ''),
        "contactname":req.get('contactname', ''), # '', #req.get('mot_datanasc', ''),
        "contacttel":req.get('contacttel', ''), # '',# req.get('veic_anofab', ''),
        "decoy":req.get('decoy', ''), # '0',# req.get('mot_datanasc', ''),
        "decoytrackingtecnology": req.get('decoytrackingtecnology', ''), # '0',  # req.get('mot_datanasc', ''),
        "decoyserial": req.get('decoyserial', ''), # '',#req.get('veic_anofab', ''),
        "decoysite": req.get('decoysite', ''), # '',#'(' + req.get('mot_celularddd', '') + ') ' + req.get('mot_celularnumero', ''),
        "decoylogin": req.get('decoylogin', ''), # '', #req.get('mot_datanasc', ''),
        "decoypassword": req.get('decoypassword', ''), # '', #req.get('veic_anofab', ''),
        "charged": req.get('charged', ''), # '1',#req.get('mot_datanasc', ''),
        "charge": charges,
        "route_id": req.get('route_id', ''), #'590',#req.get('mot_datanasc', ''),
    }

    if notas:
        for nota in notas:
            charges.append({
                "description": nota.get('description', ''),
                "nf": nota.get('nf', ''),
                "amount": nota.get('amount', ''),
                "shipper_id": nota.get('shipper_id', ''),
            })
    else:
        charges.append({
            "description": req.get('description', ''),
            "nf": req.get('nf', ''),
            "amount": req.get('amount', ''),
            "shipper_id": req.get('shipper_id', ''),
        })
        charges.append({
            "description": req.get('description', ''),
            "nf": req.get('nf', ''),
            "amount": req.get('amount', ''),
            "shipper_id": req.get('shipper_id', ''),
        })

    return json.dumps({'data':[data]}), ''

@_link_to_request(_m3risk.CANCEL_SM)
@_handle_exception
def _cancel_sm(req: dict) -> Tuple[str, str]:
    data = {
        "sm_id": req.get('sm_id', ''),
        "motivo": req.get('motivo', ''),
    }

    return json.dumps({'data':[data]}), ''

@_link_to_response(_m3risk.ADD_VEHICLES, _m3risk.ADD_CARTS1, _m3risk.ADD_DRIVERS, _m3risk.ADD_SM, _m3risk.LIST_ROUTES,_m3risk.ADD_CARTS2, _m3risk.CANCEL_SM)
def _add_vehicle_response(resp: Response) -> Tuple[str, str]:
    resp_json = resp.json()
    success = resp.status_code in [200, 201, 204]
    resp_body = {'sucesso': success}
    if success:
        resp_body['conteudo'] = resp_json
    elif 'error' in resp_json:
        resp_body['msg_erro'] = deep_get(resp_json, 'error')
    elif 'errors' in resp_json:
        resp_body['msg_erro'] = deep_get(resp_json, 'errors')
    else:
        raise M3riskException('Não foi possível encontrar um retorno conhecido da M3Risk')
    return mount_xml_response(resp_body), ''

@_link_to_response(_m3risk.CANCEL_SM)
def _cancel_sm_response(resp: Response) -> Tuple[str, str]:
    resp_json = resp.json()
    success = resp.status_code in [200, 201, 204]
    resp_body = {'sucesso': success}
    if success:
        resp_body['conteudo'] = [resp_json]
    elif 'error' in resp_json:
        resp_body['msg_erro'] = deep_get(resp_json, 'error')
    elif 'errors' in resp_json:
        resp_body['msg_erro'] = deep_get(resp_json, 'errors')
    else:
        raise M3riskException('Não foi possível encontrar um retorno conhecido da M3Risk')
    return mount_xml_response(resp_body), ''

@_link_to_request(_m3risk.DEFAULT_FUNCTION)
def _out_default() -> Tuple[None, str]:
    return None, ''

@_link_to_response(_m3risk.REQUEST_SEARCH_VEHICLES, _m3risk.REQUEST_SEARCH_DRIVERS,_m3risk.REQUEST_SEARCH_CARTS)
def _find_resultado_consulta(resp: Response) -> Tuple[str, str]:
    resp_json = resp.json()
    success = resp.status_code in [200, 201, 204]
    resp_body = {'sucesso': success}
    if success and len(resp_json) > 0:
        resp_body['conteudo'] = resp_json[0]
    elif 'error' in resp_json or len(resp_json) == 0:
        resp_body['sucesso'] = False
        resp_body['msg_erro'] = 'O cadastro ainda não foi realizado, é necessário cadastrar antes para buscar informações'
    else:
        raise M3riskException('Não foi possível encontrar um retorno conhecido da M3Risk')
    return mount_xml_response(resp_body), ''

# CONVERTE 19/02/2000 PARA 2000-02-19
def _date_ddmmyy(s: str) -> str:
    try:
        return datetime.strptime(s, "%d/%m/%Y").strftime("%Y-%m-%d")
    except (Exception,):
        return ''



def estado_ibge(uf_estado):
    state_id = uf_estado
    if state_id == 'AC':
        state_id = 12
    elif state_id == 'AL':
        state_id = 27
    elif state_id == 'AP':
        state_id = 16
    elif state_id == 'AM':
        state_id = 13
    elif state_id == 'BA':
        state_id = 29
    elif state_id == 'CE':
        state_id = 23
    elif state_id == 'DF':
        state_id = 53
    elif state_id == 'ES':
        state_id = 32
    elif state_id == 'MT':
        state_id = 51
    elif state_id == 'MS':
        state_id = 50
    elif state_id == 'MG':
        state_id = 31
    elif state_id == 'PA':
        state_id = 15
    elif state_id == 'PB':
        state_id = 25
    elif state_id == 'PR':
        state_id = 41
    elif state_id == 'PE':
        state_id = 26
    elif state_id == 'PI':
        state_id = 22
    elif state_id == 'RJ':
        state_id = 33
    elif state_id == 'RN':
        state_id = 24
    elif state_id == 'RS':
        state_id = 43
    elif state_id == 'RO':
        state_id = 11
    elif state_id == 'RR':
        state_id = 14
    elif state_id == 'SC':
        state_id = 42
    elif state_id == 'SP':
        state_id = 35
    elif state_id == 'SE':
        state_id = 28
    elif state_id == 'TO':
        state_id = 17
    return state_id


def tabela_cores(cor):
    cor_id = upper(cor)
    if cor_id == 'AMARELO':
        cor_id = '1'
    elif cor_id == 'AZUL':
        cor_id = '2'
    elif cor_id == 'BEGE':
        cor_id = '3'
    elif cor_id == 'BORDO':
        cor_id = '4'
    elif cor_id == 'CINZA':
        cor_id = '6'
    elif cor_id == 'DOURADO':
        cor_id = '7'
    elif cor_id == 'GRENÁ':
        cor_id = '8'
    elif cor_id == 'LARANJA':
        cor_id = '9'
    elif cor_id == 'MARROM':
        cor_id = '10'
    elif cor_id == 'PRATA':
        cor_id = '11'
    elif cor_id == 'PRETO':
        cor_id = '12'
    elif cor_id == 'ROXO':
        cor_id = '13'
    elif cor_id == 'VERDE':
        cor_id = '14'
    elif cor_id == 'VERMELHO':
        cor_id = '15'
    elif cor_id == 'PRETA':
        cor_id = '86'
    elif cor_id == 'INOX':
        cor_id = '626'
    elif cor_id == 'BRANCO':
        cor_id = '941'
    else:
        cor_id = '0'
    return cor_id
#
# def __register_driver__(data_req: str) -> Tuple[str, str]:
#     try:
#         data: dict = {}
#         req: dict = {
#             "data": [data]
#         }
#
#         isdriver = data_req.get('mot_funcionario', '')
#         data['drivertype_id'] = {
#             'S': '4',
#             'N': '3'
#         }.get(isdriver, '')
#
#         data.update(
#             {
#                 'name': data_req.get('mot_nome', ''),
#                 'cpf': data_req.get('mot_cpf', ''),
#                 'rg': data_req.get('mot_rg', ''),
#                 'cnh': wsstrtoAAAAMMDD(data_req.get('mot_cnh', '')),
#                 'cnh_validate': data_req.get('mot_datavalidcnh', ''),
#                 'state_id': '',
#                 'city_id': data_req.get('mot_codibge', ''),
#                 'address': data_req.get('mot_endereco', ''),
#                 'zipcode': data_req.get('mot_cep', ''),
#                 'suburb': data_req.get('mot_bairro', ''),
#                 'telephone': data_req.get('mot_fone', ''),
#                 'celular': data_req.get('mot_celularnumero', ''),
#                 'birthday': wsstrtoAAAAMMDD(data_req.get('mot_datanasc', ''))
#             }
#         )
#
#         return json.dumps(req), ''
#     except Exception as e:
#         logging.warning('M3Risk |> Erro ao criar requisição de registro de carreta: ')
#         print(e)
#         return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)
#
#
# def __register_vehicle__(data_req: str) -> Tuple[str, str]:
#     try:
#         data: dict = {}
#         req: dict = {
#             "data": [data]
#         }
#
#         ownership = data_req.get('veic_propriedade', '')
#         data['contract_id'] = {
#             'S': '2', 'F': '2', 'R': '2', 'O': '2',
#             'A': '3', 'M': '3', 'G': '3',
#             'N': '1'
#         }.get(ownership, '')
#
#         data.update(
#             {
#                 'plate': data_req.get('veic_placa', ''),
#                 'state_id': data_req.get('veic_estadoibge', ''),
#                 'city_id': data_req.get('veic_codibge', ''),
#                 'year': data_req.get('veic_anofab', ''),
#                 'chassi': data_req.get('veic_chassi', ''),
#                 'frota': '',
#                 'renavam': data_req.get('veic_renavam', ''),
#                 'technology_id': ''
#             }
#         )
#
#         return json.dumps(req), ''
#     except Exception as e:
#         logging.warning('M3Risk |> Erro ao criar requisição de registro de veículo: ')
#         print(e)
#         return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)
#
#
# def __register_SM__(reqJSON: str) -> str:
#     try:
#         jsonSor = GetJson(reqJSON)
#         getJSON = jsonSor.getJSON
#         dataHoraInicio, dataHoraFim = getInicioFimViagemMotDateTime(jsonSor)
#         dataHoraInicio = dbdatetimetostr(dataHoraInicio)
#         dataHoraFim = dbdatetimetostr(dataHoraFim)
#
#         if getJSON('conh_veic_codexternosx'):
#             codVeic = getJSON('conh_veic_codexternosx')
#         else:
#             codVeic = getJSON('conh_veic_codexterno')
#         if getJSON('conh_veic_codexternosx') != '':
#             codCar1 = getJSON('conh_car1_codexternosx')
#         elif getJSON('conh_car1_codexterno') != '':
#             codCar1 = getJSON('conh_car1_codexterno')
#         else:
#             codCar1 = '0'
#         if getJSON('conh_car2_codexternosx') != '':
#             codCar2 = getJSON('conh_car2_codexternosx')
#         elif getJSON('conh_car2_codexterno') != '':
#             codCar2 = getJSON('conh_car2_codexterno')
#         else:
#             codCar2 = '0'
#         if getJSON('conh_mot_codexternosx') != '':
#             codMot = getJSON('conh_mot_codexternosx')
#         else:
#             codMot = getJSON('conh_mot_codexterno')
#         data = {}
#         data['vehicle_id'] = codVeic
#         data['cart1_id'] = codCar1
#         data['cart2_id'] = codCar2
#         data['driver1_id'] = codMot
#         data['driver2_id'] = ''
#         data['transportationtype_id'] = '1'
#         data['startdatetime'] = dataHoraInicio
#         data['enddatetime'] = dataHoraFim
#         data['consultnumber'] = ''
#         data['consultvalidity'] = ''
#         data['escorted'] = '0'
#         data['escortcompany'] = ''
#         data['escortplate'] = ''
#         data['escorttrackingtecnology'] = ''
#         data['escorttrackingserial'] = ''
#         data['contactname'] = ''
#         data['contacttel'] = ''
#         data['decoy'] = '0'
#         data['decoytrackingtecnology'] = ''
#         data['decoyserial'] = ''
#         data['decoysite'] = ''
#         data['decoylogin'] = ''
#         data['decoypassword'] = ''
#         data['charged'] = '1'
#         arrayCargas = []
#         qtdeNfs = int(getJSON('conh_ctnfs'))
#         for i in range(1, qtdeNfs + 1, 1):
#             objCarga = {}
#             objCarga['description'] = getJSON('conh_mercnf' + str(i))
#             objCarga['nf'] = getJSON('conh_numnf' + str(i))
#             objCarga['amount'] = getJSON('conh_valornf' + str(i))
#             objCarga['shipper_id'] = '1'
#             arrayCargas.append(objCarga)
#         data['charge'] = arrayCargas
#         data['routedescription'] = getJSON('conh_cidorig_nome') + '/' + getJSON(
#             'conh_cidorig_uf') + ' -> ' + getJSON('conh_ciddest_nome') + '/' + getJSON('conh_ciddest_uf')
#         data['routecountryorigin'] = getJSON('conh_cidorig_pais')
#         data['routestateorigin'] = getJSON('conh_cidorig_uf')
#         data['routecityorigin'] = getJSON('conh_codibgeorig')
#         data['routereferenceorigin'] = 'SAIDA: ' + getJSON('conh_coleta_nome')
#         data['routecountrydestination'] = getJSON('conh_ciddest_pais')
#         data['routestatedestination'] = getJSON('conh_ciddest_uf')
#         data['routecitydestination'] = getJSON('conh_codibgedest')
#         data['routereferencedestination'] = 'ENTREGA: ' + getJSON('conh_coleta_nome')
#         data['roads'] = ''
#         data['deliveries'] = ''
#         data['stops'] = ''
#         arrayData = []
#         arrayData.append(data)
#         req = {}
#         req['data'] = arrayData
#         return json.dumps(req), ''
#     except Exception as e:
#         print('Erro em requestM3riskAddSM')
#         print(e)
#         return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO'
#
#
# def __register_cart__(data_req: str, index: int) -> Tuple[str, str]:
#     try:
#         p = 'car ' + index + '_'
#
#         data: dict = {}
#         req: dict = {
#             "data": [data]
#         }
#
#         data.update(
#             {
#                 "plate": data_req.get(p + 'placa', ''),
#                 "state_id": data_req.get(p + 'stadoibge', ''),
#                 "city_id": data_req.get(p + 'codibge', ''),
#                 "year": data_req.get(p + 'anofab', ''),
#                 "chassi": data_req.get(p + 'chassi', ''),
#                 "renavam": data_req.get(p + 'renavam', '')
#             }
#         )
#
#         return json.dumps(req), ''
#     except Exception as e:
#         logging.warning('M3Risk |> Erro ao criar requisição de registro de carreta: ')
#         print(e)
#         return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)
#
#
# class M3Risk:
#     MIN_ACTION = 3400
#     MAX_ACTION = 3449
#     REGISTER_SM = 3401  # ACAO_M3RISK_ADD_SM
#     REGISTER_DRIVER = 3402  # ACAO_M3RISK_ADD_MOTORISTA
#     REGISTER_VEHICLE = 3403  # ACAO_M3RISK_ADD_VEICULO
#     REGISTER_CART1 = 3404  # ACAO_M3RISK_ADD_CARRETA1
#     REGISTER_CART2 = 3405  # ACAO_M3RISK_ADD_CARRETA2
#     REGISTER_CART3 = 3406  # ACAO_M3RISK_ADD_CARRETA3
#
#     def __init__(self):
#         self.__request_builder_record__ = {
#             self.REGISTER_SM: lambda data: __register_SM__(data.get('req')),
#             self.REGISTER_DRIVER: lambda data: __register_driver__(data.get('req')),
#             self.REGISTER_VEHICLE: lambda data: __register_vehicle__(data.get('req')),
#             self.REGISTER_CART1: lambda data: __register_cart__(data.get('req'), 1),
#             self.REGISTER_CART2: lambda data: __register_cart__(data.get('req'), 2),
#             self.REGISTER_CART3: lambda data: __register_cart__(data.get('req'), 3)
#         }
#
#     def recognize_request(self, action_cod: int) -> bool:
#         return self.MIN_ACTION < action_cod < self.MAX_ACTION
#
#     def build_request(self, context_data: dict, action_cod: int) -> str:
#         return self.__request_builder_record__.get(action_cod)(context_data)
#
#
# def preProcessRequestPropertiesM3risk(headers, requestProperties):
#     properties = {}
#     if requestProperties != '':
#         listProperties = list(requestProperties.split('&'))
#         for property in listProperties:
#             entry = property.split('=')
#             properties[entry[0]] = entry[1]
#     headers['x-api-key'] = properties['token']
#     headers['Authorization'] = properties['usuario'] + ':' + properties['senha']
#     return headers, ''
#
#
# def responseM3riskAddSM(resp):
#     try:
#         ret = resp.content.decode('utf-8')
#         root = json.loads(ret)
#         jsonResp = GetJson(root)
#         getJSON = jsonResp.getJSON
#         msgErroFinal = ''
#         if not (type(root) is list):
#             erro = getJSON('error')
#             if erro != '':
#                 msgErroFinal = erro
#             else:
#                 message = getJSON('message')
#                 erros = getJSON('errors')
#                 if len(erros) > 0:
#                     for erro in erros:
#                         msgErroFinal += '['+erro+']'
#
#         if msgErroFinal != '':
#             return '', msgErroFinal
#         else:
#             numeroSM = str(root[0])
#             NumAutGerRisco = '<NumAutGerRisco>'+numeroSM+'</NumAutGerRisco>'
#             return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>Solicitacao de monitoramento realizada com sucesso!</msg>' + NumAutGerRisco + '</resp>', ''
#     except Exception as e:
#         print('Erro em responseM3riskAddSM')
#         print(e)
#         return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA GER. RISCO'
#
#
# m3_risk = M3Risk()
