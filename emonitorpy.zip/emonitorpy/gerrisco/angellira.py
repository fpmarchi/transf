import base64
from typing import Tuple

import xmltodict
from requests import Response

from ActionProcessor import ActionProcessor, parse_props, handle_exception_factory
from geral import *
from geralxml import mount_xml_response, xml_from_dict


class AngelliraException(Exception):
    pass


# Classe base
class Angellira(ActionProcessor):
    # INSTANCIAS
    HOST = 'http://servAngelirrawin.virtuaserver.com.br'
    TEST_HOST = 'http://servAngelirrawin.virtuaserver.com.br'
    BASE_PATH = '/wsdl/WebAppAverba.exe/soap/IWebAppAverba'

    DATA_TRANSPORT_STATUS = 4450

    def __init__(self):
        self.add_callable_records('url', {
            self.DEFAULT_FUNCTION: self.make_url_assembler()
        })

        super().__init__()

    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        return {
            'Content-type': 'text/xml',
        }, ''


#
#   Códigos independentes de instancia
#
def _angellira_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a Angelirra:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    AngelliraException,
    _angellira_exception_callback,
    any_exception_callback
)

#
#   Instancia limpa e sem configuração
#
_angellira = Angellira()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = _angellira.link_to_factory('request')
_link_to_response = _angellira.link_to_factory('response')


@_link_to_request(_angellira.DATA_TRANSPORT_STATUS)
@_handle_exception
def _register_cte(req: dict) -> Tuple[str, str]:
    xml_base64 = req.get('xml_angellira', '')
    xml = base64.b64decode(xml_base64).decode('utf-8')
    xml = xml.replace('\n', '')
    xml = xml.replace('\r', '')
    # xml = xml.replace('<tpAmb>2</tpAmb>', '<tpAmb>1</tpAmb>')


    return xml, ''





@_link_to_response(_angellira.DATA_TRANSPORT_STATUS)
def _in_register_cte(resp: Response) -> Tuple[str, str]:
    ret = resp.text
    status_code = resp.status_code
    if status_code == 200:
        resp_data = {
            'sucesso': False,
            'conteudo': ret
        }

    return mount_xml_response(resp_data), ''

