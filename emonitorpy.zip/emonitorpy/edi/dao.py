import json

from sqlalchemy.sql import *
import base64
import gzip

from geral import getstrnotempty, removeAccents, clearNoDigits, strtodatetime, clearUnicodeNoASCII
from sefaz.dao import getCnpjCpfsInstalacao
from geralxml import createtag

from emws import EMONITORSPOOL_PENDENTE, EMONITORSPOOL_PROCESSADO, EMONITORSPOOL_ERROPROCESSAMENTO


######################################################################
# MERCADORIA
######################################################################
def findMercadoria(conn, codMercadoria):
    try:
        sql = text('SELECT m.descricao, m.ncm, m.especie '
                   'FROM mercadoria m ' +
                   'WHERE m.codMercadoria = ' + str(codMercadoria)
                   )
        #print(sql)
        rs = conn.execute(sql)
        return rs.fetchone()
    except Exception as e:
        print('Erro em edi.dao.findMercadoria')
        print(e)
        return None


def existMercadoria(conn, descricao: str):
    try:
        descricao = removeAccents(descricao.upper())
        sql = text('SELECT codmercadoria '
                   'FROM mercadoria '
                   'WHERE descricao = :descricao'
                   )
        sql = sql.bindparams(descricao=descricao)
        #print(sql)
        rs = conn.execute(sql)
        dados = rs.fetchone()
        if dados is not None and int(dados['codmercadoria']) > 0:
            return int(dados['codmercadoria'])
        else:
            return 0
    except Exception as e:
        print('Erro em edi.dao.existMercadoria')
        print(e)
        return -1


def insMercadoria(conn, campos):
    try:
        descricao = campos['MERCADORIA']
        try:
            ncm = campos['MERCADORIANCM']
        except:
            ncm = ''
        try:
            especie = campos['ESPECIEMERC']
        except:
            especie = ''
        #
        codMercadoria = existMercadoria(conn, descricao)
        if codMercadoria <= 0:
            descricao = removeAccents(descricao.upper())
            sql = text('INSERT INTO mercadoria (descricao, ncm, especie) VALUES (:descricao, :ncm, :especie)')
            sql = sql.bindparams(descricao=descricao)
            sql = sql.bindparams(ncm=ncm)
            sql = sql.bindparams(especie=especie)
            #print(sql)
            conn.execute(sql)
            codMercadoria = existMercadoria(conn, descricao)
        return codMercadoria
    except Exception as e:
        print('Erro em edi.dao.insMercadoria')
        print(e)
        return -1


######################################################################
# VEICULO
######################################################################
def findVeiculo(conn, codVeiculo):
    try:
        sql = text('SELECT v.placa '
                   'FROM veiculo v ' +
                   'WHERE v.codVeiculo = ' + str(codVeiculo)
                   )
        #print(sql)
        rs = conn.execute(sql)
        return rs.fetchone()
    except Exception as e:
        print('Erro em edi.dao.findVeiculo')
        print(e)
        return None


def existVeiculo(conn, placa: str):
    try:
        placa = placa.upper()
        sql = text('SELECT codveiculo '
                   'FROM veiculo '
                   'WHERE placa = :placa'
                   )
        sql = sql.bindparams(placa=placa)
        #print(sql)
        rs = conn.execute(sql)
        dados = rs.fetchone()
        if dados is not None and int(dados['codveiculo']) > 0:
            return int(dados['codveiculo'])
        else:
            return 0
    except Exception as e:
        print('Erro em edi.dao.existVeiculo')
        print(e)
        return -1


def insVeiculo(conn, campos):
    try:
        placa = campos['PLACA']
        #
        codVeiculo = existVeiculo(conn, placa)
        if codVeiculo <= 0:
            placa = placa.upper()
            sql = text('INSERT INTO veiculo (placa) VALUES (:placa)')
            sql = sql.bindparams(placa=placa)
            #print(sql)
            conn.execute(sql)
            codVeiculo = existVeiculo(conn, placa)
        return codVeiculo
    except Exception as e:
        print('Erro em edi.dao.insVeiculo')
        print(e)
        return -1


######################################################################
# CIDADE
######################################################################
def findCidade(conn, codCidade):
    try:
        sql = text('SELECT c.nome, c.uf, c.codibge '
                   'FROM cidade c ' +
                   'WHERE c.codCidade = ' + str(codCidade)
                   )
        #print(sql)
        rs = conn.execute(sql)
        return rs.fetchone()
    except Exception as e:
        print('Erro em edi.dao.findCidade')
        print(e)
        return None


def existCidade(conn, codIBGE: str):
    try:
        sql = text('SELECT codcidade '
                   'FROM cidade '
                   'WHERE codibge = :codibge'
                   )
        sql = sql.bindparams(codibge=codIBGE)
        #print(sql)
        rs = conn.execute(sql)
        dados = rs.fetchone()
        if dados is not None and int(dados['codcidade']) > 0:
            return int(dados['codcidade'])
        else:
            return 0
    except Exception as e:
        print('Erro em edi.dao.existCidade')
        print(e)
        return -1


def insCidade(conn, campos, sufixo):
    codIBGE = campos['CODIBGE' + sufixo]
    nome = campos['CIDADE' + sufixo]
    uf = campos['UF' + sufixo]
    return insCidade(conn, nome, uf, codIBGE)


def insCidadeOrigem(conn, campos):
    codIBGE = campos['CODIBGEORIGEM']
    nome = campos['CIDORIGEM']
    uf = campos['UFCIDORIGEM']
    return insCidade(conn, nome, uf, codIBGE)


def insCidadeDestino(conn, campos):
    codIBGE = campos['CODIBGEDESTINO']
    nome = campos['CIDDESTINO']
    uf = campos['UFCIDDESTINO']
    return insCidade(conn, nome, uf, codIBGE)


def insCidadeCampos(conn, campos):
    codIBGE = campos['cidade_codibge']
    nome = campos['cidade_nome']
    uf = campos['cidade_uf']
    return insCidade(conn, nome, uf, codIBGE)


def insCidade(conn, nome, uf, codIBGE):
    try:
        if codIBGE == '':
            return -1
        #
        codCidade = existCidade(conn, codIBGE)
        if codCidade <= 0:
            sql = text('INSERT INTO cidade (nome, uf, codibge) VALUES (:nome, :uf, :codibge)')
            sql = sql.bindparams(nome=nome)
            sql = sql.bindparams(uf=uf)
            sql = sql.bindparams(codibge=codIBGE)
            #print(sql)
            conn.execute(sql)
            codCidade = existCidade(conn, codIBGE)
        return codCidade
    except Exception as e:
        print('Erro em edi.dao.insCidade')
        print(e)
        return -1


######################################################################
# PESSOA
######################################################################
def findPessoa(conn, codPessoa):
    try:
        sql = text('SELECT p.nome, p.cnpjcpf, p.inscricaoestadual, c.codcidade, c.nome nomecidade, c.uf, c.codibge '
                   'FROM pessoa p LEFT JOIN cidade c ON p.codcidade = c.codcidade ' +
                   'WHERE p.codPessoa = ' + str(codPessoa)
                   )
        #print(sql)
        rs = conn.execute(sql)
        return rs.fetchone()
    except Exception as e:
        print('Erro em edi.dao.findPessoa')
        print(e)
        return None


def existPessoa(conn, nome: str, cnpjcpf: str, inscricaoestadual: str):
    try:
        cnpjcpf = clearNoDigits(cnpjcpf)
        inscricaoestadual = clearNoDigits(inscricaoestadual)
        if cnpjcpf != '' and inscricaoestadual != '':
            filtro = 'WHERE cnpjcpf = \'' + cnpjcpf + '\' AND inscricaoestadual = \'' + inscricaoestadual + '\''
        elif cnpjcpf != '':
            filtro = 'WHERE cnpjcpf = \'' + cnpjcpf + '\''
        else:
            filtro = 'WHERE nome = \'' + nome + '\''
        sql = text('SELECT codpessoa '
                   'FROM pessoa ' +
                   filtro
                   )
        #print(sql)
        rs = conn.execute(sql)
        dados = rs.fetchone()
        if dados is not None and int(dados['codpessoa']) > 0:
            return int(dados['codpessoa'])
        else:
            return 0
    except Exception as e:
        print('Erro em edi.dao.existPessoa')
        print(e)
        return -1


def insPessoaMotorista(conn, campos):
    nome = campos['NOMEMOTORISTA']
    cnpjcpf = campos['CPFMOTORISTA']
    return insPessoa(conn, nome, cnpjcpf, '', 0)


def insPessoaProprietario(conn, campos):
    nome = campos['NOMEPROP']
    cnpjcpf = campos['CGCCPFPROP']
    inscricaoestadual = campos['INSCESTPROP']
    return insPessoa(conn, nome, cnpjcpf, inscricaoestadual, 0)


def insPessoaFilial(conn, campos):
    nome = campos['NOMECLI']
    cnpjcpf = campos['CGCCPFCLI']
    inscricaoestadual = campos['INSCESTCLI']
    codcidade = insCidade(conn, campos['CIDADECLI'], campos['UFCLI'], campos['CODIBGECLI'])
    return insPessoa(conn, nome, cnpjcpf, inscricaoestadual, codcidade)


def insPessoaRemetente(conn, campos):
    nome = campos['NOMEREM']
    cnpjcpf = campos['CGCCPFREM']
    inscricaoestadual = campos['INSCESTREM']
    codcidade = insCidade(conn, campos['CIDADEREM'], campos['UFREM'], campos['CODIBGEREM'])
    return insPessoa(conn, nome, cnpjcpf, inscricaoestadual, codcidade)


def insPessoaDestinatario(conn, campos):
    nome = campos['NOMEDEST']
    cnpjcpf = campos['CGCCPFDEST']
    inscricaoestadual = campos['INSCESTDEST']
    codcidade = insCidade(conn, campos['CIDADEDEST'], campos['UFDEST'], campos['CODIBGEDEST'])
    return insPessoa(conn, nome, cnpjcpf, inscricaoestadual, codcidade)


def insPessoaColeta(conn, campos):
    nome = campos['DESCCOLETA']
    cnpjcpf = campos['CNPJCPFCOLETA']
    inscricaoestadual = campos['INSCESTCOLETA']
    codcidade = insCidade(conn, campos['CIDADECOLETA'], campos['UFCOLETA'], campos['CODIBGECOLETA'])
    return insPessoa(conn, nome, cnpjcpf, inscricaoestadual, codcidade)


def insPessoaEntrega(conn, campos):
    nome = campos['DESCENTREGA']
    cnpjcpf = campos['CNPJCPFENTREGA']
    inscricaoestadual = campos['INSCESTENTREGA']
    codcidade = insCidade(conn, campos['CIDADEENTREGA'], campos['UFENTREGA'], campos['CODIBGEENTREGA'])
    return insPessoa(conn, nome, cnpjcpf, inscricaoestadual, codcidade)


def insPessoaCampos(conn, campos, codcidade):
    nome = campos['pessoa_nome']
    cnpjcpf = campos['pessoa_cnpjcpf']
    inscricaoestadual = campos['pessoa_inscricaoestadual']
    fone = campos['pessoa_fone']
    celular = campos['pessoa_celular']
    email = campos['pessoa_email']
    return insPessoa(conn, nome, cnpjcpf, inscricaoestadual, codcidade, fone, celular, email)


def insPessoa(conn, nome, cnpjcpf, inscricaoestadual, codcidade, fone='', celular='', email=''):
    try:
        if nome == '':
            return -1
        #
        codPessoa = existPessoa(conn, nome, cnpjcpf, inscricaoestadual)
        if codPessoa <= 0:
            if codcidade > 0:
                sql = text('INSERT INTO pessoa (nome, cnpjcpf, inscricaoestadual, codcidade, fone, celular, email) VALUES (:nome, :cnpjcpf, :inscricaoestadual, :codcidade, :fone, :celular, :email)')
                sql = sql.bindparams(codcidade=codcidade)
            else:
                sql = text('INSERT INTO pessoa (nome, cnpjcpf, inscricaoestadual, fone, celular, email) VALUES (:nome, :cnpjcpf, :inscricaoestadual, :fone, :celular, :email)')
            cnpjcpf = clearNoDigits(cnpjcpf)
            inscricaoestadual = clearNoDigits(inscricaoestadual)
            sql = sql.bindparams(nome=nome)
            sql = sql.bindparams(cnpjcpf=cnpjcpf)
            sql = sql.bindparams(inscricaoestadual=inscricaoestadual)
            sql = sql.bindparams(fone=fone)
            sql = sql.bindparams(celular=celular)
            sql = sql.bindparams(email=email)
            #print(sql)
            conn.execute(sql)
            codPessoa = existPessoa(conn, nome, cnpjcpf, inscricaoestadual)
        else:
            if codcidade > 0:
                sql = text('SELECT codcidade FROM pessoa WHERE codpessoa = :codpessoa')
                sql = sql.bindparams(codpessoa=codPessoa)
                rs = conn.execute(sql)
                dados = rs.fetchone()
                if dados['codcidade'] is not None:
                    codcidadeAtual = int(dados['codcidade'])
                else:
                    codcidadeAtual = -1
                if codcidade != codcidadeAtual:
                    sql = text('UPDATE pessoa SET codcidade = :codcidade WHERE codpessoa = :codpessoa')
                    sql = sql.bindparams(codcidade=codcidade)
                    sql = sql.bindparams(codpessoa=codPessoa)
                    conn.execute(sql)
        return codPessoa
    except Exception as e:
        print('Erro em edi.dao.insPessoa')
        print(e)
        return -1


def insPessoaLog(conn, codPessoa, codInstalacao, tipoUsuario, codUsuario, data):
    try:
        sql = text('INSERT INTO pessoalog (codpessoa,codinstalacao,tipousuario,codusuario,data) VALUES (:codpessoa, :codinstalacao, :tipousuario, :codusuario, :data)')
        sql = sql.bindparams(codpessoa=codPessoa)
        sql = sql.bindparams(codinstalacao=codInstalacao)
        sql = sql.bindparams(tipousuario=tipoUsuario)
        sql = sql.bindparams(codusuario=codUsuario)
        sql = sql.bindparams(data=strtodatetime(data, '%d/%m/%Y %H:%M:%S'))
        #print(sql)
        conn.execute(sql)
        return 0
    except Exception as e:
        print('Erro em edi.dao.insPessoaLog')
        print(e)
        return -1


def getPessoaLogEdi(conn, campos):
    try:
        #
        if campos['tipo_usuario'] and campos['tipo_usuario'] != 'T':
            sqlTipoUsuario = 'AND pl.tipousuario = \'' + campos['tipo_usuario'] + '\' '
        else:
            sqlTipoUsuario = ''
        #
        if campos['insts']:
            sqlInsts = 'AND pl.codinstalacao IN (\'' + campos['insts'] + '\') '
        else:
            sqlInsts = ''
        #
        if campos['usuario_coduf'] and campos['usuario_coduf'] != '0':
            sqlUsuarioCodUF = 'AND c.uf = \'' + campos['usuario_coduf'] + '\' '
        else:
            sqlUsuarioCodUF = ''
        #
        if campos['usuario_cnpjcpf']:
            sqlUsuarioCNPJCPF = 'AND p.cnpjcpf = \'' + campos['usuario_cnpjcpf'] + '\' '
        else:
            sqlUsuarioCNPJCPF = ''
        #
        if campos['usuario_ie']:
            sqlUsuarioIE = 'AND p.inscricaoestadual = \'' + campos['usuario_ie'] + '\' '
        else:
            sqlUsuarioIE = ''
        #
        sql = text('SELECT DISTINCT '
                   'pl.codinstalacao, pl.tipousuario, pl.codusuario, TO_CHAR(pl.data,\'YYYY/MM/DD HH:MM:SS\') data, '
                   'p.nome nomepessoa, p.cnpjcpf, p.inscricaoestadual, p.fone, p.celular, p.email, '
                   'c.nome nomecidade, c.uf '
                   'FROM pessoalog pl ' +
                   'JOIN pessoa p ON pl.codpessoa = p.codpessoa ' +
                   'JOIN cidade c ON p.codcidade = c.codcidade ' +
                   'WHERE pl.data BETWEEN :data_ini AND :data_fim ' +
                   sqlTipoUsuario +
                   sqlInsts +
                   sqlUsuarioCodUF +
                   sqlUsuarioCNPJCPF +
                   sqlUsuarioIE +
                   'ORDER BY pl.codinstalacao, pl.tipousuario, pl.codusuario, data, nomepessoa, c.uf, nomecidade'
                   )
        sql = sql.bindparams(data_ini=strtodatetime(campos['data_ini'], '%d/%m/%Y %H:%M:%S'))
        sql = sql.bindparams(data_fim=strtodatetime(campos['data_fim'], '%d/%m/%Y %H:%M:%S'))
        # print(sql)
        rs = conn.execute(sql)
        dados = rs.fetchall()
        #
        return json.dumps([dict(d) for d in dados])
    except Exception as e:
        print('Erro em edi.dao.getPessoaLogEdi')
        print(e)
        return ''


######################################################################
# VIAGEM
######################################################################
def existViagem(conn, codinstalacao, numerosor):
    try:
        sql = text('SELECT codviagem '
                   'FROM viagem '
                   'WHERE codinstalacao = :codinstalacao '
                   'AND numerosor = :numerosor'
                   )
        sql = sql.bindparams(codinstalacao=codinstalacao)
        sql = sql.bindparams(numerosor=numerosor)
        # print(sql)
        rs = conn.execute(sql)
        dados = rs.fetchone()
        if dados is not None and int(dados['codviagem']) > 0:
            return int(dados['codviagem'])
        else:
            return 0
    except Exception as e:
        print('Erro em edi.dao.existViagem')
        print(e)
        return -1


def insViagem(conn, campos,
              codInstalacao, codFilialSor, codFilial,
              codRemetente, codDestinatario,
              codColeta, codEntrega,
              codCidOrigem, codCidDestino,
              codProprietario, codMotorista,
              codMercadoria, codVeiculo,
              valor, txt):
    try:
        #
        codViagem = existViagem(conn, codInstalacao, campos['NUMERO'])
        if codViagem <= 0:
            sql = text('INSERT INTO viagem ('
                       'codinstalacao, codfilialsor, codfilial, '
                       'data, numerosor, numconhec, serie, tipocte, '
                       'codremetente, coddestinatario, '
                       'codcoleta, codentrega, '
                       'codcidorigem, codciddestino, '
                       'codproprietario, codmotorista, '
                       'codmercadoria, codveiculo, '
                       'freteempresa, fretemotorista, '
                       'pesosaida, pesochegada, '
                       'status, txt'
                       ') '
                       'VALUES ('
                       ':codinstalacao, :codfilialsor, :codfilial, '
                       ':data, :numerosor, :numconhec, :serie, :tipocte, '
                       ':codremetente, :coddestinatario, '
                       ':codcoleta, :codentrega, '
                       ':codcidorigem, :codciddestino, '
                       ':codproprietario, :codmotorista, '
                       ':codmercadoria, :codveiculo, '
                       ':freteempresa, :fretemotorista, '
                       ':pesosaida, :pesochegada, '
                       ':status, :txt'
                       ')')
            sql = sql.bindparams(codinstalacao=codInstalacao)
            sql = sql.bindparams(codfilialsor=codFilialSor)
            sql = sql.bindparams(codfilial=codFilial)
            if len(campos['DATA']) == 19:
                sql = sql.bindparams(data=strtodatetime(campos['DATA'], '%d/%m/%Y %H:%M:%S'))
            else:
                sql = sql.bindparams(data=strtodatetime(campos['DATA'], '%d/%m/%Y %H:%M:%S.%f'))
            sql = sql.bindparams(numerosor=int(campos['NUMERO']))
            sql = sql.bindparams(numconhec=int(campos['NUMEROCONHECIMENTO']))
            sql = sql.bindparams(serie=campos['SERIE'])
            sql = sql.bindparams(tipocte=campos['TIPOCTE'])
            sql = sql.bindparams(codremetente=codRemetente)
            sql = sql.bindparams(coddestinatario=codDestinatario)
            sql = sql.bindparams(codcoleta=codColeta)
            sql = sql.bindparams(codentrega=codEntrega)
            sql = sql.bindparams(codcidorigem=codCidOrigem)
            sql = sql.bindparams(codciddestino=codCidDestino)
            sql = sql.bindparams(codproprietario=codProprietario)
            sql = sql.bindparams(codmotorista=codMotorista)
            sql = sql.bindparams(codmercadoria=codMercadoria)
            sql = sql.bindparams(codveiculo=codVeiculo)
            sql = sql.bindparams(freteempresa=valor)
            sql = sql.bindparams(fretemotorista=float(campos['FRETEMOTORISTA'].replace(',', '.')))
            sql = sql.bindparams(pesosaida=float(campos['PESOSAIDA'].replace(',', '.')))
            sql = sql.bindparams(pesochegada=float(campos['PESOCHEGADA'].replace(',', '.')))
            sql = sql.bindparams(status='A')
            sql = sql.bindparams(txt=clearUnicodeNoASCII(txt))
            # print(sql)
            conn.execute(sql)
            codViagem = existViagem(conn, codInstalacao, campos['NUMERO'])
        else:
            sql = text('UPDATE viagem SET txt = :txt WHERE codviagem = :codviagem')
            sql = sql.bindparams(txt=clearUnicodeNoASCII(txt))
            sql = sql.bindparams(codviagem=codViagem)
            conn.execute(sql)
        return codViagem
    except Exception as e:
        print('Erro em edi.dao.insViagem')
        print(e)
        return -1


def cancViagem(conn, codinstalacao, numerosor):
    try:
        sql = text('UPDATE viagem SET status = :status '
                   'WHERE codinstalacao = :codinstalacao '
                   'AND numerosor = :numerosor'
                   )
        sql = sql.bindparams(status='C')
        sql = sql.bindparams(codinstalacao=codinstalacao)
        sql = sql.bindparams(numerosor=numerosor)
        # print(sql)
        conn.execute(sql)
        return existViagem(conn, codinstalacao, numerosor)
    except Exception as e:
        print('Erro em edi.dao.cancViagem')
        print(e)
        return -1


def getViagem(conn, connEMonitor, codInstalacao, ultCodViagem):
    try:
        listCnpjCpf = getCnpjCpfsInstalacao(connEMonitor, codInstalacao)
        if len(listCnpjCpf) > 0:
            primeiraVez = True
            sqlCnpjCpf = 'AND ('
            for cnpjCpf in listCnpjCpf:
                if primeiraVez:
                    primeiraVez = False
                    sqlCnpjCpf += 'p.cnpjcpf LIKE \'' + cnpjCpf + '%\' '
                else:
                    sqlCnpjCpf += 'OR p.cnpjcpf LIKE \'' + cnpjCpf + '%\' '
            sqlCnpjCpf += ') '
        else:
            sqlCnpjCpf = 'AND 1 = 2 '
        sql = text('SELECT DISTINCT v.* FROM viagem v JOIN pessoa p ON v.codproprietario = p.codpessoa '
                   'WHERE ((v.data >= NOW() - INTERVAL \'45 DAY\' AND v.status != \'C\' AND v.codviagem > ' + str(ultCodViagem) + ') ' +
                   'OR (v.data >= NOW() - INTERVAL \'5 DAY\' AND v.status = \'C\')) ' +
                   sqlCnpjCpf +
                   'ORDER BY v.codviagem'
                   )
        # print(sql)
        rs = conn.execute(sql)
        dados = rs.fetchall()
        listRet = list()
        for viagem in dados:
            listRet.append('<viagem>')
            #
            listRet.append(createtag('codediviagem',str(viagem['codviagem'])))
            listRet.append(createtag('data',str(viagem['data'])))
            listRet.append(createtag('numconhec',str(viagem['numconhec'])))
            listRet.append(createtag('serie',str(viagem['serie'])))
            listRet.append(createtag('tipocte',str(viagem['tipocte'])))
            listRet.append(createtag('fretemotorista',str(viagem['fretemotorista'])))
            listRet.append(createtag('pesosaida',str(viagem['pesosaida'])))
            listRet.append(createtag('pesochegada',str(viagem['pesochegada'])))
            listRet.append(createtag('status',str(viagem['status'])))
            listRet.append(createtag('txt',base64.b64encode(gzip.compress(viagem['txt'].encode())).decode()))
            #
            codPessoa = viagem['codfilial']
            dadosPessoa = findPessoa(conn, codPessoa)
            if dadosPessoa is None:
                return '' # nao deve entrar aqui em CNTP
            listRet.append(createtag('clinome', str(dadosPessoa['nome'])))
            listRet.append(createtag('clicnpjcpf', str(dadosPessoa['cnpjcpf'])))
            listRet.append(createtag('cliie', str(dadosPessoa['inscricaoestadual'])))
            #
            codPessoa = viagem['codcoleta']
            dadosPessoa = findPessoa(conn, codPessoa)
            if dadosPessoa is not None:
                listRet.append(createtag('colnome', str(dadosPessoa['nome'])))
                listRet.append(createtag('colcnpjcpf', str(dadosPessoa['cnpjcpf'])))
                listRet.append(createtag('colie', str(dadosPessoa['inscricaoestadual'])))
            #
            codPessoa = viagem['codentrega']
            dadosPessoa = findPessoa(conn, codPessoa)
            if dadosPessoa is not None:
                listRet.append(createtag('entnome', str(dadosPessoa['nome'])))
                listRet.append(createtag('entcnpjcpf', str(dadosPessoa['cnpjcpf'])))
                listRet.append(createtag('entie', str(dadosPessoa['inscricaoestadual'])))
            #
            codCidade = viagem['codcidorigem']
            dadosCidade = findCidade(conn, codCidade)
            if dadosCidade is None:
                return '' # nao deve entrar aqui em CNTP
            listRet.append(createtag('orignome', str(dadosCidade['nome'])))
            listRet.append(createtag('origuf', str(dadosCidade['uf'])))
            listRet.append(createtag('origibge', str(dadosCidade['codibge'])))
            #
            codCidade = viagem['codciddestino']
            dadosCidade = findCidade(conn, codCidade)
            if dadosCidade is None:
                return '' # nao deve entrar aqui em CNTP
            listRet.append(createtag('destnome', str(dadosCidade['nome'])))
            listRet.append(createtag('destuf', str(dadosCidade['uf'])))
            listRet.append(createtag('destibge', str(dadosCidade['codibge'])))
            #
            codVeiculo = viagem['codveiculo']
            dadosVeiculo = findVeiculo(conn, codVeiculo)
            if dadosVeiculo is None:
                return '' # nao deve entrar aqui em CNTP
            listRet.append(createtag('placa', str(dadosVeiculo['placa'])))
            #
            codPessoa = viagem['codproprietario']
            dadosPessoa = findPessoa(conn, codPessoa)
            if dadosPessoa is None:
                return ''  # nao deve entrar aqui em CNTP
            listRet.append(createtag('propnome', str(dadosPessoa['nome'])))
            listRet.append(createtag('propcnpjcpf', str(dadosPessoa['cnpjcpf'])))
            listRet.append(createtag('propie', str(dadosPessoa['inscricaoestadual'])))
            #
            codPessoa = viagem['codmotorista']
            dadosPessoa = findPessoa(conn, codPessoa)
            if dadosPessoa is None:
                return ''  # nao deve entrar aqui em CNTP
            listRet.append(createtag('motnome', str(dadosPessoa['nome'])))
            listRet.append(createtag('motcpf', str(dadosPessoa['cnpjcpf'])))
            #
            codMercadoria = viagem['codmercadoria']
            dadosMercadoria = findMercadoria(conn, codMercadoria)
            if dadosMercadoria is None:
                return ''  # nao deve entrar aqui em CNTP
            listRet.append(createtag('mercdescricao', str(dadosMercadoria['descricao'])))
            listRet.append(createtag('mercncm', str(dadosMercadoria['ncm'])))
            #
            listRet.append('</viagem>')
        #
        return ''.join(listRet)
    except Exception as e:
        print('Erro em edi.dao.getViagem - inst: ' + str(codInstalacao) + ' - ultCodViagem: ' + str(ultCodViagem))
        print(e)
        return ''


######################################################################
# METODOS ABAIXO SEMELHANTES AOS CRIADOS PARA CADASTRO DE TABELAS DO EDI, MAS AGORA PRA GERRISCO
######################################################################

def insPessoaFilialGerRisco(conn, campos):
    try:
        nome = campos['nomeFilial']
        cnpjcpf = campos['cnpjCpfFilial']
        inscricaoestadual = campos['ieFilial']
        codcidade = insCidade(conn, campos['cidadeFilial'], campos['ufFilial'], campos['codIBGEFilial'])
        return insPessoa(conn, nome, cnpjcpf, inscricaoestadual, codcidade)
    except Exception as e:
        print('Erro em edi.dao.insPessoaFilialGerRisco')
        print(e)
        return -1


def insPessoaEmpresasGerRisco(conn, campos):
    try:
        nome = campos['nomeEmpresas']
        cnpjcpf = campos['cnpjCpfEmpresas']
        inscricaoestadual = campos['ieEmpresas']
        codcidade = insCidade(conn, campos['cidadeEmpresas'], campos['ufEmpresas'], campos['codIBGEEmpresas'])
        return insPessoa(conn, nome, cnpjcpf, inscricaoestadual, codcidade)
    except Exception as e:
        print('Erro em edi.dao.insPessoaEmpresasGerRisco')
        print(e)
        return -1


def insPessoaProprietarioGerRisco(conn, campos):
    try:
        nome = campos['nomeProp']
        cnpjcpf = campos['cnpjCpfProp']
        inscricaoestadual = campos['ieProp']
        codcidade = insCidade(conn, campos['cidadeProp'], campos['ufProp'], campos['codIBGEProp'])
        return insPessoa(conn, nome, cnpjcpf, inscricaoestadual, codcidade)
    except Exception as e:
        print('Erro em edi.dao.insPessoaProprietarioGerRisco')
        print(e)
        return -1


def insPessoaMotoristaGerRisco(conn, campos):
    try:
        nome = campos['nomeMot']
        cnpjcpf = campos['cpfMot']
        inscricaoestadual = ''
        codcidade = insCidade(conn, campos['cidadeMot'], campos['ufMot'], campos['codIBGEMot'])
        return insPessoa(conn, nome, cnpjcpf, inscricaoestadual, codcidade)
    except Exception as e:
        print('Erro em edi.dao.insPessoaMotoristaGerRisco')
        print(e)
        return -1


def insPessoaClienteGerRisco(conn, campos):
    try:
        nome = campos['nomeCl']
        cnpjcpf = campos['cnpjCpfCl']
        inscricaoestadual = campos['ieCl']
        codcidade = insCidade(conn, campos['cidadeCl'], campos['ufCl'], campos['codIBGECl'])
        return insPessoa(conn, nome, cnpjcpf, inscricaoestadual, codcidade)
    except Exception as e:
        print('Erro em edi.dao.insPessoaClienteGerRisco')
        print(e)
        return -1


def insPessoaFornecedorGerRisco(conn, campos, sufixo):
    try:
        nome = campos['nomeForn'+sufixo]
        if nome is None or nome == '':
            return -999
        cnpjcpf = campos['cnpjCpfForn'+sufixo]
        inscricaoestadual = campos['ieForn'+sufixo]
        codcidade = insCidade(conn, campos['cidadeForn'+sufixo], campos['ufForn'+sufixo], campos['codIBGEForn'+sufixo])
        return insPessoa(conn, nome, cnpjcpf, inscricaoestadual, codcidade)
    except Exception as e:
        print('Erro em edi.dao.insPessoaFornecedorGerRisco')
        print(e)
        return -1


def insVeiculoGerRisco(conn, campos):
    try:
        placa = campos['placaVeiculo']
        #
        codVeiculo = existVeiculo(conn, placa)
        if codVeiculo <= 0:
            placa = placa.upper()
            sql = text('INSERT INTO veiculo (placa) VALUES (:placa)')
            sql = sql.bindparams(placa=placa)
            #print(sql)
            conn.execute(sql)
            codVeiculo = existVeiculo(conn, placa)
        return codVeiculo
    except Exception as e:
        print('Erro em edi.dao.insVeiculoGerRisco')
        print(e)
        return -1


######################################################################
# GERRISCO
######################################################################
def findGerRisco(conn, codGerRisco):
    try:
        sql = text('SELECT gr.nome, gr.cnpj '
                   'FROM gerrisco gr ' +
                   'WHERE gr.codGerRisco = ' + str(codGerRisco)
                   )
        #print(sql)
        rs = conn.execute(sql)
        return rs.fetchone()
    except Exception as e:
        print('Erro em edi.dao.findGerRisco')
        print(e)
        return None


def existGerRisco(conn, cnpj: str):
    try:
        cnpj = removeAccents(cnpj.upper())
        sql = text('SELECT codgerrisco '
                   'FROM gerrisco '
                   'WHERE cnpj = :cnpj'
                   )
        sql = sql.bindparams(cnpj=cnpj)
        #print(sql)
        rs = conn.execute(sql)
        dados = rs.fetchone()
        if dados is not None and int(dados['codgerrisco']) > 0:
            return int(dados['codgerrisco'])
        else:
            return 0
    except Exception as e:
        print('Erro em edi.dao.existGerRisco')
        print(e)
        return -1


def insGerRisco(conn, campos, sufixo):
    try:
        cnpj = campos['cnpjGr'+sufixo]
        if cnpj is None or cnpj == '':
            return -999
        #
        codGerRisco = existGerRisco(conn, cnpj)
        if codGerRisco <= 0:
            nome = campos['nomeGr'+sufixo]
            nome = removeAccents(nome.upper())
            sql = text('INSERT INTO gerrisco (nome, cnpj) VALUES (:nome, :cnpj)')
            sql = sql.bindparams(nome=nome)
            sql = sql.bindparams(cnpj=cnpj)
            #print(sql)
            conn.execute(sql)
            codGerRisco = existGerRisco(conn, cnpj)
        return codGerRisco
    except Exception as e:
        print('Erro em edi.dao.insGerRisco')
        print(e)
        return -1


def existViagemGerRisco(conn, codinstalacao, numerosor):
    try:
        sql = text('SELECT codviagemgerrisco '
                   'FROM viagemgerrisco '
                   'WHERE codinstalacao = :codinstalacao '
                   'AND numerosor = :numerosor'
                   )
        sql = sql.bindparams(codinstalacao=codinstalacao)
        sql = sql.bindparams(numerosor=numerosor)
        # print(sql)
        rs = conn.execute(sql)
        dados = rs.fetchone()
        if dados is not None and int(dados['codviagemgerrisco']) > 0:
            return int(dados['codviagemgerrisco'])
        else:
            return 0
    except Exception as e:
        print('Erro em edi.dao.existViagemGerRisco')
        print(e)
        return -1


def insViagemGerRisco(conn, campos,
              codInstalacao, codFilialSor, codFilial, codEmpresasSor, codEmpresas,
              codVeiculo, codProprietario, codMotorista, codCliente,
              codFornecedorAdiant, codFornecedorSaldo, codFornecedorPedagio,
              codGr, codGrPedagio):
    try:
        codViagemGerRisco = existViagemGerRisco(conn, codInstalacao, campos['numero'])
        if codViagemGerRisco <= 0:
            #
            sql = text('INSERT INTO viagemgerrisco ('
                       'codinstalacao, codfilialsor, codfilial, codempresassor, codempresas, '
                       'data, numerosor, '
                       'adiantamentomotorista, freteempresa, fretemotorista, valorpedagio, '
                       'tipofrete, ciot, tipoanttproprietario, '
                       'codveiculo, codproprietario, codmotorista, codcliente, '
                       'codfornecedoradiant, codfornecedorsaldo, codfornecedorpedagio, '
                       'codgerrisco, codgerriscopedagio '
                       ') '
                       'VALUES ('
                       ':codinstalacao, :codfilialsor, :codfilial, :codempresassor, :codempresas, '
                       ':data, :numerosor, '
                       ':adiantamentomotorista, :freteempresa, :fretemotorista, :valorpedagio, '
                       ':tipofrete, :ciot, :tipoanttproprietario, '
                       ':codveiculo, :codproprietario, :codmotorista, :codcliente, '
                       ':codfornecedoradiant, :codfornecedorsaldo, :codfornecedorpedagio, '
                       ':codgerrisco, :codgerriscopedagio '
                       ')')
            sql = sql.bindparams(codinstalacao=codInstalacao)
            sql = sql.bindparams(codfilialsor=codFilialSor)
            sql = sql.bindparams(codfilial=codFilial)
            sql = sql.bindparams(codempresassor=codEmpresasSor)
            sql = sql.bindparams(codempresas=codEmpresas)
            if len(campos['dataEmissao']) == 19:
                sql = sql.bindparams(data=strtodatetime(campos['dataEmissao'], '%d/%m/%Y %H:%M:%S'))
            else:
                sql = sql.bindparams(data=strtodatetime(campos['dataEmissao'], '%d/%m/%Y %H:%M:%S.%f'))
            sql = sql.bindparams(numerosor=int(campos['numero']))
            sql = sql.bindparams(adiantamentomotorista=campos['adiantamentoMotorista'].replace(',', '.'))
            sql = sql.bindparams(freteempresa=campos['freteEmpresa'].replace(',', '.'))
            sql = sql.bindparams(fretemotorista=campos['freteMotorista'].replace(',', '.'))
            sql = sql.bindparams(valorpedagio=campos['valorPedagio'].replace(',', '.'))
            sql = sql.bindparams(tipofrete=campos['tipoFrete'])
            sql = sql.bindparams(ciot=campos['ciot'])
            sql = sql.bindparams(tipoanttproprietario=campos['tipoAnttProp'])
            sql = sql.bindparams(codveiculo=codVeiculo)
            sql = sql.bindparams(codproprietario=codProprietario)
            sql = sql.bindparams(codmotorista=codMotorista)
            if codCliente > 0:
                sql = sql.bindparams(codcliente=codCliente)
            else:
                sql = sql.bindparams(codcliente=None)
            if codFornecedorAdiant > 0:
                sql = sql.bindparams(codfornecedoradiant=codFornecedorAdiant)
            else:
                sql = sql.bindparams(codfornecedoradiant=None)
            if codFornecedorSaldo > 0:
                sql = sql.bindparams(codfornecedorsaldo=codFornecedorSaldo)
            else:
                sql = sql.bindparams(codfornecedorsaldo=None)
            if codFornecedorPedagio > 0:
                sql = sql.bindparams(codfornecedorpedagio=codFornecedorPedagio)
            else:
                sql = sql.bindparams(codfornecedorpedagio=None)
            if codGr > 0:
                sql = sql.bindparams(codgerrisco=codGr)
            else:
                sql = sql.bindparams(codgerrisco=None)
            if codGrPedagio > 0:
                sql = sql.bindparams(codgerriscopedagio=codGrPedagio)
            else:
                sql = sql.bindparams(codgerriscopedagio=None)
            # print(sql)
            conn.execute(sql)
            codViagemGerRisco = existViagemGerRisco(conn, codInstalacao, campos['numero'])
        return codViagemGerRisco
    except Exception as e:
        print('Erro em edi.dao.insViagemGerRisco')
        print(e)
        return -1


def getViagemGerRisco(conn, dataIni, dataFim, cnpjGerRisco, cnpjGerRiscoPedagio, listaInstalacoes, tipoFrete, tipoAnttProprietario, apenasViagensOpCar, cnpjCpfBaseClienteTransp, dadosResumidos):
    try:
        #
        dataIni = dataIni + ' 00:00:00'
        dataFim = dataFim + ' 23:59:59'
        #
        sqlCnpjGerRisco = ''
        if cnpjGerRisco != 'T':
            cnpjGerRisco = cnpjGerRisco.replace(',','\',\'')
            sqlCnpjGerRisco = 'AND gr.cnpj IN (\'' + cnpjGerRisco + '\') '
        #
        sqlCnpjGerRiscoPedagio = ''
        if cnpjGerRiscoPedagio != 'T':
            cnpjGerRiscoPedagio = cnpjGerRiscoPedagio.replace(',','\',\'')
            sqlCnpjGerRiscoPedagio = 'AND grp.cnpj IN (\'' + cnpjGerRiscoPedagio + '\') '
        #
        sqlListaInstalacoes = ''
        if listaInstalacoes != '':
            sqlListaInstalacoes = 'AND v.codinstalacao IN (' + listaInstalacoes + ') '
        #
        sqlTipoFrete = ''
        if tipoFrete != 'T':
            if tipoFrete != 'AS':
                sqlTipoFrete = 'AND v.tipofrete = \'' + tipoFrete + '\' '
            else:
                sqlTipoFrete = 'AND v.tipofrete IN (\'A\',\'S\') '
        #
        sqlTipoAnttProprietario = ''
        if tipoAnttProprietario != 'T':
            sqlTipoAnttProprietario = 'AND v.tipoanttproprietario = ' + tipoAnttProprietario + ' '
        #
        sqlApenasViagensOpCar = ''
        if apenasViagensOpCar == 'S':
            sqlApenasViagensOpCar = 'AND (v.codgerrisco IS NOT NULL OR v.codgerriscopedagio IS NOT NULL) '
        #
        sqlCnpjCpfBaseClienteTransp = ''
        if len(cnpjCpfBaseClienteTransp) == 8:
            sqlCnpjCpfBaseClienteTransp = 'AND SUBSTRING(cl.cnpjcpf,1,8) = \'' + cnpjCpfBaseClienteTransp + '\''
            #
        if dadosResumidos:
            sql = text('SELECT '
                   'v.codinstalacao, gr.cnpj AS grcnpj, grp.cnpj AS grpcnpj, '
                   'cl.nome AS clnome, cl.cnpjcpf AS clcnpjcpf, cl.inscricaoestadual AS clie, cidcl.nome AS cidclnome, cidcl.uf AS cidcluf, cidcl.codibge AS cidclibge, '
                   'SUM(v.adiantamentomotorista) AS adiantamentomotorista, SUM(v.freteempresa) AS freteempresa, SUM(v.fretemotorista) AS fretemotorista, SUM(v.valorpedagio) AS valorpedagio, '
                   'COUNT(v.codviagemgerrisco) AS quant '
                   'FROM viagemgerrisco AS v '
                   'LEFT JOIN pessoa AS cl ON v.codcliente = cl.codpessoa '
                   'LEFT JOIN cidade AS cidcl ON cl.codcidade = cidcl.codcidade '
                   'LEFT JOIN gerrisco AS gr ON v.codgerrisco = gr.codgerrisco '
                   'LEFT JOIN gerrisco AS grp ON v.codgerriscopedagio = grp.codgerrisco '
                   'WHERE v.data BETWEEN :dataIni AND :dataFim ' +
                   sqlCnpjGerRisco + sqlCnpjGerRiscoPedagio + sqlListaInstalacoes +
                   sqlTipoFrete + sqlTipoAnttProprietario + sqlApenasViagensOpCar + sqlCnpjCpfBaseClienteTransp +
                   'GROUP BY v.codinstalacao, gr.cnpj, grp.cnpj, ' +
                   'cl.nome, cl.cnpjcpf, cl.inscricaoestadual, cidcl.nome, cidcl.uf, cidcl.codibge '
                   'ORDER BY v.codinstalacao, gr.cnpj, grp.cnpj')
        else:
            sql = text('SELECT DISTINCT '
                   'v.codviagemgerrisco, v.codinstalacao, v.data, gr.cnpj AS grcnpj, grp.cnpj AS grpcnpj, '
                   'cl.nome AS clnome, cl.cnpjcpf AS clcnpjcpf, cl.inscricaoestadual AS clie, cidcl.nome AS cidclnome, cidcl.uf AS cidcluf, cidcl.codibge AS cidclibge, '
                   'v.adiantamentomotorista, v.freteempresa, v.fretemotorista, v.valorpedagio, '
                   'v.tipofrete, v.ciot, v.tipoanttproprietario, 1 AS quant '
                   'FROM viagemgerrisco AS v '
                   'LEFT JOIN pessoa AS cl ON v.codcliente = cl.codpessoa '
                   'LEFT JOIN cidade AS cidcl ON cl.codcidade = cidcl.codcidade '
                   'LEFT JOIN gerrisco AS gr ON v.codgerrisco = gr.codgerrisco '
                   'LEFT JOIN gerrisco AS grp ON v.codgerriscopedagio = grp.codgerrisco '
                   'WHERE v.data BETWEEN :dataIni AND :dataFim ' +
                   sqlCnpjGerRisco + sqlCnpjGerRiscoPedagio + sqlListaInstalacoes +
                   sqlTipoFrete + sqlTipoAnttProprietario + sqlApenasViagensOpCar + sqlCnpjCpfBaseClienteTransp +
                   'ORDER BY v.codviagemgerrisco')
        sql = sql.bindparams(dataIni=strtodatetime(dataIni, '%d/%m/%Y %H:%M:%S'))
        sql = sql.bindparams(dataFim=strtodatetime(dataFim, '%d/%m/%Y %H:%M:%S'))
        # print(sql)
        rs = conn.execute(sql)
        dados = rs.fetchall()
        listRet = list()
        for viagem in dados:
            listRet.append('<v>')
            # gerando tags XMLs menores devido a grande quantidade de informacoes a retornar
            listRet.append(createtag('inst',str(viagem['codinstalacao'])))
            listRet.append(createtag('clnome',getstrnotempty(viagem['clnome'])))
            listRet.append(createtag('clcnpjcpf',getstrnotempty(viagem['clcnpjcpf'])))
            listRet.append(createtag('clie',getstrnotempty(viagem['clie'])))
            listRet.append(createtag('cidclnome',getstrnotempty(viagem['cidclnome'])))
            listRet.append(createtag('cidcluf',getstrnotempty(viagem['cidcluf'])))
            listRet.append(createtag('cidclibge',getstrnotempty(viagem['cidclibge'])))
            listRet.append(createtag('admot',str(viagem['adiantamentomotorista'])))
            listRet.append(createtag('fremp',str(viagem['freteempresa'])))
            listRet.append(createtag('frmot',str(viagem['fretemotorista'])))
            listRet.append(createtag('vlped',str(viagem['valorpedagio'])))
            listRet.append(createtag('quant',str(viagem['quant'])))
            if viagem['grcnpj'] is None:
                listRet.append(createtag('grcnpj','00000000000000'))
            else:
                listRet.append(createtag('grcnpj', viagem['grcnpj']))
            if viagem['grpcnpj'] is None:
                listRet.append(createtag('grpcnpj','00000000000000'))
            else:
                listRet.append(createtag('grpcnpj',viagem['grpcnpj']))
            #
            listRet.append('</v>')
        #
        return base64.b64encode(gzip.compress(bytes(''.join(listRet).encode()))).decode()
    except Exception as e:
        print('Erro em edi.dao.getViagemGerRisco - Periodo: ' + dataIni + ' a ' + dataFim + ' - inst(s). ' + listaInstalacoes)
        print(e)
        return ''


######################################################################
# Integracao com SISTEMAEXT
######################################################################


def insSistemaExt(conn, codInstalacao, codEmpresa, codEMonitorAcao, tipo, tpAmb, chave, url, dataReq, requestJSON, dataResp, responseJSON):
    #
    try:
        requestJSON = json.loads(requestJSON)
        chave = requestJSON[chave]
        if responseJSON['erro'] == 'f':
            status = EMONITORSPOOL_PROCESSADO
        else:
            status = EMONITORSPOOL_ERROPROCESSAMENTO
        #
        requestJSON = json.dumps(requestJSON)
        responseJSON = json.dumps(responseJSON)
        #
        sql = text('INSERT INTO sistemaext ('
                   'codinstalacao, codempresa, acao, tipo, '
                   'status, tpamb, chave, url, '
                   'datareq, req, dataresp, resp'
                   ') '
                   'VALUES ('
                   ':codinstalacao, :codempresa, :acao, :tipo, '
                   ':status, :tpamb, :chave, :url, '
                   ':datareq, :req, :dataresp, :resp'
                   ')')
        sql = sql.bindparams(codinstalacao=codInstalacao)
        sql = sql.bindparams(codempresa=codEmpresa)
        sql = sql.bindparams(acao=codEMonitorAcao)
        sql = sql.bindparams(tipo=tipo)
        sql = sql.bindparams(status=status)
        sql = sql.bindparams(tpamb=tpAmb)
        sql = sql.bindparams(chave=chave)
        sql = sql.bindparams(url=url)
        sql = sql.bindparams(datareq=strtodatetime(dataReq, '%d/%m/%Y %H:%M:%S'))
        sql = sql.bindparams(req=requestJSON)
        sql = sql.bindparams(dataresp=strtodatetime(dataResp, '%d/%m/%Y %H:%M:%S'))
        sql = sql.bindparams(resp=responseJSON)
        #
        # print(sql)
        conn.execute(sql)
        return True
        #
    except Exception as e:
        print('Erro em edi.dao.insSistemaExt: ' + str(codInstalacao) + '/' + str(codEmpresa) + ' - Acao:' + str(codEMonitorAcao) + ' - Tipo:' + str(tipo) + ' - Chave:' + chave + ' - URL:' + url)
        print(e)
        return False


