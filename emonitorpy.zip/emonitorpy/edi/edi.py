import base64
import gzip
import json

from geral import printdh, dateactualtostr, datetostr, incdatetimeactual
from metadata import getConnPG
from edi import dao


printlog = False


def insertViagem(engine, request):
    try:
        # parametros passados na URL
        codInstalacao = request.args.get('inst',type=int)
        codFilialSor = request.args.get('fil',type=int)
        valor = request.args.get('v',type=float) # Viagem.FreteEmpresa
        if codInstalacao <= 0:
            return '<erro>true</erro><msgRet>INSTALACAO ' + str(codInstalacao) + ' INVALIDA</msgRet>'
        if codFilialSor <= 0:
            return '<erro>true</erro><msgRet>FILIAL SOR ' + str(codFilialSor) + ' INVALIDA</msgRet>'
        #
        body = gzip.decompress(base64.b64decode(request.data.decode())).decode()
        #
        if printlog:
            printdh('Processando insertViagemEdi - Inst. ' + str(codInstalacao) + ' - Fil. ' + str(codFilialSor))
        #
        campos = {}
        dados = list(body.split('\n'))
        for lin in dados:
            if lin.startswith('*'):
                break
            s = lin.split('^')
            nomeCampo = s[0]
            valorCampo = s[1]
            if valorCampo[len(valorCampo)-1] == '\r':
                valorCampo = valorCampo[0:len(valorCampo) - 1]  # tirar \r do final do valorCampo
            valorCampo = valorCampo[0:len(valorCampo)-1] # tirar < do final do valorCampo
            campos[nomeCampo] = valorCampo
            #print(nomeCampo + ' = ' + valorCampo)
        #
        with getConnPG(engine) as conn:
            codMercadoria = dao.insMercadoria(conn, campos)
            if codMercadoria <= 0:
                return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE MERCADORIA</msgRet>'
            codVeiculo = dao.insVeiculo(conn, campos)
            if codVeiculo <= 0:
                return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE VEICULO</msgRet>'
            codCidOrigem = dao.insCidadeOrigem(conn, campos)
            if codCidOrigem <= 0:
                return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE CIDADE ORIGEM</msgRet>'
            codCidDestino = dao.insCidadeDestino(conn, campos)
            if codCidDestino <= 0:
                return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE CIDADE DESTINO</msgRet>'
            codMotorista = dao.insPessoaMotorista(conn, campos)
            if codMotorista <= 0:
                return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE MOTORISTA</msgRet>'
            codProprietario = dao.insPessoaProprietario(conn, campos)
            if codProprietario <= 0:
                return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE PROPRIETARIO</msgRet>'
            codFilial = dao.insPessoaFilial(conn, campos)
            if codFilial <= 0:
                return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE FILIAL/CLIENTE</msgRet>'
            codRemetente = dao.insPessoaRemetente(conn, campos)
            if codRemetente <= 0:
                return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE CLIENTE REMETENTE</msgRet>'
            codDestinatario = dao.insPessoaDestinatario(conn, campos)
            if codDestinatario <= 0:
                return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE CLIENTE DESTINATARIO</msgRet>'
            codColeta = dao.insPessoaColeta(conn, campos)
            if codColeta <= 0:
                codColeta = codRemetente
            codEntrega = dao.insPessoaEntrega(conn, campos)
            if codEntrega <= 0:
                codEntrega = codDestinatario
            codViagem = dao.insViagem(conn, campos,
                          codInstalacao, codFilialSor, codFilial,
                          codRemetente, codDestinatario,
                          codColeta, codEntrega,
                          codCidOrigem, codCidDestino,
                          codProprietario, codMotorista,
                          codMercadoria, codVeiculo,
                          valor, body)
            #
            if codViagem > 0:
                return '<erro>false</erro><msgRet>VIAGEM ' + str(codViagem) + ' INSERIDA COM SUCESSO NO EDI</msgRet>'
            else:
                return '<erro>true</erro><msgRet>ERRO AO INSERIR VIAGEM ' + str(codViagem) + '</msgRet>'
    except Exception as e:
        print('Erro em insertViagem')
        print(e)
        return '<erro>true</erro><msgRet>EXCECAO insertViagem: ' + str(e) + '</msgRet>'


def cancelViagem(engine, request):
    try:
        # parametros passados na URL
        codInstalacao = request.args.get('inst',type=int)
        codFilialSor = request.args.get('fil',type=int)
        numeroSor = request.args.get('num',type=int)
        if codInstalacao <= 0:
            return '<erro>true</erro><msgRet>INSTALACAO ' + str(codInstalacao) + ' INVALIDA</msgRet>'
        if codFilialSor <= 0:
            return '<erro>true</erro><msgRet>FILIAL SOR ' + str(codFilialSor) + ' INVALIDA</msgRet>'
        if numeroSor <= 0:
            return '<erro>true</erro><msgRet>NUMERO SOR ' + str(numeroSor) + ' INVALIDO</msgRet>'
        #
        if printlog:
            printdh('Processando cancelViagemEdi - Inst. ' + str(codInstalacao) + ' - Fil. ' + str(codFilialSor) + ' - Num. ' + str(numeroSor))
        #
        with getConnPG(engine) as conn:
            codViagem = dao.cancViagem(conn, codInstalacao, numeroSor)
            #
            if codViagem > 0:
                return '<erro>false</erro><msgRet>VIAGEM ' + str(codViagem) + ' CANCELADA COM SUCESSO NO EDI</msgRet>'
            else:
                return '<erro>true</erro><msgRet>VIAGEM ' + str(codViagem) + ' NAO ENCONTRADA PARA SER CANCELADA</msgRet>'
    except Exception as e:
        print('Erro em cancelViagem')
        print(e)
        return '<erro>true</erro><msgRet>EXCECAO cancelViagem: ' + str(e) + '</msgRet>'


def getViagem(engine, engineEMonitor, request):
    try:
        # parametros passados na URL
        codInstalacao = request.args.get('inst',type=int)
        ultCodViagem = request.args.get('ultcodviagem',type=int)
        if codInstalacao <= 0:
            return '<erro>true</erro><msgRet>INSTALACAO ' + str(codInstalacao) + ' INVALIDA</msgRet>'
        if ultCodViagem < 0:
            ultCodViagem = 0
        #
        if printlog:
            printdh('Processando getViagem - Inst. ' + str(codInstalacao) + ' - Ult.Cod.Viagem ' + str(ultCodViagem))
        #
        with getConnPG(engine) as conn:
            with getConnPG(engineEMonitor) as connEMonitor:
                xml = dao.getViagem(conn, connEMonitor, codInstalacao, ultCodViagem)
                if xml == '':
                    return '<erro>true</erro><msgRet>NENHUMA VIAGEM ENCONTRADA</msgRet>'
                else:
                    return '<erro>false</erro><msgRet>' + xml + '</msgRet>'
    except Exception as e:
        print('Erro em getViagem')
        print(e)
        return '<erro>true</erro><msgRet>EXCECAO getViagem: ' + str(e) + '</msgRet>'


def insertViagemGerRisco(engine, request):
    try:
        # parametros passados na URL
        codInstalacao = request.args.get('inst',type=int)
        if codInstalacao <= 0:
            return '<erro>true</erro><msgRet>INSTALACAO ' + str(codInstalacao) + ' INVALIDA</msgRet>'
        #
        body = gzip.decompress(base64.b64decode(request.data.decode())).decode()
        viagens = json.loads(body)
        #
        if printlog:
            printdh('Processando insertViagemGerRisco - Inst. ' + str(codInstalacao))
        #
        with getConnPG(engine) as conn:
            for viagem in viagens:
                numeroSor = viagem['numero']
                #
                try:
                    codFilial = dao.insPessoaFilialGerRisco(conn, viagem)
                    if codFilial <= 0:
                        return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE FILIAL DA VIAGEM ' + numeroSor + '</msgRet>'
                    #
                    codEmpresas = dao.insPessoaEmpresasGerRisco(conn, viagem)
                    if codEmpresas <= 0:
                        return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE EMPRESA DA VIAGEM ' + numeroSor + '</msgRet>'
                    #
                    codVeiculo = dao.insVeiculoGerRisco(conn, viagem)
                    if codVeiculo <= 0:
                        return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE VEICULO DA VIAGEM ' + numeroSor + '</msgRet>'
                    #
                    codProprietario = dao.insPessoaProprietarioGerRisco(conn, viagem)
                    if codProprietario <= 0:
                        return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE PROPRIETARIO DA VIAGEM ' + numeroSor + '</msgRet>'
                    #
                    codMotorista = dao.insPessoaMotoristaGerRisco(conn, viagem)
                    if codMotorista <= 0:
                        return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE MOTORISTA DA VIAGEM ' + numeroSor + '</msgRet>'
                    #
                    codCliente = dao.insPessoaClienteGerRisco(conn, viagem)
                    if codCliente <= 0:
                        # return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE CLIENTE DA VIAGEM ' + numeroSor + '</msgRet>'
                        codCliente = -999 # como cliente foi incluido depois, deixar por um tempo desta forma ate que todos os SORs SS/timerSor e SAT estejam atualizados
                    #
                    codFornecedorAdiant = dao.insPessoaFornecedorGerRisco(conn, viagem, 'Adiant')
                    if codFornecedorAdiant <= 0 and codFornecedorAdiant != -999:
                        return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE FORNECEDOR DE ADIANTAMENTO DA VIAGEM ' + numeroSor + '</msgRet>'
                    #
                    codFornecedorSaldo = dao.insPessoaFornecedorGerRisco(conn, viagem, 'Saldo')
                    if codFornecedorSaldo <= 0 and codFornecedorSaldo != -999:
                        return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE FORNECEDOR DE SALDO DA VIAGEM ' + numeroSor + '</msgRet>'
                    #
                    codFornecedorPedagio = dao.insPessoaFornecedorGerRisco(conn, viagem, 'Pedagio')
                    if codFornecedorPedagio <= 0 and codFornecedorPedagio != -999:
                        return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE FORNECEDOR DE PEDAGIO DA VIAGEM ' + numeroSor + '</msgRet>'
                    #
                    codGr = dao.insGerRisco(conn, viagem, '')
                    if codGr <= 0 and codGr != -999:
                        return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE OPERADORA DE CARTAO DE ADIANTAMENTO E/OU SALDO DA VIAGEM ' + numeroSor + '</msgRet>'
                    #
                    codGrPedagio = dao.insGerRisco(conn, viagem, 'Pedagio')
                    if codGrPedagio <= 0 and codGrPedagio != -999:
                        return '<erro>true</erro><msgRet>ERRO DE INSERCAO DE OPERADORA DE CARTAO DE PEDAGIO DA VIAGEM ' + numeroSor + '</msgRet>'
                    #
                    codFilialSor = viagem['codFilial']
                    codEmpresasSor = viagem['codEmpresas']
                    codViagemGerRisco = dao.insViagemGerRisco(conn, viagem,
                                  codInstalacao, codFilialSor, codFilial, codEmpresasSor, codEmpresas,
                                  codVeiculo, codProprietario, codMotorista, codCliente,
                                  codFornecedorAdiant, codFornecedorSaldo, codFornecedorPedagio,
                                  codGr, codGrPedagio)
                    if codViagemGerRisco == -1:
                        print('Erro em insertViagemGerRisco da viagem ' + numeroSor)
                    else:
                        print('insertViagemGerRisco - Viagem ' + numeroSor + ' inserida!')
                    #
                except Exception as e:
                    print('Erro em insertViagemGerRisco da viagem ' + numeroSor + '... continuando na proxima')
                    print(e)
            #
            return '<erro>false</erro><msgRet>VIAGENS INSERIDAS COM SUCESSO NO GERRISCO</msgRet>'
    except Exception as e:
        print('Erro em insertViagemGerRisco')
        print(e)
        return '<erro>true</erro><msgRet>EXCECAO insertViagemGerRisco: ' + str(e) + '</msgRet>'


def getViagemGerRisco(engine, request, dadosResumidos):
    try:
        # parametros passados na URL
        dataIni = request.args.get('di', type=str)
        if dataIni is None or dataIni == '':
            dataIni = datetostr(incdatetimeactual(-30))
        dataFim = request.args.get('df', type=str)
        if dataFim is None or dataFim == '':
            dataFim = dateactualtostr()
        #
        cnpjGerRisco = request.args.get('cnpjgr',type=str)
        if cnpjGerRisco is None or cnpjGerRisco == '':
            cnpjGerRisco = 'T'
        #
        cnpjGerRiscoPedagio = request.args.get('cnpjgrp',type=str)
        if cnpjGerRiscoPedagio is None or cnpjGerRiscoPedagio == '':
            cnpjGerRiscoPedagio = 'T'
        #
        listaInstalacoes = request.args.get('insts',type=str)
        if listaInstalacoes is None:
            listaInstalacoes = ''
        #
        tipoFrete = request.args.get('tf',type=str)
        if tipoFrete is None or tipoFrete == '':
            tipoFrete = 'T'
        #
        tipoAnttProprietario = request.args.get('tap',type=str)
        if tipoAnttProprietario is None or tipoAnttProprietario == '':
            tipoAnttProprietario = 'T'
        #
        apenasViagensOpCar = request.args.get('voc',type=str)
        if apenasViagensOpCar is None or apenasViagensOpCar == '':
            apenasViagensOpCar = 'S'
        #
        cnpjCpfBaseClienteTransp = request.args.get('basecltr',type=str)
        if cnpjCpfBaseClienteTransp is None:
            cnpjCpfBaseClienteTransp = ''
        if len(cnpjCpfBaseClienteTransp) > 8:
            cnpjCpfBaseClienteTransp = cnpjCpfBaseClienteTransp[0:8]
        #
        if printlog:
            printdh('Processando getViagemGerRisco - Periodo: ' + dataIni + ' a ' + dataFim + ' - inst(s). ' + listaInstalacoes)
        #
        with getConnPG(engine) as conn:
            xml = dao.getViagemGerRisco(conn, dataIni, dataFim, cnpjGerRisco, cnpjGerRiscoPedagio, listaInstalacoes, tipoFrete, tipoAnttProprietario, apenasViagensOpCar, cnpjCpfBaseClienteTransp, dadosResumidos)
            if xml == '':
                return '<erro>true</erro><msgRet>NENHUMA VIAGEM ENCONTRADA</msgRet>'
            else:
                return '<erro>false</erro><msgRet>' + xml + '</msgRet>'
    except Exception as e:
        print('Erro em getViagemGerRisco')
        print(e)
        return '<erro>true</erro><msgRet>EXCECAO getViagemGerRisco: ' + str(e) + '</msgRet>'


def insertPessoaLogEdi(engine, request):
    try:
        # parametros passados na URL
        codInstalacao = request.args.get('inst',type=int)
        if codInstalacao <= 0:
            return {'erro': 'true', 'msgRet': 'INSTALACAO ' + str(codInstalacao) + ' INVALIDA'}
        tipoUsuario = __getTipoUsuario(request.args.get('tipoUsuario',type=str))
        codUsuario = request.args.get('codUsuario',type=int)
        #
        body = base64.b64decode(request.data.decode())
        campos = json.loads(body)
        #
        if printlog:
            printdh('Processando insertPessoaLogEdi - Inst. ' + str(codInstalacao))
        #
        with getConnPG(engine) as conn:
            codCidade = dao.insCidadeCampos(conn, campos)
            if codCidade <= 0:
                return {'erro': 'true', 'msgRet': 'ERRO DE INSERCAO DE CIDADE - INST.=' + str(codInstalacao) + ', TIPOUSUARIO=' + tipoUsuario + ', CODUSUARIO=' + str(codUsuario)}
            codPessoa = dao.insPessoaCampos(conn, campos, codCidade)
            if codPessoa <= 0:
                return {'erro': 'true', 'msgRet': 'ERRO DE INSERCAO DE PESSOA - INST.=' + str(codInstalacao) + ', TIPOUSUARIO=' + tipoUsuario + ', CODUSUARIO=' + str(codUsuario)}
            codPessoaLog = dao.insPessoaLog(conn, codPessoa, codInstalacao, tipoUsuario, codUsuario, campos['data'])
            if codPessoaLog == 0:
                return {'erro': 'false', 'msgRet': 'PESSOALOG INSERIDA COM SUCESSO - INST.=' + str(codInstalacao) + ', TIPOUSUARIO=' + tipoUsuario + ', CODUSUARIO=' + str(codUsuario)}
            else:
                return {'erro': 'true', 'msgRet': 'ERRO AO INSERIR PESSOALOG - INST.=' + str(codInstalacao) + ', TIPOUSUARIO=' + tipoUsuario + ', CODUSUARIO=' + str(codUsuario)}
    except Exception as e:
        print('Erro em insertPessoaLogEdi')
        print(e)
        return {'erro': 'true', 'msgRet': 'EXCECAO insertPessoaLogEdi: ' + str(e)}


def __getTipoUsuario(tipoUsuario):
    if tipoUsuario == '1': # TIPOUSUARIO_INTRANET
        return 'I'
    elif tipoUsuario == '2': # TIPOUSUARIO_CLIENTE
        return 'C'
    elif tipoUsuario == '3': # TIPOUSUARIO_FORN
        return 'F'
    elif tipoUsuario == '4': # TIPOUSUARIO_PROP
        return 'P'
    elif tipoUsuario == '5': # TIPOUSUARIO_FUNC
        return 'N'
    else: # na verdade nunca deve entrar aqui
        return ''


def getPessoaLogEdi(engine, request):
    try:
        #
        body = base64.b64decode(request.data.decode())
        campos = json.loads(body)
        #
        if printlog:
            printdh('Processando getPessoaLogEdi ' +
                    campos['data_ini'] + ' a ' + campos['data_fim'] +
                    ', Tipo Usuário: ' + campos['tipo_usuario'] +
                    ', Instalações: ' + campos['insts'] +
                    ', UF/Usuário: ' + campos['usuario_coduf'] +
                    ', CNPJ/CPF/Usuário: ' + campos['usuario_cnpjcpf'] +
                    ', IE/Usuário: ' + campos['usuario_ie'])
        #
        with getConnPG(engine) as conn:
            ret = dao.getPessoaLogEdi(conn, campos)
            if ret == '':
                return {'erro': 'true', 'msgRet': 'NENHUM LOG ENCONTRADO'}
            else:
                return {'erro': 'false', 'msgRet': ret}
    except Exception as e:
        print('Erro em getPessoaLogEdi')
        print(e)
        return {'erro': 'true', 'msgRet': 'EXCECAO getPessoaLogEdi: ' + str(e)}


