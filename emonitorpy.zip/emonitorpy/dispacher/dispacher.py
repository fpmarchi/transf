import logging
from inspect import signature, Parameter
from typing import Callable, Tuple, Union, Any, List, Dict

from dispacher.decorators import parse_props, handle_exception_factory

Callable_cfg = Dict[
    Union[int, str],
    Union[
        Callable,
        Tuple[Callable, dict]
    ]
]


class Dispacher:
    MIN_ACTION = 0
    MAX_ACTION = 0
    DEFAULT_FUNCTION = 0

    context = {}

    _custom_records = None
    __instance = None

    @classmethod
    def get_instance(cls, min_action: int, max_action: int):
        cls.MIN_ACTION = min_action
        cls.MAX_ACTION = max_action

        if cls.__instance:
            return cls.__instance
        else:
            return cls()

    def __new__(cls, *args, **kwargs):
        instance = super().__new__(cls)
        cls.__instance = instance
        instance._custom_records = {}
        return instance

    def is_recognized_action(self, action_cod: int, ignore: List[int] = None, check_records: list = None) -> bool:
        """
            Verifica que os código passado está entre os valores definidos nas constantes
            MIN_ACTION e MAX_ACTION.

            :param action_cod: (Int)
                Código da a ação a ser verificada.
            :param ignore: (List[int])
                List comas ações ignoradas pela função.
            :return: (bool) Retorna True ou False.
        """

        if ignore and (action_cod in ignore):
            return False

        recognized = self.MIN_ACTION <= action_cod <= self.MAX_ACTION

        if recognized is False or not check_records:
            return recognized

        for x in check_records:
            test = self._custom_records.get(x)
            if not test:
                continue

            return recognized and action_cod in test

    def add_callable_records(self, name: str, callable_cfg: Callable_cfg):
        if not name:
            name = 'default'

        if name in self._custom_records:
            self._custom_records[name].update(_make_callable_record(callable_cfg))
        else:
            self._custom_records[name] = _make_callable_record(callable_cfg)

    def dispatch(self, callable_key: int, context=None, record_name: str = 'default'):
        if context is None:
            context = {}

        self.context = context
        context['callable_key'] = callable_key

        try:
            record = self._custom_records[record_name]
        except KeyError:
            err = f'Não existe registro de funções personalizadas com o nome {record_name}.'
            logging.warning(' ActionProcessor |> ' + err)
            return '', err

        return self._call_from_record(record, callable_key, context)

    @handle_exception_factory()
    @parse_props
    def _call_from_record(self, callable_record, key: int, data):
        callable_config = callable_record.get(key) \
                          or callable_record.get(self.DEFAULT_FUNCTION)

        if not callable_config:
            err = 'Nenhuma função foi definida para chave ' + str(key)
            logging.warning(' ActionProcessor |> ' + err)
            return '', err

        default: dict
        (callable_, args_names, defaults, kwargs, direct) = callable_config

        if direct and (len(args_names) == 1):
            return callable_(data)

        internal = {
            'internal': {
                'context_data': data
            }
        }

        try:
            filtered_args: list = [
                {**kwargs, **data, **defaults, **internal}[arg]
                for arg
                in args_names
            ]
        except KeyError:
            available = set([*defaults.keys()] + [*data.keys()] + [*kwargs.keys()])
            err = f'Argumento não definido para o método {callable_.__name__}.' \
                  '\n\tRequeridos: ' + ', '.join(sorted(args_names)) + \
                  '\n\tDisponíveis: ' + ', '.join(sorted(available))

            logging.error(' ActionProcessor |> ' + err)
            return '', err

        return callable_(*filtered_args)

    def link_to(self, name: str = 'default', *args: Union[str, int]):
        def link_to_decorator(func: Callable) -> Callable:
            return self._link_to_decorator(func, args, name)

        return link_to_decorator

    def link_to_factory(self, callable_record_name: str = 'default'):
        def link_to(*args: Union[str, int]):
            def link_to_decorator(func: Callable) -> Callable:
                return self._link_to_decorator(func, args, callable_record_name)

            return link_to_decorator

        return link_to

    def _link_to_decorator(self, func: Callable, actions: Tuple[Union[str, int]], record_name: str) -> Callable:
        def map_actions(action: Any):
            for a in action:
                if type(a) is list:
                    map_actions(a)
                    continue

                self.add_callable_records(record_name, {a: func})

        map_actions(actions)
        return func


# Funções utilitárias
def _make_callable_record(callable_cfg: Callable_cfg):
    callable_kwargs = {}

    def process_param(param: Parameter) -> str:
        if param.default != Parameter.empty:
            callable_kwargs[param.name] = param.default

        return param.name

    def setup_params(builder: Union[Callable, Tuple]) -> Tuple[Callable, List[str], dict, dict, bool]:
        direct = False
        if callable(builder):
            target = builder
            direct = builder.__name__ == '<lambda>'
            defaults = {}
        else:
            target, defaults = builder

        return target, [process_param(t) for t in
                        signature(target).parameters.values()], defaults, callable_kwargs, direct

    return {
        k: setup_params(v)
        for k, v
        in callable_cfg.items()
    }
