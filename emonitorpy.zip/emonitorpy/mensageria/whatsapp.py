import requests
from flask import jsonify
import json

import geral
import edi.dao as dao
from sefaz_spooler import PRODUCAO, HOMOLOGACAO
from metadata import getConnPG


CONNECTTIMEOUTWS = 10
READTIMEOUTWS = 180

ACAO_WHATSAPP_TECNOSPEED_INICIO = 10000
ACAO_WHATSAPP_TECNOSPEED_ENVIARMSG = 10001
ACAO_WHATSAPP_TECNOSPEED_ENVIARIMG = 10002
ACAO_WHATSAPP_TECNOSPEED_ENVIARARQ = 10003
ACAO_WHATSAPP_TECNOSPEED_FIM = 10099

SISTEMAEXT_TIPO_WHATSAPP = 10000


headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
}


def get_full_url(url, codEMonitorAcao):
    if codEMonitorAcao == ACAO_WHATSAPP_TECNOSPEED_ENVIARMSG:
        return url + '/send-text'
    elif codEMonitorAcao == ACAO_WHATSAPP_TECNOSPEED_ENVIARIMG:
        return url + '/send-image'
    elif codEMonitorAcao == ACAO_WHATSAPP_TECNOSPEED_ENVIARARQ:
        return url + '/send-document'
    else:
        return url

def call_whatsapp(request, engineEMonitor):
    dataReq = geral.datetimeactualtostr()
    codInstalacao = request.args.get('inst', type=int)
    codEmpresa = request.args.get('emp', type=int)
    codEMonitorAcao = request.args.get('emac', type=int) # IMPORTANTE: NAO ESTA RELACIONADA COM TABELA EMONITORACAO, DEVIDO A QUANTIDADE GRANDE DE POSSIBILIDADES
    requestJSON = request.json
    url = requestJSON['url']
    tpAmb = requestJSON['tpAmb']
    req = requestJSON['request']
    #
    with getConnPG(engineEMonitor) as conn:
        if codEMonitorAcao == ACAO_WHATSAPP_TECNOSPEED_ENVIARMSG:
            resp = send_text(url, req)
            dataResp = geral.datetimeactualtostr()
            dao.insSistemaExt(conn, codInstalacao, codEmpresa, codEMonitorAcao, SISTEMAEXT_TIPO_WHATSAPP, tpAmb, 'celular', url, dataReq, req, dataResp, resp.json)
            return resp
        elif codEMonitorAcao == ACAO_WHATSAPP_TECNOSPEED_ENVIARIMG:
            resp = send_image(url, req)
            dataResp = geral.datetimeactualtostr()
            dao.insSistemaExt(conn, codInstalacao, codEmpresa, codEMonitorAcao, SISTEMAEXT_TIPO_WHATSAPP, tpAmb, 'celular', url, dataReq, req, dataResp, resp.json)
            return resp
        elif codEMonitorAcao == ACAO_WHATSAPP_TECNOSPEED_ENVIARARQ:
            resp = send_file(url, req)
            dataResp = geral.datetimeactualtostr()
            dao.insSistemaExt(conn, codInstalacao, codEmpresa, codEMonitorAcao, SISTEMAEXT_TIPO_WHATSAPP, tpAmb, 'celular', url, dataReq, req, dataResp, resp.json)
            return resp
        else:
            return jsonify({'erro': 't', 'msgRet': 'Acao nao encontrada no EMonitorPY'})


def send_text(url, req, msg = '', do_jsonify = True):
    try:
        if do_jsonify:
            req = json.loads(req)
        celular = '55' + req['celular']
        if msg == '':
            msg = req['msg']
        #
        full_url = get_full_url(url, ACAO_WHATSAPP_TECNOSPEED_ENVIARMSG)
        body = {
            'phone': celular,
            'message': msg
        }
        response = requests.post(full_url, headers=headers, data=json.dumps(body), timeout=READTIMEOUTWS)
        if response.status_code != 200:
            responseJSON = {'erro': 't', 'msgRet': response.content.decode('utf-8')}
        else:
            responseJSON = {'erro': 'f', 'msgRet': response.content.decode('utf-8') + 'Mensagem enviada com sucesso para o WhatsApp ' + celular}
        if do_jsonify:
            return jsonify(responseJSON)
        else:
            return responseJSON
        #
    except Exception as e:
        print('Erro em send_file')
        print(e)
        responseJSON = {'erro': 't', 'msgRet': 'ERRO NO ENVIO DE MENSAGEM PARA WHATSAPP: ' + str(e)}
        if do_jsonify:
            return jsonify(responseJSON)
        else:
            return responseJSON


def get_prefix_file(tipo):
    if tipo == 'pdf':
        return 'data:application/pdf;base64,'
    elif tipo == 'xml':
        return 'data:application/xml;base64,'
    elif tipo == 'jpg':
        return 'data:image/jpg;base64,'
    elif tipo == 'png':
        return 'data:image/png;base64,'
    else:
        return 'data:text/plain;base64,'


def send_image(url, req, do_jsonify = True):
    try:
        req = json.loads(req)
        nome = req['nome']
        if req.get('texto_complementar', ''):
            texto_complementar = '\n\n' + req['texto_complementar']
        else:
            texto_complementar = ''
        if req.get('nome_usuario', ''):
            nome_usuario = '\n\nNome Usuário: ' + req.get('nome_usuario')
        else:
            nome_usuario = ''
        celular = '55' + req['celular']
        msg = 'Olá *' + nome + '*,\n\nA seguir, imagem(ns) enviada(s) pela transportadora:\n\n' + req['titulo'] \
              + '\n\nMensagem automática enviada pela InterSite Sistemas, favor não responder!\n\nhttps://www.intersite.com.br'\
              + texto_complementar\
              + nome_usuario
        anexos = req['anexos']
        #
        responseJSON = send_text(url, req, msg, False)
        if responseJSON['erro'] == 't':
            if do_jsonify:
                return jsonify(responseJSON)
            else:
                return responseJSON
        #
        full_url = get_full_url(url, ACAO_WHATSAPP_TECNOSPEED_ENVIARIMG)
        for anexo in anexos:
            nome_anexo = anexo['nome'][0:len(anexo['nome'])-4]
            body = {
                'phone': celular,
                'image': get_prefix_file(anexo['tipo']) + anexo['conteudo'],
                'caption': nome_anexo
            }
            response = requests.post(full_url + '/' + anexo['tipo'], headers=headers, data=json.dumps(body), timeout=READTIMEOUTWS)
            if response.status_code != 200:
                responseJSON = {'erro': 't', 'msgRet': response.content}
                if do_jsonify:
                    return jsonify(responseJSON)
                else:
                    return responseJSON
        #
        responseJSON = {'erro': 'f', 'msgRet': response.content.decode('utf-8') + 'Imagem(ns) enviada(s) com sucesso para o WhatsApp ' + celular}
        if do_jsonify:
            return jsonify(responseJSON)
        else:
            return responseJSON
        #
    except Exception as e:
        print('Erro em send_file')
        print(e)
        responseJSON = {'erro': 't', 'msgRet': 'ERRO NO ENVIO DE ARQUIVO PARA WHATSAPP: ' + str(e)}
        if do_jsonify:
            return jsonify(responseJSON)
        else:
            return responseJSON


def send_file(url, req, do_jsonify = True):
    try:
        req = json.loads(req)
        nome = req['nome']
        if req.get('texto_complementar', ''):
            texto_complementar = '\n\n' + req.get('texto_complementar')
        else:
            texto_complementar = ''
        if req.get('nome_usuario', ''):
            nome_usuario = '\n\nNome Usuário: ' + req.get('nome_usuario')
        else:
            nome_usuario = ''
        celular = '55' + req['celular']
        msg = 'Olá *' + nome + '*,\n\nA seguir, documento(s) enviado(s) pela transportadora:\n\n' + req['titulo']\
              + '\n\nMensagem automática enviada pela InterSite Sistemas, favor não responder!\n\nhttps://www.intersite.com.br'\
              + texto_complementar\
              + nome_usuario
        anexos = req['anexos']
        #
        responseJSON = send_text(url, req, msg, False)
        if responseJSON['erro'] == 't':
            if do_jsonify:
                return jsonify(responseJSON)
            else:
                return responseJSON
        #
        full_url = get_full_url(url, ACAO_WHATSAPP_TECNOSPEED_ENVIARARQ)
        for anexo in anexos:
            nome_anexo = anexo['nome'][0:len(anexo['nome'])-4]
            body = {
                'phone': celular,
                'document': get_prefix_file(anexo['tipo']) + anexo['conteudo'],
                'fileName': nome_anexo
            }
            response = requests.post(full_url + '/' + anexo['tipo'], headers=headers, data=json.dumps(body), timeout=READTIMEOUTWS)
            if response.status_code != 200:
                responseJSON = {'erro': 't', 'msgRet': response.content}
                if do_jsonify:
                    return jsonify(responseJSON)
                else:
                    return responseJSON
        #
        responseJSON = {'erro': 'f', 'msgRet': response.content.decode('utf-8') + 'Arquivos(s) enviado(s) com sucesso para o WhatsApp ' + celular}
        if do_jsonify:
            return jsonify(responseJSON)
        else:
            return responseJSON
        #
    except Exception as e:
        print('Erro em send_file')
        print(e)
        responseJSON = {'erro': 't', 'msgRet': 'ERRO NO ENVIO DE ARQUIVO PARA WHATSAPP: ' + str(e)}
        if do_jsonify:
            return jsonify(responseJSON)
        else:
            return responseJSON







# https://app.plugzapi.com.br/
# https://developer.plugzapi.com.br/
# url = 'https://api.plugzapi.com.br/instances/3BBB8A8DDDE820D395487296C04D749E/token/F39682541F49EF5611D357DD/status'
# url = 'https://api.plugzapi.com.br/instances/3BBB8A8DDDE820D395487296C04D749E/token/F39682541F49EF5611D357DD/device'
# url = 'https://api.plugzapi.com.br/instances/3BBB8A8DDDE820D395487296C04D749E/token/F39682541F49EF5611D357DD/chats'
# url = 'https://api.plugzapi.com.br/instances/3BCDA2B83FBE70DCA38E2A5F1760FC74/token/3BCDA2B83FBE71C533B22A5F1760FC74' # fone de plantao
# response = requests.get(url)
# print('---------------------')
# print(response.status_code)
# print(response.content)
# print('---------------------')
# exit(0)
######################################
# headers = {
#   'Content-Type': 'application/json',
#   'Accept': 'application/json'
# }
# phone = '5567999128008'
# url = 'https://api.plugzapi.com.br/instances/3BBB8A8DDDE820D395487296C04D749E/token/F39682541F49EF5611D357DD/send-text'
# message = '*Senhor Baca*\n\nO que acha de receber mensagens automáticas do WhatsApp?\n\n\nSe achar legal, _responda essa mensagem_...'
# body = {
#     'phone': phone,
#     'message': message
# }
# url = 'https://api.plugzapi.com.br/instances/3BBB8A8DDDE820D395487296C04D749E/token/F39682541F49EF5611D357DD/send-image'
# with open('/home/edilmar/Downloads/promocao.jpeg', "rb") as image_file:
#     image = 'data:image/jpg;base64,' + base64.b64encode(image_file.read()).decode()
# body = {
#     'phone': phone,
#     'image': image,
#     'caption': 'Lá vai uma promo'
# }
# phone = '556799128008-1519084640' # fone do grupo IS Comercial
# url = 'https://api.plugzapi.com.br/instances/3BBB8A8DDDE820D395487296C04D749E/token/F39682541F49EF5611D357DD/send-document/pdf'
# with open('/home/edilmar/Downloads/DACTE.pdf', "rb") as document_file:
#     document = 'data:application/pdf;base64,' + base64.b64encode(document_file.read()).decode()
# body = {
#     'phone': phone,
#     'document': document,
#     'fileName': 'DACTE_BACACOMOITODIGITOS'
# }
# reqjson = json.dumps(body)
# response = requests.post(url, headers=headers, data=reqjson, timeout=180)
# print('---------------------')
# print(response.status_code)
# print(response.content)
# print('---------------------')
# exit(0)
