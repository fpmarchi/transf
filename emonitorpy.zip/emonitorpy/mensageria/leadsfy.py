import base64
from io import BytesIO
from typing import Tuple

from requests import Response

from dispacher import ActionProcessor
from dispacher.decorators import handle_exception_factory, parse_props
from geral import deep_get
from geralxml import mount_xml_response


class LeadsfyException(Exception):
    pass


class Leadsfy(ActionProcessor):
    # HOST = 'https://everest.boot.leadsfy.com.br'
    # TEST_HOST = 'https://everest.boot.leadsfy.com.br'

    SEND_WHATSAPP = 1700

    def __init__(self):
        self.BASE_PATH = '/webhook/enviar_modelo/'
        self.TEST_BASE_PATH = '/webhook/enviar_modelo/'

        # Hosts de Backup. São usados caso o SAT não informar

        self.add_callable_records('url', {
            self.SEND_WHATSAPP: self.make_url_assembler(),
        })

        super().__init__()

    __token_cache: dict = {}

    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        props = context_req.get('props', {})
        user = props.get('usuario', '')
        password = props.get('senha', '')

        try:
            if not user or not password:
                return {}, 'O usuario ou senha não foram informados!'

            token_bytes: bytes = base64.b64encode(f'{user}:{password}'.encode())

            return {
                'Authorization': f'Basic {token_bytes.decode("ascii")}',
            }, ''

        except(Exception,):
            return {}, 'Por favor verifique as credenciais de acesso para Leadsy WhatsApp!'


#
#   Códigos independentes de instancia
#

# Tratamento de exceções
def _leadsfy_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a Leadsy:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    LeadsfyException,
    _leadsfy_exception_callback,
    any_exception_callback
)

#
#   Códigos dependentes de instancia
#

# Instancia limpa e sem configuração (singleton)
_leadsfy = Leadsfy()

# Decorators da instancia
_link_to_request = _leadsfy.link_to_factory('request')
_link_to_response = _leadsfy.link_to_factory('response')


# Login paragerar o token Bearer para realizar as autenticações
@_link_to_request(_leadsfy.SEND_WHATSAPP)
@_handle_exception
def _out_send_whatsapp(req: dict):
    data = {
        'para': req.get('mot_cel', ''),
        'modelo': req.get('doc_descricao', ''),
        'id_numero': req.get('id_numero', ''),
        'paramentros[1]': req.get('paramentro_1', ''),
        'paramentros[2]': req.get('paramentro_2', ''),
        'paramentros[3]': req.get('paramentro_3', '')

    }



    if req.get('arquivo'):
        files = {
            'arquivo': (req.get('arq_name', ''), BytesIO(base64.b64decode(req.get('arquivo'))), 'application/pdf'),
        }
        return data, '', files
    else:
        return data, '', ''


#
# Tratamento de retornos
@_link_to_response(_leadsfy.DEFAULT_FUNCTION)
@_handle_exception
def _in_default(resp: Response) -> Tuple[str, str]:
    ret = resp.json()

    try:

        if 'error' in ret and ret.get:
            resp_data = {
                'sucesso': False,
                'msg_erro': deep_get(ret, 'error.message')
            }
        elif ('messages' in ret) and ('contacts' in ret):
            resp_data = {
                'sucesso': True,
                'conteudo': ret
            }
        else:
            resp_data = {
                'sucesso': False,
                'msg_erro': deep_get(ret, 'msg')
            }
    except Exception as e:
        resp_data = {
            'sucesso': False,
            'msg_erro': 'Ocorreu um erro desconhecido ao tentar retornar as informações do EmonitorPy:\n' + str(e)
        }

    return mount_xml_response(resp_data), ''
