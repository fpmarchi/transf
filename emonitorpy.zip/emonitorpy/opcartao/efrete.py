'''
Sequencia de testes SOR+EMPY:
1) Cadastrar Prop
2) Cadastrar Mot
3) Cadastrar Veic
4) Gerar Ciot
5) Imprimir Contrato
6) Cancelar Contrato
7) Gerar Ciot Completo
'''

import xml.dom.minidom as mdom

from entity import proprietario, motorista, veiculo, conhecimento
from geral import padlzero
from geraljson import getJSON
from geralxml import *
from consist import *

ACAO_EFRETE_INICIO = 1050
ACAO_EFRETE_AUTENTICARUSUARIO = 1050
ACAO_EFRETE_CADASTRARPROPRIETARIO = 1051
ACAO_EFRETE_CADASTRARMOTORISTA = 1052
ACAO_EFRETE_CADASTRARVEICULO = 1053
ACAO_EFRETE_CADASTRARCARRETA1 = 1054
ACAO_EFRETE_CADASTRARCARRETA2 = 1055
ACAO_EFRETE_CADASTRARCARRETA3 = 1056
ACAO_EFRETE_GERARMODCOMPVEIC = 1059 # SEM IMPLEMENTACAO POR ENQTO COMPLETO... PENSAR MELHOR NO FLUXO DE DADOS QUE TEM QUE SER ENVIADOS, NA SEQUENCIA DE TRABALHO DO USUARIO
ACAO_EFRETE_GERARMODCOMPCIOT = 1060
ACAO_EFRETE_CADASTRARCONHECIMENTO = 1061
ACAO_EFRETE_OBTERPDFCONHECIMENTO = 1062
ACAO_EFRETE_CANCELARCONHECIMENTO = 1063
# deixar uma margem de codigos para nao misturar
ACAO_EFRETE_CONCILIACAO_FINANCEIRA_DATA = 1091
ACAO_EFRETE_CONCILIACAO_CONTABIL_DATA = 1092
ACAO_EFRETE_FIM = 1099


def consistEFreteCadastrarProprietario(reqJSON):
    ret = proprietario.consistCadastrarProprietario(reqJSON)
    # PENDENTE CHECAR CONSISTENCIAS ESPECIFICAS DA EFRETE
    #ret += 'outro erro'
    return ret


def requestEFreteCadastrarProprietario(reqJSON):
    reqJSON['prop_rntrc'] = padlzero(getJSON(reqJSON, 'prop_rntrc'), 8)
    erros = consistEFreteCadastrarProprietario(reqJSON)
    if erros != '':
       return '', erros

    if getJSON(reqJSON,'prop_integrador') == '': # este caso somente ocorre no processamento de modulo completo, onde pode ter alguns cadastros que nao serao feitos
        return '', ''

    reqXML = (
        '<?xml version=\"1.0\" encoding=\"utf-8\"?>'
        '<soap12:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\">'
            '<soap12:Body>'
                '<Gravar xmlns=\"http://schemas.ipc.adm.br/efrete/proprietarios\">'
                    '<GravarRequest xmlns=\"http://schemas.ipc.adm.br/efrete/proprietarios/objects\">'
                        '<Integrador xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">' + getJSON(reqJSON,'prop_integrador') + '</Integrador>'
                        '<CNPJ>' + getJSON(reqJSON,'prop_cnpjcpf') + '</CNPJ>'
                        '<TipoPessoa>' + getJSON(reqJSON,'prop_tipopessoa') + '</TipoPessoa>'
                        '<Endereco>'
                            '<Bairro xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">' + getJSON(reqJSON,'prop_bairro') + '</Bairro>'
                            '<CEP xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">' + getJSON(reqJSON,'prop_cep') + '</CEP>'
                            '<CodigoMunicipio xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">' + getJSON(reqJSON,'prop_codibge') + '</CodigoMunicipio>'
                            '<Rua xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">' + getJSON(reqJSON,'prop_endereco') + '</Rua>'
                            '<Numero xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">' + getJSON(reqJSON,'prop_numero') + '</Numero>'
                            '<Complemento xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">' + getJSON(reqJSON,'prop_complemento') + '</Complemento>'
                        '</Endereco>'
                        '<RNTRC>' + getJSON(reqJSON,'prop_rntrc') + '</RNTRC>'
                        '<RazaoSocial>' + getJSON(reqJSON,'prop_nome') + '</RazaoSocial>'
                        '<Telefones>'
                            '<Celular xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">'
                                '<DDD>' + getJSON(reqJSON,'prop_celularddd') + '</DDD>'
                                '<Numero>' + getJSON(reqJSON,'prop_celularnumero') + '</Numero>'
                            '</Celular>'
                            '<Fax xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">'
                                '<DDD>' + getJSON(reqJSON,'prop_faxddd') + '</DDD>'
                                '<Numero>' + getJSON(reqJSON,'prop_faxnumero') + '</Numero>'
                            '</Fax>'
                            '<Fixo xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">'
                                '<DDD>' + getJSON(reqJSON,'prop_foneddd') + '</DDD>'
                                '<Numero>' + getJSON(reqJSON,'prop_fonenumero') + '</Numero>'
                            '</Fixo>'
                        '</Telefones>'
                        '<Versao xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">3</Versao>'
                        '<Token></Token>'
                    '</GravarRequest>'
                 '</Gravar>'
             '</soap12:Body>'
         '</soap12:Envelope>'
    )
    return reqXML, ''


def consistEFreteCadastrarMotorista(reqJSON):
    ret = motorista.consistCadastrarMotorista(reqJSON)
    # PENDENTE CHECAR CONSISTENCIAS ESPECIFICAS DA EFRETE
    #ret += 'outro erro'
    return ret


def requestEFreteCadastrarMotorista(reqJSON):
    erros = consistEFreteCadastrarMotorista(reqJSON)
    if erros != '':
        return '', erros
    #
    if getJSON(reqJSON,'mot_integrador') == '': # este caso somente ocorre no processamento de modulo completo, onde pode ter alguns cadastros que nao serao feitos
        return '', ''
    #
    reqXML = (
        '<?xml version=\"1.0\" encoding=\"utf-8\"?>'
        '<soap12:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\">'
            '<soap12:Body>'
                '<Gravar xmlns=\"http://schemas.ipc.adm.br/efrete/motoristas\">'
                    '<GravarRequest xmlns=\"http://schemas.ipc.adm.br/efrete/motoristas/objects\">'
                        '<Integrador xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">' + getJSON(reqJSON,'mot_integrador') + '</Integrador>'
                        '<CPF>' + getJSON(reqJSON,'mot_cpf') + '</CPF>'
                        '<CNH>' + getJSON(reqJSON,'mot_cnh') + '</CNH>'
                        '<DataNascimento>' + getJSON(reqJSON,'mot_datanasc') + '</DataNascimento>'
                        '<Endereco>'
                            '<Bairro xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">' + getJSON(reqJSON,'mot_bairro') + '</Bairro>'
                            '<CEP xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">' + getJSON(reqJSON,'mot_cep') + '</CEP>'
                            '<CodigoMunicipio xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">' + getJSON(reqJSON,'mot_codibge') + '</CodigoMunicipio>'
                            '<Rua xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">' + getJSON(reqJSON,'mot_endereco') + '</Rua>'
                            '<Numero xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">' + getJSON(reqJSON,'mot_numero') + '</Numero>'
                            '<Complemento xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">' + getJSON(reqJSON,'mot_complemento') + '</Complemento>'
                        '</Endereco>'
                        '<Nome>' + getJSON(reqJSON,'mot_nome') + '</Nome>'
                        '<NomeDeSolteiraDaMae></NomeDeSolteiraDaMae>'
                        '<Telefones>'
                            '<Celular xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">'
                                '<DDD>' + getJSON(reqJSON,'mot_celularddd') + '</DDD>'
                                '<Numero>' + getJSON(reqJSON,'mot_celularnumero') + '</Numero>'
                            '</Celular>'
                            '<Fax xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">'
                                '<DDD>0</DDD>'
                                '<Numero>0</Numero>'
                            '</Fax>'
                            '<Fixo xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">'
                                '<DDD>' + getJSON(reqJSON,'mot_foneddd') + '</DDD>'
                                '<Numero>' + getJSON(reqJSON,'mot_fonenumero') + '</Numero>'
                            '</Fixo>'
                        '</Telefones>'
                        '<Versao xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">2</Versao>'
                        '<Token></Token>'
                    '</GravarRequest>'
                 '</Gravar>'
             '</soap12:Body>'
         '</soap12:Envelope>'
    )
    return reqXML, ''


def consistEFreteCadastrarVeiculo(reqJSON,prefixTag):
    ret = veiculo.consistCadastrarVeiculo(reqJSON,prefixTag)
    if ret == 'VAZIO':
        return '' # pois as carretas nao sao obrigatorias
    #
    ret += consistEmpty(reqJSON, prefixTag + 'chassi', 'Chassi')
    ret += consistEmpty(reqJSON, prefixTag + 'renavam', 'Renavam')
    #
    return ret


def getTipoCarroceria(tipo):
    if tipo == '':
        return 'NaoAplicavel'
    elif 'ABERT' in tipo:
        return 'Aberta'
    elif 'FECHAD' in tipo:
        return 'FechadaOuBau'
    elif 'GRANELE' in tipo:
        return 'Granelera'
    elif 'CONTAINER' in tipo:
        return 'PortaContainer'
    elif 'SIDER' in tipo:
        return 'Sider'
    else:
        return 'NaoAplicavel'


def getTipoRodado(tipo):
    if tipo == '':
        return 'NaoAplicavel'
    elif 'TRUCK' in tipo:
        return 'Truck'
    elif 'TOCO' in tipo:
        return 'Toco'
    else:
        return 'Cavalo'


def requestEFreteCadastrarVeiculo(reqJSON, codEMonitorAcao):
    if codEMonitorAcao == ACAO_EFRETE_CADASTRARVEICULO:
        prefixTag = 'veic_'
    elif codEMonitorAcao == ACAO_EFRETE_CADASTRARCARRETA1:
        prefixTag = 'car1_'
    elif codEMonitorAcao == ACAO_EFRETE_CADASTRARCARRETA2:
        prefixTag = 'car2_'
    else: # if codEMonitorAcao == ACAO_EFRETE_CADASTRARCARRETA3:
        prefixTag = 'car3_'
    #
    erros = consistEFreteCadastrarVeiculo(reqJSON,prefixTag)
    if erros != '':
        return '', erros
    #
    if getJSON(reqJSON,prefixTag+'integrador') == '': # este caso somente ocorre no processamento de modulo completo, onde pode ter alguns cadastros que nao serao feitos
        return '', ''
    #
    reqXML = (
        '<?xml version=\"1.0\" encoding=\"utf-8\"?>'
        '<soap12:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\">'
            '<soap12:Body>'
                '<Gravar xmlns=\"http://schemas.ipc.adm.br/efrete/veiculos\">'
                    '<GravarRequest xmlns=\"http://schemas.ipc.adm.br/efrete/veiculos/objects\">'
                        '<Integrador xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">' + getJSON(reqJSON,prefixTag + 'integrador') + '</Integrador>'
                        '<Veiculo>'
                            '<AnoFabricacao>' + getJSON(reqJSON,prefixTag + 'anofab') + '</AnoFabricacao>'
                            '<AnoModelo>' + getJSON(reqJSON,prefixTag + 'anomod') + '</AnoModelo>'
                            '<CapacidadeKg>' + getJSON(reqJSON,prefixTag + 'capkg') + '</CapacidadeKg>'
                            '<CapacidadeM3>' + getJSON(reqJSON,prefixTag + 'capm3') + '</CapacidadeM3>'
                            '<Chassi>' + getJSON(reqJSON,prefixTag + 'chassi') + '</Chassi>'
                            '<CodigoMunicipio>' + getJSON(reqJSON,prefixTag + 'codibge') + '</CodigoMunicipio>'
                            '<Cor>' + getJSON(reqJSON,prefixTag + 'cor') + '</Cor>'
                            '<Marca>' + getJSON(reqJSON,prefixTag + 'marca') + '</Marca>'
                            '<Modelo>' + getJSON(reqJSON,prefixTag + 'modelo') + '</Modelo>'
                            '<NumeroDeEixos>' + getJSON(reqJSON,prefixTag + 'quanteixos') + '</NumeroDeEixos>'
                            '<Placa>' + getJSON(reqJSON,prefixTag + 'placa') + '</Placa>'
                            '<RNTRC>' + getJSON(reqJSON,prefixTag + 'rntrc') + '</RNTRC>'
                            '<Renavam>' + getJSON(reqJSON,prefixTag + 'renavam') + '</Renavam>'
                            '<Tara>' + getJSON(reqJSON,prefixTag + 'tara') + '</Tara>'
                            '<TipoCarroceria>' + getTipoCarroceria(getJSON(reqJSON,prefixTag + 'tipocarr')) + '</TipoCarroceria>'
                            '<TipoRodado>' + getTipoRodado(getJSON(reqJSON,prefixTag + 'tipoveic')) + '</TipoRodado>'
                        '</Veiculo>'
                        '<Versao xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">1</Versao>'
                        '<Token></Token>'
                    '</GravarRequest>'
                 '</Gravar>'
             '</soap12:Body>'
         '</soap12:Envelope>'
    )
    return reqXML, ''


def consistEFreteCadastrarConhecimento(reqJSON):
    # PENDENTE CHECAR CAMPOS OBRIGATORIOS GENERICOS NO METODO ABAIXO QUE FICA NO opcartao
    ret = conhecimento.consistCadastrarConhecimento(reqJSON)
    # PENDENTE CHECAR CONSISTENCIAS ESPECIFICAS DA EFRETE
    #ret += 'outro erro'
    return ret


def requestEFreteCadastrarConhecimento(reqJSON):
    erros = consistEFreteCadastrarConhecimento(reqJSON)
    if erros != '':
        return '', erros
    #
    if getJSON(reqJSON,'conh_integrador') == '': # este caso somente ocorre no processamento de modulo completo, onde pode ter alguns cadastros que nao serao feitos
        return '', ''
    #
    if getJSON(reqJSON,'conh_formapagtoopcartao') == 'T':
        formaPagtoTransfBancaria = True
    else:
        formaPagtoTransfBancaria = False
    if not formaPagtoTransfBancaria:
        informacoesBancarias = ''
    else:
        informacoesBancarias = \
            '<obj:InformacoesBancarias>' + \
                createtag('obj:InstituicaoBancaria', getJSON(reqJSON,'conh_banco')) + \
                createtag('obj:Agencia', getJSON(reqJSON,'conh_agencia')) + \
                createtag('obj:Conta', getJSON(reqJSON,'conh_conta')) + \
            '</obj:InformacoesBancarias>'
    #
    ''' CIOT PARA TODOS
                createtag('obj:TipoConta', getJSON(reqJSON,'conh_tipoconta')) + \
    '''

    if getJSON(reqJSON,'conh_formapagtoopcartao') == 'O':
        pagamentos = ''
    else:
        pagamentos = ''
        if float(getJSON(reqJSON,'conh_valoradiant')) > 0:
            pagamentos += \
                '<adic:Pagamentos>' + \
                    createtag('adic:IdPagamentoCliente', 'AD') + \
                    createtag('adic:DataDeLiberacao', getJSON(reqJSON,'conh_dataemissao')) + \
                    createtag('adic:Valor', getJSON(reqJSON,'conh_valoradiant')) + \
                    createtag('obj:TipoPagamento', getJSON(reqJSON,'conh_formapagto')) + \
                    createtag('obj:Categoria', 'Adiantamento') + \
                    createtag('adic:Documento', getJSON(reqJSON,'conh_numconhec')) + \
                    informacoesBancarias + \
                '</adic:Pagamentos>'
        if float(getJSON(reqJSON,'conh_valoradiant2')) > 0:
            pagamentos += \
                '<adic:Pagamentos>' + \
                createtag('adic:IdPagamentoCliente', 'AD2') + \
                createtag('adic:DataDeLiberacao', getJSON(reqJSON,'conh_dataemissao')) + \
                createtag('adic:Valor', getJSON(reqJSON,'conh_valoradiant2')) + \
                createtag('obj:TipoPagamento', getJSON(reqJSON,'conh_formapagto')) + \
                createtag('obj:Categoria', 'Adiantamento') + \
                createtag('adic:Documento', getJSON(reqJSON,'conh_numconhec')) + \
                informacoesBancarias + \
                '</adic:Pagamentos>'
        if float(getJSON(reqJSON,'conh_valorsaldo')) > 0:
            pagamentos += \
                '<adic:Pagamentos>' + \
                createtag('adic:IdPagamentoCliente', 'SD') + \
                createtag('adic:DataDeLiberacao', getJSON(reqJSON,'conh_datafim')) + \
                createtag('adic:Valor', getJSON(reqJSON,'conh_valorsaldo')) + \
                createtag('obj:TipoPagamento', getJSON(reqJSON,'conh_formapagto')) + \
                createtag('obj:Categoria', 'Quitacao') + \
                createtag('adic:Documento', getJSON(reqJSON,'conh_numconhec')) + \
                informacoesBancarias + \
                '</adic:Pagamentos>'
    #
    nfs = '<adic:NotasFiscais>'
    ctnfs = int(getJSON(reqJSON,'conh_ctnfs'))
    i = 1
    while i <= ctnfs:
        nfs = nfs + \
            '<adic:NotaFiscal>' + \
                createtag('adic:Numero', getJSON(reqJSON,'conh_numnf'+str(i))) + \
                createtag('adic:Serie', getJSON(reqJSON,'conh_serienf' + str(i))) + \
                createtag('adic:Data', getJSON(reqJSON,'conh_datanf' + str(i))) + \
                createtag('adic:ValorTotal', getJSON(reqJSON,'conh_valornf' + str(i))) + \
                createtag('adic:ValorDaMercadoriaPorUnidade', getJSON(reqJSON,'conh_valorunitnf' + str(i))) + \
                createtag('adic:CodigoNCMNaturezaCarga', getJSON(reqJSON,'conh_ncmnf' + str(i))) + \
                createtag('adic:DescricaoDaMercadoria', getJSON(reqJSON,'conh_mercnf' + str(i))) + \
                createtag('adic:UnidadeDeMedidaDaMercadoria', getJSON(reqJSON,'conh_unidmednf' + str(i))) + \
                createtag('adic:TipoDeCalculo', getJSON(reqJSON,'conh_tipodescnf' + str(i))) + \
                createtag('adic:ValorDoFretePorUnidadeDeMercadoria', getJSON(reqJSON,'conh_valorfreteunitnf' + str(i))) + \
                createtag('adic:QuantidadeDaMercadoriaNoEmbarque', getJSON(reqJSON,'conh_quantnf' + str(i))) + \
                '<adic:ToleranciaDePerdaDeMercadoria>' + \
                    createtag('adic:Tipo', getJSON(reqJSON,'conh_tipotoler' + str(i))) + \
                    createtag('adic:Valor', getJSON(reqJSON,'conh_valortoler' + str(i))) + \
                '</adic:ToleranciaDePerdaDeMercadoria>'
        if getJSON(reqJSON, 'conh_pesosaidamotorista') == 'S':
            nfs = nfs + \
                '<adic:DiferencaDeFrete>' + \
                    createtag('obj:Tipo', 'SemDiferenca') + \
                    createtag('obj:Base', 'QuantidadeDesembarque') + \
                    '<obj:Tolerancia>' + \
                    createtag('obj:Tipo', 'Nenhum') + \
                    createtag('obj:Valor', '0') + \
                    '</obj:Tolerancia>' + \
                    '<obj:MargemGanho>' + \
                    createtag('obj:Tipo', 'Nenhum') + \
                    createtag('obj:Valor', '0') + \
                    '</obj:MargemGanho>' + \
                    '<obj:MargemPerda>' + \
                    createtag('obj:Tipo', 'Nenhum') + \
                    createtag('obj:Valor', '0') + \
                    '</obj:MargemPerda>' + \
                '</adic:DiferencaDeFrete>'
        nfs = nfs + \
              '</adic:NotaFiscal>'

        i += 1
    nfs = nfs + '</adic:NotasFiscais>'
    #
    if getJSON(reqJSON,'conh_veic_placacarreta1') == '':
        placacarreta1 = ''
    else:
        placacarreta1 = \
            '<adic:Veiculos>' + \
                createtag('adic:Placa', getJSON(reqJSON,'conh_veic_placacarreta1')) + \
            '</adic:Veiculos>'
    if getJSON(reqJSON,'conh_veic_placacarreta2') == '':
        placacarreta2 = ''
    else:
        placacarreta2 = \
            '<adic:Veiculos>' + \
                createtag('adic:Placa', getJSON(reqJSON,'conh_veic_placacarreta2')) + \
            '</adic:Veiculos>'
    if getJSON(reqJSON,'conh_veic_placacarreta3') == '':
        placacarreta3 = ''
    else:
        placacarreta3 = \
            '<adic:Veiculos>' + \
                createtag('adic:Placa', getJSON(reqJSON,'conh_veic_placacarreta3')) + \
            '</adic:Veiculos>'
    #
    obsCredenc = ''
    exige = getJSON(reqJSON,'conh_params_exigeticketdescarga')
    if exige == '' or exige == 'S':
        obsCredenc = obsCredenc + '<obj:string>DOCUMENTO REQUERIDO: TICKET BALANÇA</obj:string>'
    exige = getJSON(reqJSON,'conh_params_exigecanhotodacte')
    if exige == '' or exige == 'S':
        obsCredenc = obsCredenc + '<obj:string>DOCUMENTO REQUERIDO: CANHOTO DACTE</obj:string>'
    exige = getJSON(reqJSON,'conh_params_exigecanhotonfe')
    if exige == '' or exige == 'S':
        obsCredenc = obsCredenc + '<obj:string>DOCUMENTO REQUERIDO: CANHOTO NFE</obj:string>'
    #
    if getJSON(reqJSON,'conh_tpamb') == '1':
        emissaoGratuita = createtag('obj:EmissaoGratuita', getJSON(reqJSON,'conh_params_emisgrat'))
    else:
        emissaoGratuita = ''
    #

    ''' CIOT PARA TODOS
                        createtag('obj1:Versao', getJSON(reqJSON,'conh_versao')) + \

                            createtag('adic:CepOrigem', getJSON(reqJSON,'conh_ceporig')) + \
                            createtag('adic:CepDestino', getJSON(reqJSON,'conh_cepdest')) + \
                            createtag('adic:DistanciaPercorrida', getJSON(reqJSON,'conh_kmrodado')) + \
    '''

    reqXML = \
        '<?xml version=\"1.0\" encoding=\"utf-8\"?>' + \
        '<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:pef=\"http://schemas.ipc.adm.br/efrete/pef\" ' + \
        'xmlns:obj=\"http://schemas.ipc.adm.br/efrete/pef/objects\" xmlns:obj1=\"http://schemas.ipc.adm.br/efrete/objects\" ' + \
        'xmlns:adic=\"http://schemas.ipc.adm.br/efrete/pef/AdicionarOperacaoTransporte\">' + \
            '<soap:Body>' + \
                '<pef:AdicionarOperacaoTransporte>' + \
                    '<obj:AdicionarOperacaoTransporteRequest>' + \
                        createtag('obj:TipoViagem','Padrao') + \
                        createtag('obj1:Integrador', getJSON(reqJSON,'conh_integrador')) + \
                        createtag('obj1:Versao', '5') + \
                        createtag('obj1:Token', '') + \
                        createtag('obj:MatrizCNPJ', getJSON(reqJSON,'conh_cnpjue')) + \
                        createtag('obj:FilialCNPJ', getJSON(reqJSON,'conh_filial_cnpjcpf')) + \
                        createtag('obj:IdOperacaoCliente', getJSON(reqJSON,'conh_numero')) + \
                        createtag('obj:DataInicioViagem', getJSON(reqJSON,'conh_dataini')) + \
                        createtag('obj:DataFimViagem', getJSON(reqJSON,'conh_datafim')) + \
                        createtag('obj:CodigoNCMNaturezaCarga', getJSON(reqJSON,'conh_ncm')) + \
                        createtag('obj:PesoCarga', getJSON(reqJSON,'conh_pesosaida')) + \
                        createtag('obj:TipoEmbalagem', getJSON(reqJSON,'conh_tipoemb')) + \
                        '<adic:Viagens>' + \
                            createtag('adic:DocumentoViagem', getJSON(reqJSON,'conh_numconhec')) + \
                            createtag('adic:CodigoMunicipioOrigem', getJSON(reqJSON,'conh_codibgeorig')) + \
                            createtag('adic:CodigoMunicipioDestino', getJSON(reqJSON,'conh_codibgedest')) + \
                            '<obj:Valores>' + \
                                createtag('obj:TotalOperacao', getJSON(reqJSON,'conh_valorviagem')) + \
                                createtag('obj:TotalViagem', getJSON(reqJSON,'conh_valorviagem')) + \
                                createtag('obj:TotalDeAdiantamento', getJSON(reqJSON,'conh_valoradiant')) + \
                                createtag('obj:TotalDeQuitacao', getJSON(reqJSON,'conh_valorsaldo')) + \
                                createtag('obj:Combustivel', '0.00') + \
                                createtag('obj:Pedagio', getJSON(reqJSON,'conh_valorpedagio')) + \
                                createtag('obj:OutrosCreditos', '0.00') + \
                                createtag('obj:JustificativaOutrosCreditos', '') + \
                                createtag('obj:Seguro', getJSON(reqJSON,'conh_valorseguro')) + \
                                createtag('obj:OutrosDebitos', '0.00') + \
                                createtag('obj:JustificativaOutrosDebitos', '') + \
                            '</obj:Valores>' + \
                            createtag('obj:TipoPagamento', getJSON(reqJSON,'conh_formapagto')) + \
                            informacoesBancarias + \
                            nfs + \
                        '</adic:Viagens>' + \
                        '<obj:Impostos>' + \
                            createtag('obj:IRRF', getJSON(reqJSON,'conh_impirrf')) + \
                            createtag('obj:SestSenat', getJSON(reqJSON,'conh_impsestsenat')) + \
                            createtag('obj:INSS', getJSON(reqJSON,'conh_impinss')) + \
                            createtag('obj:ISSQN', getJSON(reqJSON,'conh_impiss')) + \
                            createtag('obj:OutrosImpostos', '0.00') + \
                            createtag('obj:DescricaoOutrosImpostos', '') + \
                        '</obj:Impostos>' + \
                        pagamentos + \
                        '<adic:Contratado>' + \
                            createtag('adic:CpfOuCnpj', getJSON(reqJSON,'conh_prop_cnpjcpf')) + \
                            createtag('adic:RNTRC', getJSON(reqJSON,'conh_prop_rntrc')) + \
                        '</adic:Contratado>' + \
                        '<adic:Motorista>' + \
                            createtag('adic:CpfOuCnpj', getJSON(reqJSON,'conh_mot_cpf')) + \
                            createtag('adic:CNH', getJSON(reqJSON,'conh_mot_cnh')) + \
                            '<obj:Celular>' + \
                                createtag('obj1:DDD', getJSON(reqJSON,'conh_mot_celularddd')) + \
                                createtag('obj1:Numero', getJSON(reqJSON,'conh_mot_celularnumero')) + \
                            '</obj:Celular>' + \
                        '</adic:Motorista>' + \
                        '<obj:Destinatario>' + \
                            createtag('obj:NomeOuRazaoSocial', getJSON(reqJSON,'conh_dest_nome')) + \
                            createtag('obj:CpfOuCnpj', getJSON(reqJSON,'conh_dest_cnpjcpf')) + \
                            '<obj:Endereco>' + \
                                createtag('obj1:Bairro', getJSON(reqJSON,'conh_dest_bairro')) + \
                                createtag('obj1:Rua', getJSON(reqJSON,'conh_dest_endereco')) + \
                                createtag('obj1:Numero', getJSON(reqJSON,'conh_dest_numero')) + \
                                createtag('obj1:Complemento', getJSON(reqJSON,'conh_dest_complemento')) + \
                                createtag('obj1:CEP', getJSON(reqJSON,'conh_dest_cep')) + \
                                createtag('obj1:CodigoMunicipio', getJSON(reqJSON,'conh_dest_codibge')) + \
                            '</obj:Endereco>' + \
                            createtag('obj:ResponsavelPeloPagamento', 'false') + \
                        '</obj:Destinatario>' + \
                        '<obj:TomadorServico>' + \
                            createtag('obj:NomeOuRazaoSocial', getJSON(reqJSON,'conh_cliente_nome')) + \
                            createtag('obj:CpfOuCnpj', getJSON(reqJSON,'conh_cliente_cnpjcpf')) + \
                            '<obj:Endereco>' + \
                                createtag('obj1:Bairro', getJSON(reqJSON,'conh_cliente_bairro')) + \
                                createtag('obj1:Rua', getJSON(reqJSON,'conh_cliente_endereco')) + \
                                createtag('obj1:Numero', getJSON(reqJSON,'conh_cliente_numero')) + \
                                createtag('obj1:CEP', getJSON(reqJSON,'conh_cliente_cep')) + \
                                createtag('obj1:CodigoMunicipio', getJSON(reqJSON,'conh_cliente_codibge')) + \
                            '</obj:Endereco>' + \
                            '<obj:Telefones>' + \
                                '<obj:Fixo>' + \
                                    createtag('obj1:DDD', getJSON(reqJSON,'conh_cliente_foneddd')) + \
                                    createtag('obj1:Numero', getJSON(reqJSON,'conh_cliente_fonenumero')) + \
                                '</obj:Fixo>' + \
                                '<obj:fax>' + \
                                    createtag('obj1:DDD', getJSON(reqJSON,'conh_cliente_faxddd')) + \
                                    createtag('obj1:Numero', getJSON(reqJSON,'conh_cliente_faxnumero')) + \
                                '</obj:fax>' + \
                            '</obj:Telefones>' + \
                        '</obj:TomadorServico>' + \
                        '<obj:Contratante>' + \
                            createtag('obj:NomeOuRazaoSocial', getJSON(reqJSON,'conh_filial_nome')) + \
                            createtag('obj:RNTRC', getJSON(reqJSON,'conh_filial_rntrc')) + \
                            createtag('obj:CpfOuCnpj', getJSON(reqJSON,'conh_filial_cnpjcpf')) + \
                            '<obj:Endereco>' + \
                                createtag('obj1:Bairro', getJSON(reqJSON,'conh_filial_bairro')) + \
                                createtag('obj1:Rua', getJSON(reqJSON,'conh_filial_endereco')) + \
                                createtag('obj1:Numero', getJSON(reqJSON,'conh_filial_numero')) + \
                                createtag('obj1:CEP', getJSON(reqJSON,'conh_filial_cep')) + \
                                createtag('obj1:CodigoMunicipio', getJSON(reqJSON,'conh_filial_codibge')) + \
                            '</obj:Endereco>' + \
                            createtag('obj:ResponsavelPeloPagamento', 'true') + \
                        '</obj:Contratante>' + \
                        '<adic:Veiculos>' + \
                            createtag('adic:Placa', getJSON(reqJSON,'conh_veic_placa')) + \
                        '</adic:Veiculos>' + \
                        placacarreta1 + placacarreta2 + placacarreta3 + \
                        emissaoGratuita + \
                        '<obj:ObservacoesAoTransportador>' + \
                        '</obj:ObservacoesAoTransportador>' + \
                        '<obj:ObservacoesAoCredenciado>' + \
                            obsCredenc + \
                        '</obj:ObservacoesAoCredenciado>' + \
                    '</obj:AdicionarOperacaoTransporteRequest>' + \
                '</pef:AdicionarOperacaoTransporte>' + \
             '</soap:Body>' + \
         '</soap:Envelope>'
    #print(reqXML)
    return reqXML, ''
    ''' CIOT PARA TODOS
                        createtag('obj:CodigoTipoCarga', getJSON(reqJSON,'conh_tipocarga')) + \
                        createtag('obj:AltoDesempenho', getJSON(reqJSON,'conh_altodesemp')) + \
                        createtag('obj:DestinacaoComercial', 'true') + \
                        createtag('obj:FreteRetorno', 'false') + \
                        createtag('obj:TipoPagamento', getJSON(reqJSON,'conh_formapagto')) + \
    '''


def consistEFreteObterPdfConhecimento(reqJSON):
    # PENDENTE CHECAR CAMPOS OBRIGATORIOS GENERICOS NO METODO ABAIXO QUE FICA NO opcartao
    ret = conhecimento.consistObterPdfConhecimento(reqJSON)
    # PENDENTE CHECAR CONSISTENCIAS ESPECIFICAS DA EFRETE
    #ret += 'outro erro'
    return ret


def requestEFreteObterPdfConhecimento(reqJSON):
    erros = consistEFreteObterPdfConhecimento(reqJSON)
    if erros != '':
        return '', erros
    reqXML = \
        '<?xml version=\"1.0\" encoding=\"utf-8\"?>' + \
        '<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:pef=\"http://schemas.ipc.adm.br/efrete/pef\" xmlns:obj=\"http://schemas.ipc.adm.br/efrete/pef/objects\" xmlns:obj1=\"http://schemas.ipc.adm.br/efrete/objects\">' + \
            '<soap:Body>' + \
                '<pef:ObterOperacaoTransportePdf>' + \
                    '<obj:ObterOperacaoTransportePdfRequest>' + \
                        createtag('obj:CodigoIdentificacaoOperacao', getJSON(reqJSON,'conh_ciot')) + \
                        '<obj1:Integrador xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">' + getJSON(reqJSON,'conh_integrador') + '</obj1:Integrador>' + \
                        '<obj1:Versao>1</obj1:Versao>' + \
                        '<obj1:Token></obj1:Token>' + \
                    '</obj:ObterOperacaoTransportePdfRequest>' + \
                 '</pef:ObterOperacaoTransportePdf>' + \
             '</soap:Body>' + \
         '</soap:Envelope>'
    return reqXML, ''


def consistEFreteCancelarConhecimento(reqJSON):
    # PENDENTE CHECAR CAMPOS OBRIGATORIOS GENERICOS NO METODO ABAIXO QUE FICA NO opcartao
    ret = conhecimento.consistCancelarConhecimento(reqJSON)
    # PENDENTE CHECAR CONSISTENCIAS ESPECIFICAS DA EFRETE
    #ret += 'outro erro'
    return ret


def requestEFreteCancelarConhecimento(reqJSON):
    erros = consistEFreteCancelarConhecimento(reqJSON)
    if erros != '':
        return '', erros
    reqXML = \
        '<?xml version=\"1.0\" encoding=\"utf-8\"?>' + \
        '<soap12:Envelope xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">' + \
            '<soap12:Body>' + \
                '<CancelarOperacaoTransporte xmlns=\"http://schemas.ipc.adm.br/efrete/pef\">' + \
                    '<CancelarOperacaoTransporteRequest xmlns=\"http://schemas.ipc.adm.br/efrete/pef/objects\">' + \
                        '<Token xmlns=\"http://schemas.ipc.adm.br/efrete/objects\"></Token>' + \
                        '<Integrador xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">' + getJSON(reqJSON,'conh_integrador') + '</Integrador>' + \
                        '<Versao xmlns=\"http://schemas.ipc.adm.br/efrete/objects\">1</Versao>' + \
                        createtag('CodigoIdentificacaoOperacao', getJSON(reqJSON,'conh_ciot')) + \
                        createtag('Motivo', getJSON(reqJSON,'conh_motcanc')) + \
                    '</CancelarOperacaoTransporteRequest>' + \
                 '</CancelarOperacaoTransporte>' + \
             '</soap12:Body>' + \
         '</soap12:Envelope>'
    return reqXML, ''


def responseEFreteCadastrarProprietario(ret):
    return responseEFreteCadastrarGeral(ret)


def responseEFreteCadastrarMotorista(ret):
    return responseEFreteCadastrarGeral(ret)


def responseEFreteCadastrarVeiculo(ret):
    return responseEFreteCadastrarGeral(ret)


def responseEFreteCadastrarConhecimento(ret):
    return responseEFreteCadastrarGeral(ret)


def responseEFreteObterPdfConhecimento(ret):
    resp, erros = responseEFreteCadastrarGeral(ret)
    if resp != '':
        root = mdom.parseString(ret)
        pdf = root.getElementsByTagName('Pdf')
        if pdf:
            pdfResp = '<pdf>' + pdf[0].firstChild.data + '</pdf>'
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + 'Obtido PDF com sucesso' + '</msg>' + pdfResp + '</resp>', ''
        else:
            return '', 'ERRO AO OBTER PDF'
    else:
        return '', erros


def responseEFreteCancelarConhecimento(ret):
    return responseEFreteCadastrarGeral(ret)


def responseEFreteCadastrarGeral(ret):
    try:
        root = mdom.parseString(ret)
        sucesso = root.getElementsByTagName('Sucesso')
        if sucesso and sucesso[0] is not None and sucesso[0].firstChild.data == 'true':
            ciot = root.getElementsByTagName('CodigoIdentificacaoOperacao')
            if ciot:
                ciotResp = '<ciot>' + ciot[0].firstChild.data + '</ciot>'
            else:
                ciotResp = ''
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + 'Cadastrado com sucesso' + '</msg>' + ciotResp + '</resp>', ''
        else:
            mensagem = root.getElementsByTagName('Mensagem')
            if not mensagem or mensagem[0] is None:
                mensagem = root.getElementsByTagName('soap:Text')
                if not mensagem or mensagem[0] is None:
                    msgResp = 'MENSAGEM DE ERRO DA OPERADORA NÃO ENCONTRADA'
                else:
                    msgResp = mensagem[0].firstChild.data
            else:
                msgResp = mensagem[0].firstChild.data
            return '', msgResp
    except Exception as e:
        print('Erro em responseEFreteCadastrarGeral')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseEFreteErro500(req, ret, arqreq, arqresp):
    strIndex = 'Erro no documento XML (1, '
    if strIndex in ret:
        index = ret.index(strIndex) + len(strIndex)
        index2 = ret.index(')', index)
        coluna = int(ret[index:index2])
        coluna2 = req.index('>',coluna)
        strColuna = req[coluna-1:coluna2]
        return '', 'ERRO INTERNO DA EFRETE (500), PROVAVELMENTE A TAG ' + strColuna + ' ESTA COM INFORMAÇÃO INVÁLIDA', arqreq, arqresp
    else:
        return '', 'ERRO INTERNO DO SERVIDOR DA OPERADORA DE CARTÃO (500)', arqreq, arqresp


