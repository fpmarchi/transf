import base64
import json
from urllib.parse import urlunparse, urlparse

from requests import post, Response
from geraljson import *
from geral import *
import time
from ActionProcessor import ActionProcessor, Callable_cfg, parse_props



cartao_mastercard = 1   # 1- Cartao Mastercard / 2-Cartão TruckPag / 3-Depósito em Conta Corrente / 4-Depósito em Conta Poupança
cartao_truckpag = 2
deposito_contacorrente = 3
deposito_contapoupanca = 4

def declarar_op_transporte(req: dict):
    try:
        reqObj = {}
        erros = consistir(req)
        if erros:
            return erros

        tipoAntt = req.get('conh_prop_tipoantt', '')
        reqObj['TipoViagem'] = (3 if tipoAntt == 3 else 1)   # 1 - Padrão 3 - TAC Agregado
        reqObj['CpfCnpjContratante'] = req.get('conh_filial_cnpjcpf', '')
        #reqObj['CpfCnpjContratante'] = '24952520000162'
        rntrc = req.get('conh_filial_rntrc', '')
        if len(rntrc) == 8: # a pedido da gabriela a ciotpag valida com 9 digitos
            rntrc = "0" + rntrc
        reqObj['RNTRCContratante'] = rntrc
        #reqObj['RNTRCContratante'] = '12751170'
        reqObj['CpfCnpjContratado'] = req.get('conh_prop_cnpjcpf', '')

        rntrc_prop = req.get('conh_prop_rntrc', '')
        if len(rntrc_prop) == 8:
            rntrc_prop = "0"+rntrc_prop

        reqObj['RNTRCContratado'] = rntrc_prop

        veiculoArray = []
        veiculoObj = {}
        veiculoObj['Placa'] = req.get('conh_veic_placa', '')
        veiculoObj['RNTRC'] = rntrc_prop
        veiculoObj['TipoVeiculo'] = 'C'  # C- cavalo/caminhao   S- carreta ou semireboque
        veiculoArray.append(veiculoObj)

        reqObj['Veiculos'] = veiculoArray
        reqObj['CpfCnpjDestinatario'] = req.get('conh_dest_cnpjcpf', '')
        reqObj['CodigoMunicipioOrigem'] = req.get('conh_codibgeorig', '')
        reqObj['CodigoMunicipioDestino'] = req.get('conh_codibgedest', '')
        if req.get('conh_ncm', '') != '':
            reqObj['CodigoNaturezaCarga'] = req.get('conh_ncm', '')
        else:
            reqObj['CodigoNaturezaCarga'] = '0001'
        reqObj['PesoCarga'] = req.get('conh_pesosaida', '')
        reqObj['DataInicioViagem'] = req.get('conh_dataini', '')
        reqObj['DataFimViagem'] = req.get('conh_datafim', '')
        reqObj['QuantidadeTarifas'] = 0
        reqObj['ValorTarifas'] = 0
        reqObj['ValorBruto'] = req.get('conh_valorviagem', '')
        reqObj['ValorAdiantamento'] = req.get('conh_valoradiant', '')
        reqObj['ValorPago'] = req.get('conh_valorsaldo', '')
        reqObj['ValorSest'] = req.get('conh_impsest', '')
        reqObj['ValorINSS'] = req.get('conh_impinss', '')
        reqObj['ValePedagio'] = 0
        reqObj['ValorCombustível'] = 0
        reqObj['ValorIRRF'] = req.get('conh_impirrf', '')
        reqObj['ValorDesconto'] = req.get('conh_outrosdescmot', '')
        if req.get('conh_outrosdescmot') and req.get('conh_outrosdescmot') != '0.00':
            reqObj['NomeDesconto'] = 'OUTROS DESCONTOS MOT'
        else:
            reqObj['NomeDesconto'] = ''
        reqObj['ValorAcrescimo'] = 0
        reqObj['NomeAcrescimo'] = 0
        reqObj['Observacao'] = ''
        reqObj['IdExterno'] = req.get('conh_numero', '')

        formaPagamentoArray = []
        formaPagamentoObj = {}
        var = int(req.get('conh_formapagamento', 0))
        if var:
            formaPagamentoObj['TipoFormaPagamento'] = var
            if var == cartao_mastercard or var == cartao_truckpag:
                formaPagamentoObj['NumeroCartao'] = req.get('conh_numerocartao', '')
            else:
                formaPagamentoObj['Banco'] = req.get('conh_codbanco', '')
                formaPagamentoObj['NumeroAgencia'] = req.get('conh_agencia', '')
                formaPagamentoObj['NumeroConta'] = req.get('conh_conta', '')
                formaPagamentoObj['DigitoConta'] = req.get('conh_digitoconta', '')
                formaPagamentoObj['CpfCnpj'] = req.get('conh_titularconta', '')
            formaPagamentoObj['ValorPrevisto'] = req.get('conh_valorsaldo', '')
            formaPagamentoArray.append(formaPagamentoObj)
            reqObj['FormasPagamento'] = formaPagamentoArray

        return json.dumps(reqObj), ''
    except Exception as e:
        print('Erro em encerrar_op_transporte')
        print(e)
        return '', 'ERRO AO TRATAR ENVIO PARA OPERADORA DE CARTÃO ' + str(e)


def encerrar_op_transporte(req: dict):
    try:
        reqObj = {}
        reqObj['IdExterno'] = req.get('conh_numero', '')
        reqObj['PesoCarga'] = req.get('conh_pesosaida', '')
        reqObj['QuantidadeTarifas'] = 0
        reqObj['ValorTarifas'] = 0
        rotaArray = []
        rotaObj = {}
        rotaObj['CodigoMunicipioOrigem'] = req.get('conh_codibgeorig', '')
        rotaObj['CodigoMunicipioDestino'] = req.get('conh_codibgedest', '')
        if req.get('conh_ncm', '') != '':
            rotaObj['CodigoNaturezaCarga'] = req.get('conh_ncm', '')
        else:
            rotaObj['CodigoNaturezaCarga'] = '0001'
        rotaObj['PesoCarga'] = req.get('conh_pesosaida', '')
        rotaObj['QtdeViagens'] = 1
        rotaArray.append(rotaObj)
        reqObj['Rotas'] = rotaArray

        return json.dumps(reqObj), ''
    except Exception as e:
        print('Erro em encerrar_op_transporte')
        print(e)
        return '', 'ERRO AO TRATAR ENVIO PARA OPERADORA DE CARTÃO ' + str(e)


def cancelar_op_transporte(req: dict):
    reqObj = {}
    reqObj['IdExterno'] = req.get('conh_numero', '')
    reqObj['motivo'] = req.get('conh_motcanc', '')

    return json.dumps(reqObj), ''


def retificar_op_transporte(req: dict):
    try:
        reqObj = {}
        reqObj['IdExterno'] = req.get('conh_numero', '')
        veiculoArray = []
        veiculoObj = {}
        veiculoObj['Placa'] = req.get('conh_veic_placa', '')
        veiculoObj['RNTRC'] = req.get('conh_prop_rntrc', '')
        veiculoObj['TipoVeiculo'] = 'C'  # C- cavalo/caminhao   S- carreta ou semireboque
        veiculoArray.append(veiculoObj)
        reqObj['Veiculos'] = veiculoArray
        reqObj['CodigoMunicipioOrigem'] = req.get('conh_codibgeorig', '')
        reqObj['CodigoMunicipioDestino'] = req.get('conh_codibgedest', '')
        if req.get('conh_ncm', '') != '':
            reqObj['CodigoNaturezaCarga'] = req.get('conh_ncm', '')
        else:
            reqObj['CodigoNaturezaCarga'] = '0001'
        reqObj['PesoCarga'] = req.get('conh_pesosaida', '')
        reqObj['DataInicioViagem'] = req.get('conh_dataini', '')
        reqObj['DataFimViagem'] = req.get('conh_datafim', '')
        reqObj['QuantidadeTarifas'] = 0
        reqObj['ValorTarifas'] = 0

        return json.dumps(reqObj), ''
    except Exception as e:
        print('Erro em retificar_op_transporte')
        print(e)
        return '', 'ERRO AO TRATAR ENVIO PARA OPERADORA DE CARTÃO ' + str(e)


def getpdf_op_transporte():
    return ''

def consistir(req:dict):

    forma_pag = int(req.get('conh_formapagamento', 0))
    msg = ''
    if forma_pag:
        if forma_pag == deposito_contacorrente or forma_pag == deposito_contapoupanca:
            if req.get('conh_codbanco', '') == '':
                msg = 'Banco'
            if req.get('conh_agencia', '') == '':
                msg += ', Agência'
            if req.get('conh_conta', '') == '':
                msg += ', Conta'
            if req.get('conh_titularconta', '') == '':
                msg += ', Cpf/Cnpj do Titular da Conta'
            if msg:
                msg = 'Para forma de pagamento depósito, é obrigatório informar o(s) campo(s) '+msg
                return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><retorno>'+msg+'</retorno></resp>'
        elif forma_pag == cartao_truckpag or forma_pag == cartao_mastercard:
            if req.get('conh_numerocartao', '') == '':
                msg = 'Para forma de pagamento cartão, é obrigatório informar o número do cartão no cadastro do proprietário ou motorista'
                return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><retorno>' + msg + '</retorno></resp>'


def response_declarar_op_transporte(resp: Response):
    try:
        status = resp.status_code
        if status == 200 or status == 201:
            retorno = resp.json()
            ciot = retorno['CodigoIdentificacaoOperacao']
            numviagemopcartao = retorno['CodigoVerificador']
            mensagem = retorno['Mensagem']

            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><retorno>'+str(mensagem)+'</retorno><ciot>'+str(ciot)+'</ciot><numviagopcartao>'+str(numviagemopcartao)+'</numviagopcartao></resp>', ''
        else:
            retorno = resp.json()
            return '',  '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><retorno>'+str(retorno['Mensagem'])+'</retorno></resp>'

    except Exception as e:
        print('Erro em responseCiotPagDeclararOpTransp')
        print(e)
        return '', 'ERRO AO TRATAR RETORNO DA OPERADORA DE CARTÃO ' + str(e)

def response_retificar_op_transporte(resp:Response):
    try:
        status = resp.status_code
        if status == 200 or status == 201 or status == 202:
            retorno = resp.json()
            dataretificacao = str(retorno['DataRetificacao'])
            protocolo = str(retorno['Protocolo'])
            ciot = str(retorno['CodigoIdentificacaoOperacao'])
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><dataretificacao>'+dataretificacao+'</dataretificacao><protocolo>'+protocolo+'</protocolo><ciot>'+ciot+'</ciot></resp>', ''
        else:
            retorno = resp.json()
            return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><retorno>' + str(retorno['Mensagem']) + '</retorno></resp>'

    except Exception as e:
        print('Erro em responseCiotPagRetificar')
        print(e)
        return '', 'ERRO AO TRATAR RETORNO DA OPERADORA DE CARTÃO '+str(e)

def response_encerrar_op_transporte(resp:Response):
    try:
        status = resp.status_code
        if status == 200 or status == 201 or status == 202:
            retorno = resp.json()
            dataencerramento = str(retorno['DataEncerramento'])
            protocolo = str(retorno['Protocolo'])
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><dataencerramento>' + dataencerramento + '</dataencerramento><protocolo>'+protocolo+'</protocolo></resp>', ''
        else:
            retorno = resp.json()
            return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><retorno>' + str(retorno['erro']) + '</retorno></resp>'

    except Exception as e:
        print('Erro em responseCiotPagRetificar')
        print(e)
        return '', 'ERRO AO TRATAR RETORNO DA OPERADORA DE CARTÃO ' + str(e)

def response_cancelar_op_transporte(resp:Response):
    status = resp.status_code
    if status == 200 or status == 201 or status == 202:
        retorno = resp.json()
        datacancelamento = str(retorno['DataCancelamento'])
        protocolo = str(retorno['Protocolo'])
        return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><datacancelamento>' + datacancelamento + '</datacancelamento><protocolo>'+protocolo+'</protocolo></resp>', ''
    else:
        retorno = resp.json()
        return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><retorno>' + str(retorno['erro']) + '</retorno></resp>'


def getHeadersMD5(props):
    usuario = props.get('usuario', '')
    senha = props.get('senha', '')
    senhamd5 = encryptMd5(senha.strip())
    headers = {}
    headers['Authorization'] = 'Basic ' + base64.b64encode(bytes(f"{usuario}:{senhamd5}", "utf-8")).decode("ascii")
    return headers


class CiotPagAC(ActionProcessor):
    MIN_ACTION = 1450
    MAX_ACTION = 1499
    ACAO_CIOTPAG_DECLARAR_OPTRANSP = 1450
    ACAO_CIOTPAG_CANCELAR_OPTRANSP = 1451
    ACAO_CIOTPAG_ENCERRAR_OPTRANSP = 1452
    ACAO_CIOTPAG_RETIFICAR_OPTRANSP = 1453
    ACAO_CIOTPAG_GETPDF_OPTRANSP = 1454

    __token_cache = {}

    def __init__(self):

        request_builders: Callable_cfg = {
            self.ACAO_CIOTPAG_DECLARAR_OPTRANSP: declarar_op_transporte,
            self.ACAO_CIOTPAG_CANCELAR_OPTRANSP: cancelar_op_transporte,
            self.ACAO_CIOTPAG_ENCERRAR_OPTRANSP: encerrar_op_transporte,
            self.ACAO_CIOTPAG_RETIFICAR_OPTRANSP: retificar_op_transporte,
            self.ACAO_CIOTPAG_GETPDF_OPTRANSP: getpdf_op_transporte
        }

        response_parsers: Callable_cfg = {
            self.ACAO_CIOTPAG_DECLARAR_OPTRANSP: response_declarar_op_transporte,
            self.ACAO_CIOTPAG_RETIFICAR_OPTRANSP: response_retificar_op_transporte,
            self.ACAO_CIOTPAG_ENCERRAR_OPTRANSP: response_encerrar_op_transporte,
            self.ACAO_CIOTPAG_CANCELAR_OPTRANSP: response_cancelar_op_transporte
        }
        super().__init__(request_builders, response_parsers)

    @parse_props
    def get_token(self, context_req: dict) -> str:

        props = context_req.get('props', {})
        usuario = props.get('usuario', '')
        senha = props.get('senha', '')
        url = context_req.get('url', '')

        if not usuario or not senha:
            raise Exception('O usuário ou senha não foram informados.')

        usuario = hash(usuario)

        (token, gen_time) = self.__token_cache.get(usuario, (bytearray(), 0))

        if token and (time.time() - gen_time) < 3300:  # Se a idade for menor que 55 minutos
            return token

        try:
            headers = getHeadersMD5(props)

            parsed_uri = list(urlparse(url.strip()))
            parsed_uri[2] = '/signIn'

            resp = post(urlunparse(parsed_uri), headers=headers)

        except Exception as e:
            raise Exception('Erro ao buscar token de autorização na CiotPag!\n' + str(e))

        if resp.status_code == 200 or resp.status_code == 201:
            ret = resp.content.decode('utf-8')
            root = json.loads(ret)
            token = getJSON(root, 'token')
            self.__token_cache[usuario] = (token, time.time())
            return token
        elif resp.status_code == 401:
            raise Exception('401 - Usuário ou Senha inválidos')

        else:
            raise Exception('Não foi possível realizar a autenticação na CiotPag.')

    def get_headers(self, dict_with_props: dict):
        try:
            token = self.get_token(dict_with_props)
            headers = {'Authorization': 'Bearer ' + token}
            headers['Content-Type'] = 'application/json'

            return headers, ''
        except Exception as e:
            return '', 'Erro ao processar solicitação.\nDetalhes: ' + str(e)


ciot_pag = CiotPagAC()
