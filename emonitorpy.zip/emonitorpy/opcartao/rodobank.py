import json
from GetJson import GetJson
from entity import proprietario, motorista, veiculo, conhecimento
from consist import *
from geral import *
import base64
from datetime import datetime
import requests

ACAO_RODOBANK_INICIO = 1400
ACAO_RODOBANK_CADASTRARPROPRIETARIO = 1401
ACAO_RODOBANK_CADASTRARMOTORISTA = 1402
ACAO_RODOBANK_CADASTRARVEICULO = 1403
ACAO_RODOBANK_CADASTRARCARRETA1 = 1404
ACAO_RODOBANK_CADASTRARCARRETA2 = 1405
ACAO_RODOBANK_CADASTRARCARRETA3 = 1406

ACAO_RODOBANK_EMITE_CONTRATO = 1407
ACAO_RODOBANK_INTERROMPER_CONTRATO = 1408
ACAO_RODOBANK_CANCELAR_CONTRATO = 1409
ACAO_RODOBANK_QUITAR_CONTRATO = 1410
ACAO_RODOBANK_INSERIR_ROTA = 1411
ACAO_RODOBANK_CONSULTAR_ROTA = 1412
ACAO_RODOBANK_OBTERCUSTO_ROTA = 1413
ACAO_RODOBANK_INSERIRROTA_IDAVOLTA = 1413

ACAO_RODOBANK_FIM = 1449


def preProcessRequestPropertiesRodobank(headers, requestProperties):
    properties = {}
    if requestProperties != '':
        listProperties = list(requestProperties.split('&'))
        for property in listProperties:
            entry = property.split('=')
            properties[entry[0]] = entry[1]

    login = properties['login']
    token = properties['token']

    # headers['Content-Type'] = 'application/json'
    headers['Authorization'] = 'Basic ' + base64.b64encode(bytes(f"{login}:{token}", "utf-8")).decode("ascii")

    return headers, ''


def requestRodobankAddProp(reqJSON, requestProperties):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        erros = consistRodobankCadastrarProprietario(reqJSON)
        if erros != '':
            return '', erros

        req = {}
        tipopessoa = len(getJSON('prop_cnpjcpf'))
        if tipopessoa == 11:
            tipopessoa = 0
        else:
            if getJSON('prop_tipotributacao') == '1' or getJSON('prop_tipotributacao') == '2':
                tipopessoa = 1
            else:
                tipopessoa = 2

        req['cnpj_cpf'] = getJSON('prop_cnpjcpf')
        req['person_type'] = tipopessoa
        req['name'] = getJSON('prop_nome')
        req['fantasy_name'] = getJSON('prop_nome')
        req['address'] = getJSON('prop_endereco') + ", " + getJSON('prop_numero')
        req['neighborhood'] = getJSON('prop_bairro')
        req['city'] = getJSON('prop_cidade')
        req['cep'] = getJSON('prop_cep')
        req['state'] = getJSON('prop_uf')
        req['phone1'] = getJSON('prop_foneddd') + getJSON('prop_fonenumero')
        req['mobile_phone'] = getJSON('prop_celularddd') + getJSON('prop_celularnumero')
        req['email'] = getJSON('prop_email')
        req['contact_name'] = getJSON('prop_nome')
        req['inss_code'] = getJSON('prop_cei')
        req['rntrc_code'] = getJSON('prop_rntrc')
        #req['rntrc_date_issue'] = "04/10/2018",
        req['rntrc_date_due'] = wsstrtoDDMMAAAA(getJSON('prop_validaderntrc'))

        if getJSON('mot_adtoliberado') == 'S':
            req['driver_percentual'] = '100'
        else:
            req['driver_percentual'] = '0'

        if getJSON('mot_sdliberado') == 'S':
            req['driver_balance_percentual'] = '100'
        else:
            req['driver_balance_percentual'] = '0'

        if tipopessoa == 0:
            req['rg'] = getJSON('prop_rg')
            req['birth_date'] = wsstrtoDDMMAAAA(getJSON('prop_datanasc'))

        req['client'] = requestProperties['login']
        req['auth'] = requestProperties['token']

        req = json.dumps(req)
        return req, ''
    except Exception as e:
        print('Erro em requestRodobankAddProprietario')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def requestRodobankAddMot(reqJSON, requestProperties):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        erros = consistRodobankCadastrarMotorista(reqJSON)
        if erros != '':
            return '', erros

        req = {}

        req['cpf'] = getJSON('mot_cpf')
        if getJSON('prop_cnpjcpf') != '':
            req['hired_cnpj_cpf'] = getJSON('prop_cnpjcpf')
        req['name'] = getJSON('mot_nome')
        req['cep'] = getJSON('mot_cep')
        req['address'] = getJSON('mot_endereco')
        req['neighborhood'] = getJSON('mot_bairro')
        req['city'] = getJSON('mot_cidadeend')
        req['state'] = getJSON('mot_ufend')
        req['phone'] = getJSON('mot_foneddd') + getJSON('mot_fonenumero')
        req['mobile_phone'] = getJSON('mot_celularddd') + getJSON('mot_celularnumero')
        req['email'] = getJSON('')
        req['naturalness'] = getJSON('mot_cidadenasc')
        req['naturalness_state'] = getJSON('mot_ufnasc')
        req['birth_date'] = wsstrtoDDMMAAAA(getJSON('mot_datanasc'))
        req['father_name'] = getJSON('mot_nomepai')
        req['mother_name'] = getJSON('mot_nomemae')
        req['rg'] = getJSON('mot_rg')
        req['rg_date_issue'] = wsstrtoDDMMAAAA(getJSON('mot_datarg'))
        req['rg_issuing_body'] = getJSON('mot_orgaorg')
        req['rg_issuing_state'] = getJSON('mot_orgaorguf')
        req['cnh'] = getJSON('mot_cnh')
        req['cnh_date_issue'] = wsstrtoDDMMAAAA(getJSON('mot_dataprimcnh'))
        req['cnh_category'] = getJSON('mot_catcnh')
        req['cnh_date_due'] = wsstrtoDDMMAAAA(getJSON('mot_datavalidcnh'))
        req['cnh_date'] = wsstrtoDDMMAAAA(getJSON('mot_dataprimcnh'))
        req['client'] = requestProperties['login']
        req['auth'] = requestProperties['token']


        req = json.dumps(req)
        return req, ''

    except Exception as e:
        print('Erro em requestRodobankAddMot')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def requestRodobankAddVeic(reqJSON, requestProperties, codEMonitorAcao):
    try:

        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        if codEMonitorAcao == ACAO_RODOBANK_CADASTRARVEICULO:
            prefixTag = 'veic_'
        elif codEMonitorAcao == ACAO_RODOBANK_CADASTRARCARRETA1:
            prefixTag = 'car1_'
        elif codEMonitorAcao == ACAO_RODOBANK_CADASTRARCARRETA2:
            prefixTag = 'car2_'
        elif codEMonitorAcao == ACAO_RODOBANK_CADASTRARCARRETA3:
            prefixTag = 'car3_'

        erros = consistRodobankCadastrarVeiculo(reqJSON, prefixTag)
        if erros != '':
            return '', erros

        req = {}

        req['hired_cnpj_cpf'] = getJSON('prop_cnpjcpf')
        req['car_plate'] = getJSON(prefixTag + 'placa')
        req['number_axes'] = getJSON(prefixTag + 'quanteixos')
        req['year'] = getJSON(prefixTag + 'anofab')
        req['color'] = getJSON(prefixTag + 'cor')
        req['chassis'] = getJSON(prefixTag + 'chassi')
        req['renavam'] = getJSON(prefixTag + 'renavam')

        cidade = getJSON(prefixTag + 'nomecidade')
        cidade = cidade.split('-')

        req['city'] = cidade[0].rstrip()
        req['state'] = cidade[1].strip()

        if codEMonitorAcao == ACAO_RODOBANK_CADASTRARVEICULO:
            req['vehicle_type'] = '2' #truck
            req['tracker'] = '0'  # rastreador
            req['rntrc_vehicle'] = getJSON(prefixTag + 'rntrc')
        else:
            #req['vehicle_type'] = '1' #carreta
            req['rntrc_code'] = getJSON(prefixTag + 'rntrc')


        req['client'] = requestProperties['login']
        req['auth'] = requestProperties['token']

        req = json.dumps(req)
        return req, ''

    except Exception as e:
        print('Erro em requestRodobankAddMot')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def requestRodobankNewContract(reqJSON, requestProperties):
    try:

        ticket_balanca = 78  # 78   Ticket de Balança
        canhoto_nfe = 178  # 178	CANHOTO DA NOTA FISCAL (NOME POR EXTENSO + RG OU CPF + DATA)
        canhoto_cte = 179  # 179	CANHOTO DO DACTE ASSINADO

        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}

        operating_data = {}
        custom_operation_type = {}
        custom_operation_type['weightbreak_type_id'] = getTipoDescontoQuebra(getJSON('conh_tipodescnf1'))
        custom_operation_type['weightbreak_tolerance'] = getJSON('conh_valortoler1')
        custom_operation_type['freight_adjustment'] = getMenorPeso(getJSON('conh_tipodescnf1'))
        custom_operation_type['damage_control'] = False
        checklist = []

        if getJSON('conh_params_exigeticketdescarga') == 'S':
            checklist.append(ticket_balanca)
        if getJSON('conh_params_exigecanhotodacte') == 'S':
            checklist.append(canhoto_cte)
        if getJSON('conh_params_exigecanhotonfe') == 'S':
            checklist.append(canhoto_nfe)

        custom_operation_type['checklist'] = checklist

        operating_data['custom_operation_type'] = custom_operation_type

        operating_data['route_code'] = getJSON('conh_codextrota')
        operating_data['way_code'] = getJSON('conh_codextrota')
        operating_data['travelled_distance'] = getJSON('conh_kmrodado')

        operating_data['origin_name'] = getJSON('conh_rem_nome')
        operating_data['origin_address'] = getJSON('conh_rem_endereco')
        operating_data['origin_post_code'] = getJSON('conh_rem_cep')
        operating_data['origin_fiscal_number'] = getJSON('conh_rem_cnpjcpf')

        operating_data['destination_name'] = getJSON('conh_ciddest_nome')
        operating_data['destination_fiscal_number'] = getJSON('conh_dest_cnpjcpf')
        operating_data['destination_address'] = getJSON('conh_dest_endereco')
        operating_data['destination_post_code'] = getJSON('conh_cepdest')

        operating_data['way_round_trip'] = '0'
        operating_data['branch_client_code'] = getJSON('conh_filial_cnpjcpf')
        operating_data['process_client_code'] = getJSON('conh_numero')
        operating_data['card_number'] = getJSON('conh_numerocartao')
        operating_data['tms_user'] = getJSON('conh_usuariocorrente')

        req['operating_data'] = operating_data

        travel_data = {}
        travel_data['date_departure'] = wsstrtoDDMMAAAA(getJSON('conh_dataini'))
        travel_data['hour_departure'] = wsstrtoDDMMAAAA(getJSON('conh_datafim'))

        req['travel_data'] = travel_data

        documents = []
        invoices = []
        cte = {}

        cte['ctrc_code'] = getJSON('conh_numconhec')
        cte['ctrc_serie'] = getJSON('conh_serie')
        cte['ctrc_filial_codigo_cliente'] = getJSON('conh_numero')
        cte['document_type'] = '0'  # 0 - CTRC, 5 – Manifesto, 6 - Ordem de Coleta, 14 - Nota Fiscal do Produto, 21 - Nota Fiscal de Serviço
        cte['access_key'] = getJSON('conh_ctechave')
        cte['xml'] = getJSON('conh_xmlass')

        index = 1
        while True:
            nfe = {}

            chave = getJSON('conh_chavenf' + str(index))
            if not chave:
                break

            nfe['nf_code'] = getJSON('conh_numnf' + str(index))
            nfe['nf_serie'] = getJSON('conh_serienf' + str(index))
            nfe['nf_sender_cnpj'] = chave[6:18]
            nfe['nf_sender_social_name'] = ''
            nfe['nf_recipient_cnpj'] = ''
            nfe['nf_recipient_social_name'] = ''
            nfe['nf_access_key'] = chave

            invoices.append(nfe)
            index += 1

        cte['invoices'] = invoices
        documents.append(cte)

        integrated_documents = {}

        integrated_documents['documents'] = documents
        req['integrated_documents'] = integrated_documents

        hired = {}
        hired['hired_fiscal_number'] = getJSON('conh_prop_cnpjcpf')
        hired['driver_fiscal_number'] = getJSON('conh_mot_cpf')
        hired['truck_plate'] = getJSON('conh_veic_placa')

        if getJSON('conh_veic_placacarreta1') != '':
            hired['truck_cart_plate'] = getJSON('conh_veic_placacarreta1')
        # if getJSON('conh_veic_placacarreta2') != '':
        #     hired['truck_cart_plate'] = getJSON('conh_veic_placacarreta2')
        # if getJSON('conh_veic_placacarreta3') != '':
        #     hired['truck_cart_plate'] = getJSON('conh_veic_placacarreta3')

        hired['rnrtc_code'] = getJSON('conh_prop_rntrc')
        req['hired'] = hired

        load_data = {}
        load_data['antt_ncm_classification_code_merchandise'] = getJSON('conh_ncm')
        load_data['load_weight'] = getJSON('conh_pesosaida')
        load_data['load_value'] = getJSON('conh_valormerc')
        load_data['load_recipient_fiscal_number'] = getJSON('conh_dest_cnpjcpf')
        load_data['load_recipient_social_name'] = getJSON('conh_dest_nome')
        load_data['load_unity_code'] = getEspecieMerc(getJSON('conh_especmerc1'))
        load_data['load_type_code'] = getJSON('conh_tipocarga')
        req['load_data'] = load_data

        delivery_data = {}

        if getJSON('conh_valorsaldo') != '':
            saldo = float(getJSON('conh_valorsaldo'))
        if getJSON('conh_valoradiant') != '':
            adto = float(getJSON('conh_valoradiant'))
        if getJSON('conh_valorviagem') != '':
            freteMotBruto = float(getJSON('conh_valorviagem'))

        delivery_data['gross_delivery_value'] = freteMotBruto
        delivery_data['delivery_value'] = saldo + adto

        if getJSON('conh_enviarpedagio') != "" and getJSON('conh_enviarpedagio') == 'S':
            delivery_data['toll_value'] = getJSON('conh_valorpedagio')
        else:
            delivery_data['toll_value'] = 0

        delivery_data['in_advance_value'] = getJSON('conh_valoradiant')
        delivery_data['inss'] = getJSON('conh_impinss')
        delivery_data['irrf'] = getJSON('conh_impirrf')
        delivery_data['sest'] = getJSON('conh_impsest')
        delivery_data['senat'] = getJSON('conh_impsenat')

        req['delivery_data'] = delivery_data
        req['movimentos'] = getMovimentos(reqJSON)

        req['toll_payment'] = 'off'

        req['client'] = requestProperties['login']
        req['auth'] = requestProperties['token']

        req = json.dumps(req)
        return req, ''
    except Exception as e:
        print('Erro em requestRodobankNewContract')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def requestRodobankGetRoute(reqJSON, requestProperties):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}
        req['roteiro_codigo_cliente'] = getJSON('rot_codrota')

        req = json.dumps(req)
        return req, ''
    except Exception as e:
        print('Erro em response responseRondobankGetRoute')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def getMovimentos(reqJSON):
    jsonSor = GetJson(reqJSON)
    getJSON = jsonSor.getJSON

    movimentos = []

    if getJSON('conh_valorseguro') != '':
        if float(getJSON('conh_valorseguro')) > 0:
            obj = {}
            obj['movement_code'] = '147'
            obj['value'] = getJSON('conh_valorseguro')
            obj['tms_user'] = getJSON('conh_usuariocorrente')
            movimentos.append(obj)
    if getJSON('conh_outrosdescmot') != '':
        if float(getJSON('conh_outrosdescmot')) > 0:
            obj = {}
            obj['movement_code'] = '149'
            obj['value'] = getJSON('conh_outrosdescmot')
            obj['tms_user'] = getJSON('conh_usuariocorrente')
            movimentos.append(obj)

    return movimentos


def requestRodobankInsertRoute(reqJSON, requestProperties):
    try:

        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}

        req['roteiro_codigo_cliente'] = getJSON('rot_codrota')
        req['cidade_origem_ibge'] = getJSON('rot_codibgeorig')
        req['cidade_origem_cep'] = ''
        req['estado_origem'] = getJSON('rot_uforig')
        req['cidade_destino_ibge'] = getJSON('rot_codibgedest')
        req['cidade_destino_cep'] = ''
        req['estado_destino'] = getJSON('rot_ufdest')
        req['tipo_processo_transporte'] = '0'
        req['ida_volta'] = getJSON('rot_idavolta')
        req['vias'] = getJSON('')

        req = json.dumps(req)
        return req, ''
    except Exception as e:
        print('Erro em response responseRondobankInsertRoute')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def requestRodobankCancelContract(reqJSON, requestProperties):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}
        req['process_client_code'] = getJSON('conh_numero')
        req['branch_client_code'] = getJSON('conh_filial_cnpjcpf')
        req['tms_user'] = getJSON('conh_usuariocorrente')
        req['client'] = requestProperties['login']
        req['auth'] = requestProperties['token']

        req = json.dumps(req)
        return req, ''
    except Exception as e:
        print('Erro em response requestRondobankCancelContract')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def requestRodobankInterruptContract(reqJSON, requestProperties):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}
        req['process_transport_code'] = getJSON('conh_id')
        req['process_client_code'] = getJSON('conh_numero')
        req['contract_interrupt'] = 1
        req['observation'] = getJSON('conh_motcanc')
        req['reason'] = 1
        req['tms_user'] = getJSON('conh_usuariocorrente')
        req['client'] = requestProperties['login']
        req['auth'] = requestProperties['token']

        req = json.dumps(req)
        return req, ''
    except Exception as e:
        print('Erro em response requestRondobankInterruptContract')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def requestRodobankObterCustoRota(reqJSON, requestProperties):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}

        req['roteiro_codigo'] = getJSON('rot_codext')
        req['percurso_codigo'] = getJSON('rot_perext')
        req['roteiro_cliente_codigo'] = getJSON('rot_codrota')
        req['numero_eixos'] = getJSON('rot_quanteixos')
        req['eixos_suspensos_ida'] = getJSON('')
        req['eixos_suspensos_volta'] = getJSON('')
        req['client'] = requestProperties['login']
        req['auth'] = requestProperties['token']

        req = json.dumps(req)
        return req, ''

    except Exception as e:
        print('Erro em response requestRondobankQuitarContract')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def requestRodobankQuitarContract(reqJSON):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}
        req['tms_user'] = getJSON('conh_usuariocorrente')
        req['process_transport_code'] = getJSON('conh_id')

        req = json.dumps(req)
        return req, ''
    except Exception as e:
        print('Erro em response requestRondobankQuitarContract')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def responseRodobankObterCustoRota(resp):
    root = json.loads(resp)
    jsonResp = GetJson(root)
    getJSON = jsonResp.getJSON

    valortotalvpr = 0
    vl_vpr = getJSON('valor_vpr')
    if 'valor_total_vpr' in vl_vpr:
        valortotalvpr = vl_vpr['valor_total_vpr']

    return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro> <valorpedagio>' + str(valortotalvpr) + '</valorpedagio></resp>', ''


def responseRodobankInserirRota(resp):
    try:

        root = json.loads(resp)
        jsonResp = GetJson(root)
        getJSON = jsonResp.getJSON

        if getJSON('success') != '' or getJSON('message') != '':
            return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><retorno>' + getJSON(
                'message') + '</retorno></resp>'
        else:
            xml = ''
            parametros = getJSON('parametros')
            roteiros = parametros['roteiros']
            roteiro = roteiros['roteiro']

            km_previsto = 0
            ida_volta = '0'

            if roteiro['km_ida'] != '':
                km_previsto += int(roteiro['km_ida'])
            if roteiro['km_volta'] != '':
                km_previsto += int(roteiro['km_volta'])
                if km_previsto > 0:
                    ida_volta = '1'

            xml = '<roteirocodigoexterno>' + str(roteiro['roteiro_codigo']) + '</roteirocodigoexterno>'
            xml += '<roteirocodigointerno>' + str(roteiro['roteiro_cliente_codigo']) + '</roteirocodigointerno>'
            xml += '<kmprevisto>' + str(km_previsto) + '</kmprevisto>'
            xml += '<ida_volta>' + str(ida_volta) + '</ida_volta>'

            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro> <retorno>' + xml + '</retorno></resp>', ''


    except Exception as e:
        print('Erro em response responseRondobankCadastros')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def responseRodobankNewContract(resp):
    try:
        root = json.loads(resp)
        jsonResp = GetJson(root)
        getJSON = jsonResp.getJSON

        if getJSON('success') != '' or getJSON('message') != '':
            return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><retorno>' + getJSON('message') + '</retorno></resp>'
        else:
            processoTransporte = getJSON('processo_transporte')

            if 'processo_transporte_codigo' in processoTransporte:
                idViagem = processoTransporte['processo_transporte_codigo']

            if 'dados_viagem' in processoTransporte:
                dadosViagem = processoTransporte['dados_viagem']
                ciot = dadosViagem['ciot']

            arrayDocuments = []
            objDocuments = {}
            if 'documentos' in processoTransporte:
                documentos = processoTransporte['documentos']
                for doc in documentos:
                   tipo = doc['tipo']
                   link = doc['link']
                   objDocuments['tipo'] = tipo
                   objDocuments['link'] = link
                   arrayDocuments.append(objDocuments)


            xml = ''
            xml = '<idviagem>'+str(idViagem)+'</idviagem>'
            xml += '<ciot>'+str(ciot)+'</ciot>'
            if len(arrayDocuments) > 0:
                xml += '<documentos>'+str(arrayDocuments)+'</documentos>'

            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro> <retorno>' + xml + '</retorno></resp>', ''

    except Exception as e:
        print('Erro em response responseRondobankCadastros')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def responseRondobankCadastros(resp, acao):
    try:

        root = json.loads(resp)
        jsonResp = GetJson(root)
        getJSON = jsonResp.getJSON

        if getJSON('success') != '' or getJSON('message') != '':
            return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><retorno>' + getJSON(
                'message') + '</retorno></resp>'
        else:
            if acao == ACAO_RODOBANK_CADASTRARPROPRIETARIO:
                tipo = 'Proprietário'
            elif acao == ACAO_RODOBANK_CADASTRARMOTORISTA:
                tipo = 'Motorista'
            elif acao == ACAO_RODOBANK_CADASTRARVEICULO:
                tipo = 'Veiculo'
            elif acao == ACAO_RODOBANK_CADASTRARCARRETA1:
                tipo = 'Carreta1'
            elif acao == ACAO_RODOBANK_CADASTRARCARRETA2:
                tipo = 'Carreta2'
            elif acao == ACAO_RODOBANK_CADASTRARCARRETA3:
                tipo = 'Carreta3'
            else:
                tipo = ''

            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><retorno>' + tipo + ' Cadastrado com sucesso' + '</retorno></resp>', ''


    except Exception as e:
        print('Erro em response responseRondobankCadastros')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def responseErrorRodobank(ret, arqreq, arqresp):
    root = json.loads(ret)
    jsonResp = GetJson(root)
    getJSON = jsonResp.getJSON

    if getJSON('success') != '' or getJSON('message') != '':
        return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><retorno>' + getJSON(
            'message') + '</retorno></resp>', arqreq, arqresp


def consistRodobankCadastrarProprietario(reqJSON):
    jsonSor = GetJson(reqJSON)
    getJSON = jsonSor.getJSON

    ret = proprietario.consistCadastrarProprietario(reqJSON)

    if getJSON('prop_datanasc') == '0000-00-00':
        ret += '[Data Nasc. deve ser informado!]'

    return ret


def consistRodobankCadastrarMotorista(reqJSON):
    ret = motorista.consistCadastrarMotorista(reqJSON)

    return ret


def consistRodobankCadastrarVeiculo(reqJSON, prefixTag):
    ret = veiculo.consistCadastrarVeiculo(reqJSON, prefixTag)

    ret += consistEmpty(reqJSON, 'prop_rntrc', 'RNTRC')
    ret += consistEmpty(reqJSON, prefixTag + 'nomecidade', 'Cidade de Emplacamento')

    return ret


def getEspecieMerc(especie):
    especie = especie.upper()

    if especie == 'CAIXA' or especie == 'CAIXAS':
        return 1
    elif especie == 'LATA' or especie == 'LATAS':
        return 2
    elif especie == 'PET' or especie == 'PETS':
        return 3
    elif especie == 'PALLET' or especie == 'PALET' or especie == 'PALLETS' or especie == 'PALETS':
        return 4
    elif especie == 'RACK' or especie == 'RACKS':
        return 5
    elif especie == 'FARDO' or especie == 'FARDOS':
        return 6
    elif especie == 'GRANEL' or especie == 'KG':
        return 7
    elif especie == 'SACO' or especie == 'SACA' or especie == 'SACOS' or especie == 'SACAS':
        return 8
    elif especie == 'TONELADA' or especie == 'TON':
        return 9
    elif especie == 'M3' or especie == 'METRO CUBICO' or especie == 'METROS CUBICOS':
        return 10
    elif especie == 'UNIDADE' or especie == 'UNIDADES' or especie == 'UNITARIO':
        return 11
    elif especie == 'LT' or especie == 'LITRO' or especie == 'LITROS':
        return 12
    else:
        return 0


def getMenorPeso(pesosaidamot):
    if pesosaidamot == 'M':
        menorPeso = True
    elif pesosaidamot == 'S':
        menorPeso = False
    else:
        menorPeso = ''

    return menorPeso


def getTipoDescontoQuebra(tipo):
    tipoDescontoQuebra = ''
    if tipo == 'N':
        tipoDescontoQuebra = 0
    elif tipo == 'P' or tipo == 'F':
        tipoDescontoQuebra = 1
    elif tipo == 'I' or tipo == 'H':
        tipoDescontoQuebra = 2

    return tipoDescontoQuebra
