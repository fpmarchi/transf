import base64
import json
import locale
from datetime import datetime
from requests import Response
from typing import Tuple, List

from dispacher import ActionProcessor
from dispacher.decorators import handle_exception_factory, parse_props
from geral import deep_get, format_cell, safe_cast, format_plate
from geralxml import mount_xml_response


class PoziDigitalException(Exception):
    pass


class PoziDigital(ActionProcessor):
    HOST = 'https://api.pozi.com.br'
    TEST_HOST = 'https://api.pozi.com.br'

    GENERATE_CIOT = 1750
    CANCEL_CIOT = 1751
    CHANGE_STATUS = 1752
    CLOSE_CIOT = 1753

    def __init__(self):
        self.BASE_PATH = ''
        self.TEST_BASE_PATH = ''

        # Hosts de Backup. São usados caso o SAT não informar

        self.add_callable_records('url', {
            self.GENERATE_CIOT: self.make_url_assembler('/Cadastros/Ciot'),
            self.CANCEL_CIOT: self.make_url_assembler('/Cadastros/CancelarCiot'),
            self.CHANGE_STATUS: self.make_url_assembler('/Acoes/Status'),
            self.CLOSE_CIOT: self.make_url_assembler('/Cadastros/EncerrarCiot'),
        })

        super().__init__()

    __token_cache: dict = {}

    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        props = context_req.get('props', {})
        user = props.get('usuario', '')
        password = props.get('senha', '')

        try:
            if not user or not password:
                return {}, 'O usuario ou senha não foram informados!'

            token_bytes: bytes = base64.b64encode(f'{user}:{password}'.encode())

            return {
                'Authorization': f'Basic {token_bytes.decode("ascii")}',
            }, ''

        except(Exception,):
            return {}, 'Por favor verifique as credenciais de acesso para Pozi Digital!'


#
#   Códigos independentes de instancia
#

# Tratamento de exceções
def _pozidigital_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a Pozi Digital:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    PoziDigitalException,
    _pozidigital_exception_callback,
    any_exception_callback
)

#
#   Códigos dependentes de instancia
#

# Instancia limpa e sem configuração (singleton)
_pozidigital = PoziDigital()

# Decorators da instancia
_link_to_request = _pozidigital.link_to_factory('request')
_link_to_response = _pozidigital.link_to_factory('response')


# Login paragerar o token Bearer para realizar as autenticações
@_link_to_request(_pozidigital.GENERATE_CIOT)
@_handle_exception
def _out_generate_ciot(req: dict):
    loc = locale.getlocale()

    def format_brl(value_str: str):
        locale.setlocale(locale.LC_ALL, 'pt_BR.UTF-8')
        try:
            for char in reversed(value_str):
                if char == ',':
                    value_str = value_str.replace('.', '').replace(',', '.')
                elif char == '.':
                    value_str = value_str.replace(',', '')

            return locale.currency(safe_cast(value_str, float, 0), grouping=True, symbol=False)
        finally:
            locale.setlocale(locale.LC_ALL, loc)

    req_data = {
        'tipo_cte': _type_cte(req.get('conh_tipocte', '')),
        'cnpj_emitente': req.get('cnpj_empresa', '') if req.get('cnpj_empresa', '') else req.get('conh_filial_cnpjcpf', ''),
        'numero_interno': req.get('conh_numero', ''),
        'cnpj_filial': req.get('conh_filial_cnpjcpf', ''),
        'tributacao': _type_of_taxation(req.get('conh_prop_tipotributacao', '')),
        'tomador': {
            'cnpj': req.get('conh_cliente_cnpjcpf', ''),
            'IE': req.get('conh_cliente_ie', ''),
            'nome': req.get('conh_cliente_nome', ''),
            'celular': format_cell(req.get('conh_cliente_foneddd', ''),
                                   req.get('conh_cliente_fonenumero', '')),
            'email': req.get('conh_cliente_email', ''),
            'endereco': {
                'cod_ibge': req.get('conh_cliente_codibge', ''),
                'cep': req.get('conh_cliente_cep', ''),
                'logradouro': req.get('conh_cliente_endereco', ''),
                'bairro': req.get('conh_cliente_bairro', ''),
                'cidade': req.get('conh_cliente_cidade_nome', ''),
                'uf': req.get('conh_cliente_cidade_uf', ''),
                'numero': req.get('conh_cliente_numero', ''),
                'complemento': req.get('conh_cliente_complemento', '')
            }
        },
        'remetente': {
            'cnpj': req.get('conh_rem_cnpjcpf', ''),
            'IE': req.get('conh_rem_ie', ''),
            'nome': req.get('conh_rem_nome', ''),
            'celular': format_cell(req.get('conh_rem_foneddd', ''),
                                   req.get('conh_rem_fonenumero', '')),
            'email': req.get('conh_rem_email', ''),
            'endereco': {
                'cod_ibge': req.get('conh_rem_codibge', ''),
                'cep': req.get('conh_rem_cep', ''),
                'logradouro': req.get('conh_rem_endereco', ''),
                'bairro': req.get('conh_rem_bairro', ''),
                'cidade': req.get('conh_rem_cidade_nome', ''),
                'uf': req.get('conh_rem_cidade_uf', ''),
                'numero': req.get('conh_rem_numero', ''),
                'complemento': req.get('conh_rem_complemento', '')
            }
        },
        'destinatario': {
            'cnpj': req.get('conh_dest_cnpjcpf', ''),
            'IE': req.get('conh_dest_ie', ''),
            'nome': req.get('conh_dest_nome', ''),
            'celular': format_cell(req.get('conh_dest_celularddd', ''),
                                   req.get('conh_dest_celularnumero', '')),
            'endereco': {
                'cod_ibge': req.get('conh_dest_codibge', ''),
                'cep': req.get('conh_dest_cep', ''),
                'logradouro': req.get('conh_dest_endereco', ''),
                'bairro': req.get('conh_dest_bairro', ''),
                'cidade': req.get('conh_dest_cidade_nome', ''),
                'uf': req.get('conh_dest_cidade_uf', ''),
                'numero': req.get('conh_dest_numero', ''),
                'complemento': req.get('conh_dest_complemento', '')
            }
        },
        'contratado': {
            'cnpj': req.get('conh_prop_cnpjcpf', ''),
            'IE': deep_get(req, 'prop_mot_veic.prop_ie', ''),
            'nome': req.get('conh_prop_nome', ''),
            'email': req.get('conh_prop_email', ''),
            'rntc': req.get('conh_prop_rntrc', ''),
            'tipo_transportador': deep_get(req, 'prop_mot_veic.prop_tipoantt', ''),
            'celular': format_cell(req.get('conh_prop_celularddd', ''),
                                   req.get('conh_prop_celularnumero', '')),
            'endereco': {
                'cod_ibge': req.get('conh_prop_codibge', ''),
                'cep': deep_get(req, 'prop_mot_veic.prop_cep', ''),
                'logradouro': deep_get(req, 'prop_mot_veic.prop_endereco', ''),
                'bairro': deep_get(req, 'prop_mot_veic.prop_bairro', ''),
                'cidade': deep_get(req, 'prop_mot_veic.prop_cidade', ''),
                'uf': deep_get(req, 'prop_mot_veic.prop_uf', ''),
                'numero': deep_get(req, 'prop_mot_veic.prop_numero', ''),
                'complemento': deep_get(req, 'prop_mot_veic.prop_complemento', ''),
            },
            'dados_bancarios': {
                'banco': req.get('contratado_banco', ''),
                'agencia': req.get('contratado_agencia', ''),
                'tipo_conta': _account_type(req.get('contratado_tipo_conta', '')),
                'conta': req.get('contratado_conta', ''),
                'chave_pix': req.get('contratado_chave_pix', ''),
            }
        },
        'motorista': {
            'cpf': req.get('conh_mot_cpf', ''),
            'nome': req.get('conh_mot_nome', ''),
            'cnh': req.get('conh_mot_cnh', ''),
            'renach': deep_get(req, 'prop_mot_veic.mot_renachcnh', ''),
            'codigo_seguranca_cnh': deep_get(req, 'prop_mot_veic.mot_numsegcnh', ''),
            'celular': format_cell(req.get('conh_mot_celularddd', ''),
                                   req.get('conh_mot_celularnumero', '')),
            'endereco': {
                'cod_ibge': req.get('conh_mot_codibge', ''),
                'cep': deep_get(req, 'prop_mot_veic.mot_cep', ''),
                'logradouro': deep_get(req, 'prop_mot_veic.mot_endereco', ''),
                'bairro': deep_get(req, 'prop_mot_veic.mot_bairro', ''),
                'cidade': deep_get(req, 'prop_mot_veic.mot_nomecidendereco', ''),
                'uf': deep_get(req, 'prop_mot_veic.mot_ufcidendereco', ''),
                'numero': deep_get(req, 'prop_mot_veic.mot_numero', ''),
                'complemento': deep_get(req, 'prop_mot_veic.mot_complemento', ''),
            },
            'dados_bancarios': {
                'banco': req.get('motorista_banco', ''),
                'agencia': req.get('motorista_agencia', ''),
                'tipo_conta': _account_type(req.get('motorista_tipo_conta', '')),
                'conta': req.get('motorista_conta', ''),
                'chave_pix': req.get('motorista_chave_pix', ''),
            }
        },
        'viagem': {
            'data_inicio': format_data_z(req.get('conh_datafimcarregamento')),
            'data_fim': format_data(req.get('conh_dataprevisaodescarga')),
            'distancia': req.get('conh_kmprevistoperc', '') if req.get('conh_kmprevistoperc', '') else req.get(
                'conh_kmrodado', ''),
            'ncm': req.get('conh_ncm_completo', ''),
            'descricao_produto': req.get('conh_descmerc', ''),
            'valor_pedagio': req.get('conh_valorpedagio', ''),
            'tipo_carga': safe_cast(req.get('conh_tipocarga', ''), int, 0),
            'tipo_viagem': req.get('tipo_viagem', ''),
            'peso': format_brl(req.get('conh_pesosaida')),
            'qtde_tarifas': '',  # Não precisa mandar
            'valor_tarifas': format_brl(req.get('conh_precotonmot')),
            'valor_frete': format_brl(req.get('conh_valorfretemot')),
            'vl_adiantamento': format_brl(req.get('conh_valoradiant')),
            'vl_adiantamento2': format_brl(req.get('conh_valoradiant2')),
            'tipo_pagamento': req.get('contratado_tipo_conta'),
            'observacao': '',  # não enviar
            'vl_mercadoria': req.get('conh_valormerc', ''),
            'preco_kg': req.get('conh_precokgmercquebra', ''),
            'tx_tolerancia': req.get('conh_valortoler', ''),
            'tipo_quebras': _type_of_break(req.get('conh_tipodesc', '')),
            'vl_mercadoria_segurada': req.get('conh_vl_merc_segurada'),
            'sest_senat': format_brl(req.get('conh_impsestsenat')),
            'tx_seguro': format_brl(req.get('conh_taxaseguro')),
            'inss': format_brl(req.get('conh_impinss')),
            'vl_seguro': format_brl(req.get('conh_valorseguro')),
            'tx_administrativa': format_brl(req.get('conh_impureza')),  # Taxa adm
            'link_pedagio': req.get('conhec_link_pedagio'),
            'outros_descontos': format_brl(req.get('conh_outrosdescontosmot')),
            'IRRF': format_brl(req.get('conh_impirrf'))
        },
        'veiculos': list(filter(lambda x: not not x.get('placa'), [
            {
                'placa': format_plate(req.get('conh_veic_placa', '')),
                'marca': deep_get(req, 'prop_mot_veic.veic_marca', ''),
                'rntc': req.get('conh_prop_rntrc', '')

            },
            {
                'placa': format_plate(req.get('conh_veic_placacarreta1', '')),
                'marca': deep_get(req, 'prop_mot_veic.car1_marca', ''),
                'rntc': req.get('conh_car1_prop_rntrc')
                if req.get('conh_car1_prop_rntrc')
                else req.get('conh_prop_rntrc', '')
            },
            {
                'placa': format_plate(req.get('conh_veic_placacarreta2', '')),
                'marca': deep_get(req, 'prop_mot_veic.car2_marca', ''),
                'rntc': req.get('conh_car2_prop_rntrc')
                if req.get('conh_car2_prop_rntrc')
                else req.get('conh_prop_rntrc', '')

            },
            {
                'placa': format_plate(req.get('conh_veic_placacarreta3', '')),
                'marca': deep_get(req, 'prop_mot_veic.car3_marca', ''),
                'rntc': req.get('conh_car3_prop_rntrc')
                if req.get('conh_car3_prop_rntrc')
                else req.get('conh_prop_rntrc', '')

            }
        ])),
        'cte': {
            # 'tipo_cte': req.get('tipo_cte', ''), Pediram para retirar
            'num_cte': req.get('conh_numconhec', ''),
            'serie_cte': req.get('conh_serie', ''),
            'chave_cte': req.get('conh_ctechave', ''),
            'valor_cte': req.get('conh_valorfretefiscal', ''),
            'vl_pedagio_cte': req.get('conh_valorpedagio', ''),
            'vl_pedagio_eixo': round(
                safe_cast(req.get('conh_valorpedagio'), float, 0) / req.get('quant_eixo_cavalo', ''), 2),
            'pedagio_embutido': 'SIM' if req.get('pedagio_emb_frete_mot') is True else 'NAO',
            'num_contrato_vl_pedagio': req.get('numero_pedagio', ''),
            'operadora_vale_pedagio': req.get('nome_operadora_pedagio', ''),
            'dact_pdf': req.get('conhec_dacte_pdf', ''),
            'cte_xml': req.get('conhec_cte_xml', '')
        },
        'nfe': {
            'chave_nfe': req.get('conh_chavenf1', ''),
            'tipo_nfe': req.get('conh_modelo_nf1', ''),
            'num_nfe': req.get('conh_numnf1', ''),
            'serie_nfe': req.get('conh_serienf1', ''),
            'valor_nfe': format_brl(req.get('conh_valornf1', '')),
        },
        'ICMS': {
            'base_calculo': format_brl(req.get('conh_baseicms')),
            'aliquota': format_brl(req.get('conh_poricms')),
            'reducao_base': format_brl(req.get('conh_percredbaseicms')),
            'vl_liquido_icms': format_brl(req.get('conh_valoricms'))
        },
        'pedido': req.get('cod_pedido', ''),
        'pedido_cliente': req.get('cod_pedido_cli', ''),
        'ordem': req.get('conh_ordemcar_codigo', ''),
        'coleta': {
            'cnpj': req.get('conh_cole_cnpjcpf'),
            'IE': req.get('conh_cole_ie'),
            'nome': req.get('conh_cole_nome'),
            'celular': req.get('conh_cole_celular'),
            'endereco': {
                'cod_ibge': req.get('conh_cole_codibge', ''),
                'uf': req.get('conh_cole_cidade_uf'),
                'cep': req.get('conh_cole_cep'),
                'bairro': req.get('conh_cole_bairro'),
                'cidade': req.get('conh_cole_cidade_nome'),
                'numero': req.get('conh_cole_numero'),
                'logradouro': req.get('conh_cole_endereco'),
                'complemento': req.get('conh_cole_complemento')
            }
        },
        'entrega': {
            'cnpj': req.get('conh_entr_cnpjcpf'),
            'IE': req.get('conh_entr_ie'),
            'nome': req.get('conh_entr_nome'),
            'celular': req.get('conh_entr_celular'),
            'endereco': {
                'cod_ibge': req.get('conh_entr_codibge', ''),
                'uf': req.get('conh_entr_cidade_uf'),
                'cep': req.get('conh_entr_cep'),
                'bairro': req.get('conh_entr_bairro'),
                'cidade': req.get('conh_entr_cidade_nome'),
                'numero': req.get('conh_entr_numero'),
                'logradouro': req.get('conh_entr_endereco'),
                'complemento': req.get('conh_entr_complemento')
            }
        },
    }

    return json.dumps(req_data), ''


@_link_to_request(_pozidigital.CANCEL_CIOT)
@_handle_exception
def _out_cancel_ciot(req: dict):
    req_data = {
        'cod_ciot': req.get('ciot', ''),
        'motivo': req.get('motivo_cancelamento', '')
    }

    return json.dumps(req_data), ''


@_link_to_request(_pozidigital.CHANGE_STATUS)
@_handle_exception
def _out_change_status(req: dict):
    req_data = {
        'acao': req.get('acao_status', ''),
        'peso_chegada': req.get('peso_chegada', ''),
        'cod_contrato': req.get('cod_contrato', '')
    }

    return json.dumps(req_data), ''


@_link_to_request(_pozidigital.CLOSE_CIOT)
@_handle_exception
def _out_change_status(req: dict):
    req_data = {
        'cod_contrato': req.get('cod_contrato', ''),
        'cod_ciot': req.get('cod_ciot', ''),
        'motivo': req.get('motivo', ''),
        'peso_chegada': req.get('peso_chegada', ''),
        'mdfe': {
            'num_mdfe': req.get('num_mdfe', ''),
            'chave_mdfe': req.get('chave_mdfe', ''),
            'serie_mdfe': req.get('serie_mdfe', ''),
            'vl_mdfe': req.get('vl_mdfe', '').replace('.', ','),
        }
    }

    return json.dumps(req_data), ''


#
# Tratamento de retornos
@_link_to_response(_pozidigital.GENERATE_CIOT, _pozidigital.CANCEL_CIOT, _pozidigital.CLOSE_CIOT)
@_handle_exception
def _in_default(resp: Response) -> Tuple[str, str]:
    def make_errors_list(errors: List[dict]):
        return {
            'sucesso': False,
            'erros': [
                {
                    'campo': '',
                    'descricao': err.get('descricao') or ''
                }
                for err in errors
            ]
        }

    ret = resp.json()

    sucesso = ret.get('codigo_retorno')

    if sucesso:
        resp_data = {
            'sucesso': True,
            'conteudo': ret
        }
    elif type(ret.get('erros')) is list:
        resp_data = make_errors_list(ret.get('erros', []))
    elif type(ret.get('motivo')) is list:
        resp_data = make_errors_list(ret.get('motivo', []))
    else:
        error = ret.get('msg', '')

        if not error:
            error = (
                'Erro Retornado pela Pozi Digital!'
                f'\nLocal: {ret.get("local") or "indefinido"}'
                f'\nMotivo: {ret.get("motivo") or "indefinido"}'
            )
        resp_data = {
            'sucesso': False,
            'msg_erro': error
        }

    return mount_xml_response(resp_data), ''


@_link_to_response(_pozidigital.CHANGE_STATUS)
@_handle_exception
def _in_change_status(resp: Response) -> Tuple[str, str]:
    ret = resp.json()

    sucesso = ret.get('cod_retorno')

    try:
        if sucesso:
            resp_data = {
                'sucesso': True,
                'conteudo': ret
            }
        elif 'erros' in ret and ret.get:
            resp_data = {
                'sucesso': False,
                'erros': [
                    {
                        'campo': '',
                        'descricao': deep_get(erro, 'descricao') or ''
                    }
                    for erro in ret.get('erros', [])
                ]
            }
        else:
            resp_data = {
                'sucesso': False,
                'msg_erro': deep_get(ret, 'msg')
            }
    except Exception as e:
        resp_data = {
            'sucesso': False,
            'msg_erro': 'Ocorreu um erro desconhecido ao tentar retornar as informações do EmonitorPy para Pozi Digital:\n' + str(
                e)
        }

    return mount_xml_response(resp_data), ''


def _type_cte(type_cte: str) -> str:
    if type_cte == '0':
        return 'Normal/Normal'
    elif type_cte == '1':
        return 'Normal/Multimodal'
    else:
        ''


def _type_of_taxation(type_of_taxation: str) -> str:
    if type_of_taxation == '0':
        return 'Normal-0'
    elif type_of_taxation == '1':
        return 'Simples-1'
    else:
        ''


def _type_of_break(type_of_break: str) -> str:
    if type_of_break == 'P':
        return '1'
    elif type_of_break == 'I':
        return '2'
    elif type_of_break == 'N':
        return '3'
    else:
        ''


def _type_trip(type_trip: str) -> str:
    if type_trip == '0':
        return '1'
    elif type_trip == 'I':
        return '2'
    elif type_trip == 'N':
        return '3'
    else:
        ''


def _account_type(type_of_payment: str) -> str:
    if type_of_payment == '1' or type_of_payment == '3':
        return 'C'
    elif type_of_payment == '2':
        return 'P'
    else:
        ''


def format_data_z(date: str) -> str:
    try:
        date = datetime.strptime(date, '%Y-%m-%dT%H:%M:%S.000Z').strftime("%d/%m/%Y")
    except(Exception,):
        return ''
    return date


def format_data(date: str) -> str:
    try:
        date = datetime.strptime(date, '%Y-%m-%d').strftime("%d/%m/%Y")
    except(Exception,):
        return ''
    return date
