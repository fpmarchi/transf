import json
from string import Template
from typing import Tuple

import requests
import xmltodict
from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Util.Padding import unpad
from requests import Response

from ActionProcessor import ActionProcessor, handle_exception_factory, HttpMethod, parse_props
from geral import *
from geralxml import *


# Exceção customizada
class TipFreteException(Exception):
    pass


class TipFrete(ActionProcessor):
    BASE_URL = 'https://wsconvenio.strada.log.br/wsconvenio/resources/'
    BASE_URL_TEST = 'https://hml-wsconvenio.strada.log.br/wsconvenio/resources/'

    OBTERAUTENTICACAO = -2

    CADASTRARMOTORISTA = 1550
    CONSULTARTRANSPORTADOR = 1551
    CADASTRARVIAGEM = 1552
    CONSULTARVIAGEM = 1553
    AUTORIZARCANCELARVIAGEM = 1554
    CADASTRARROTA = 1555
    CONSULTARROTA = 1556
    AJUSTEIMEDIATO = 1557
    COMPRARPEDAGIOAVULSO = 1558
    CANCELARPEDAGIOAVULSO = 1559
    CREDITOIMEDIATO = 1560
    ARQUIVOCOBRANCA = 1561
    ATUALIZARROTA = 1562
    CIOTGRATUITO = 1564
    CANCELARCIOTGRATUITO = 1565
    ENCERRARCIOTGRATUITO = 1566
    FINALIZARVIAGEM = 1568
    CONSULTARFINALIZACAO = 1569

    def __init__(self):
        self.add_callable_records('url', {
            self.OBTERAUTENTICACAO: (_make_url, _make_defaults('/autenticacaoViagem', HttpMethod.POST)),
            self.CADASTRARMOTORISTA: (_make_url, _make_defaults('/cadastroIntegracaoMotorista', HttpMethod.POST)),
            self.CONSULTARTRANSPORTADOR: (_make_url, _make_defaults('/consultaSituacaoTransportador', HttpMethod.POST)),
            self.CADASTRARVIAGEM: (_make_url, _make_defaults('/cadastroViagemSec', HttpMethod.POST)),
            self.CIOTGRATUITO: (_make_url, _make_defaults('/cadastroViagemSec', HttpMethod.POST)),
            self.CANCELARCIOTGRATUITO: (_make_url, _make_defaults('/cancelarOperacaoTransporte', HttpMethod.POST)),
            self.ENCERRARCIOTGRATUITO: (_make_url, _make_defaults('/encerrarOperacaoTransporte', HttpMethod.POST)),
            self.CONSULTARVIAGEM: (_make_url, _make_defaults('/consultaResgateViagemSec', HttpMethod.POST)),
            self.AUTORIZARCANCELARVIAGEM: (_make_url,
                                           _make_defaults('/autorizacaoCancelamentoViagemSec', HttpMethod.POST)),
            self.FINALIZARVIAGEM: (_make_url, _make_defaults('/viagem/finalizacao', HttpMethod.POST)),
            self.CONSULTARFINALIZACAO: (_make_url, _make_defaults('/viagem/consulta', HttpMethod.POST)),
            self.CADASTRARROTA: (_make_url, _make_defaults('/criaRota', HttpMethod.POST)),
            self.CONSULTARROTA: (_make_url, _make_defaults('/consultaRota', HttpMethod.POST)),
            self.ATUALIZARROTA: (_make_url, _make_defaults('/atualizaRota', HttpMethod.POST)),
            self.AJUSTEIMEDIATO: (_make_url, _make_defaults('/ajusteImediato', HttpMethod.POST)),
            self.COMPRARPEDAGIOAVULSO: (_make_url, _make_defaults('/pedagio/compra', HttpMethod.POST)),
            self.CANCELARPEDAGIOAVULSO: (_make_url, _make_defaults('/pedagio/cancela', HttpMethod.POST)),
            self.CREDITOIMEDIATO: (_make_url, _make_defaults('/creditoImediato', HttpMethod.POST)),
            self.ARQUIVOCOBRANCA: (_make_url, _make_defaults('/gerarArquivoCobrancaPedagio', HttpMethod.POST)),
        })

        super().__init__()

    @parse_props
    def get_headers(self) -> Tuple[dict, str]:
        return {
                   'Content-type': 'application/xml;charset=utf-8'
               }, ''

    def get_key(self, context_data: dict):
        body = {
            'autenticacao': {
                'usuario': deep_get(context_data, 'props.usuario', ''),
                'senha': deep_get(context_data, 'props.senha', '')
            }
        }
        url, _ = self.dispatch(self.OBTERAUTENTICACAO, context_data, 'url')
        resp: Response = requests.post(url, data=dict_to_xml(body), headers=self.get_headers()[0])
        ret = xmltodict.parse(resp.text)
        return deep_get(ret, 'retornoAutenticacao.chave', '')


#   Códigos independentes de instancia
#
def _tipfrete_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a TipFrete:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    TipFreteException,
    _tipfrete_exception_callback,
    any_exception_callback
)


# Funções para obtenção de URLs
@_handle_exception
def _make_defaults(path_: str, method: HttpMethod = None, use_template: bool = None) -> dict:
    return {
        'path_': path_,
        **conditional_key('method', method),
        **conditional_key('use_template', use_template)
    }


@_handle_exception
def _make_url(path_: str, method: HttpMethod = HttpMethod.GET, use_template: bool = False,
              req: dict = None, url: str = '', props: dict = None) -> Tuple[str, str]:
    if props is None:
        props = {}

    ambiente = 0
    try:
        ambiente = int(props.get('ws_ambiente'))
    except (Exception,):
        pass

    base = url.strip().rstrip('/') or (TipFrete.BASE_URL if ambiente == 1 else TipFrete.BASE_URL_TEST)
    if use_template:
        t = Template(path_)
        url = base + t.substitute(req)
    else:
        url = base + path_

    return url, method.name


tipfrete = TipFrete()

# Decorators da instancia
_link_to_request = tipfrete.link_to_factory('request')
_link_to_response = tipfrete.link_to_factory('response')


@_link_to_request(TipFrete.CADASTRARMOTORISTA)
@_handle_exception
def _add_driver_body(req: dict, internal: dict) -> Tuple[str, str]:
    body = {
        'cadastroMotorista': {
            'chave': tipfrete.get_key(internal.get('context_data')),
            'cnpjContratante': req.get('mot_cnpj_contratante', ''),
            'nome': req.get('mot_nome', ''),
            'numeroCNPJ': req.get('mot_cnpj', ''),
            'numeroCPF': req.get('mot_cpf', ''),
            'numeroRG': req.get('mot_rg', ''),
            'ufRG': req.get('mot_uf_rg', ''),
            'orgaoEmissorRG': req.get('mot_orgao_emissor', ''),
            'numeroCNH': req.get('mot_cnh', ''),
            'ufCNH': req.get('mot_uf_cnh', ''),
            'numeroPIS': req.get('mot_pis', ''),
            'endereco': {
                'logradouro': req.get('mot_logradouro', ''),
                'numero': req.get('mot_numero', ''),
                'complemento': req.get('mot_complemento', ''),
                'bairro': req.get('mot_bairro', ''),
                'codigoMunicipio': req.get('mot_cod_municipio', ''),
                'cep': req.get('mot_cep', ''),
                'fone': req.get('mot_fone', ''),
            },
            **conditional_key('dataNascimento', req.get('mot_data_nasc', '')),
            'sexo': req.get('mot_sexo', ''),
            'nomeMae': req.get('mot_nome_mae', ''),
            'estadoCivil': req.get('mot_estado_civil', ''),
            'dataEmissaoRG': req.get('mot_data_emis_rg', ''),
            **conditional_key('nomeConjuge', req.get('mot_nome_conj', '')),
            'localNascimento': req.get('mot_cid_nasc', ''),
            'nomePai': req.get('mot_nome_pai', ''),
            'nacionalidade': req.get('mot_nacionalidade', ''),
            'dataVencimentoCNH': req.get('mot_data_venc_cnh', ''),
            **conditional_key('numeroEnvelope', req.get('mot_numero_envelope', ''))
        }
    }

    return remove_accents(dict_to_xml(body)), ''


@_link_to_request(TipFrete.CADASTRARVIAGEM, TipFrete.CIOTGRATUITO)
@_handle_exception
def _add_shipping_body(req: dict, internal: dict) -> Tuple[str, str]:
    parceiros = []
    veiculos = []
    ajustes = []
    notas = []
    parceiros.append({
        'tipo': req.get('conh_coleta_tipo', ''),
        'nome': req.get('conh_coleta_nome', ''),
        **conditional_key('numeroCNPJ', req.get('conh_coleta_cnpj', '')),
        **conditional_key('numeroCPF', req.get('conh_coleta_cpf', '')),
        'endereco': {
            'logradouro': req.get('conh_coleta_logradouro', ''),
            'numero': req.get('conh_coleta_numero', ''),
            'complemento': req.get('conh_coleta_complemento', ''),
            'bairro': req.get('conh_coleta_bairro', ''),
            'codigoMunicipio': req.get('conh_coleta_codMunicipio', ''),
            'cep': req.get('conh_coleta_cep', ''),
            'fone': req.get('conh_coleta_fone', ''),
        },
    })
    parceiros.append({
        'tipo': req.get('conh_entrega_tipo', ''),
        'nome': req.get('conh_entrega_nome', ''),
        **conditional_key('numeroCNPJ', req.get('conh_entrega_cnpj', '')),
        **conditional_key('numeroCPF', req.get('conh_entrega_cpf', '')),
        'endereco': {
            'logradouro': req.get('conh_entrega_logradouro', ''),
            'numero': req.get('conh_entrega_numero', ''),
            'complemento': req.get('conh_entrega_complemento', ''),
            'bairro': req.get('conh_entrega_bairro', ''),
            'codigoMunicipio': req.get('conh_entrega_codMunicipio', ''),
            'cep': req.get('conh_entrega_cep', ''),
            'fone': req.get('conh_entrega_fone', ''),
        },
    })
    parceiros.append({
        'tipo': req.get('conh_mot_tipo', ''),
        'nome': req.get('conh_mot_nome', ''),
        'nomeMae': req.get('conh_mot_nomeMae', ''),
        'nomePai': req.get('conh_mot_nomePai', ''),
        'sexo': req.get('conh_mot_sexo', ''),
        'dataNascimento': req.get('conh_mot_dataNasc', ''),
        'numeroCPF': req.get('conh_mot_cpf', ''),
        'numeroRG': req.get('conh_mot_rg', ''),
        'orgaoEmissorRg': req.get('conh_mot_orgaoEmissor', ''),
        'dataEmissaoRG': req.get('conh_mot_dataEmisRg', ''),
        'ufRG': req.get('conh_mot_ufRg', ''),
        'numeroCNH': req.get('conh_mot_cnh', ''),
        'ufCNH': req.get('conh_motUfCnh', ''),
        'dataVencimentoCNH': req.get('conh_mot_dataVencCnh', ''),
        **conditional_key('numeroPIS', req.get('conh_mot_pis', '')),
        **conditional_key('numeroEnvelope', req.get('conh_mot_numeroEnvelope', '')),
        'endereco': {
            'logradouro': req.get('conh_mot_logradouro', ''),
            'numero': req.get('conh_mot_numero', ''),
            'complemento': req.get('conh_mot_complemento', ''),
            'bairro': req.get('conh_mot_bairro', ''),
            'codigoMunicipio': req.get('conh_mot_codMunicipio', ''),
            'cep': req.get('conh_mot_cep', ''),
            'fone': req.get('conh_mot_fone', ''),
        },
    })
    veiculos.append({
        'placa': req.get('conh_veic_placa', ''),
        'renavam': req.get('conhec_veic_renavam', ''),
        'codigoMunicipio': req.get('conhec_veic_codMunicipio', ''),
        'tipoVeiculo': req.get('conhec_veic_tipoVeic', ''),
        'rntrc': req.get('conhec_veic_rntrc', ''),
        'tagCaminhao': req.get('conhec_veic_tagCaminhao', ''),
        'eixos': req.get('conhec_veic_eixos', ''),
    })
    ajustes.append({
        'tipo': req.get('conh_tipoOutrosDescMot', ''),
        'valor': req.get('conh_valorOutrosDescMot', ''),
        'precisao': req.get('conh_precOutrosDescMot', ''),
        'observacao': req.get('conh_obsOutrosDescMot', ''),
    })
    if req.get('conh_ctnfs', '') != '':
        qtdeNfs = int(req.get('conh_ctnfs', ''))
    else:
        qtdeNfs = 0
    for i in range(1, qtdeNfs + 1, 1):
        notas.append({
            'numeroNF': req.get('conh_numNf' + str(i), ''),
            'serie': req.get('conh_serieNf' + str(i), ''),
            'modelo': req.get('conh_modeloNf' + str(i), ''),
            'chaveNFe': req.get('conh_chaveNf' + str(i), ''),
            'remetenteNome': req.get('conh_remNomeNf' + str(i), ''),
            **conditional_key('remetenteCNPJ', req.get('conh_remCnpjNf' + str(i), '')),
            **conditional_key('remetenteCPF', req.get('conh_remCpfNf' + str(i), '')),
            'volumeTotalNota': req.get('conh_quantMercTotalNf' + str(i), ''),
            'precisaoVolTotalNota': req.get('conh_precQuantMercTotal' + str(i), ''),
            'unidadeMedida': req.get('conh_unidMedNf' + str(i), ''),
            'valorTotalNota': req.get('conh_valorTotalNf' + str(i), ''),
            'precisaoTotalNota': req.get('conh_precValorTotal' + str(i), '')
        })

    if req.get('conh_veic_placaCarreta1', '') != '':
        veiculos.append({
            'placa': req.get('conh_veic_placaCarreta1', ''),
            'renavam': req.get('conhec_veic_renavamCarreta1', ''),
            'codigoMunicipio': req.get('conhec_veic_codMunicipioCarreta1', ''),
            'tipoVeiculo': req.get('conhec_veic_tipoVeicCarreta1', ''),
            **conditional_key('rntrc', req.get('conhec_veic_rntrcCarreta1', '')),
            'tagCaminhao': req.get('conhec_veic_tagCaminhaoCarreta1', ''),
            'eixos': req.get('conhec_veic_eixosCarreta1', ''),
        })
    if req.get('conh_veic_placaCarreta2', '') != '':
        veiculos.append({
            'placa': req.get('conh_veic_placaCarreta2', ''),
            'renavam': req.get('conhec_veic_renavamCarreta2', ''),
            'codigoMunicipio': req.get('conhec_veic_codMunicipioCarreta2', ''),
            'tipoVeiculo': req.get('conhec_veic_tipoVeicCarreta2', ''),
            **conditional_key('rntrc', req.get('conhec_veic_rntrcCarreta2', '')),
            'tagCaminhao': req.get('conhec_veic_tagCaminhaoCarreta2', ''),
            'eixos': req.get('conhec_veic_eixosCarreta2', ''),
        })
    if req.get('conh_veic_placaCarreta3', '') != '':
        veiculos.append({
            'placa': req.get('conh_veic_placaCarreta3', ''),
            'renavam': req.get('conhec_veic_renavamCarreta3', ''),
            'codigoMunicipio': req.get('conhec_veic_codMunicipioCarreta3', ''),
            'tipoVeiculo': req.get('conhec_veic_tipoVeicCarreta3', ''),
            **conditional_key('rntrc', req.get('conhec_veic_rntrcCarreta3', '')),
            'tagCaminhao': req.get('conhec_veic_tagCaminhaoCarreta3', ''),
            'eixos': req.get('conhec_veic_eixosCarreta3', ''),
        })
    if req.get('conh_tipoOutrosDescMot2', '') != '':
        ajustes.append({
            'tipo': req.get('conh_tipoOutrosDescMot2', ''),
            'valor': req.get('conh_valorOutrosDescMot2', ''),
            'precisao': req.get('conh_precOutrosDescMot2', ''),
            'observacao': req.get('conh_obsOutrosDescMot2', ''),
        })
    body = {
        'viagem': {
            'versao': req.get('conh_versao_xml', ''),
            'chave': tipfrete.get_key(internal.get('context_data')),
            **conditional_key("apenasCiot", 'S', internal.get('context_data').get('acao') == TipFrete.CIOTGRATUITO),
            'rota': req.get('conh_rota', ''),
            'admPedagio': req.get('conh_admPedagio', ''),
            'distanciaTotal': req.get('conh_distanciaTotal', ''),
            'eixos': req.get('conhec_veic_eixos', ''),
            'cnpjContratante': req.get('conh_cnpjContratante', ''),
            'idSolicitacaoContratante': req.get('conh_numero', ''),
            'dataSolicitacao': req.get('conh_dataSolicitacao', ''),
            'dataInicioFrete': req.get('conh_dataIni', ''),
            'dataFimFrete': req.get('conh_dataFim', ''),
            'parceiros>parceiro': parceiros,
            'carga': {
                **conditional_key('notas>nota', notas, req.get('is_viagens_agrupadas') != 'S'),
                **conditional_key('ctes>cte', [{
                    'modeloConhecimento': 57,  # Conhecimento Agrupado
                    'serieConhecimento': req.get('conh_serie', ''),
                    'numeroConhecimento': req.get('conh_numconhec', ''),
                    'notas>nota': notas
                }], req.get('is_viagens_agrupadas') == 'S'),
                'codigoNaturezaCarga': req.get('conh_ncm', ''),
                'quantidadeTotal': req.get('conh_quantTotal', ''),
                'precisao': req.get('conh_precisao', ''),
                'unidadeMedida': req.get('conh_unidadeMedida', ''),
                'descricaoProduto': req.get('conh_descMerc', ''),
            },
            'informacoesAcessorias': {
                'percentualTolerancia': req.get('conh_percentualTolerancia', ''),
                'precisaoTolerancia': req.get('conh_precisaoTolerancia', ''),
                'valorUnitMercPerda': req.get('conh_valorUnitMercPerda', ''),
                'precisaoUnitMercPerda': req.get('conh_precisaoUnitMercPerda', ''),
                'unidMedUnitMercPerda': req.get('conh_unidMedUnitMercPerda', ''),
                'valorUnitNegociadoFrete': req.get('conh_valorUnitNegociadoFrete', ''),
                'precisaoValorNegociado': req.get('conh_precisaoValorNegociado', ''),
                'unidMedUnitNegociadoFrete': req.get('conh_unidMedUnitNegociadoFrete', ''),
                'flagCalculoPerda': req.get('conh_flagCalculoPerda', ''),
                'flagCalculoQuebra': req.get('conh_flagCalculoQuebra', ''),
                'flagLiberacaoAdiantamento': req.get('conh_flagLiberacaoAdt', ''),
                'flagLiberacaoFinalizacao': req.get('conh_flagLiberacaoFinalizacao', ''),
                'altoDesempenho': req.get('conh_altoDesemp', ''),
                'destinacaoComercial': req.get('conh_destinacaoComercial', ''),
                'freteRetorno': req.get('conh_freteRetorno', ''),
            },
            'itens': {
                'item': {
                    'contratado': {
                        'rntrc': req.get('conh_prop_rntrc', ''),
                        'nome': req.get('conh_prop_nome', ''),
                        **conditional_key('numeroCNPJ', req.get('conh_prop_cnpj', '')),
                        **conditional_key('numeroCPF', req.get('conh_prop_cpf', '')),
                        'numeroRG': req.get('conh_prop_rg', ''),
                        'ufRG': req.get('conh_prop_ufRg', ''),
                        'numeroPIS': req.get('conh_prop_pis', ''),
                        'logradouro': req.get('conh_prop_logradouro', ''),
                        'numero': req.get('conh_prop_numero', ''),
                        'complemento': req.get('conh_prop_complemento', ''),
                        'bairro': req.get('conh_prop_bairro', ''),
                        'codigoMunicipio': req.get('conh_prop_codMunicipio', ''),
                        'cep': req.get('conh_prop_cep', ''),
                        'fone': req.get('conh_prop_fone', ''),
                        'banco': req.get('conh_prop_banco', ''),
                        'agencia': req.get('conh_prop_agencia', ''),
                        'conta': req.get('conh_prop_conta', ''),
                        'tipoconta': req.get('conh_prop_tipoConta', ''),
                    },
                    'veiculos>veiculo': veiculos,
                    'servico': {
                        'valorPedagio': req.get('conh_valorPedagio', ''),
                        'precisaoPedagio': req.get('conh_precValorPedagio', ''),
                        'valorSeguro': req.get('conh_valorSeguro', ''),
                        'precisaoSeguro': req.get('conh_precValorSeguro', ''),
                        'impostos>imposto': [
                            {
                                'nome': req.get('conh_nomeInss', ''),
                                'valor': req.get('conh_impInss', ''),
                                'precisao': req.get('conh_precImpInss', ''),
                            },
                            {
                                'nome': req.get('conh_nomeIrrf', ''),
                                'valor': req.get('conh_impIrrf', ''),
                                'precisao': req.get('conh_precImpIrrf', ''),
                            },
                            {
                                'nome': req.get('conh_nomeSest', ''),
                                'valor': req.get('conh_impSest', ''),
                                'precisao': req.get('conh_precImpSest', ''),
                            }
                        ],

                        'valorContratoFrete': req.get('conh_valorContratadoFrete', ''),
                        'precisaoContratoFrete': req.get('conh_precContratoFrete', ''),
                        'limiteAdiantamento': req.get('conh_limAdiantamento', ''),
                        'precisaoLimAdiantamento': req.get('conh_precLimAdiantamento', ''),
                        'dataPrevisaoAdiantamento': req.get('conh_dataPrevAdiantamento', ''),
                        'periodoRepasseFinalizacao': req.get('conh_periodoRepasseFinalizacao', ''),
                        'unidadeRepasseFinalizacao': req.get('conh_unidadeRepasseFinalizacao', ''),
                    },
                    'ajustes>ajuste': ajustes,
                },
            },
        }
    }
    return remove_accents(xml_from_dict(body)), ''


@_link_to_request(TipFrete.CONSULTARVIAGEM)
@_handle_exception
def _cons_shipping_body(req: dict, internal: dict) -> Tuple[str, str]:
    body = {
        'consultaViagem': {
            'numeroProtocolo': req.get('cons_numeroProtocolo', ''),
            'dataRequisicao': req.get('cons_dataReq', ''),
            'chave': tipfrete.get_key(internal.get('context_data')),
        }
    }
    return remove_accents(dict_to_xml(body)), ''


@_link_to_request(TipFrete.AUTORIZARCANCELARVIAGEM)
@_handle_exception
def _auth_shipping_body(req: dict, internal: dict) -> Tuple[str, str]:
    body = {
        'confirmacaoViagem': {
            'tipoOperacao': req.get('auth_tipoOperacao', ''),
            'idOperacaoViagem': req.get('auth_idOperacaoViagem', ''),
            'dataRequisicao': req.get('auth_dataReq', ''),
            'chave': tipfrete.get_key(internal.get('context_data')),
            'motivoCancelamento': req.get('auth_motivoCanc', ''),
        }
    }
    return remove_accents(dict_to_xml(body)), ''


@_link_to_request(TipFrete.CANCELARCIOTGRATUITO)
@_handle_exception
def _canc_ciot_body(req: dict, internal: dict) -> Tuple[str, str]:
    body = {
        'cancelarOperacaoTransporte': {
            'chave': tipfrete.get_key(internal.get('context_data')),
            'cnpjContratante': req.get('conh_cnpjContratante', ''),
            'codigoOperacao': req.get('codigo_operacao', ''),
            'motivo': req.get('auth_motivoCanc', ''),
        }
    }
    return remove_accents(dict_to_xml(body)), ''


@_link_to_request(TipFrete.ENCERRARCIOTGRATUITO)
@_handle_exception
def _enc_ciot_body(req: dict, internal: dict) -> Tuple[str, str]:
    viagemAgregado = {
        'codigoMunicipioRemetente': req.get('conh_remet_codMunicipio', ''),
        'codigoMunicipioDestinatario': req.get('conh_dest_codMunicipio', ''),
        'codigoNaturezaCarga': req.get('conh_cfop'),
        'pesoCarga': req.get('conh_pesoCarga'),
        'precisaoPesoCarga': req.get('conh_precPesoCarga'),
        'quantidadeViagens': req.get('conh_quantViagens')
    }

    viagensAgregado = {
        'viagemAgregado': viagemAgregado
    }

    body = {
        'encerrarOperacaoTransporte': {
            'chave': tipfrete.get_key(internal.get('context_data')),
            'cnpjContratante': req.get('conh_cnpjContratante', ''),
            'codigoOperacao': req.get('codigo_operacao', ''),
            'pesoChegada': req.get('conh_pesoChegada', ''),
            'precisaoPesoChegada': req.get('conh_precPesoChegada', ''),
            'viagensAgregado': viagensAgregado
        }
    }
    return remove_accents(dict_to_xml(body)), ''


@_link_to_request(TipFrete.CADASTRARROTA)
@_handle_exception
def _add_route_body(req: dict, internal: dict) -> Tuple[str, str]:
    cidades = []
    body = {
        'rota': {
            'chave': tipfrete.get_key(internal.get('context_data')),
            'cnpjContratante': req.get('rota_cnpjContratante', ''),
            'retornoOrigem': req.get('rota_retornoOrigem', ''),
            'cidades': (cidades,
                        {
                            'list_item': 'codigoCidade'
                        }
                        ),
        }
    }
    cidades.append(req.get('rota_codCidadeOrigem', ''))
    if req.get('rota_codCidade2', '') != '':
        cidades.append(req.get('rota_codCidade2', ''))
    if req.get('rota_codCidade3', '') != '':
        cidades.append(req.get('rota_codCidade3', ''))
    if req.get('rota_codCidade4', '') != '':
        cidades.append(req.get('rota_codCidade4', ''))
    if req.get('rota_codCidade5', '') != '':
        cidades.append(req.get('rota_codCidade5', ''))
    cidades.append(req.get('rota_codCidadeDestino', ''))
    return remove_accents(dict_to_xml(body)), ''


@_link_to_request(TipFrete.CONSULTARROTA)
@_handle_exception
def _cons_route_body(req: dict, internal: dict) -> Tuple[str, str]:
    body = {
        'consultaRota': {
            'chave': tipfrete.get_key(internal.get('context_data')),
            'cnpjContratante': req.get('rota_cnpjContratante', ''),
            'codigoRota': req.get('rota_codigoRota', ''),
        }
    }
    return dict_to_xml(body), ''

@_link_to_request(TipFrete.ATUALIZARROTA)
@_handle_exception
def _update_route_body(req: dict, internal: dict) -> Tuple[str, str]:
    body = {
        'atualizaRota': {
            'chave': tipfrete.get_key(internal.get('context_data')),
            'cnpjContratante': req.get('rota_cnpjContratante', ''),
            'tipoConsulta': req.get('rota_tipoConsulta', ''),
        }
    }
    return dict_to_xml(body), ''


@_link_to_request(TipFrete.AJUSTEIMEDIATO)
@_handle_exception
def _imm_adjustment_body(req: dict, internal: dict) -> Tuple[str, str]:
    body = {
        'ajusteImediato': {
            'chave': tipfrete.get_key(internal.get('context_data')),
            'cnpjContratante': req.get('aj_cnpjContratante', ''),
            'contrato': req.get('aj_contrato', ''),
            'ajustes': {
                'ajuste': {
                    'tipo': req.get('aj_tipo', ''),
                    'observacao': req.get('aj_obs', ''),
                    'valor': req.get('aj_valor', ''),
                    'precisao': req.get('aj_prec', ''),
                },
            },
        }
    }
    return remove_accents(dict_to_xml(body)), ''


@_link_to_request(TipFrete.COMPRARPEDAGIOAVULSO)
@_handle_exception
def _toll_purchase_body(req: dict, internal: dict) -> Tuple[str, str]:
    veiculos = [{
        'placa': req.get('pedag_placaVeic', ''),
        'renavam': req.get('pedag_renavamVeic', ''),
        'codigoMunicipio': req.get('pedag_codIbgeVeic', ''),
        'tipoVeiculo': req.get('pedag_tipoVeic', ''),
        'rntrc': req.get('pedag_rntrcVeicProp', ''),
        'tagCaminhao': req.get('pedag_tagVeic', ''),
        'eixos': req.get('pedag_eixoVeic', ''),
    }]

    if req.get('pedag_placaCarreta1', '') != '':
        veiculos.append({
            'placa': req.get('pedag_placaCarreta1', ''),
            'renavam': req.get('pedag_renavamCarreta1', ''),
            'codigoMunicipio': req.get('pedag_codMunicipioCarreta1', ''),
            'tipoVeiculo': req.get('pedag_tipoVeicCarreta1', ''),
            'rntrc': req.get('pedag_rntrcCarreta1', ''),
            'tagCaminhao': req.get('pedag_tagCaminhaoCarreta1', ''),
            'eixos': req.get('pedag_eixosCarreta1', ''),
        })
    if req.get('pedag_placaCarreta2', '') != '':
        veiculos.append({
            'placa': req.get('pedag_placaCarreta2', ''),
            'renavam': req.get('pedag_renavamCarreta2', ''),
            'codigoMunicipio': req.get('pedag_codMunicipioCarreta2', ''),
            'tipoVeiculo': req.get('pedag_tipoVeicCarreta2', ''),
            'rntrc': req.get('pedag_rntrcCarreta2', ''),
            'tagCaminhao': req.get('pedag_tagCaminhaoCarreta2', ''),
            'eixos': req.get('pedag_eixosCarreta2', ''),
        })
    if req.get('pedag_placaCarreta3', '') != '':
        veiculos.append({
            'placa': req.get('pedag_placaCarreta3', ''),
            'renavam': req.get('pedag_renavamCarreta3', ''),
            'codigoMunicipio': req.get('pedag_codMunicipioCarreta3', ''),
            'tipoVeiculo': req.get('pedag_tipoVeicCarreta3', ''),
            'rntrc': req.get('pedag_rntrcCarreta3', ''),
            'tagCaminhao': req.get('pedag_tagCaminhaoCarreta3', ''),
            'eixos': req.get('pedag_eixosCarreta3', ''),
        })
    body = {
        'pedagio': {
            'chave': tipfrete.get_key(internal.get('context_data')),
            'cnpjContratante': req.get('pedag_cnpjContratante', ''),
            'idSolicitacaoContratante': req.get('pedag_idSolicContratante', ''),
            'dataSolicitacao': req.get('pedag_dataSolic', ''),
            'dataInicio': req.get('pedag_dataIni', ''),
            'dataFim': req.get('pedag_dataFim', ''),
            'rota': req.get('pedag_rota', ''),
            'eixos': req.get('pedag_eixos', ''),
            'admPedagio': req.get('pedag_admPedagio', ''),
            'modeloConhecimento': req.get('pedag_modeloConhec', ''),
            'serieConhecimento': req.get('pedag_serieConhec', ''),
            'numeroConhecimento': req.get('pedag_numeroConhec', ''),
            'valorPedagio': req.get('pedag_valor', ''),
            'precisaoValorPedagio': req.get('pedag_precValor', ''),
            'motorista': {
                'nome': req.get('pedag_nomeMot', ''),
                'nomeMae': req.get('pedag_nomeMaeMot', ''),
                'sexo': req.get('pedag_sexoMot', ''),
                'numeroCPF': req.get('pedag_cpfMot', ''),
                'numeroCNPJ': req.get('pedag_cnpjMot', ''),
                'dataNascimento': req.get('pedag_dataNascMot', ''),
                'numeroCNH': req.get('pedag_cnhMot', ''),
                'ufCNH': req.get('pedag_ufCnhMot', ''),
                'numeroEnvelope': req.get('pedag_numEnvelope', ''),
                'endereco': {
                    'logradouro': req.get('pedag_logradMot', ''),
                    'numero': req.get('pedag_numeroMot', ''),
                    'complemento': req.get('pedag_complMot', ''),
                    'bairro': req.get('pedag_bairroMot', ''),
                    'codigoMunicipio': req.get('pedag_codIbgeMot', ''),
                    'cep': req.get('pedag_cepMot', ''),
                    'fone': req.get('pedag_foneMot', ''),
                },
            },
            'contratado': {
                'rntrc': req.get('pedag_rntrcProp', ''),
                'nome': req.get('pedag_nomeProp', ''),
                'numeroCNPJ': req.get('pedag_cnpjProp', ''),
                'numeroCPF': req.get('pedag_cpfProp', ''),
                'logradouro': req.get('pedag_logradProp', ''),
                'numero': req.get('pedag_numeroProp', ''),
                'complemento': req.get('pedag_complProp', ''),
                'bairro': req.get('pedag_bairroProp', ''),
                'codigoMunicipio': req.get('pedag_codIbgeProp', ''),
                'cep': req.get('pedag_cepProp', ''),
                'fone': req.get('pedag_foneProp', ''),
                'banco': req.get('pedag_bancoProp', ''),
                'agencia': req.get('pedag_agenciaProp', ''),
                'conta': req.get('pedag_contaProp', ''),
                'tipoconta': req.get('pedag_tipoContaProp', ''),
                'cnpjRecebedor': req.get('pedag_cnpjRecebProp', ''),
            },
            'veiculos': (veiculos,
                         {
                             'list_item': 'veiculo'
                         }
                         ),
        }
    }
    return remove_accents(dict_to_xml(body)), ''


@_link_to_request(TipFrete.CANCELARPEDAGIOAVULSO)
@_handle_exception
def _toll_cancellation_body(req: dict, internal: dict) -> Tuple[str, str]:
    body = {
        'pedagio': {
            'chave': tipfrete.get_key(internal.get('context_data')),
            'cnpjContratante': req.get('pedag_cnpjContratante', ''),
            'dataSolicitacao': req.get('pedag_dataSolic', ''),
            'idPedagio': req.get('pedag_idPedagio', ''),
            'motivoCancelamento': req.get('pedag_motivoCanc', ''),
        }
    }
    return remove_accents(dict_to_xml(body)), ''


@_link_to_request(TipFrete.CONSULTARTRANSPORTADOR)
@_handle_exception
def _status_carrier_body(req: dict, internal: dict) -> Tuple[str, str]:
    body = {
        'situacaoTransportador': {
            'chave': tipfrete.get_key(internal.get('context_data')),
            'cnpjContratante': req.get('prop_cnpjContratante', ''),
            'cnpj': req.get('prop_cnpj', ''),
            'rntrc': req.get('prop_rntrc', ''),
            'placa': req.get('prop_placa', ''),
        }
    }
    return remove_accents(dict_to_xml(body)), ''


@_link_to_request(TipFrete.CREDITOIMEDIATO)
@_handle_exception
def _imm_credit_body(req: dict, internal: dict) -> Tuple[str, str]:
    body = {
        'creditoImediato': {
            'chave': tipfrete.get_key(internal.get('context_data')),
            'cnpjContratante': req.get('credit_cnpjContratante'),
            'cpfCnpjMotorista': req.get('credit_cnpjCpfMot', ''),
            'idSolicitacaoContratante': req.get('credit_idSolicContratante', ''),
            'observacao': req.get('credit_obs', ''),
            'valor': req.get('credit_valor', ''),
            'precisao': req.get('credit_prec', ''),
        }
    }
    return remove_accents(dict_to_xml(body)), ''


#@_link_to_request(TipFrete.ARQUIVOCONFERENCIA)
#@_handle_exception
#def _conference_file_body(req: dict, internal: dict) -> Tuple[str, str]:
#    body = {
#        'requisicaoArquivoConferencia': {
#            'chave': tipfrete.get_key(internal.get('context_data')),
#            'cnpjContratante': req.get('arq_cnpjContratante', ''),
#            'dataConferenciaInicio': req.get('arq_dataIni', ''),
#            'dataConferenciaFim': req.get('arq_dataFim'),
#        }
#    }
#    return remove_accents(dict_to_xml(body)), ''

@_link_to_request(TipFrete.ARQUIVOCOBRANCA)
@_handle_exception
def _billing_file_body(req: dict, internal: dict) -> Tuple[str, str]:
    body = {
        'arquivoCobrancaPedagio': {
            'chave': tipfrete.get_key(internal.get('context_data')),
            'cnpjContratante': req.get('arq_cnpjContratante', ''),
            'codigoFatura': req.get('arq_codigoFatura', ''),
            'dataFaturamento': req.get('arq_dataFaturamento'),
        }
    }
    return remove_accents(dict_to_xml(body)), ''

@_link_to_request(TipFrete.CONSULTARFINALIZACAO)
@_handle_exception
def _cons_completion_body(req: dict, internal: dict) -> Tuple[str, str]:
    body = {
        'consultaFinalizacaoViagem': {
            'chave': tipfrete.get_key(internal.get('context_data')),
            'cnpjContratante': req.get('conh_cnpjContratante', ''),
            'protocolo': req.get('conh_protocolo', ''),
        }
    }
    return dict_to_xml(body), ''

@_link_to_request(TipFrete.FINALIZARVIAGEM)
@_handle_exception
def _finish_shipping_body(req: dict, internal: dict) -> Tuple[str, str]:
    body = {
        'finalizacaoViagem': {
            'chave': tipfrete.get_key(internal.get('context_data')),
            'cnpjContratante': req.get('conh_cnpjContratante', ''),
            'contrato': req.get('conh_protocolo', ''),
            'dataChegada': req.get('conh_dataChegada', ''),
            'peso': req.get('conh_pesoChegada', ''),
            'precisaoPeso': req.get('conh_precisaoPeso', ''),
            'tipoTransacao': req.get('conh_tipoTransacao', ''),
        }
    }
    return dict_to_xml(body), ''



# Processamento de respostas
fix_pattern = re.compile(r'\\u0022([^"]+)\\u0022')


# Funções para tratamento de retorno
@_link_to_response(TipFrete.CADASTRARMOTORISTA)
@_handle_exception
def _add_driver_resp(resp: Response) -> Tuple[str, str]:
    resp_json = xmltodict.parse(resp.text)

    success = resp.status_code == 200
    mot_protocolo = resp_json.get('cadastroMotoristaResponseTO', '').get('protocolo', '')
    msg = resp_json.get('cadastroMotoristaResponseTO', '').get('msg', '')
    if success and mot_protocolo != '':
        resp_body = {'sucesso': success, 'protocolo': mot_protocolo}
    elif success and msg:
        resp_body = {'erro': msg}
    else:
        raise TipFreteException('Erro ao cadastrar motorista')

    return mount_xml_response(resp_body), ''


@_link_to_response(TipFrete.CADASTRARVIAGEM)
@_handle_exception
def _add_shipping_resp(resp: Response) -> Tuple[str, str]:
    try:
        resp_json = xmltodict.parse(resp.text)
    except (Exception,):
        raise TipFreteException('Retorno inválido da TipFrete')

    success = resp.status_code == 200
    conhec_protocolo = resp_json.get('retornoSolicitacaoCIOT', '').get('numeroProtocolo', '')
    conhec_idOperacaoViagem = resp_json.get('retornoSolicitacaoCIOT', '').get('idOperacaoViagem', '')
    msg = resp_json.get('retornoSolicitacaoCIOT', '').get('msg', '')
    if msg and msg != 'OK':
        resp_body = {'erro': msg}
    elif success and conhec_protocolo != '' and conhec_protocolo is not None:
        resp_body = {'sucesso': success, 'protocolo': conhec_protocolo, 'idOperacaoViagem': conhec_idOperacaoViagem}
    else:
        raise TipFreteException('Erro ao cadastrar viagem')

    return mount_xml_response(resp_body), ''

@_link_to_response(TipFrete.CIOTGRATUITO)
@_handle_exception
def _free_ciot_resp(resp: Response) -> Tuple[str, str]:
    try:
        resp_json = xmltodict.parse(resp.text)
    except (Exception,):
        raise TipFreteException('Retorno inválido da TipFrete')

    success = resp.status_code == 200
    conhec_ciot = resp_json.get('retornoSolicitacaoCIOT', '').get('ciot', '')
    conhec_linkContrato = resp_json.get('retornoSolicitacaoCIOT', '').get('linkContrato', '')
    msg = resp_json.get('retornoSolicitacaoCIOT', '').get('msg', '')
    codigoOperacao = resp_json.get('retornoSolicitacaoCIOT', '').get('codigoOperacao', '')
    if msg and msg != 'OK':
        resp_body = {'erro': msg}
    elif success and conhec_ciot != '' and conhec_ciot is not None:
        resp_body = {'sucesso': success, 'ciot': conhec_ciot, 'linkContrato': conhec_linkContrato, 'codigoOperacao': codigoOperacao}
    else:
        raise TipFreteException('Erro ao cadastrar CIOT Gratuito')

    return mount_xml_response(resp_body), ''


@_link_to_response(TipFrete.CONSULTARVIAGEM)
@_handle_exception
def _cons_shipping_resp(resp: Response) -> Tuple[str, str]:
    resp_json = xmltodict.parse(resp.text)

    success = resp.status_code == 200
    conhec_idOperacao = resp_json.get('retornoViagem', '').get('idOperacaoViagem', '')
    msg = resp_json.get('retornoViagem', '').get('msg', '')
    status = resp_json.get('retornoViagem', '').get('statusOperacao', '')
    ciot = deep_get(resp_json, 'retornoViagem.retornoItens.retornoItem.numeroCIOT','')
    contrato = deep_get(resp_json, 'retornoViagem.retornoItens.retornoItem.nuContrato', '')
    if success and conhec_idOperacao != '':
        if ciot != '':
            resp_body = {'sucesso': success, 'idOperacaoViagem': conhec_idOperacao, 'status_op': status, 'ciot': ciot, 'contrato': contrato, 'msg': msg}
        else:
            resp_body = {'sucesso': success, 'idOperacaoViagem': conhec_idOperacao, 'status_op': status, 'msg': msg}
    elif success and msg != '':
        resp_body = {'erro': msg}
    else:
        raise TipFreteException('Erro ao consultar viagem')

    return mount_xml_response(resp_body), ''


@_link_to_response(TipFrete.AUTORIZARCANCELARVIAGEM)
@_handle_exception
def _auth_shipping_resp(resp: Response) -> Tuple[str, str]:
    resp_json = xmltodict.parse(resp.text)

    success = resp.status_code == 200
    resp_body = {
        'sucesso': success
    }

    conhec = resp_json.get('confirmacaoViagem', '')
    if success and 'numeroProtocolo' in conhec:
        resp_body.update({
            'sucesso': success,
            'protocolo': conhec.get('numeroProtocolo', ''),
            'idOperacaoViagem': conhec.get('idOperacaoViagem', ''),
            'linkContrato': conhec.get('linkContrato', '')
        })
    elif success and 'mensagem' in conhec:
        resp_body['erro'] = conhec.get('mensagem', '')
    else:
        raise TipFreteException('Erro ao autorizar/cancelar viagem')

    return mount_xml_response(resp_body), ''


@_link_to_response(TipFrete.CADASTRARROTA)
@_handle_exception
def _add_route_resp(resp: Response) -> Tuple[str, str]:
    resp_json = xmltodict.parse(resp.text)

    success = resp.status_code == 200
    rota_codRota = resp_json.get('retornoRota', '').get('codigoRota', '')
    msg = resp_json.get('retornoRota', '').get('msg', '')
    if success and rota_codRota != '':
        resp_body = {'sucesso': success, 'codigoRota': rota_codRota}
    elif success and msg:
        resp_body = {'erro': msg}
    else:
        raise TipFreteException('Erro ao cadastrar rota')

    return mount_xml_response(resp_body), ''


@_link_to_response(TipFrete.CONSULTARROTA)
@_handle_exception
def _cons_route_resp(resp: Response, req_in: str) -> Tuple[str, str]:
    resp_json = xmltodict.parse(resp.text)
    req_in = json.loads(req_in)
    success = resp.status_code == 200
    rota_codRota = resp_json.get('retornoConsultaRota', '').get('codigoRota', '')
    msg = resp_json.get('retornoConsultaRota', '').get('msg', '')
    eixo = 0.0
    tagEixo = 0.0
    praca = deep_get(resp_json, 'retornoConsultaRota.pracasPedagio.praca', [])
    if type(praca) is not list:
        praca = [praca]
    for item in praca:
        if (req_in.get('rota_eixo', '') and (
                item.get('eixo' + req_in.get('rota_eixo', '')) or item.get('tagEixo' + req_in.get('rota_eixo', '')))):
            precisaoEixo = safe_cast(item.get('precisaoEixo'), int, 0)
            eixo += safe_cast(item.get('eixo' + req_in.get('rota_eixo', '')), float, 0) / pow(10, precisaoEixo)
            tagEixo += safe_cast(item.get('tageixo' + req_in.get('rota_eixo', '')), float, 0) / pow(10, precisaoEixo)
    if success and rota_codRota != '':
        resp_body = {'sucesso': success, 'codigoRota': rota_codRota, 'eixo': eixo, 'tagEixo': tagEixo}
    elif success and msg:
        resp_body = {'erro': msg}
    else:
        raise TipFreteException('Erro ao consultar rota')

    return mount_xml_response(resp_body), ''


@_link_to_response(TipFrete.ATUALIZARROTA)
@_handle_exception
def _update_route_resp(resp: Response, req_in: str) -> Tuple[str, str]:
    resp_json = xmltodict.parse(resp.text)
    req_in = json.loads(req_in)
    success = resp.status_code == 200
    msg = resp_json.get('retornoAtualizaRota', '').get('msg', '')
    rota = deep_get(resp_json, 'retornoAtualizaRota.rotas.rota', [])
    rotas = []
    if type(rota) is not list:
        rota = [rota]
    for r in rota:
        rota_codRota = r.get('codigoRota', '')
        eixo = 0.0
        tagEixo = 0.0
        praca = deep_get(r, 'pracasPedagio.praca', [])
        if type(praca) is not list:
            praca = [praca]
        for p in praca:
            if (req_in.get('rota_eixo', '') and (
                    p.get('eixo' + req_in.get('rota_eixo', '')) or p.get('tagEixo' + req_in.get('rota_eixo', '')))):
                precisaoEixo = safe_cast(p.get('precisaoEixo'), int, 0)
                eixo += safe_cast(p.get('eixo' + req_in.get('rota_eixo', '')), float, 0) / pow(10, precisaoEixo)
                tagEixo += safe_cast(p.get('tageixo' + req_in.get('rota_eixo', '')), float, 0) / pow(10, precisaoEixo)
                break;
        rotas.append({
            'codigoRota': rota_codRota,
            'eixo': eixo,
            'tagEixo': tagEixo
        })

    if success and rotas != []:
        resp_body = {'sucesso': success, 'conteudo': {'rotas': rotas}}
    elif success and msg:
        resp_body = {'erro': msg}
    else:
        raise TipFreteException('Erro ao consultar rota')

    return mount_xml_response(resp_body), ''

@_link_to_response(TipFrete.AJUSTEIMEDIATO)
@_handle_exception
def _imm_adjustment_resp(resp: Response) -> Tuple[str, str]:
    resp_json = xmltodict.parse(resp.text)

    success = resp.status_code == 200
    aj_nsu = resp_json.get('ajusteImediatoRetorno', '').get('nsus', '').get('nsu', '')
    msg = resp_json.get('ajusteImediatoRetorno', '').get('msg', '')
    if success and aj_nsu != '':
        resp_body = {'sucesso': success, 'nsu': aj_nsu}
    elif success and msg:
        resp_body = {'erro': msg}
    else:
        raise TipFreteException('Erro ao realizar o ajuste imediato rota')

    return mount_xml_response(resp_body), ''


@_link_to_response(TipFrete.COMPRARPEDAGIOAVULSO)
@_handle_exception
def _toll_purchase_resp(resp: Response) -> Tuple[str, str]:
    resp_json = xmltodict.parse(resp.text)

    success = resp.status_code == 200
    pedag_idPedagio = resp_json.get('pedagioRetorno', '').get('idPedagio', '')
    pedag_protocolo = resp_json.get('pedagioRetorno', '').get('numeroProtocolo', '')
    msg = resp_json.get('pedagioRetorno', '').get('msg', '')
    if success and pedag_idPedagio != '':
        resp_body = {'sucesso': success, 'idPedagio': pedag_idPedagio, 'numeroProtocolo': pedag_protocolo}
    elif success and msg:
        resp_body = {'erro': msg}
    else:
        raise TipFreteException('Erro ao comprar pedagio avulso')

    return mount_xml_response(resp_body), ''


@_link_to_response(TipFrete.CANCELARPEDAGIOAVULSO)
@_handle_exception
def _toll_cancellation_resp(resp: Response) -> Tuple[str, str]:
    resp_json = xmltodict.parse(resp.text)

    success = resp.status_code == 200
    pedag_idPedagio = resp_json.get('cancelarPedagioRetorno', '').get('idPedagio', '')
    pedag_protocolo = resp_json.get('cancelarPedagioRetorno', '').get('numeroProtocolo', '')
    msg = resp_json.get('cancelarPedagioRetorno', '').get('msg', '')
    if success and pedag_idPedagio != '':
        resp_body = {'sucesso': success, 'idPedagio': pedag_idPedagio, 'protocolo': pedag_protocolo}
    elif success and msg:
        resp_body = {'erro': msg}
    else:
        raise TipFreteException('Erro ao cancelar pedagio avulso')

    return mount_xml_response(resp_body), ''


@_link_to_response(TipFrete.CANCELARCIOTGRATUITO)
@_handle_exception
def _canc_ciot_resp(resp: Response) -> Tuple[str, str]:
    resp_json = xmltodict.parse(resp.text)

    msg = resp_json.get('retornoCancelarOperacaoTranporte', '').get('msg', '')
    protocolo = resp_json.get('retornoCancelarOperacaoTranporte', '').get('protocolo', '')
    success = resp.status_code == 200
    if success and protocolo:
        resp_body = {'sucesso': success, 'protocolo': protocolo}
    elif success and msg:
        resp_body = {'sucesso': False, 'erro': msg}
    else:
        raise TipFreteException('Erro ao cancelar CIOT Gratuito')

    return mount_xml_response(resp_body), ''


@_link_to_response(TipFrete.ENCERRARCIOTGRATUITO)
@_handle_exception
def _enc_ciot_resp(resp: Response) -> Tuple[str, str]:
    resp_json = xmltodict.parse(resp.text)

    msg = resp_json.get('retornoEncerrarOperacaoTranporte', '').get('msg', '')
    protocolo = resp_json.get('retornoEncerrarOperacaoTranporte', '').get('protocolo', '')
    success = resp.status_code == 200
    if success and protocolo:
        resp_body = {'sucesso': success, 'protocolo': protocolo}
    elif success and msg:
        resp_body = {'sucesso': False, 'erro': msg}
    else:
        raise TipFreteException('Erro ao encerrar CIOT Gratuito')

    return mount_xml_response(resp_body), ''


@_link_to_response(TipFrete.CONSULTARTRANSPORTADOR)
@_handle_exception
def _status_carrier_resp(resp: Response) -> Tuple[str, str]:
    resp_json = xmltodict.parse(resp.text)

    success = resp.status_code == 200
    transp_rntrcAtivo = resp_json.get('retornoSituacaoTransportador', '').get('transportador', '').get('rntrcAtivo', '')
    msg = resp_json.get('retornoSituacaoTransportador', '').get('transportador', '').get('msg', '')
    if success and transp_rntrcAtivo != '':
        resp_body = {'sucesso': success, 'rntrcAtivo': transp_rntrcAtivo}
    elif success and msg:
        resp_body = {'erro': msg}
    else:
        raise TipFreteException('Erro ao consultar situacao do Transportador')

    return mount_xml_response(resp_body), ''


@_link_to_response(TipFrete.CREDITOIMEDIATO)
@_handle_exception
def _imm_credit_resp(resp: Response) -> Tuple[str, str]:
    resp_json = xmltodict.parse(resp.text)

    success = resp.status_code == 200
    cred_numContrato = resp_json.get('creditoImediatoRetorno', '').get('numerocontrato', '')
    msg = resp_json.get('creditoImediatoRetorno', '').get('msg', '')
    if success and cred_numContrato != '':
        resp_body = {'sucesso': success, 'numeroContrato': cred_numContrato}
    elif success and msg:
        resp_body = {'erro': msg}
    else:
        raise TipFreteException('Erro ao realizar o credito imediato')

    return mount_xml_response(resp_body), ''


#@_link_to_response(TipFrete.ARQUIVOCONFERENCIA)
#@_handle_exception
#def _toll_conference_resp(resp: Response) -> Tuple[str, str]:
#    resp_json = xmltodict.parse(resp.text)

#    success = resp.status_code == 200
#    arq_codMsg = resp_json.get('respostaArquivoConferencia', '').get('codigoMensagem', '')
#    arq_linkArq = resp_json.get('respostaArquivoConferencia', '').get('linkArquivo', '')
#    msg = resp_json.get('respostaArquivoConferencia', '').get('mensagem', '')
#    if success and (arq_codMsg != '' or arq_linkArq != ''):
#        resp_body = {'sucesso': success, 'codigoMensagem': arq_codMsg, 'linkArquivo': arq_linkArq}
#    elif success and msg:
#        resp_body = {'erro': msg}
#    else:
#        raise TipFreteException('Erro ao gerar o arquivo de cobranca de pedagio')

#    return mount_xml_response(resp_body), ''

@_link_to_response(TipFrete.ARQUIVOCOBRANCA)
@_handle_exception
def _toll_billing_resp(resp: Response) -> Tuple[str, str]:
    resp_json = xmltodict.parse(resp.text)

    success = resp.status_code == 200
    arq_linkArqCob = resp_json.get('retornoArquivoCobrancaPedagio', '').get('linkArquivoCobranca', '')
    arq_linkArqPed = resp_json.get('retornoArquivoCobrancaPedagio', '').get('linkArquivoPedagio', '')
    msg = resp_json.get('retornoArquivoCobrancaPedagio', '').get('mensagem', '')
    if success and (arq_linkArqCob != '' or arq_linkArqPed != ''):
        resp_body = {'sucesso': success, 'linkArquivoCobranca': arq_linkArqCob, 'linkArquivoPedagio': arq_linkArqPed}
    elif success and msg:
        resp_body = {'erro': msg}
    else:
        raise TipFreteException('Erro ao gerar o arquivo de cobranca de pedagio')

    return mount_xml_response(resp_body), ''

@_link_to_response(TipFrete.CONSULTARFINALIZACAO)
@_handle_exception
def _cons_completion_resp(resp: Response, req_in: str) -> Tuple[str, str]:
    resp_json = xmltodict.parse(resp.text)
    success = resp.status_code == 200
    msg = resp_json.get('consultaFinalizacaoViagemRetorno', '').get('mensagem', '')
    status = resp_json.get('consultaFinalizacaoViagemRetorno', '').get('status', '')
    linkComprovante = resp_json.get('consultaFinalizacaoViagemRetorno', '').get('linkComprovante', '')
    obs = resp_json.get('consultaFinalizacaoViagemRetorno', '').get('observacao', '')
    if success and status != '':
        resp_body = {'sucesso': success, 'status': status, 'msg': msg, 'linkComprovante': linkComprovante, 'obs': obs}
    elif success and msg:
        resp_body = {'erro': msg}
    else:
        raise TipFreteException('Erro ao consultar finalizacao da viagem')

    return mount_xml_response(resp_body), ''


@_link_to_response(TipFrete.FINALIZARVIAGEM)
@_handle_exception
def _finish_shipping_resp(resp: Response, req_in: str) -> Tuple[str, str]:
    resp_json = xmltodict.parse(resp.text)
    success = resp.status_code == 200
    protocolo = resp_json.get('finalizacaoViagemRetorno', '').get('protocolo', '')
    msg = resp_json.get('finalizacaoViagemRetorno', '').get('mensagem', '')
    if success and protocolo != '':
        resp_body = {'sucesso': success, 'protocolo': protocolo, 'msg': msg}
    elif success and msg:
        resp_body = {'erro': msg}
    else:
        raise TipFreteException('Erro ao finalizar viagem')

    return mount_xml_response(resp_body), ''

# Funções utilitárias
def _get_token(url: str, data: dict, cache: dict) -> str:
    usuario = data.get('usuario', '')
    senha = data.get('senha', '')

    if not usuario or not senha:
        raise Exception('O e-mail, senha não foram informados.')

    aes_key = PBKDF2(senha, usuario, 32, count=500, hmac_hash_module=SHA256)
    cipher = AES.new(aes_key, AES.MODE_ECB)

    usuario_hash = hash(usuario)
    (token, gen_time) = cache.get(usuario_hash, (bytearray(), 0))

    if token and (time.time() - gen_time) < 31531000:  # Se a idade for menor que 55 minutos
        token = cipher.decrypt(token)
        return unpad(token, cipher.block_size).decode('UTF-8')

    if not url:
        raise TipFreteException('Não foi possível obter a URL para requisitar o token.')
