'''
SWAGGER: https://homologacao.integracao.pagbem.com.br/swagger/ui/index
LOGIN: 02104333000196:Bop42fGYGtSfi97
'''

import json
import requests
import time

from entity import proprietario, motorista, veiculo, conhecimento
from geral import *
from geraljson import *
from geralxml import *
from consist import *
from geralsis import getTokenByCnpjCpf

ACAO_PAGBEM_INICIO = 1200
ACAO_PAGBEM_GERARTOKEN = 1211
ACAO_PAGBEM_CADASTRAR_MOTORISTA = 1212
ACAO_PAGBEM_CADASTRAR_CONTRATANTE = 1213
ACAO_PAGBEM_CADASTRAR_VEICULO = 1214
ACAO_PAGBEM_BUSCAR_ROTA = 1215
ACAO_PAGBEM_CONSULTAR_MOTORISTA = 1216
ACAO_PAGBEM_ADD_CARTAO_MOTORISTA = 1217
ACAO_PAGBEM_ADD_CARTAO_PROPRIETARIO = 1218
ACAO_PAGBEM_ADD_VIAGEM = 1219
ACAO_PAGBEM_CONSULTAR_CONTRATANTE = 1220
ACAO_PAGBEM_VIAGEM_QUITACAO = 1221
ACAO_PAGBEM_VIAGEM_SEM_FLUXO_FINANCEIRO = 1222
ACAO_PAGBEM_VIAGEM_LIBERAR = 1223
ACAO_PAGBEM_DEL_VIAGEM = 1224
ACAO_PAGBEM_CADASTRAR_ROTA = 1225
# deixar uma margem de codigos para nao misturar
ACAO_PAGBEM_RELATORIO_FINANCEIRO_DATA = 1240
ACAO_PAGBEM_CONCILIACAO_FINANCEIRA_DATA = 1241
ACAO_PAGBEM_CONCILIACAO_CONTABIL_DATA = 1242
ACAO_PAGBEM_CONSULTAR_ABASTECIMENTOS = 1243
ACAO_PAGBEM_ENVIAR_RECALCULO_IMPOSTOS = 1244
ACAO_PAGBEM_BAIXAR_RECIBO_VALE_PEDAGIO = 1245
ACAO_PAGBEM_FIM = 1249


listTokens = [] # cache de tokens


def preProcessRequestPropertiesPagBem(cert, codEMonitorAcao, url, requestProperties, headers):
    # para cada comunicacao com a PagBem, precisa gerar um token, ou usar um valido da variavel de cache local listTokens
    url = url[0:url.rindex('/') + 1] + 'token'
    #
    req = 'grant_type=password'
    listProperties = list(requestProperties.split('&'))
    cnpjcpf = ''
    for property in listProperties:
        entry = property.split('=')
        if entry[0] == 'login':
            req += '&username=' + entry[1]
        elif entry[0] == 'senha':
            req += '&password=' + entry[1]
        elif entry[0] == 'cnpjcpf':
            cnpjcpf = entry[1]
    # verificar se o token esta no cache local
    token = getTokenByCnpjCpf(cnpjcpf,listTokens)
    if token != '':
        #print('token do cache = ' + token)
        headers['Authorization'] = 'Bearer ' + token
        return headers, ''
    #
    resp = requests.post(url, cert=cert, data=req, headers=headers)
    retcode = resp.status_code
    if retcode == 200:
        ret = resp.content.decode('utf-8')
        root = json.loads(ret)
        token = getJSON(root,'access_token')
        if token is None or token == '':
            return headers, 'ERRO DE GERAR TOKEN VAZIO NO SERVIDOR DA OPERADORA DE CARTÃO (' + str(retcode) + ')'
        else:
            #print('token novo = ' + token)
            listTokens.append([cnpjcpf,token,timems()])
            headers['Authorization'] = 'Bearer ' + token
            headers['CNPJContratante'] = cnpjcpf
            return headers, ''
    else:
        print(resp.content.decode('utf-8'))
        return headers, 'ERRO INTERNO DE GERAR TOKEN NO SERVIDOR DA OPERADORA DE CARTÃO (' + str(retcode) + ')'


def preProcessURLPagBem(cert, codEMonitorAcao, url, headers, req, numTent):
    # se for uma dessas acoes, pode ser que o SOR ja tenha o ShippingID
    req = req.replace('\\"', '"')
    reqJSON = json.loads(req)
    if codEMonitorAcao == ACAO_PAGBEM_CADASTRAR_CONTRATANTE:
        cnpjcpf = getJSON(reqJSON,'CNPJCPF')
        if cnpjcpf != '':
            return url + 'api/contratados/' + cnpjcpf, ''
        else:
            return '', 'CNPJ/CPF NÃO ENVIADO'
    elif codEMonitorAcao == ACAO_PAGBEM_RELATORIO_FINANCEIRO_DATA:
        dataIni = getJSON(reqJSON,'dataInicial') + 'T00:00:00Z'
        dataFim = getJSON(reqJSON,'dataFinal') + 'T00:00:00Z'
        cnpjContratante = getJSON(reqJSON,'cnpjContratante')
        return url + 'api/viagens/relatorioFinanceiro?periodo_De='+dataIni+'&periodo_Ate='+dataFim+'&CNPJ_Contratante='+cnpjContratante, ''
    elif codEMonitorAcao == ACAO_PAGBEM_CONCILIACAO_FINANCEIRA_DATA:
        data = getJSON(reqJSON,'data')
        cnpjContratante = getJSON(reqJSON,'cnpjContratante')
        return url + 'api/conciliacoes/financeira/data/'+data+'/contratante/'+cnpjContratante, ''
    elif codEMonitorAcao == ACAO_PAGBEM_CONSULTAR_ABASTECIMENTOS:
        cnpjContratante = getJSON(reqJSON, 'cnpjContratante')
        idViagem = getJSON(reqJSON,'conh_id')
        return url + 'api/viagens/abastecimento?CNPJContratante='+cnpjContratante+'&contratoViagem='+idViagem, ''
    elif codEMonitorAcao == ACAO_PAGBEM_ENVIAR_RECALCULO_IMPOSTOS:
        idViagem = getJSON(reqJSON,'conh_id')
        return url + 'api/viagens/abastecimento/'+idViagem, ''
    elif codEMonitorAcao == ACAO_PAGBEM_BAIXAR_RECIBO_VALE_PEDAGIO:
        id_viagem = getJSON(reqJSON,'id_viagem')
        return url + '/api/pedagio/' + id_viagem + '/recibopedagio?TipoImpressaoRecibo=PDF', ''
    else:
        return '', 'AÇÃO ' + str(codEMonitorAcao) + ' NÃO IMPLEMENTADA'


def consistPagBemCadastrarProprietario(reqJSON):
    ret = proprietario.consistCadastrarProprietario(reqJSON)
    # PENDENTE CHECAR CONSISTENCIAS ESPECIFICAS DA REPOM
    #ret += 'outro erro'
    return ret


def requestPagBemCadastrarProprietario(reqJSON):
    reqJSON['prop_rntrc'] = padlzero(getJSON(reqJSON, 'prop_rntrc'), 9)
    erros = consistPagBemCadastrarProprietario(reqJSON)
    if erros != '':
        return '', erros
    #
    if getJSON(reqJSON,'prop_integrador') == '': # este caso somente ocorre no processamento de modulo completo, onde pode ter alguns cadastros que nao serao feitos
        return '', ''
    #
    isPF = len(getJSON(reqJSON, 'prop_cnpjcpf')) == 11
    # PENDENTE MANDAR VARIOS FONES
    if isPF:
        foneddd = getJSON(reqJSON,'prop_celularddd')
        fonenumero = getJSON(reqJSON,'prop_celularnumero')
        if foneddd == '' or fonenumero == '' or foneddd == '00':
            foneddd = getJSON(reqJSON,'prop_foneddd')
            fonenumero = getJSON(reqJSON,'prop_fonenumero')
    else:
        foneddd = getJSON(reqJSON,'prop_foneddd')
        fonenumero = getJSON(reqJSON,'prop_fonenumero')
        if foneddd == '' or fonenumero == '' or foneddd == '00':
            foneddd = getJSON(reqJSON,'prop_celularddd')
            fonenumero = getJSON(reqJSON,'prop_celularnumero')
    reqJSONRepom = \
        '{' + \
            createelem('CNPJCPF', getJSON(reqJSON,'prop_cnpjcpf')) + \
            createelem('nome', getJSON(reqJSON,'prop_nome')) + \
            createelem('IE', getJSON(reqJSON,'prop_ie')) + \
            createelem('dataNascimento', getJSON(reqJSON,'prop_datanasc') + 'T00:00:00.000Z') + \
            createelemtree('endereco') + \
                '{' + \
                createelem('logradouro', removeAccents(getJSON(reqJSON,'prop_endereco'))) + \
                createelem('numero', removeAccents(getJSON(reqJSON,'prop_numero'))) + \
                createelem('complemento', removeAccents(getJSON(reqJSON,'prop_complemento'))) + \
                createelem('bairro', removeAccents(getJSON(reqJSON,'prop_bairro'))) + \
                createelem('CEP', clearNoASCII(getJSON(reqJSON,'prop_cep'))) + \
                createelemnum2('codigoIBGE', clearNoASCII(getJSON(reqJSON,'prop_codibge')), '') + \
                '},' + \
            createelemtree('telefone1') + \
                '{' + \
                createelemnum('DDD', foneddd) + \
                createelemnum2('numero', fonenumero, '') + \
                '},' + \
            createelem('email', getJSON(reqJSON,'prop_email')) + \
            createelem2('RNTRC', getJSON(reqJSON,'prop_rntrc'), '') + \
        '}'
    return reqJSONRepom, ''


def responsePagBemCadastrarProprietario(resp):
    return responsePagBemCadastrarGeral(resp)


def getMensagemErroPadrao(resp):
    ret = resp.content.decode('utf-8')
    retcode = resp.status_code
    root = json.loads(ret)
    errors = getJSON(root, 'erros')
    msgResp = ''
    for error in errors:
        msgResp += ' - ' + error['mensagem'] + ' (' + str(error['codigo']) + ')'
    if msgResp is None or msgResp == '':
        msgResp = 'MENSAGEM DE ERRO DA OPERADORA NÃO ENCONTRADA (' + str(retcode) + ')'

    return '',  msgResp


def responsePagBemCadastrarGeral(resp):
    try:
        ret = resp.content.decode('utf-8')
        retcode = resp.status_code
        root = json.loads(ret)
        isSucesso = getJSON(root, 'isSucesso')
        if isSucesso:
            msg = getJSON(root, 'resultado')
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msg + '</msg></resp>', ''
        else:
            return getMensagemErroPadrao(resp)
    except Exception as e:
        print('Erro em responsePagBemCadastrarGeral')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responsePagBemConsultarAbastecimento(resp):
    try:
        ret = resp.content.decode('utf-8')
        retcode = resp.status_code
        root = json.loads(ret)
        isSucesso = getJSON(root, 'isSucesso')
        if isSucesso:
            retFinal = {}
            resultado = getJSON(root, 'resultado')
            pagina = getJSON(resultado, 'pagina')
            somaAbastecimentos = 0
            msgAux = ''
            for contrato in pagina:
                movimentos = getJSON(contrato, 'movimentos')
                for movimento in movimentos:
                    valorAbastecimento = getJSON(movimento, 'valorAbastecimento')
                    cnpjEtf = getJSON(movimento, 'CNPJETF')
                    nomeLocalQuitacao = getJSON(movimento, 'nomeLocalQuitacao')
                    somaAbastecimentos += valorAbastecimento
                    msgAux += ' | [PAGBEM] Abastecimento valor:'+str(valorAbastecimento)+' realizado. Local: '+nomeLocalQuitacao+ ' '+cnpjEtf
            if msgAux == '':
                msgAux = 'Nenhum abastecimento encontrado para esta viagem'
            retFinal['somaAbastecimentos'] = somaAbastecimentos
            retFinal['msg'] = msgAux
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>Dados processados com sucesso</msg><json>' + json.dumps(retFinal) + '</json></resp>', ''
        else:
            return getMensagemErroPadrao(resp)
    except Exception as e:
        print('Erro em responsePagBemConsultarAbastecimento')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responsePagBemRelatorioFinanceiroData(resp, req):
    try:
        retcode = resp.status_code
        ret = resp.content.decode('utf-8')
        root = json.loads(ret)
        isSucesso = getJSON(root, 'isSucesso')
        req = json.loads(req)
        if isSucesso:
            resultado = getJSON(root, 'resultado')
            financeiroFrete = getJSON(resultado, 'financeiroFrete')
            arrayViagens = []
            for viagemPagbem in financeiroFrete:
                tipoEvento = getJSON(viagemPagbem, 'nm_TipoMovimento')
                if tipoEvento == 'Quitação' or tipoEvento == 'Adiantamento':
                    viagem = {}
                    if tipoEvento == 'Quitação':
                        viagem['tipoMov'] = 'Q'
                    else:
                        viagem['tipoMov'] = 'A'
                    viagem['numero'] = getJSON(viagemPagbem,'no_Viagem').split('/')[0]
                    viagem['numViagOpCartao'] = strtonum(getJSON(viagemPagbem,'no_Contrato'),0)
                    viagem['pesoChegada'] = strtonum(getJSON(viagemPagbem,'vl_PesoChegada'),0)
                    viagem['valorQuebra'] = strtonum(getJSON(viagemPagbem,'vl_Quebra'),0)
                    viagem['valorDifFrete'] = strtonum(getJSON(viagemPagbem,'vl_DiferencaFrete'),0)
                    viagem['valorOutrosDebitos'] = strtonum(getJSON(viagemPagbem,'vl_OutrosDebitos'),0)
                    viagem['valorAjustes'] = strtonum(getJSON(viagemPagbem,'vl_Ajustes'),0)
                    data = getJSON(viagemPagbem,'dt_Vencimento')
                    if data is not None and data != '':
                        data = datetostr(dbstrtodate(data[0:10]))
                    viagem['dataVenc'] = data
                    viagem['valorMov'] = strtonum(getJSON(viagemPagbem,'vl_Movimento'),0)
                    viagem['tarifaCartao'] = strtonum(getJSON(viagemPagbem,'tarifaCartao'),0)
                    arrayViagens.append(viagem)
            #
            retFinal = {}
            retFinal['viagens'] = arrayViagens
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>Dados processados com sucesso</msg><json>' + json.dumps(retFinal) + '</json></resp>', ''
        else:
            return getMensagemErroPadrao(resp)
    except Exception as e:
        print('Erro em responsePagBemRelatorioFinanceiroData')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responsePagBemConciliacaoFinanceiraData(resp, req):
    try:

        # ret = '{"isSucesso":true,"resultado":[{"idViagem":4321933,"numeroViagemCliente":"461858/1203147/3","tipoEvento":"Adiantamento","valorEvento":5400.00,"eventoLocal":"PAGBEM - ADIANTAMENTO","eventoTipoLocal":"Filial","data":"2020-11-14T11:33:54.627","dataVencimento":"2020-11-19T00:00:00","produto":"Frete"},{"idViagem":4298914,"numeroViagemCliente":"461047/131345/2","tipoEvento":"Quitacao","valorEvento":548.88,"eventoLocal":"TRANSVAL","eventoTipoLocal":"Filial","data":"2020-11-14T11:04:50.843","composicaoSaldoQuitacao":{"saldoQuitacao":548.88,"saldoAdiantamento":0.00,"quitacaoParcial":0.00},"detalhesQuitacao":{"pesoChegada":47560.000,"dataChegada":"2020-11-14T11:04:50.843","valorAvaria":0.00,"valorDiferencaFrete":-15.40,"valorQuebra":-143.11},"dataVencimento":"2020-11-19T00:00:00","produto":"Frete"},{"idViagem":4323485,"numeroViagemCliente":"461928/1203175/3","tipoEvento":"CompraPedagio","valorEvento":112.00,"data":"2020-11-14T16:17:35.613","dataVencimento":"2020-11-15T00:00:00","produto":"Pedagio"}]}'
        retcode = resp.status_code
        ret = resp.content.decode('utf-8')
        root = json.loads(ret)
        isSucesso = getJSON(root, 'isSucesso')
        req = json.loads(req)
        regra = getJSON(req, 'regra')
        dataVencimentoPedagio = ''
        dataVencimentoFrete = ''
        dataEmissao = ''

        if isSucesso:
            resultado = getJSON(root, 'resultado')
            arrayViagensFrete = []
            arrayViagensPedagio = []
            arrayFaturas = []
            totalViagensFrete = 0
            totalViagensPedagio = 0

            for viagemPagbem in resultado:
                parcela=''
                tipoEvento = getJSON(viagemPagbem, 'tipoEvento')
                valorEvento = getJSON(viagemPagbem, 'valorEvento')
                saldoQuitacao = 0
                saldoAdiantamento = 0
                pesoChegada = 0
                if tipoEvento == 'Quitacao':
                    composicaoSaldoQuitacao = getJSON(viagemPagbem, 'composicaoSaldoQuitacao')
                    saldoQuitacao = getJSON(composicaoSaldoQuitacao, 'saldoQuitacao')
                    saldoAdiantamento = getJSON(composicaoSaldoQuitacao, 'saldoAdiantamento')
                    detalhesQuitacao = getJSON(viagemPagbem, 'detalhesQuitacao')
                    valorEvento += getJSON(detalhesQuitacao, 'valorDiferencaFrete')
                    valorEvento += getJSON(detalhesQuitacao, 'valorQuebra')
                    saldoQuitacao += getJSON(detalhesQuitacao, 'valorDiferencaFrete')
                    saldoQuitacao += getJSON(detalhesQuitacao, 'valorQuebra')
                    pesoChegada += safe_cast(detalhesQuitacao.get('pesoChegada'), int, 0)

                dataVencimento = getJSON(viagemPagbem, 'dataVencimento')
                if dataVencimento:
                    dataVencimento = datetostr(dbstrtodate(dataVencimento[0:10]))
                dataEmissao = getJSON(viagemPagbem, 'data')
                dataEmissao = datetostr(dbstrtodate(dataEmissao[0:10]))
                produto = getJSON(viagemPagbem, 'produto')
                numeroViagemCliente = getJSON(viagemPagbem, 'numeroViagemCliente')
                if '/' in numeroViagemCliente:
                    numeroViagemCliente = getJSON(viagemPagbem, 'numeroViagemCliente').split('/')

                    if (len(numeroViagemCliente) == 3) or (len(numeroViagemCliente) == 2):
                        numero = numeroViagemCliente[0]
                    else:
                        numero = ''
                else:
                    numero = numeroViagemCliente

                if produto == 'Frete':
                    dataVencimentoFrete = dataVencimento
                elif produto == 'Pedagio':
                    dataVencimentoPedagio = dataVencimento
                if tipoEvento == 'Adiantamento':
                    parcela = 'AD '
                elif tipoEvento == 'Quitacao':
                    parcela = 'SD '
                elif (tipoEvento == 'CompraPedagio') and (numero.isdigit()):
                    parcela = 'PED'
                elif (tipoEvento == 'EstornoPedagio') and (numero.isdigit()):
                    parcela = 'PEDES'

                viagem = {}
                viagemAD = {}

                viagem['numViagOpCartao'] = getJSON(viagemPagbem, 'idViagem')
                viagem['numero'] = numero
                viagem['valor'] = valorEvento
                viagem['pesoChegada'] = pesoChegada
                if saldoQuitacao != '':
                    viagem['composicaoSaldoQuitacao'] = saldoQuitacao
                if saldoAdiantamento != '':
                    viagem['composicaoAdiantamentoQuitacao'] = saldoAdiantamento
                viagem['parcela'] = parcela

                if saldoAdiantamento > 0:

                    viagemAD['numViagOpCartao'] = getJSON(viagemPagbem, 'idViagem')
                    viagemAD['numero'] = numero
                    viagemAD['valor'] = valorEvento
                    viagem['pesoChegada'] = pesoChegada
                    if saldoQuitacao != '':
                        viagemAD['composicaoSaldoQuitacao'] = saldoQuitacao
                    if saldoAdiantamento > 0:
                        viagemAD['composicaoAdiantamentoQuitacao'] = saldoAdiantamento
                    viagemAD['parcela'] = 'AD '

                if regra == '2':
                    totalViagensFrete += valorEvento
                    arrayViagensFrete.append(viagem)
                    if viagemAD:
                        arrayViagensFrete.append(viagemAD)

                else:
                    if produto == 'Frete':
                        totalViagensFrete += valorEvento
                        arrayViagensFrete.append(viagem)
                        if viagemAD:
                            arrayViagensFrete.append(viagemAD)
                    elif produto == 'Pedagio':
                        totalViagensPedagio += valorEvento
                        arrayViagensPedagio.append(viagem)

            #
            if len(resultado) > 0:
                faturaFrete = {}
                faturaFrete['serie'] = 'FPV'
                faturaFrete['serienf'] = '1'
                faturaFrete['valor'] = totalViagensFrete
                faturaFrete['data'] = dataEmissao
                faturaFrete['dataVencimento'] = dataVencimentoFrete
                faturaFrete['viagens'] = arrayViagensFrete
                faturaPedagio = {}
                faturaPedagio['serie'] = 'FPV'
                faturaPedagio['serienf'] = '2'
                faturaPedagio['valor'] = totalViagensPedagio
                faturaPedagio['data'] = dataEmissao
                faturaPedagio['dataVencimento'] = dataVencimentoPedagio
                faturaPedagio['viagens'] = arrayViagensPedagio
                arrayFaturas.append(faturaFrete)
                arrayFaturas.append(faturaPedagio)
            retFinal = {}
            retFinal['faturas'] = arrayFaturas
            #ret = json.dumps(retFinal)

            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>Dados processados com sucesso</msg><json>' + json.dumps(retFinal) + '</json></resp>', ''
        else:
            return getMensagemErroPadrao(resp)
    except Exception as e:
        print('Erro em responsePagBemConciliacaoFinanceiraData')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestPagBemEnviarRecalculoImpostos(reqJSON):
    reqJsonPagBem = {}
    reqJsonPagBem['valorAbastecimento'] = float(getJSON(reqJSON, 'conh_cargadescarga'))
    reqJsonPagBem['INSSRecalculado'] = float(getJSON(reqJSON, 'conh_impinss'))
    reqJsonPagBem['IRRecalculado'] = float(getJSON(reqJSON, 'conh_impirrf'))
    reqJsonPagBem['sestSenatRecalculado'] = float(getJSON(reqJSON, 'conh_impsestsenat'))
    reqJsonPagBem['valorCreditoImposto'] = float(getJSON(reqJSON, 'conh_creditoimposto'))
    return json.dumps(reqJsonPagBem), ''


def responsePagBemEnviarRecalculoImpostos(resp):
    try:
        retcode = resp.status_code
        ret = resp.content.decode('utf-8')
        root = json.loads(ret)
        isSucesso = getJSON(root, 'isSucesso')
        if isSucesso:
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>Dados processados com sucesso</msg></resp>', ''
        else:
            return getMensagemErroPadrao(resp)
    except Exception as e:
        print('Erro em responsePagBemEnviarRecalculoImpostos')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def response_pag_bem_baixar_recibo_vale_pedagio(resp):
    try:
        resp_json = resp.json()

        if resp_json.get('isSucesso',''):
            return mount_xml_response(resp_json), ''
        else:
            return getMensagemErroPadrao(resp)

    except Exception as e:
        return '', 'OCORREU UM ERRO AO TENTAR BUSCAR O COMPROVANTE DE VALE PEDÁGIO'


