import json
from GetJson import GetJson
from entity import proprietario, motorista, veiculo, conhecimento
from consist import *
from geral import *
import base64
from datetime import datetime
import requests

ACAO_CARGOBANK_INICIO = 1500

ACAO_CARGOBANK_EMITE_CIOT = 1501
ACAO_CARGOBANK_FINALIZAR_CIOT = 1502
ACAO_CARGOBANK_CANCELAR_CIOT = 1503
ACAO_CARGOBANK_QUITAR_CIOT = 1504

ACAO_CARGOBANK_PEDAGIO_CRIARROTA = 1505
ACAO_CARGOBANK_PEDAGIO_CONSULTARVALORROTA = 1506
ACAO_CARGOBANK_PEDAGIO_EMITIRPEDAGIO = 1507
ACAO_CARGOBANK_PEDAGIO_CANCELARPEDAGIO = 1508

ACAO_CARGOBANK_FIM = 1549


def preProcessRequestPropertiesCargobank(headers, requestProperties):
    properties = {}
    if requestProperties != '':
        listProperties = list(requestProperties.split('&'))
        for property in listProperties:
            entry = property.split('=')
            properties[entry[0]] = entry[1]

    headers['Authorization'] = 'Bearer ' + properties['token']
    return headers, ''

def preProcessUrlCargobank(url, req):
    req = req.replace('\\"', '"')
    reqJSON = json.loads(req)
    url = url + getJSON(reqJSON, 'protocoloVPR')+'/cancelar'
    return url, ''


def requestCargobank_GerarCiot(reqJSON, requestProperties):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}
        req['Token'] = requestProperties['token']
        req['CpfCnpjContratado'] = getJSON('conh_prop_cnpjcpf')
        req['RNTRCContratado'] = getJSON('conh_prop_rntrc')

        veiculoArray = []
        veiculoObj = {}
        veiculoObj['Placa'] = getJSON('conh_veic_placa')
        veiculoObj['RNTRC'] = getJSON('conh_prop_rntrc')
        veiculoArray.append(veiculoObj)

        req['Veiculos'] = veiculoArray

        req['CpfCnpjContratante'] = getJSON('conh_filial_cnpjcpf')
        req['CpfCnpjDestinatario'] = getJSON('conh_dest_cnpjcpf')
        req['CodigoMunicipioOrigem'] = getJSON('conh_codibgeorig')
        req['CodigoMunicipioDestino'] = getJSON('conh_codibgedest')
        req['CpfCnpjMotorista'] = getJSON('conh_mot_cpf')
        if getJSON('conh_ncm') != '':
            req['CodigoNaturezaCarga'] = getJSON('conh_ncm')
        else:
            req['CodigoNaturezaCarga'] = '0001'

        req['PesoCarga'] = getJSON('conh_pesosaida')
        req['DataInicioViagem'] = wsstrtoDDMMAAAA(getJSON('conh_dataini'))
        req['DataFimViagem'] = wsstrtoDDMMAAAA(getJSON('conh_datafim'))

        tipoAntt = req.get('conh_prop_tipoantt')
        req['TipoViagem'] = (3 if tipoAntt == 3 else 1)  # 1 - Padrão 3 - TAC Agregado

        req['RNTRCContratante'] = getJSON('conh_filial_rntrc')
        req['QuantidadeTarifas'] = 0
        req['ValorTarifas'] = 0
        req['ValorFreteTotal'] = getJSON('conh_valorviagem')
        req['TipoDeQuebra'] = 'nenhum-desconto'
        req['LimiteMinQuebra'] = 0
        req['LimiteMaxQuebra'] = 0
        req['CodigoInterno'] = getJSON('conh_numero')
        req['ValorMercadoriaTotal'] = getJSON('conh_quantmerc')
        req['ValorFretePorUnidade'] = 0

        req['IRRF'] = getJSON('conh_impirrf')
        req['INSS'] = getJSON('conh_impinss')
        req['SEST_SENAT'] = getJSON('conh_impsestsenat')
        req['cte'] = getJSON('conh_ctechave')

        if getJSON('conh_programa_pgto') == 'S': # Caso N é ciot gratuito, isso é um paramentro empresa no SOR WSCargobankNaoProgramaSaldoAdtoPed

            req['DiferencaFrete'] = 1  #0-Saída, 1-Chegada 2-Chegada, se peso menor que saída, 3-Chegada com tolerância, O valor padrão é por peso de "Chegada"

            req['DiferencaFreteTolerancia'] = getJSON('conh_valortoler1')

            if getJSON('conh_meiopagamento') == 'CD':
                req['PagtoContaDigital'] = 1  # Informar se o CIOT será pago via Conta Digital (1) ou Carta Frete (0). Caso não informar o padrão será 1 (pagamento em Conta Digital)
            else:
                req['PagtoContaDigital'] = 0
                req['CartaFrete'] = getJSON('conh_cartafrete')

            if getJSON('conh_favorecido') == 'P':   # Informar se, ao quitar o CIOT, deve-se pagar o motorista ou o proprietário do veículo  /Onde, "sim" pagará o motorista e "nao" pagará o proprietário
                req['PagarMotorista'] = 'nao'
            else:
                req['PagarMotorista'] = 'sim'

        return json.dumps(req), ''
    except Exception as e:
        print('Erro em requestCargobankGerarCiot')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def responseCargobank_GerarCiot(resp):

    try:
        resp = resp.content.decode('utf-8')
        root = json.loads(resp)
        jsonResp = GetJson(root)
        getJSON = jsonResp.getJSON

        sucesso = getJSON('Sucesso')
        if sucesso:
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><retorno>' + str(getJSON('Mensagem')) + '</retorno>' + '<ciot>' + str(getJSON('CIOT')) + '</ciot>', ''
        else:
            return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><retorno>' + str(getJSON('Mensagem')) + '</retorno>'

    except Exception as e:
        print('Erro em requestCargobankGerarCiot')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)

def responseCargobank_CancelarCiot(resp):
    try:
        resp = resp.content.decode('utf-8')
        root = json.loads(resp)
        jsonResp = GetJson(root)
        getJSON = jsonResp.getJSON

        sucesso = getJSON('Sucesso')
        if sucesso:
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><retorno>' + str(getJSON('Mensagem')) + '</retorno>' + '<protocolo>' + str(getJSON('ProtocoloCancelamento')) + '</protocolo>', ''
        else:
            return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><retorno>' + str(
                getJSON('Mensagem')) + '</retorno>'

    except Exception as e:
        print('Erro em responseCargobank_CancelarCiot')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)



def responseCargobank_FinalizarCiot(resp):
    try:
        resp = resp.content.decode('utf-8')
        root = json.loads(resp)
        jsonResp = GetJson(root)
        getJSON = jsonResp.getJSON

        sucesso = getJSON('Sucesso')
        if sucesso:
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><retorno>' + str(
                getJSON('Mensagem')) + '</retorno>' + '<protocolo>' + str(getJSON('ProtocoloEncerramento')) + '</protocolo>', ''
        else:
            return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><retorno>' + str(
                getJSON('Mensagem')) + '</retorno>'

    except Exception as e:
        print('Erro em responseCargobank_FinalizarCiot')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def responseCargobank_QuitarCiot(resp):
    resp = resp.content.decode('utf-8')
    root = json.loads(resp)
    jsonResp = GetJson(root)
    getJSON = jsonResp.getJSON

    sucesso = getJSON('Sucesso')
    if sucesso:
        return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><retorno>' + str(
            getJSON('Mensagem')) + '</retorno>', ''
    else:
        return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><retorno>' + str(
            getJSON('Mensagem')) + '</retorno>'


def requestCargobank_CancelarCiot(reqJSON,requestProperties):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}
        req['Token'] = requestProperties['token']
        req['Ciot'] = getJSON('conh_ciot')
        req['Motivo'] = getJSON('conh_motcanc')

        return json.dumps(req), ''
    except Exception as e:
        print('Erro em response requestCargobank_CancelarCiot')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def requestCargobank_FinalizarCiot(reqJSON, requestProperties):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}
        req['Token'] = requestProperties['token']
        req['Ciot'] = getJSON('conh_ciot')

        return json.dumps(req), ''
    except Exception as e:
        print('Erro em response requestCargobank_FinalizarCiot')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def requestCargobank_QuitarCiot(reqJSON,requestProperties):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}
        req['Token'] = requestProperties['token']
        req['Ciot'] = getJSON('conh_ciot')
        req['CnpjQuitador'] = getJSON('conh_filial_cnpjcpf')
        req['PesoCargaEntregue'] = getJSON('conh_pesochegada').replace('.', '').replace(',', '.')
        now = datetime.now()
        date_time = now.strftime("%m/%d/%Y")
        req['DataEntrega'] = date_time
        req['DataQuitacao'] = date_time
        # Arquivos = []
        # req['Arquivos'] = Arquivos

        return json.dumps(req), ''
    except Exception as e:
        print('Erro em response requestCargobank_QuitarCiot')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)

def requestCargobank_CriarRota(reqJSON):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}
        req['Descricao'] = getJSON('rot_nome')

        paradas = {}
        paradasArray = []

        paradas['Pais'] = 'BR'
        paradas['Uf'] = getJSON('rot_origem_uf')
        paradas['Cidade'] = getJSON('rot_origem_cidade')
        paradas['Rua'] = None
        paradas['Numero'] = None
        paradas['Cep'] = None
        paradas['Latitude'] = None
        paradas['Longitude'] = None
        paradas['LevantarEixo'] = False
        paradasArray.append(paradas)

        qtdeIbge = int(getJSON('rot_quantibge'))  #cidades intermediarisa entre a origem e o destino
        for i in range(1, qtdeIbge + 1, 1):
            paradas = {}
            paradas['Pais'] = 'BR'
            paradas['Uf'] = getJSON('rot_uf' + str(i))
            paradas['Cidade'] = getJSON('rot_cidade' + str(i))
            paradas['Rua'] = None
            paradas['Numero'] = None
            paradas['Cep'] = None
            paradas['Latitude'] = None
            paradas['Longitude'] = None
            paradas['LevantarEixo'] = False
            paradasArray.append(paradas)

        paradas = {}
        paradas['Pais'] = 'BR'
        paradas['Uf'] = getJSON('rot_destino_uf')
        paradas['Cidade'] = getJSON('rot_destino_cidade')
        paradas['Rua'] = None
        paradas['Numero'] = None
        paradas['Cep'] = None
        paradas['Latitude'] = None
        paradas['Longitude'] = None
        paradas['LevantarEixo'] = False
        paradasArray.append(paradas)

        req['Paradas'] = paradasArray

        return json.dumps(req), ''
    except Exception as e:
        print('Erro em request requestCargobank_CriarRota')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)

def requestCargobank_ConsultaValorRota(reqJSON):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}
        req['RotaId'] = getJSON('rot_codext')
        req['DataHora'] = getJSON('rot_dataprevchegada').replace('.0', '')
        req['Saida'] = False
        if getJSON('rot_idavolta') == 'S':
            req['IdaVolta'] = True
        else:
            req['IdaVolta'] = False
        if getJSON('rot_quanteixos') != '':
           quanteixos = int(getJSON('rot_quanteixos'))
           catVeic =  getCategoriaVeic(quanteixos)
        req['VeiculoCategoria'] = catVeic
        req['VeiculoCategoriaEixoSuspenso'] = catVeic
        if getJSON('rot_evitarpedagio') == 'S':
            req['EvitarPedagio'] = True
        else:
            req['EvitarPedagio'] = False

        if getJSON('rot_evitarbalsa') == 'S':
            req['EvitarBalsa'] = True
        else:
            req['EvitarBalsa'] = False

        return json.dumps(req), ''
    except Exception as e:
        print('Erro em request requestCargobank_ConsultaValorRota')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def responseCargobank_ConsultaValorPedagio(resp):
    try:
        resp = resp.content.decode('utf-8')
        root = json.loads(resp)
        jsonResp = GetJson(root)
        getJSON = jsonResp.getJSON

        sucesso = getJSON('Sucesso')
        if sucesso:
            retorno = getJSON('Retorno')
            valorPedagio = retorno['ValorPedagioTag']
            consultaRotaID = retorno['ConsultaRotaId']
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><retorno><valorpedagio>'\
                   +str(valorPedagio)+'</valorpedagio> <consultarotaid>'+str(consultaRotaID)+'</consultarotaid>' \
                                                                                             '</retorno>', ''
        else:
            return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><retorno>' + str(
                    getJSON('Mensagem')) + '</retorno>'

    except Exception as e:
        print('Erro em request requestCargobank_ConsultaValorRota')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)

def requestCargobank_EmitirPedagio(reqJSON):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}
        req['ConsultaRotaId'] = getJSON('identificador_consulta')
        req['CpfCnpjEmbarcador'] = getJSON('filial_cnpj')
        req['ValidadeVP'] = getJSON('rot_dataprevchegada').replace('.0', '')
        req['ValorTotalVP'] = getJSON('valorpedagio')
        req['TipoVP'] = 1 # TAG / analisar rota GET /tiposVP
        req['PlacaVeiculo'] = getJSON('placa')

        if getJSON('quant_eixos') != '':
            quanteixos = int(getJSON('quant_eixos'))
            req['CategoriaVeiculo'] = getCategoriaVeic(quanteixos)

        return json.dumps(req), ''
    except Exception as e:
        print('Erro em request requestCargobank_ConsultaValorRota')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)

def requestCargobank_CancelarPedagio(reqJSON):
    return None, ''


def responseCargobank_CriarRota(resp):
    try:
        resp = resp.content.decode('utf-8')
        root = json.loads(resp)
        jsonResp = GetJson(root)
        getJSON = jsonResp.getJSON

        sucesso = getJSON('Sucesso')
        if sucesso:
            rota = getJSON('Rota')
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro> <retorno><rotadescricao>' + str(rota['Descricao']) + '</rotadescricao>' +\
                                                                             '<rotaidentificador>' + str(rota['Identificador']) + '</rotaidentificador></retorno>', ''

        else:
            return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><retorno>' + str(
                getJSON('Mensagem')) + '</retorno>'

    except Exception as e:
        print('Erro em request requestCargobank_ConsultaValorRota')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)




def responseCargobank_EmitirPedagio(resp):
    try:
        resp = resp.content.decode('utf-8')
        root = json.loads(resp)
        jsonResp = GetJson(root)
        getJSON = jsonResp.getJSON
        sucesso = getJSON('Sucesso')
        if sucesso:
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro> <retorno><valepedagio>' + \
                   str(getJSON('ValePedagio')) + '</valepedagio>' + \
                   '<mensagem>' + str(getJSON('Mensagem')) + '</mensagem></retorno>', ''

        else:
            return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><retorno>' + str(
                getJSON('Mensagem')) + '</retorno>'

    except Exception as e:
        print('Erro em request requestCargobank_ConsultaValorRota')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def responseCargobank_CancelarPedagio(resp):
    try:
        resp = resp.content.decode('utf-8')
        root = json.loads(resp)
        jsonResp = GetJson(root)
        getJSON = jsonResp.getJSON

        sucesso = getJSON('Sucesso')
        if sucesso:
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><retorno>' + str(
                getJSON('Mensagem')) + '</retorno>', ''
        else:
            return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><retorno>' + str(
                getJSON('Mensagem')) + '</retorno>'

    except Exception as e:
        print('Erro em request responseCargobank_CancelarPedagio')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def responseTratarErro500Cargobank(ret, arqreq, arqresp):
    try:
        root = json.loads(ret)
        jsonResp = GetJson(root)
        getJSON = jsonResp.getJSON


        return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><retorno>' + str(
            getJSON('Mensagem')) + '</retorno>', arqreq, arqresp

    except Exception as e:
        print('Erro em request responseTratarErro500Cargobank')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)






# mapeamento formado a partir do endpoint https://pedagio-hml.ciot.gratis/api/pedagio/categorias
def getCategoriaVeic(quant_eixos):

    if quant_eixos == 2:
        return 2
    elif quant_eixos == 3:
        return 4
    elif quant_eixos == 4:
        return 6
    elif quant_eixos == 5:
        return 7
    elif quant_eixos == 6:
        return 8
    elif quant_eixos == 7:
        return 10
    elif quant_eixos == 8:
        return 11
    elif quant_eixos == 9:
        return 12
    elif quant_eixos == 10:
        return 13
    else:  # acima de 10 eixos
        return 14



