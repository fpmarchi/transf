from json import dumps
from typing import Tuple

from requests import Response

from dispacher import ActionProcessor
from dispacher.decorators import handle_exception_factory, parse_props
from geral import datetime_from_iso
from geralxml import mount_xml_response


class MyTrackingException(Exception):
    pass


class MyTracking(ActionProcessor):
    HOST = 'https://app.mytracking.com.br'
    TEST_HOST = 'https://app.mytracking.com.br'
    BASE_PATH = '/myroute/service/dynamicjson1'

    # Actions
    CONSULT_DELIVERIES = 2300
    SEND_ORDERS = 2301

    def __init__(self):
        super().__init__()

        self.add_callable_records('url', {
            self.DEFAULT_FUNCTION: self.make_url_assembler()
        })

    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        props = context_req.get('props')
        token = props.get('token')

        return \
            {
                'Content-type': 'application/json',
                'token': token
            }, ''


#
#   Códigos independentes de instancia
#


# Tratamento de exceções
def _mytracking_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def _any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a MyTracking:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    MyTrackingException,
    _mytracking_exception_callback,
    _any_exception_callback
)

#
#   Instancia limpa e sem configuração
#
_mytracking = MyTracking()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = _mytracking.link_to_factory('request')
_link_to_response = _mytracking.link_to_factory('response')


@_link_to_request(_mytracking.CONSULT_DELIVERIES)
def _out_consult_deliveries(req: dict) -> Tuple[str, str]:
    ultima_busca = datetime_from_iso(req.get('data_ult_busca'))
    req_body = {
        'busca': [
            {
                'ultimaBusca': ultima_busca.strftime('%d/%m/%Y %H:%M') if ultima_busca else None
            }
        ]
    }

    return dumps(req_body), ''


@_link_to_request(_mytracking.SEND_ORDERS)
def _out_send_orders(req: dict) -> Tuple[str, str]:
    travel_list = req.get('entregas', [])

    orders = [{
        # - Main
        'cnpjCd': travel.get('cnpj_cd', ''),
        'numeroRemessa': travel.get('numero_remessa', ''),
        'tipoOpe': '2' if travel.get('tipo_ope', False) is True else '1',
        'tipoOper': '2' if travel.get('tipo_oper', False) is True else '1',
        # - CTe
        'serieCte': travel.get('serie_cte', ''),
        'numeroCte': travel.get('numero_cte', ''),
        'dataCte': _format_date_from_iso(travel.get('data_cte', '')),
        'chaveCte': travel.get('chave_cte', ''),
        'valorCte': travel.get('valor_cte', ''),
        # - NFe
        'serieNfe': travel.get('serie_nfe', ''),
        'numeroNfe': travel.get('numero_nfe', ''),
        'dataNfe': _format_date_from_iso(travel.get('data_nfe', '')),
        'chaveNfe': travel.get('chave_nfe', ''),
        'valorNfe': travel.get('valor_nfe', ''),
        'identificadorNfe': travel.get('identificador_nfe', ''),
        # - NFSe
        'numeroNfse': travel.get('serie_nfse', ''),
        'serieNfse': travel.get('numero_nfse', ''),
        'dataNfse': _format_date_from_iso(travel.get('data_nfse', '')),
        'chaveNfse': travel.get('chave_nfse', ''),
        'valorNfse': travel.get('valor_nfse', ''),
        # - Order
        'numeroPedido': travel.get('numero_pedido', ''),
        'dataPedido': _format_date_from_iso(travel.get('data_pedido', '')),
        'valorPedido': travel.get('valor_pedido', ''),
        'grauRisco': '1',
        # - Route
        'rota': travel.get('rota', ''),
        'agrupadorRota': travel.get('cod_rota', ''),
        #'subRota': travel.get('', ''),
        # 'seqRota': travel.get('', ''),
        # - MDFe
        'numeroManifesto': travel.get('numero_manif', ''),
        # - Recipient
        'chaveDes': travel.get('chave_des', ''),
        'cnpjCpfDes': travel.get('cnpj_cpf_des', ''),
        'nomeDes': travel.get('nome_des', ''),
        'endDes': travel.get('end_des', ''),
        'numDes': travel.get('num_des', ''),
        'baiDes': travel.get('bai_des', ''),
        'cidDes': travel.get('cid_des', ''),
        'ufDes': travel.get('uf_des', ''),
        'cplDes': travel.get('complemento_des', ''),
        'cepDes': travel.get('cep_des', ''),
        # - Sender
        'cnpjCpfEmitente': travel.get('cnpj_cpf_emit', ''),
        'nomeEmitente': travel.get('nome_emit', ''),
        'inscEstadualEmitente': travel.get('insc_est_emit', ''),
        'endEmitente': travel.get('end_emit', ''),
        'baiEmitente': travel.get('bairro_emit', ''),
        'cidEmitente': travel.get('cid_emit', ''),
        'ufEmitente': travel.get('uf_emit', ''),
        'numEmitente': travel.get('num_emit', ''),
        'cplEmitente': travel.get('complemento_emit', ''),
        'cepEmitente': travel.get('cep_emit', ''),
        # - Delivery
        'codBarras': travel.get('cod_barras', ''),
        'turnoEntrega': travel.get('turno_entrega', ''),
        'valorEntrega': travel.get('valor_entrega', ''),
        'pesoEntrega': travel.get('peso_entrega', ''),
        'qtdVolumes': travel.get('quantidade_volumes', ''),
        'dataPrvEntIni': _format_date_from_iso(travel.get('data_prev_entrega_ini', '')),
        'dataPrvEntFim': _format_date_from_iso(travel.get('data_prev_entrega_fim', '')),
        # - Shipping company
        'chaveTranspMatriz': travel.get('cod_emp', ''),
        'cnpjTransportadora': travel.get('cnpj_cd', ''),
        'nomeTransportadora': travel.get('nome_emp', ''),
        'inscEstadualTra': travel.get('insc_est_emp', ''),
        # - Driver
        'cpfMotorista': travel.get('cpf_mot', ''),
        'nomeMotorista': travel.get('nome_mot', ''),
        'foneMotorista': travel.get('fone_mot', ''),
        # - Vehicle
        'placaVeiculo': travel.get('placa_veic', ''),
        # - Others
        # 'numeroDt1': travel.get('', ''),
        'numeroDt2': travel.get('numero_dt', ''),
        # 'tipoNatura': '4',
        'codigoRevendedora': travel.get('cod_revendedora', '')
    } for travel in travel_list]

    req_body = {
        'entregas': orders
    }

    return dumps(req_body), ''


@_link_to_response(_mytracking.DEFAULT_FUNCTION)
def _in_send_orders(resp: Response) -> Tuple[str, str]:
    resp_json = resp.json()
    success = resp.status_code in [200]

    resp_body = {
        'sucesso': success,
    }

    deliveries = resp_json.get('entregas', [])

    msg_error = ''
    if len(deliveries) == 1 and 'mesnagem_erro' in deliveries[0]:
        msg_error = deliveries[0].get('mesnagem_erro')
        success = False

    if success:
        resp_body['conteudo'] = {
            'entregas': [x for x in deliveries if x.get('cnpjCpfDes')]
        }
    elif msg_error:
        resp_body['sucesso'] = False
        resp_body['msg_erro'] = msg_error
    elif 'mensagem' in resp_json:
        resp_body['sucesso'] = False
        resp_body['msg_erro'] = resp_json.get('mensagem')
    else:
        raise MyTrackingException('Não foi possível compreender o retorna da MyTracking')

    return mount_xml_response(resp_body), ''


def _format_date_from_iso(date_: str):
    datetime_ = datetime_from_iso(date_)
    try:
        return datetime_.strftime('%d/%m/%Y %H:%M')
    except (Exception,):
        return ''

