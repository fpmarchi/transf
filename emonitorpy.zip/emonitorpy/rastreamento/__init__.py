from mytracking import MyTracking
from uberlog import Uberlog

mytracking = MyTracking.get_instance(min_action=2300, max_action=2349)
uberlog = Uberlog.get_instance(min_action=4250, max_action=4299)
