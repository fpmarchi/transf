import json
from urllib.parse import urlunparse, urlparse

from requests import post, Response

from ActionProcessor import ActionProcessor, Callable_cfg, parse_props, handle_exception_factory
from geral import *
from geraljson import *
from geralxml import mount_xml_response


def busca_ultima_posicao():
    return '', ''


@handle_exception_factory()
def response_ultima_posicoes(resp: Response):
    try:

        if resp.status_code != 200:
            return '', 'Não foi possível obter um retorno bem sucedido da Tracker'

        res: dict
        try:
            res = resp.json()
        except (Exception,):
            res = {}

        if res.get('status', '') != 'OK':
            return '', 'Não foi possível obter as posições da Tracker'

        data_itens = []
        for arrayObj in res.get('object', []):
            data = {'placa': arrayObj['placa']}
            dispositivosArray = arrayObj.get('dispositivos', [])
            for dispositivos in dispositivosArray:
                posicoesArray = dispositivos['posicoes']
                for posicoes in posicoesArray:
                    data['idposicao'] = int(posicoes['id'])
                    data['latitude'] = posicoes['latitude']
                    data['longitude'] = posicoes['longitude']
                    data['velocidade'] = posicoes['velocidade']
                    data['local'] = posicoes['endereco']
                    data['data'] = unix_date_to_date(posicoes['dataProcessamento'])
                    data_itens.append(data)
        return mount_xml_response(data_itens), ''
    except Exception as e:
        print('Erro ao tratar resposta da tracker')
        print(e)
        return '', 'ERRO AO TRATAR ENVIO PARA OPERADORA DE CARTÃO (Erro ao tratar resposta da tracker) ' + str(e)


def request_login(context_req: dict) -> dict:
    try:
        props = context_req.get('props', {})

        data = {
            'username': props.get('usuario', ''),
            'password': props.get('senha', ''),
            'appid': '168',
            'token': 'null',
            'expiration': ''
        }
        return data
    except Exception as e:
        print('Erro ao criar request de login na tracker')
        print(e)
        return {}


class Tracker(ActionProcessor):
    MIN_ACTION = 2250
    MAX_ACTION = 2299
    ACAO_TRACKER_BUSCAULTIMAPOSICAO = 2250

    __token_cache = {}

    def __init__(self):
        request_builders: Callable_cfg = {
            self.ACAO_TRACKER_BUSCAULTIMAPOSICAO: busca_ultima_posicao,
        }

        response_parsers: Callable_cfg = {
            self.ACAO_TRACKER_BUSCAULTIMAPOSICAO: response_ultima_posicoes,
        }
        super().__init__(request_builders, response_parsers)

    @parse_props
    def get_token(self, context_req: dict) -> str:

        props = context_req.get('props', {})
        usuario = props.get('usuario', '')
        senha = props.get('senha', '')
        url = context_req.get('url', '')

        if not usuario or not senha:
            raise Exception('O usuário ou senha não foram informados.')

        data = request_login(context_req)

        parsed_uri = list(urlparse(url.strip()))
        parsed_uri[2] = '/seguranca/logon'

        h = {'Content-Type': 'application/json'}

        resp = post(urlunparse(parsed_uri), json=data, headers=h)

        if resp.status_code == 200 or resp.status_code == 201:
            ret = resp.content.decode('utf-8')
            root = json.loads(ret)
            obj = getJSON(root, 'object')
            token = obj['token']

            self.__token_cache[usuario] = (token, time.time())
            return token
        elif resp.status_code == 401:
            raise Exception('401 - Usuário ou Senha inválidos')
        elif resp.status_code == 503:
            # a Tracker reseta o sistema deles nos horarios 03:00 / 04:00  /10:00 /23:00
            raise Exception('503 - Sistema parceiro indisponivel, aguarde 1 minuto e tente novamente')
        else:
            raise Exception('Não foi possível realizar a autenticação na Tracker.')

    def get_headers(self, dict_with_props: dict):
        try:
            token = self.get_token(dict_with_props)
            headers = {
                'token': token,
                'Content-Type': 'application/json'
            }

            return headers, ''
        except Exception as e:
            return '', 'Erro ao processar solicitação.\nDetalhes: ' + str(e)


tracker = Tracker()
