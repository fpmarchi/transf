import requests
import xmltodict
from collections import OrderedDict
from geralxml import *

MIN_ACTION = 50050
MAX_ACTION = 50099
ACAO_MULTISOFTWARE_OBTERCTES = 50051
ACAO_MULTISOFTWARE_OBTERMDFES = 50052


def requestObterCTes(nomeReduzEmpresa, requestJSON):
    try:
        url = requestJSON['url']
        #
        headers = {'Content-type': 'text/xml; charset=utf-8','SOAPAction': 'http://tempuri.org/ICTe/ObterProtocolos'}
        #
        req = \
            '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">' + \
               '<soapenv:Header/>' + \
               '<soapenv:Body>' + \
                  '<tem:ObterProtocolos>' + \
                     '<tem:cnpj>' + requestJSON['cnpjcpf'] + '</tem:cnpj>' + \
                     '<tem:token>' + requestJSON['token'] + '</tem:token>' + \
                     '<tem:dataInicial>' + requestJSON['dataini'] + '</tem:dataInicial>' + \
                     '<tem:dataFinal>' + requestJSON['datafim'] + '</tem:dataFinal>' + \
                  '</tem:ObterProtocolos>' + \
               '</soapenv:Body>' + \
            '</soapenv:Envelope>'
        #
        resp = requests.post(url, data=req, headers=headers)
        retcode = resp.status_code
        ret = resp.content.decode('utf-8')
        if retcode == 200:
            document = xmltodict.parse(ret)
            result = document.get('s:Envelope').get('s:Body').get('ObterProtocolosResponse').get('ObterProtocolosResult')
            status = result.get('a:Status')
            if status == 'false':
                mensagem = result.get('a:Mensagem')
                return '', '', '', '', 'ERRO ao tentar obter protocolos: ' + mensagem
            objeto = result.get('a:Objeto')
            bint = objeto.get('b:int')
            strProtocolos = ''
            if isinstance(bint, list):
                for value in bint:
                    strProtocolos += '<arr:int>' + value + '</arr:int>'
            else:
                strProtocolos += '<arr:int>' + bint + '</arr:int>'
            headers = {'Content-type': 'text/xml; charset=utf-8', 'SOAPAction': 'http://tempuri.org/ICTe/ObterXML'}
            req = \
                '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/" xmlns:arr="http://schemas.microsoft.com/2003/10/Serialization/Arrays">' + \
                    '<soapenv:Header/>' + \
                    '<soapenv:Body>' + \
                        '<tem:ObterXML>' + \
                            '<tem:cnpj>' + requestJSON['cnpjcpf'] + '</tem:cnpj>' + \
                            '<tem:token>' + requestJSON['token'] + '</tem:token>' + \
                            '<tem:protocolos>' + strProtocolos + '</tem:protocolos>' + \
                        '</tem:ObterXML>' + \
                    '</soapenv:Body>' + \
                '</soapenv:Envelope>'
            # resp = requests.post(url, data=req, headers=headers)
            # retcode = resp.status_code
            # ret = resp.content.decode('utf-8')
            # resp, erros = responseObterCTes(ret, retcode)
            # print(resp)
            # print(erros)
            return url, headers, req, [], ''
        else:
            print(resp.content.decode('utf-8'))
            return headers, 'ERRO INTERNO DE OBTER PROTOCOLOS DE CTES (' + str(retcode) + '- '+ret+ ')'
        #
    except Exception as e:
        print('Erro Interno em obterCTes')
        print(e)
        return '', '', '', '', 'ERRO INTERNO em obterCTes'


def requestObterMDFes(nomeReduzEmpresa, requestJSON):
    try:
        url = requestJSON['url']
        #
        headers = {'Content-type': 'text/xml; charset=utf-8','SOAPAction': 'http://tempuri.org/IMDFe/ObterProtocolos'}
        #
        req = \
            '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">' + \
               '<soapenv:Header/>' + \
               '<soapenv:Body>' + \
                  '<tem:ObterProtocolos>' + \
                     '<tem:cnpj>' + requestJSON['cnpjcpf'] + '</tem:cnpj>' + \
                     '<tem:token>' + requestJSON['token'] + '</tem:token>' + \
                     '<tem:dataInicial>' + requestJSON['dataini'] + '</tem:dataInicial>' + \
                     '<tem:dataFinal>' + requestJSON['datafim'] + '</tem:dataFinal>' + \
                  '</tem:ObterProtocolos>' + \
               '</soapenv:Body>' + \
            '</soapenv:Envelope>'
        #
        resp = requests.post(url, data=req, headers=headers)
        retcode = resp.status_code
        ret = resp.content.decode('utf-8')
        if retcode == 200:
            document = xmltodict.parse(ret)
            result = document.get('s:Envelope').get('s:Body').get('ObterProtocolosResponse').get('ObterProtocolosResult')
            status = result.get('a:Status')
            if status == 'false':
                mensagem = result.get('a:Mensagem')
                return '', '', '', '', 'ERRO ao tentar obter protocolos: ' + mensagem
            objeto = result.get('a:Objeto')
            bint = objeto.get('b:int')
            strProtocolos = ''
            if isinstance(bint, list):
                for value in bint:
                    strProtocolos += '<arr:int>' + value + '</arr:int>'
            else:
                strProtocolos += '<arr:int>' + bint + '</arr:int>'
            headers = {'Content-type': 'text/xml; charset=utf-8', 'SOAPAction': 'http://tempuri.org/IMDFe/ObterXML'}
            req = \
                '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/" xmlns:arr="http://schemas.microsoft.com/2003/10/Serialization/Arrays">' + \
                    '<soapenv:Header/>' + \
                    '<soapenv:Body>' + \
                        '<tem:ObterXML>' + \
                            '<tem:cnpj>' + requestJSON['cnpjcpf'] + '</tem:cnpj>' + \
                            '<tem:token>' + requestJSON['token'] + '</tem:token>' + \
                            '<tem:protocolos>' + strProtocolos + '</tem:protocolos>' + \
                        '</tem:ObterXML>' + \
                    '</soapenv:Body>' + \
                '</soapenv:Envelope>'
            # resp = requests.post(url, data=req, headers=headers)
            # retcode = resp.status_code
            # ret = resp.content.decode('utf-8')
            # resp, erros = responseObterMDFes(ret, retcode)
            # print(resp)
            # print(erros)
            return url, headers, req, [], ''
        else:
            print(resp.content.decode('utf-8'))
            return headers, 'ERRO INTERNO DE OBTER PROTOCOLOS DE MDFES (' + str(retcode) + '- '+ret+ ')'
        #
    except Exception as e:
        print('Erro Interno em obterMDFes')
        print(e)
        return '', '', '', '', 'ERRO INTERNO em obterMDFes'


def responseObterCTes(ret, retcode):
    try:
        document = xmltodict.parse(ret)
        result = document.get('s:Envelope').get('s:Body').get('ObterXMLResponse').get('ObterXMLResult')
        status = result.get('a:Status')
        if status == 'false':
            mensagem = result.get('a:Mensagem')
            return '', 'ERRO ao tentar obter XMLs: ' + mensagem
        objeto = result.get('a:Objeto')
        msgRet = ''
        for key, value in objeto.items():
            if key == 'a:RetornoConsultaXML':
                for item in value:
                    tipoXML = item.get('a:TipoXML')
                    chave = item.get('a:Chave')
                    xml = item.get('a:XML')
                    if tipoXML == 'Autorizacao':
                        msgRet += '<resp><tipo>A</tipo><chave>' + chave + '</chave><xml>' + xml + '</xml></resp>'
                    elif tipoXML == 'Cancelamento':
                        msgRet += '<resp><tipo>C</tipo><chave>' + chave + '</chave><xml>' + xml + '</xml></resp>'
        return msgRet, ''
    except Exception as e:
        print('Erro Interno em responseObterCTes')
        print(e)
        return '', 'ERRO INTERNO em responseObterCTes'


def responseObterMDFes(ret, retcode):
    try:
        document = xmltodict.parse(ret)
        result = document.get('s:Envelope').get('s:Body').get('ObterXMLResponse').get('ObterXMLResult')
        status = result.get('a:Status')
        if status == 'false':
            mensagem = result.get('a:Mensagem')
            return '', 'ERRO ao tentar obter XMLs: ' + mensagem
        objeto = result.get('a:Objeto')
        msgRet = ''
        for key, value in objeto.items():
            if key == 'a:RetornoConsultaXML':
                for item in value:
                    tipoXML = item.get('a:TipoXML')
                    chave = item.get('a:Chave')
                    xml = item.get('a:XML')
                    if tipoXML == 'Autorizacao':
                        msgRet += '<resp><tipo>A</tipo><chave>' + chave + '</chave><xml>' + xml + '</xml></resp>'
                    elif tipoXML == 'Cancelamento':
                        msgRet += '<resp><tipo>C</tipo><chave>' + chave + '</chave><xml>' + xml + '</xml></resp>'
                    elif tipoXML == 'Encerramento':
                        msgRet += '<resp><tipo>E</tipo><chave>' + chave + '</chave><xml>' + xml + '</xml></resp>'
        return msgRet, ''
    except Exception as e:
        print('Erro Interno em responseObterMDFes')
        print(e)
        return '', 'ERRO INTERNO em responseObterMDFes'
