

# Centraliza a definição dos intervalos e isola as funções internas.
from sieg import Sieg

sieg = Sieg.get_instance(min_action=50150, max_action=50199)


