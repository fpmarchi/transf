import json
import logging
from typing import Tuple

from ActionProcessor import ActionProcessor, Callable_cfg


def _build_consult_export(req: dict) -> Tuple[dict, str]:
    try:

        parsed_request: dict = {
            'protocolo': req.get('protocolo', ''),
        }

        return parsed_request, ''
    except Exception as e:
        logging.warning('TecnoSpeed |> Erro ao criar requisição para consulta de exportação: ')
        print(e)
        return {}, 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def _build_request_export(req: dict) -> Tuple[dict, str]:
    try:
        parsed_request: dict = {
            'initial_period': req.get('data_ini', '').replace("/", "-"),
            'final_period': req.get('data_fim', '').replace("/", "-"),
            'document_model': req.get('tipo_doc', ''),
            'environment': req.get('ambiente', '2'),  # 1 - Produção; 2 - Homologação
            'transaction': req.get('tp_transacao', '')
        }

        return parsed_request, ''
    except Exception as e:
        logging.warning('TecnoSpeed |> Erro ao criar requisição de exportação: ')
        print(e)
        return {}, 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def _parse_tecnospeed_resp(resp: str) -> Tuple[dict, str]:
    try:
        resp = json.loads(resp)

        if resp.get('error', False):
            return {}, resp.get('message', '')

        parsed_resp = {
            'protocolo': resp.get('protocol', '')
        }

        if 'XMLS' in resp:
            parsed_resp['XMLS'] = resp.get('XMLS', '')

        parsed_resp['base'] = resp

        return parsed_resp, ''
    except Exception as e:
        logging.warning('TecnoSpeed |> Erro ao criar requisição de exportação: ')
        print(e)
        return {}, 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


class TecnoSpeed(ActionProcessor):
    MIN_ACTION = 50100
    MAX_ACTION = 50149
    REQUEST_EXPORT = 50101  # ACAO_TECNOSPEED_SOLICITAR_EXP
    CONSULT_EXPORT = 50102  # ACAO_TECNOSPEED_CONSULTAR_EXP

    def __init__(self):
        request_builders: Callable_cfg = {
            self.REQUEST_EXPORT: _build_request_export,
            self.CONSULT_EXPORT: _build_consult_export
        }

        response_parsers: Callable_cfg = {
            self.DEFAULT_FUNCTION: _parse_tecnospeed_resp
        }

        super().__init__(request_builders, response_parsers)

    def build_request(self, context_req: dict, action_cod: int) -> Tuple[str, dict, str, dict, str]:
        (req, errors) = super().build_request(context_req, action_cod)

        props = context_req.get('props', {})
        headers = {'Authorization': 'Basic ' + props.get('login', '')}

        url = context_req.get('url', '') + '?token=' + props.get('token', '')

        return url, headers, req, {}, errors


tecno_speed = TecnoSpeed()
