import json
from geral import getMimeType, extractNameFromFilename

ACAO_TINS_REGISTRARDOCUMENTO = 50001
ACAO_TINS_ANEXARDOCUMENTO = 50002

def requestTinsRegistrarDocumento(nomeReduzEmpresa, requestJSON):
    try:
        url = requestJSON['url'] + 'documentos/registroDocumento/'
        #
        headers = {}
        #headers['Content-type'] = 'multipart/form-data'
        headers['Authorization'] = 'Token ' + requestJSON['token']
        #
        req = {}
        req['contrato'] = requestJSON['contrato']
        req['ged_ua'] = requestJSON['codunidarmaz']
        req['tipo_documental'] = requestJSON['tipodocarmaz']
        req['operador'] = requestJSON['operador']
        req['criado_em'] = requestJSON['datains']
        req['descricao'] = requestJSON['descricao']
        req['autor'] = requestJSON['usuarioins']
        req['local'] = requestJSON['local']
        req['legivel'] = '1'
        req['observacoes'] = ''
        req['cpf_cnpj'] = ''
        req['ocorrencias'] = ''
        req['assinar'] = '1'
        req['ocr'] = '1'
        #
        anexo = requestJSON['anexo']
        mime = getMimeType(anexo)
        files = [
            ('anexo', (extractNameFromFilename(anexo), open(anexo, 'rb'), mime))
        ]
        #
        return url, headers, req, files, ''
        #
    except Exception as e:
        print('Erro Interno em requestTinsRegistrarDocumento')
        print(e)
        return '', '', '', '', 'ERRO INTERNO em requestTinsRegistrarDocumento'


def responseTinsRegistrarDocumento(ret, retcode):
    try:
        respJSON = json.loads(ret)
        if retcode == 400:
            # PENDENTE FUTURAMENTE TRATAR MELHOR OS ERROS
            return '', str(respJSON['parametros']) + ' - ' + str(respJSON['mensagem'])
        else: # 200
            return str(respJSON['codigo_documento']), ''
    except Exception as e:
        print('Erro Interno em responseTinsRegistrarDocumento')
        print(e)
        return '', 'ERRO INTERNO em responseTinsRegistrarDocumento'

