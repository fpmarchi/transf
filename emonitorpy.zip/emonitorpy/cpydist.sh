#!/bin/bash

clear
echo 'NÃO SE ESQUEÇA DE DEFINIR isDebug = False NO main.py'
echo 'PRESSIONE ENTER...'
read

#cd /sistemas/emonitorpy

rm -rf cfg log tmp
zip -r emonitorpy.zip * -x venv/\*

echo 'Enviando zip para o EM1:'
echo "\$ emonitorpy" | ftp 10.75.2.5

echo 'Enviando zip para o EM2:'
echo "\$ emonitorpy" | ftp 10.75.1.86

echo 'Enviando zip para o EMP:'
echo "\$ emonitorpy" | ftp emonitorp.intersite.com.br

if [[ "$USER" == "edilmar" ]]; then
  scp -P 22022 emonitorpy.zip edilmar@10.75.2.111:
  scp -P 22022 emonitorpy.zip edilmar@10.75.2.197:
  scp -P 22022 emonitorpy.zip edilmar@10.75.2.30:
  scp -P 22022 emonitorpy.zip edilmar@10.75.2.50:
fi

rm -f emonitorpy.zip
mkdir log tmp
