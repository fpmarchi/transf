import geralsockets

# client
gs = geralsockets.Socket()
port = 60266 # pegar a porta acima e mudar aqui
gs.send('Envio de Msg para Servidor', port)
exit(0)
