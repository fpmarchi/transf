def createelem(elem, value):
    return createelem2(elem, value, ',')


def createelem2(elem, value, sufixtag):
    return '"' + elem + '": "' + value + '"' + sufixtag


def createelemnum(elem, value):
    return createelemnum2(elem, value, ',')


def createelemnum2(elem, value, sufixtag):
    return '"' + elem + '": ' + value + sufixtag


def createelemtree(elem):
    return '"' + elem + '": '


def getJSON(reqJSON, fieldname):
    ret = reqJSON.get(fieldname)
    if ret is None:
        return ''
    else:
        return ret




