import sys
import os
import csv
import shutil
import socket
import requests
from sqlalchemy.sql import *
from datetime import date, datetime, timedelta


from metadata import getEnginePGLight, getEnginePGLightInterno, getConnPG
import dao
import geral
import geralsis
import mail


# https://towardsdatascience.com/10-python-file-system-methods-you-should-know-799f90ef13c2


def __getListDirsInstEmp():
    ret = []
    listDirInst = os.listdir(geralsis.inst_path)
    for dirInst in listDirInst:
        try:
            inst = int(dirInst)
        except:
            inst = 0
        if inst > 0 and inst != 376 and inst < 100000:
            listDirEmp = os.listdir(geralsis.inst_path + str(inst) + '/')
            for dirEmp in listDirEmp:
                try:
                    emp = int(dirEmp)
                except:
                    emp = 0
                if emp > 0:
                    ret.append(geralsis.inst_path + str(inst) + '/' + str(emp) + '/')
    if ret != None:
        ret.sort()
    return ret


def __clearOldFolders():
    listDirInstEmp = __getListDirsInstEmp()
    for dirInstEmp in listDirInstEmp:
        listSub = os.listdir(dirInstEmp)
        for sub in listSub:
            if sub != 'cert':
                remSub = dirInstEmp + sub
                print('Removendo ' + remSub + '... ')
                if geral.fileexists(remSub):
                    os.remove(remSub)
                else:
                    shutil.rmtree(remSub)


def __checkCertSize():
    msgEMail = []
    listDirInstEmp = __getListDirsInstEmp()
    for dirInstEmp in listDirInstEmp:
        arqCert = dirInstEmp + 'cert/cert.pfx'
        if geral.fileexists(arqCert):
            sizeCert = os.path.getsize(arqCert)
            if sizeCert < 2048:
                msg = 'REMOCAO - MENOS DE 2K: ' + arqCert + ' = ' + str(sizeCert)
                print(msg)
                msgEMail.append(msg + '\n')
                os.remove(arqCert)
            elif sizeCert < 8192:
                msg = 'ALERTA - MENOS DE 8K: ' + arqCert + ' = ' + str(sizeCert)
                print(msg)
                msgEMail.append(msg + '\n')
        else:
            msg = 'ERRO: ' + arqCert + ' nao existe!'
            print(msg)
            msgEMail.append(msg + '\n')
    #
    if len(msgEMail) > 0:
        mail.send(
            dest_mail='servidor@intersite.com.br',
            #destMail='edilmaralves@intersite.com.br',
            title='CHECAGEM DE TAMANHO DE CERTIFICADOS - SERVIDOR ' + socket.gethostname(),
            message=str(''.join(msgEMail))
        )


# 1x/dia via cron comparar os certificados dos emonitors 2/P com o emonitor 1 e enviar um alerta
def __checkCertAll():
    msgEMail = []
    listDirInstEmp = __getListDirsInstEmp()
    engineEMonitor = getEnginePGLight(geralsis.prop, 'EMonitor')
    with getConnPG(engineEMonitor) as connPG: # IMPORTANTE: tem que rodar em ate 5 minutos devido a property maxCheckoutConnPool
        for dirInstEmp in listDirInstEmp:
            paths = dirInstEmp.split('/')
            inst = paths[4]
            emp = paths[5]
            arqCert = dirInstEmp + 'cert/cert.pfx'
            #
            if geral.fileexists(arqCert):
                sizeCert = os.path.getsize(arqCert)
            else:
                sizeCert = -1
            if sizeCert == -1:
                msg = 'ALERTA - EM1 ' + arqCert + ' NAO EXISTE'
                print(msg)
                msgEMail.append(msg + '\n')
                continue
            #
            try:
                pfx_path, pfx_password = geralsis.getCertProperties(connPG, inst, emp, 0)
                expirationCert = str(geral.pfx_expiration_date(pfx_path, pfx_password))
            except Exception as e:
                print(e)
                msg = 'ALERTA - EM1 ' + arqCert + ' COM SENHA INVALIDA'
                print(msg)
                msgEMail.append(msg + '\n')
                continue
            #
            response = list(requests.get('http://emonitor2.intersite.com.br:5000/getSizeCert?inst=' + inst + '&emp=' + emp).content.decode().split(','))
            sizeCertEM2 = int(response[0])
            expirationCertEM2 = response[1]
            response = list(requests.get('http://emonitorp.intersite.com.br:5000/getSizeCert?inst=' + inst + '&emp=' + emp).content.decode().split(','))
            sizeCertEMP = int(response[0])
            expirationCertEMP = response[1]
            #
            if sizeCert != sizeCertEM2 or expirationCert != expirationCertEM2:
                if sizeCertEM2 == -1:
                    msg = 'ALERTA - EM1 ' + arqCert + ' = ' + str(sizeCert) + ' [' + expirationCert + '] => EM2 NAO EXISTE'
                elif expirationCertEM2 == '-1':
                    msg = 'ALERTA - EM1 ' + arqCert + ' = ' + str(sizeCert) + ' [' + expirationCert + '] => EM2 TEM CERTIFICADO MAS NAO FOI POSSIVEL OBTER A VALIDADE'
                else:
                    msg = 'ALERTA - EM1 ' + arqCert + ' = ' + str(sizeCert) + ' [' + expirationCert + '] => EM2 = ' + str(sizeCertEM2) + ' [' + expirationCertEM2 + ']'
                print(msg)
                msgEMail.append(msg + '\n')
            #
            if sizeCert != sizeCertEMP or expirationCert != expirationCertEMP:
                if sizeCertEMP == -1:
                    msg = 'ALERTA - EM1 ' + arqCert + ' = ' + str(sizeCert) + ' [' + expirationCert + '] => EMP NAO EXISTE'
                elif expirationCertEMP == '-1':
                    msg = 'ALERTA - EM1 ' + arqCert + ' = ' + str(sizeCert) + ' [' + expirationCert + '] => EMP TEM CERTIFICADO MAS NAO FOI POSSIVEL OBTER A VALIDADE'
                else:
                    msg = 'ALERTA - EM1 ' + arqCert + ' = ' + str(sizeCert) + ' [' + expirationCert + '] => EMP = ' + str(sizeCertEMP) + ' [' + expirationCertEMP + ']'
                print(msg)
                msgEMail.append(msg + '\n')
    #
    if len(msgEMail) > 0:
        mail.send(
            dest_mail='servidor@intersite.com.br',
            #destMail='edilmaralves@intersite.com.br',
            title='CHECAGEM DE CERTIFICADOS DO EM1 COM EM2 E O EMP',
            message=str(''.join(msgEMail))
        )
    else:
        mail.send(
            dest_mail='servidor@intersite.com.br',
            #destMail='edilmaralves@intersite.com.br',
            title='CHECAGEM DE CERTIFICADOS DO EM1 COM EM2 E O EMP',
            message='NENHUM CERTIFICADO ENCONTRADO COM DIFERENCA DE TAMANHO OU DE VALIDADE'
        )


# 1x/mes via cron desinstalar inst/emp que nao estiver ativa no WEBSAF
def __uninstallInstEmp(full_uninstall):
    listInstEmp = ['376_1']
    listUnInstEmp = []
    msgEMail = []
    listDirInstEmp = __getListDirsInstEmp()
    websaf_url = 'http://websaf.intersite.com.br:8082/emonitorws/webresources/ws'

    engineEMonitor = getEnginePGLight(geralsis.prop, 'EMonitor')
    with getConnPG(engineEMonitor) as connPG: # IMPORTANTE: tem que rodar em ate 5 minutos devido a property maxCheckoutConnPool
        for dirInstEmp in listDirInstEmp:
            paths = dirInstEmp.split('/')
            inst = paths[4]
            emp = paths[5]

            try:
                print(f'--- Checando instalacao {inst} no WEBSAF ...')
                response = requests.get(f'{websaf_url}/hasInst/{inst}').content.decode()
                uninstall = False

                if response == 'N':
                    uninstall = True
                else:
                    print(f'--- Checando instalacao_empresa {inst}_{emp} no WEBSAF ...')
                    response = requests.get(f'{websaf_url}/hasInstEmp/{inst}/{emp}').content.decode()
                    if response == 'N':
                        uninstall = True

                if uninstall:
                    listUnInstEmp.append(paths)
                else:
                    listInstEmp.append(f'{inst}_{emp}')
            except Exception as e:
                msg = f'Erro ao analisar para desinstalacao {inst}_{emp}\n'
                print(f'{msg}{e}')
                msgEMail.append(msg)
                listInstEmp.append(f'{inst}_{emp}')  # nao desinstalar se nao conseguir checar no WEBSAF

    # desinstalar
    uninstall = True
    if len(listUnInstEmp) > 0:
        for paths in listUnInstEmp:
            inst = paths[4]
            emp = paths[5]

            nome_reduzido = requests.get(f'{websaf_url}/getNomeReduzByCodInstalacao/{inst}').content.decode()
            data_fim_contrato = requests.get(f'{websaf_url}/getDataFimContrato/{nome_reduzido}').content.decode()
            dias_expirado = None

            if not data_fim_contrato:
                data_fim_contrato = 'SEM INFO DATA FIM CONTRATO'
            else:
                alerta_desinstalar = ''
                if data_fim_contrato != 'ATIVO':
                    dt_fim_contrato = geral.defstrtodate(data_fim_contrato)
                    data_atual = date.today()
                    dias_expirado = (data_atual - dt_fim_contrato).days

                    if dias_expirado > 90:
                        alerta_desinstalar = f' - ALERTA: DESINSTALAR DO EM, DESATIVADO HA {dias_expirado} DIAS!'
                    elif dias_expirado > 0:
                        alerta_desinstalar = f' - DESATIVADO HA {dias_expirado} DIAS!'

                data_fim_contrato = f'DATA FIM CONTRATO: {data_fim_contrato}{alerta_desinstalar}'

            try:
                if full_uninstall == 'N':
                    msg = f'Analisar desinstalacao de {inst}_{emp}'
                    if data_fim_contrato:
                        msg += f' - {data_fim_contrato}'
                    print(msg)
                    msgEMail.append(msg + '\n')
                elif full_uninstall == 'S' or (full_uninstall == 'P' and dias_expirado > 90):
                    remSub = f'{geralsis.inst_path}{inst}/{emp}'
                    arqCert = f'{remSub}/cert/cert.pfx'

                    if geral.fileexists(arqCert):
                        shutil.copyfile(arqCert, f'{geralsis.inst_path}old/cert_{inst}_{emp}.pfx')
                    # remover pasta da inst/emp
                    if uninstall:
                        shutil.rmtree(remSub)
                    # remover pasta da inst se nao tiver outra emp
                    remSub = geralsis.inst_path + inst
                    listSub = os.listdir(remSub)
                    if uninstall and len(listSub) == 0:
                        shutil.rmtree(remSub)
                    # remover do bd PG instemp/instempfil
                    if uninstall and connPG:
                        dao.uninstallInstEmp(connPG, inst, emp)
                        dao.uninstallInstEmpFilAll(connPG, inst, emp)

                    msg = f'Desinstalacao de {inst}_{emp}'
                    if data_fim_contrato:
                        msg += f' - {data_fim_contrato}'
                    print(msg)
                    msgEMail.append(msg + '\n')
            except Exception as e:
                msg = f'Erro ao desinstalar {inst}_{emp}\n'
                print(f'{msg}{e}')
                msgEMail.append(msg)

    hostname_servidor = f'- SERVIDOR {socket.gethostname()}'
    if full_uninstall == 'N':
        title = f'ANALISAR DESINSTALACAO DE CLIENTES {hostname_servidor}'
    elif full_uninstall == 'S':
        title = f'DESINSTALACAO COMPLETA DE CLIENTES {hostname_servidor}'
    elif full_uninstall == 'P':
        title = f'DESINSTALACAO DE CLIENTES INATIVOS A MAIS DE 90 DIAS {hostname_servidor}'
    else:
        title = f'Executando __uninstallInstEmp(\'{full_uninstall}\') {hostname_servidor}'

    if len(msgEMail) > 0:
        mail.send(
            dest_mail='servidor@intersite.com.br',
            title=title,
            message=str(''.join(msgEMail))
        )


def __checkNfeDistConsIndev():
    ontem = geral.datetostr(geral.incdatetimeactual(-1))
    dataIni = ontem + ' 00:00:00'
    dataFim = ontem + ' 23:59:59'
    #
    engineEMonitor = getEnginePGLight(geralsis.prop, 'EMonitor')
    with getConnPG(engineEMonitor) as connPG: # IMPORTANTE: tem que rodar em ate 5 minutos devido a property maxCheckoutConnPool
        sql = text('SELECT codinstalacao, codempresa, cnpjinut, anoinut, COUNT(codemonitorspool) ct '
                   'FROM emonitorspool '
                   'WHERE datains BETWEEN :dataIni AND :dataFim '
                   'AND codemonitoracao = 11 '
                   'AND status IN (4,6) '
                   'AND msgret LIKE \'Consumo Indevido%\' '
                   'GROUP BY codinstalacao, codempresa, cnpjinut, anoinut '
                   'HAVING COUNT(codemonitorspool) > 3 '
                   'ORDER BY codinstalacao, codempresa, cnpjinut, anoinut')
        sql = sql.bindparams(dataIni=geral.strtodatetime(dataIni, '%d/%m/%Y %H:%M:%S'))
        sql = sql.bindparams(dataFim=geral.strtodatetime(dataFim, '%d/%m/%Y %H:%M:%S'))
        # print(sql)
        rs = connPG.execute(sql)
        dados = rs.fetchall()
        listRet = []
        listRet.append('<body>')
        listRet.append('<table border=0>')
        listRet.append('<tr bgcolor="#C1CDC1" color="#FFFFFF"><td>Pos.</td><td>Inst.</td><td>Emp.</td><td>CNPJ</td><td>UF</td><td>Quant.</td></tr>')
        i = 0
        for spool in dados:
            i += 1
            listRet.append('<tr>')
            listRet.append('<td align="right">' + str(i) + '. </td>')
            listRet.append('<td>' + str(spool['codinstalacao']) + '</td>')
            listRet.append('<td>' + str(spool['codempresa']) + '</td>')
            listRet.append('<td>' + str(spool['cnpjinut']) + '</td>')
            listRet.append('<td>' + str(spool['anoinut']) + '</td>')
            listRet.append('<td>' + str(spool['ct']) + '</td>')
            listRet.append('</tr>')
        listRet.append('</table>')
        listRet.append('</body>')
        #
        if len(dados) > 0:
            mail.send(
                dest_mail='servidor@intersite.com.br',
                #destMail='edilmaralves@intersite.com.br',
                title='CHECAGEM DE CONSUMOS INDEVIDOS DE NFE > 3x',
                message=str(''.join(listRet)),
                mime_type='html'
            )


def __checkSSWF():
    # Buscar schemas existentes no banco de dados SATI-is
    engineSitesat = getEnginePGLightInterno(geralsis.prop, 'Sitesat')
    with getConnPG(engineSitesat) as connPG: # IMPORTANTE: tem que rodar em ate 5 minutos devido a property maxCheckoutConnPool
        sql = text('SELECT schema_name '
                   'FROM information_schema.schemata '
                   'WHERE schema_name NOT LIKE \'pg_%\' '
                   'AND schema_name != \'information_schema\' '
                   'AND schema_name != \'public\' '
                   'ORDER BY schema_name')
        rs = connPG.execute(sql)
        dados = rs.fetchall()

    lista_nome_reduzido = []
    hostname = socket.gethostname()
    servidor = f'{hostname}.intersite.com.br'
    websaf_url = 'http://websaf.intersite.com.br:8082/emonitorws/webresources/ws'
    # websaf_url = 'http://localhost:8080/emonitorws/webresources/ws'

    for schema in dados:
        nome_reduzido = schema[0]
        print(f'Checando nome reduzido {nome_reduzido} no WEBSAF ...')

        # checar se existe servidor ativo para o nome reduzido informado
        servidor_sitesat = requests.get(f'{websaf_url}/getServidorSitesatAtivo/{nome_reduzido}').content.decode()

        # se houver servidor ativo, checar data de fim do contrato
        if servidor_sitesat:
            data_fim_contrato = requests.get(f'{websaf_url}/getDataFimContrato/{nome_reduzido}').content.decode()

            if not data_fim_contrato:
                data_fim_contrato = 'SEM INFO DATA FIM CONTRATO'
            else:
                alerta_desinstalar = ''
                if data_fim_contrato != 'ATIVO':
                    dt_fim_contrato = geral.defstrtodate(data_fim_contrato)
                    data_atual = date.today()
                    dias_expirado = (data_atual - dt_fim_contrato).days
                    if dias_expirado > 90:
                        alerta_desinstalar = f' - ALERTA: DESINSTALAR DO SS, DESATIVADO HA {dias_expirado} DIAS!'
                    elif dias_expirado > 0:
                        alerta_desinstalar = f' - DESATIVADO HA {dias_expirado} DIAS!'
                    data_fim_contrato = f'DATA FIM CONTRATO: {data_fim_contrato}{alerta_desinstalar}'
                else:
                    continue

            if servidor_sitesat == 'ERRO':
                print(f'--- INATIVO! - {data_fim_contrato}\n')
                lista_nome_reduzido.append(f'{nome_reduzido} - {data_fim_contrato}\n')
            elif servidor_sitesat != servidor:
                print(f'--- ATIVO NO SERVIDOR {servidor_sitesat}! - {data_fim_contrato}\n')
                lista_nome_reduzido.append(f'{nome_reduzido} - ATIVO NO SERVIDOR {servidor_sitesat}\n')

    # enviar email ao finalizar checagem
    if len(lista_nome_reduzido) > 0:
        #print(str(lista_nome_reduzido))
        mail.send(
            # dest_mail='edilmaralves@intersite.com.br',
            dest_mail='servidor@intersite.com.br',
            title=f'CHECAGEM DE SITESATS INATIVOS NO WEBSAF - SERVIDOR {servidor}',
            message=str(''.join(lista_nome_reduzido))
        )


def __checkSSUsuariosAtivos(email_dest, filtro_tipocr):
    engineSitesat = getEnginePGLightInterno(geralsis.prop, 'Sitesat')
    with getConnPG(engineSitesat) as connPG: # IMPORTANTE: tem que rodar em ate 5 minutos devido a property maxCheckoutConnPool
        sql = text('SELECT schema_name '
                   'FROM information_schema.schemata '
                   'WHERE schema_name NOT LIKE \'pg_%\' '
                   'AND schema_name != \'information_schema\' '
                   'AND schema_name != \'public\' '
                   'ORDER BY schema_name')
        rs = connPG.execute(sql)
        dados = rs.fetchall()

    header = ['Cliente', 'Nome Reduz.', 'No. Us.', 'Tipo Receita']
    arquivo_csv = 'tmp/contar_usuarios_ativos.csv'
    hostname = socket.gethostname()
    servidor = f'{hostname}.intersite.com.br'
    websaf_url = 'http://websaf.intersite.com.br:8082/emonitorws/webresources/ws'
    # websaf_url = 'http://localhost:8080/emonitorws/webresources/ws'

    with open(arquivo_csv, 'w') as f:
        wr = csv.writer(f)
        wr.writerow(header)

        for schema in dados:
            nome_reduzido = schema[0]
            print(f'Processando nome reduzido {nome_reduzido} ...')
            response = requests.get(f'{websaf_url}/getTipoCR/{nome_reduzido}').content.decode()
            tipo_cr, desc_tipocr, razao_social = response.split('_')
            with getConnPG(engineSitesat) as connPG: # IMPORTANTE: tem que rodar em ate 5 minutos devido a property maxCheckoutConnPool
                sql = text('SELECT COUNT(*) '
                           f'FROM {nome_reduzido}.usuario '
                           'WHERE statususuario = \'A\' ')
                rs = connPG.execute(sql)
                if not filtro_tipocr:
                    wr.writerow([razao_social, nome_reduzido, rs.fetchone()[0], desc_tipocr])
                else:
                    if int(filtro_tipocr) == int(tipo_cr):
                        wr.writerow([razao_social, nome_reduzido, rs.fetchone()[0], desc_tipocr])
                    continue

    mail.send(
        dest_mail=email_dest,
        title=f'CONTAGEM DE USUARIOS ATIVOS - SERVIDOR {servidor}',
        message='Confira o arquivo .csv anexado no e-mail',
        attachments=[arquivo_csv],
        attname=f'{servidor}_us_ativos.csv'
    )


def __relSeguradorasMDFe(email_dest, start_date, end_date):
    if not start_date:
        start_dt = datetime.now() - timedelta(30)
        start_date = start_dt.strftime('%Y-%m-%d') + ' 00:00:00.000'
    else:
        start_date += ' 00:00:00.000'
    if not end_date:
        today = datetime.today()
        end_date = today.strftime('%Y-%m-%d') + ' 23:59:59.000'
    else:
        end_date += ' 23:59:59.000'

    csv_start_date = datetime.strptime(start_date, '%Y-%m-%d %H:%M:%S.000')
    csv_start_date = date.strftime(csv_start_date, '%Y%m%d')
    csv_end_date = datetime.strptime(end_date, '%Y-%m-%d %H:%M:%S.000')
    csv_end_date = date.strftime(csv_end_date, '%Y%m%d')

    print(f'Processando registros de {start_date} ate {end_date}')

    engineEMonitor = getEnginePGLight(geralsis.prop, 'EMonitor')
    with getConnPG(engineEMonitor) as connPG: # IMPORTANTE: tem que rodar em ate 5 minutos devido a property maxCheckoutConnPool
        sql = text('SELECT arqxmlass, codemonitorspool '
                   'FROM emonitorspool '
                   'WHERE codemonitoracao = 231 '  # MDFe
                   'AND datains BETWEEN :start_date AND :end_date '
                   'AND arqxmlass IS NOT NULL')
        sql = sql.bindparams(start_date=start_date)
        sql = sql.bindparams(end_date=end_date)
        rs = connPG.execute(sql)

    arquivo_csv = 'tmp/rel_mdfe_seguradoras.csv'
    with open(arquivo_csv, 'w') as f:
        wr = csv.writer(f)
        wr.writerow(['CNPJ', 'Nome do Cliente', 'CNPJ Seg.', 'Nome da Seguradora', 'Quant. MDFes', 'Valor Total'])

        csv_dict = {}
        cnpj_nome = {}

        print('Iniciando processamento de spools...\n')
        for row in rs.fetchall():
            em_spool = row['codemonitorspool']
            print(f'Processando emonitorspool: {em_spool}')
            xml = row['arqxmlass']

            # buscar xml_emit
            xml_emit_start = xml.find("<emit>")
            xml_emit_end = xml.find("</emit>")
            if (xml_emit_start == -1) or (xml_emit_end == -1):
                print(f"xml_emit null: emonitorspool {em_spool}")
                continue
            xml_emit = xml[xml_emit_start:xml_emit_end + 7]

            # buscar xml_seg
            xml_seg_start = xml.find("<seg>")
            xml_seg_end = xml.find("</seg>")
            if (xml_seg_start == -1) or (xml_seg_end == -1):
                print(f"xml_seg null: emonitorspool {em_spool}")
                continue
            xml_seg = xml[xml_seg_start:xml_seg_end + 6]

            #
            xml_seg_infseg = xml_seg[xml_seg.find("<infSeg>"):xml_seg.find("</infSeg>") + 9]
            xml_tot = xml[xml.find("<tot>"):xml.find("</tot>") + 6]

            cnpj = xml_emit[xml_emit.find("<CNPJ>") + 6:xml_emit.find("<CNPJ>") + 6 + 8]
            nome = xml_emit[xml_emit.find("<xNome>") + 7:xml_emit.find("</xNome>")]
            seguradora = xml_seg[xml_seg.find("<xSeg>") + 6:xml_seg.find("</xSeg>")]
            cnpj_seg = xml_seg_infseg[xml_seg_infseg.find("<CNPJ>") + 6:xml_seg_infseg.find("<CNPJ>") + 6 + 8]
            valor_carga = xml_tot[xml_tot.find("<vCarga>") + 8:xml_tot.find("</vCarga>")]

            if cnpj in csv_dict:
                if cnpj_seg in csv_dict[cnpj]:
                    csv_dict[cnpj][cnpj_seg][0] += 1
                    csv_dict[cnpj][cnpj_seg][2] += float(valor_carga)
                else:
                    csv_dict[cnpj][cnpj_seg] = [1, seguradora, float(valor_carga)]
            else:
                cnpj_nome[cnpj] = nome
                csv_dict[cnpj] = {}
                csv_dict[cnpj][cnpj_seg] = [1, seguradora, float(valor_carga)]

        # print(csv_dict)
        # print(cnpj_nome)

        for cnpj_cli in csv_dict.keys():
            for cnpj_seg in csv_dict[cnpj_cli].keys():
                count_seg = csv_dict[cnpj_cli][cnpj_seg][0]
                valor_total = csv_dict[cnpj_cli][cnpj_seg][2]
                nome_seg = csv_dict[cnpj_cli][cnpj_seg][1]
                nome_cli = cnpj_nome[cnpj_cli]
                wr.writerow([cnpj_cli, nome_cli, cnpj_seg, nome_seg, count_seg, round(valor_total, 2)])
                print(f'Adicionando registro ao arquivo .csv: Cliente \"{cnpj_cli}/{nome_cli}\", Seguradora: \"{cnpj_seg}/{nome_seg}\"')

    att_name = f'{socket.gethostname()}_RelSegMDFe_{csv_start_date}_{csv_end_date}.csv'
    mail.send(
        dest_mail=email_dest,
        title='RELATÓRIO - CLIENTE / SEGURADORA',
        message='Confira o arquivo .csv anexado no e-mail',
        attachments=[arquivo_csv],
        attname=att_name
    )
    print(f'\nRelatorio \"{att_name}\" enviado para: {email_dest}')
# __relSeguradorasMDFe("thiago.freire@intersite.com.br", None, None)

def find_instempfil_inativas(exec_delete=False):
    engineEMonitor = getEnginePGLight(geralsis.prop, 'EMonitor')
    with getConnPG(engineEMonitor) as connPG:
        rs = connPG.execute('SELECT codinstalacao, codempresa, cnpjcpf, numuf FROM instempfil')
        dados = rs.fetchall()
        insts_count = len(dados)

        SQL = '''
            SELECT codemonitorspool
            FROM emonitorspool 
            WHERE codinstalacao = %s
                AND codempresa = %s
                AND cnpjinut = %s
                AND anoinut = %s
                AND datains > current_date - interval '1' month
                AND status = 4
            LIMIT 1
        '''

        print(f'Verificando {insts_count} registros de instempfil...')

        count = 0
        match_count = 0
        for inst in dados:
            count += 1
            print(f'Verificando instempfil {count} de {insts_count}' )

            rs = connPG.execute(SQL, (inst['codinstalacao'], inst['codempresa'], inst['cnpjcpf'], inst['numuf']))
            spool = rs.fetchone()

            if spool:
                continue

            match_count += 1
            print(f"Instempfil inativa: Instalação={inst['codinstalacao']}, Empresa={inst['codempresa']}, CNPJ={inst['cnpjcpf']}, NumUF={inst['numuf']}")
            if exec_delete:
                connPG.execute(
                    '''
                        DELETE FROM instempfil
                        WHERE codinstalacao = %s and codempresa = %s and cnpjcpf = %s and numuf = %s
                    ''',
                    (inst['codinstalacao'], inst['codempresa'], inst['cnpjcpf'], inst['numuf'])
                )

                print('Registro removido.')

        print(f'No total, foram encontradas {match_count} instempfil inativas.')


def del_spools_sefazdist(datalimdel: str):
    processoUnico = False # setar na mao pra False quando ativar a execucao via crontab
    engineEMonitor = getEnginePGLight(geralsis.prop, 'EMonitor')
    with getConnPG(engineEMonitor) as connPG:
        sqlSELECT = text('SELECT COUNT(*) ct FROM emonitorspool WHERE datains < :datains')
        sqlDELETE = text('DELETE FROM emonitorspool WHERE datains < :datains')
        if processoUnico:
            # codigo para remover por periodo, executado uma unica vez para limpar o BD de dados antigos
            DATAINSINICIO = geral.defstrtodate('01/05/2022')
            DATAINSFIM = geral.defstrtodate(datalimdel)
            dataIns = DATAINSINICIO
            while dataIns != DATAINSFIM:
                print(f'Processando data {geral.datetostr(dataIns)}...')
                sqlSELECT = sqlSELECT.bindparams(datains=dataIns)
                sqlDELETE = sqlDELETE.bindparams(datains=dataIns)
                rs = connPG.execute(sqlSELECT)
                dados = rs.fetchone()
                ct = dados['ct']
                print(f'    Quantidade de Registros: {str(ct)} => removendo a seguir...')
                rs = connPG.execute(sqlDELETE)
                # if ct > 0:
                #     break
                dataIns = geral.incdatetime(dataIns, 1)
        else:
            # codigo para remover tudo mais antigo de 100 dias (90 dias + 10 dias de seguranca) e rodar por crontab todo mes
            dataIns = geral.defstrtodate(datalimdel)
            print(f'Processando data {geral.datetostr(dataIns)}...')
            sqlSELECT = sqlSELECT.bindparams(datains=dataIns)
            sqlDELETE = sqlDELETE.bindparams(datains=dataIns)
            rs = connPG.execute(sqlSELECT)
            dados = rs.fetchone()
            ct = dados['ct']
            print(f'    Quantidade de Registros: {str(ct)} => removendo a seguir...')
            rs = connPG.execute(sqlDELETE)


####################################################################################
# CODIGO ABAIXO main...
####################################################################################

args = sys.argv[1:]
#args = ['delspoolssefazdist','01/02/2023']
if args is None or len(args) == 0:
    print('Favor informar uma opcao')
# Rodado apenas da 1a. vez para limpar pastas antigas do EMONITOR bd/log/xml e emonitor.properties de quando era usado isoladamente
elif args[0] == 'clear':
    print('Remover pastas antigas do emonitor ...')
    __clearOldFolders()
# Rodado apenas da 1a. vez para checar tamanho dos arquivos de certificados... < 2K=REMOVER, < 8K=ALERTAR
elif args[0] == 'certsize':
    print('Checar tamanho dos certificados do emonitor ...')
    __checkCertSize()
# Roda no EM1: comparar diariamente com certificados no EM2 e EMP, para ver se estao desatualizados
elif args[0] == 'certall':
    print('Checar todos os certificados do emonitor 1 com o 2 e o P ...')
    __checkCertAll()
# Roda no EM1/EM2/EMP: 1x/mes desinstalar certificados se instalacao/empresa nao estiver OK no WEBSAF... tem 2o. parametro para definir se deinstala ou apenas manda email de aviso
elif args[0] == 'uninstall':
    fullUninstall = 'N'
    if len(args) == 2 and args[1].upper() in ['S', 'P']:
        fullUninstall = args[1].upper()
        print('Remover instalacoes desativadas do emonitor ...')
    elif len(args) == 2 and args[1].upper() not in ['N', 'S', 'P']:
        print('Informe parametro valido para uninstall / __uninstallInstEmp()')
    __uninstallInstEmp(fullUninstall)
# Roda nos EMP: monitora erros constantes de consulta indevida de NFes Destinadas e envia email de aviso
elif args[0] == 'nfedistconsindev':
    print('Checar no emonitor P quais clientes estao com mais de 3 consumos indevidos no dia ...')
    __checkNfeDistConsIndev()
# Roda nos SSs: 1x/sem checar se todas as instalacoes nos schemas dos PGs/SSs estao ativas no WEBSAF
elif args[0] == 'checksswf':
    __checkSSWF()
elif args[0] == 'checkssusativos':
    # cd /sistemas/emonitorpy; ./checkinstempss checkssusativos edilmaralves@intersite.com.br
    print('Contando usuários ativos por schema...')
    email = args[1]
    filtro_cr = args[2] if len(args) == 3 else None
    __checkSSUsuariosAtivos(email, filtro_cr)
elif args[0] == 'relsegmdfe':
    if len(args) <= 2:
        start = None
        end = None
    else:
        start = args[2]
        end = args[3]
    email = args[1]
    __relSeguradorasMDFe(email, start, end)
elif args[0] == 'findinstempfilinativas':
    find_instempfil_inativas()
elif args[0] == 'delinstempfilinativas':
    find_instempfil_inativas(True)
elif args[0] == 'delspoolssefazdist':
    if len(args) < 2:
        print('Deve informar a data limite para remocao de spools')
        exit(-1)
    datalimdel = args[1]
    del_spools_sefazdist(datalimdel)
exit(0)

# sincronizacao de cert.pfx entre EM1 e EM2/EMP (EM1 deve ter um WS/REST que devolve o cert.pfx + campos do properties (senha,checkexp,email)
