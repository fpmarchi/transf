'''
https://realpython.com/python-send-email/
'''


import smtplib, imaplib, ssl
import msal # biblioteca da M$ para acesso ao IMAP/Azure com OAUTH2
from email import encoders, message_from_bytes
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart

from flask import jsonify
import base64
import gzip
import json
from datetime import datetime, timedelta
from time import sleep

from metadata import getConnPG
from geral import check_user_password_ws, printdh
from geralsis import getOutrasInstalacoes, getProperty
from sefaz.dao import getEndDestEmailSair

SERVSMTP = 'smtplw.com.br'
PORTSMTP = 465
SOURCEMAILSMTP = 'mailj@sat.intersite.com.br'
USERSMTP = 'intersiteinfo'
PASSWORDSMTP = 'SsOdgyTm4902'


#######################################################################33
# metodos para SMTP
#######################################################################33
def connect_smtp(serv = SERVSMTP, port = PORTSMTP, user = USERSMTP, password = PASSWORDSMTP):
    try:
        context = ssl.create_default_context()
        server = smtplib.SMTP_SSL(serv, port, context=context)
        server.login(user, password)
        return server
    except Exception as e:
        print('Erro em mail.connect_smtp')
        print(e)
        return None


def disconnect_smtp(server):
    server.quit


def send_message(
    server,
    source_mail=SOURCEMAILSMTP,
    dest_mail='',
    title='',
    message='',
    mime_type='',
    attachments: list = [],
    attname=None
):
    try:
        parts = MIMEMultipart()
        #
        parts['From'] = source_mail
        parts['To'] = dest_mail
        parts['Subject'] = title
        #
        if mime_type == '':
            mime_type = 'plain'
        parts.attach(MIMEText(message, mime_type))
        #
        if len(attachments) > 0:
            for attachment in attachments:
                with open(attachment, 'rb') as att:
                    part = MIMEBase("application", "octet-stream")
                    part.set_payload(att.read())
                encoders.encode_base64(part)
                attachment_name = attname if attname else attachment
                part.add_header("Content-Disposition", f"attachment; filename= {attachment_name}",)
                parts.attach(part)
        #
        server.sendmail(source_mail, dest_mail, parts.as_string())
        #
        return True
    except Exception as e:
        print('Erro em mail.send_message')
        print(e)
        return False


def send(
     serv=SERVSMTP,
     port=PORTSMTP,
     user=USERSMTP,
     password=PASSWORDSMTP,
     source_mail=SOURCEMAILSMTP,
     dest_mail='',
     title='',
     message='',
     mime_type='',
     attachments: list = [],
     attname=None
):
    server = connect_smtp(serv, port, user, password)
    if server is None:
        return False
    else:
        send_message(server, source_mail, dest_mail, title, message, mime_type, attachments, attname)
        disconnect_smtp(server)


def test_smtp():
    print('PY - Conectando em ' + SERVSMTP + '/' + str(PORTSMTP) + '...')
    server = connect_smtp(SERVSMTP, PORTSMTP, USERSMTP, PASSWORDSMTP)
    if server is None:
        print('PY - Erro ao conectar')
        return False
    else:
        dest_mail = 'edilmaralves@intersite.com.br'
        print('PY - Enviando email de ' + SOURCEMAILSMTP + ' para ' + dest_mail + '...')
        send_message(
            server=server,
            source_mail=SOURCEMAILSMTP,
            dest_mail=dest_mail,
            title='Mensagem EMPY',
            message='Envio de Msg a partir do EMONITORPY para testar funcionamento do sistema.'
            )
        send_message(
            server=server,
            source_mail=SOURCEMAILSMTP,
            dest_mail=dest_mail,
            title='Mensagem EMPY com Anexos',
            message='Envio de Msg com Anexos a partir do EMONITORPY para testar funcionamento do sistema.',
            attachments = ['/home/edilmar/Downloads/cte.xml','/home/edilmar/Downloads/lixo.pdf']
            )
        print('PY - Desconectando em ' + SERVSMTP + '/' + str(PORTSMTP) + '...')
        disconnect_smtp(server)
    # send(
    #     dest_mail='edilmaralves@intersite.com.br',
    #     title='Mensagem EMPY com Anexos usando send direto',
    #     message='Envio de Msg com Anexos a partir do EMONITORPY para testar funcionamento do sistema.',
    #     attachments=['/home/edilmar/Downloads/cte.xml', '/home/edilmar/Downloads/lixo.pdf']
    # )


#test()


# metodo abaixo usado apenas pelo eminstall.py, para pegar uma lista de emails de clientes para enviar uma msg via EMI/Java
def get_emails_em(engine):
    try:
        useProp = getProperty("UseProp") == "S"
        lista_emails = []
        instalacoes = getOutrasInstalacoes()
        for instalacao in instalacoes:
            if not useProp:
                sep = instalacao.index("_")
                inst = instalacao[:sep]
                emp = instalacao[sep + 1:]
                with getConnPG(engine) as conn:
                    email = getEndDestEmailSair(conn, inst, emp)
            else:
                email = getProperty('EndDestEMailSair' + instalacao)
            lista_emails.append(email)
        return set(lista_emails)  # set remove repetições
    except Exception as e:
        raise Exception(e)


#######################################################################33
# metodos para IMAP
#######################################################################33


# obter token de acesso IMAP/Azure usando biblioteca MSAL da M$
def _get_access_token_oauth2_msal(
        user: str, password: str,
        client_id: str, client_credential: str, authority: str, scope: str
):
    try:
        app = msal.ConfidentialClientApplication(
            client_id=client_id,
            client_credential=client_credential,
            authority=authority
        )
        result = None
        accounts = app.get_accounts(username=user)
        scopes = [scope]
        if accounts:
            result = app.acquire_token_silent(scopes, account=accounts[0])
        if not result:
            result = app.acquire_token_by_username_password(user, password, scopes=scopes)
        if 'access_token' in result:
            access_token = result['access_token']
            return access_token
        else:
            print('Erro: Campo access_token nao encontrado no retorno')
            return None
    except Exception as e:
        print('Erro em mail.get_access_token_oauth2_msal')
        print(e)
        return None


def connect_imap(
        serv: str, port: int, user: str, password: str,
        use_oauth2: bool = False,
        client_id: str = None, client_credential: str = None, authority: str = None, scope: str = None
):
    try:
        server = imaplib.IMAP4_SSL(serv, port)
        # server.debug = 4
        if use_oauth2:
            access_token = _get_access_token_oauth2_msal(user, password, client_id, client_credential, authority, scope)
            if access_token:
                auth_string = f"user={user}\1auth=Bearer {access_token}\1\1"
                server.authenticate('XOAUTH2', lambda x: auth_string)
                return server
            else:
                return None
        else:
            server.login(user, password)
            return server
    except Exception as e:
        print('Erro em mail.connect_imap')
        print(e)
        return None


def disconnect_imap(server):
    server.close
    server.logout


def receive_messages(
        server,
        not_seen: bool = False,
        since_date: str = ''
): # retornar a lista de numeros/indices das mensagens + lista de mensagens
    list_num = list()
    list_messages = list()
    server.select()
    if not_seen:
        filter_messages = '(UNSEEN)'
    elif since_date:
        filter_messages = since_date
    else:
        filter_messages = 'ALL'
    typ, data = server.search(None, filter_messages)
    for num in data[0].split():
        typ, data = server.fetch(num, '(RFC822)')
        list_num.append(num)
        list_messages.append(message_from_bytes(data[0][1]))
    return list_num, list_messages


def get_attachments_messages(
        server,
        not_seen: bool = False,
        prefixes_subject: list() = None,
        extensions: list() = {'*'},
        remove_mail: bool = False,
        remove_mail_without_attachments: bool = False
): # retornar lista de nomes de arquivos + conteudos dos anexos
    list_filenames = list()
    list_attachments = list()
    list_num, list_messages = receive_messages(server=server, not_seen=not_seen)
    i = 0
    for message in list_messages:
        has_prefix_subject = False
        if prefixes_subject:
            subject = message.get('Subject').upper()
            for prefix in prefixes_subject:
                if subject.startswith(prefix.upper()): # IMPORTANTE: mensagens que comecam por isso
                    has_prefix_subject = True
                    break
        else:
            has_prefix_subject = True
        if not has_prefix_subject:
            i += 1
            continue # nao achou titulo do email entre prefixos validos, ignorar este email
        #
        has_attachment = False
        for part in message.walk():
            if part.get_content_maintype() == 'multipart':
                continue
            if part.get('Content-Disposition') is None:
                continue
            filename = part.get_filename()
            if filename:
                filename = filename.replace('/','_')
                filename = filename.replace('\\','_')
                for extension in extensions:
                    if extension == '*' or filename.lower().endswith(extension.lower()):
                        list_filenames.append(filename)
                        list_attachments.append(part.get_payload(decode=True))
                        has_attachment = True
        if remove_mail or (not has_attachment and remove_mail_without_attachments):
            remove_message(server, list_num[i])
        #
        i += 1
    #
    return list_filenames, list_attachments


def remove_messages_by_filename_attached(
        server,
        prefixes_subject,
        filenames_to_remove
):
    # PENDENTE: por enqto, rodar em loop tentativa de remocao 5x
    # porque a Azure estranhamente nao esta removendo tudo da 1a. vez
    ctRem = 0
    maxRem = 5
    while ctRem < 5:
        ctRem += 1
        printdh('Tentativa ' + str(ctRem) + ' de ' + str(maxRem) + ' de remocao de emails...')
        if ctRem == 1:
            # PENDENTE: por enqto, deixar fixa a logica para remover do ultimo dia
            last_datehour = datetime.now().strftime("%d-%b-%Y")
            since_date = '(SINCE "' + last_datehour + '")'
            list_num, list_messages = receive_messages(server=server, since_date=since_date)
        else:
            # tentar varias vezes obter mensagens a remover
            list_num, list_messages = receive_messages(server=server, not_seen=False)
        i = 0
        has_message_to_remove = False
        for message in list_messages:
            has_prefix_subject = False
            if prefixes_subject:
                subject = message.get('Subject').upper()
                for prefix in prefixes_subject:
                    if subject.startswith(prefix.upper()): # IMPORTANTE: mensagens que comecam por isso
                        has_prefix_subject = True
                        break
            else:
                has_prefix_subject = True
            if not has_prefix_subject:
                i += 1
                continue # nao achou titulo do email entre prefixos validos, ignorar este email
            #
            for part in message.walk():
                if part.get_content_maintype() == 'multipart':
                    continue
                if part.get('Content-Disposition') is None:
                    continue
                filename = part.get_filename()
                if filename:
                    filename = filename.replace('/','_')
                    filename = filename.replace('\\','_')
                    for filename_to_remove in filenames_to_remove:
                        if filename_to_remove.endswith(filename):
                            printdh('......... Removendo Anexo: ' + filename)
                            remove_message(server, list_num[i])
                            has_message_to_remove = True
                            break
            i += 1
        if has_message_to_remove:
            sleep(2) # esperar um pouco antes de tentar novamente
        else:
            break


def remove_message(
        server,
        num_message
):
    server.store(num_message, '+FLAGS', '\\Deleted')
    server.expunge()


def get_files_attached(request):
    msgRet = check_user_password_ws(request)
    if msgRet is not None:
        erro = 't'
    else:
        try:
            requestJSON = json.loads(gzip.decompress(base64.b64decode(request.data.decode())).decode())
            #
            serv = requestJSON['serv']
            port = int(requestJSON['port'])
            user = requestJSON['user']
            password = requestJSON['password']
            if user == 'xml@1500transportes.com.br':
                return # temporario
            #
            use_oauth2 = requestJSON['use_oauth2'].upper() == 'S'
            client_id = requestJSON['client_id']
            client_credential = requestJSON['client_credential']
            authority = requestJSON['authority']
            scope = requestJSON['scope']
            #
            not_seen = requestJSON['not_seen'].upper() == 'S'
            if requestJSON['prefixes_subject']:
                prefixes_subject = requestJSON['prefixes_subject'].split(',')
            else:
                prefixes_subject = None
            extensions = requestJSON['extensions'].split(',')
            remove_mail = requestJSON['remove_mail'].upper() == 'S'
            remove_mail_without_attachments = requestJSON['remove_mail_without_attachments'].upper() == 'S'
            #
            server = connect_imap(
                serv=serv, port=port, user=user, password=password,
                use_oauth2=use_oauth2,
                client_id=client_id,
                client_credential=client_credential,
                authority=authority,
                scope=scope
            )
            #
            if server:
                list_filenames, list_attachments = get_attachments_messages(
                    server=server,
                    not_seen=not_seen,
                    prefixes_subject=prefixes_subject,
                    extensions=extensions,
                    remove_mail=False, # remove_mail, feito abaixo apos obter os anexos, por seguranca
                    remove_mail_without_attachments=remove_mail_without_attachments
                )
                i = 0
                listRet = list()
                printdh('Iniciando processamento de anexos com servidor IMAP ' + serv + '/' + str(port) + ' - ' + user + " - No. Anexos = " + str(len(list_filenames)))
                for filename in list_filenames:
                    attachment = base64.b64encode(gzip.compress(list_attachments[i])).decode()
                    item = {"filename": filename, "attachment": attachment}
                    listRet.append(item)
                    i += 1
                    printdh('......... Obtendo Anexo: ' + filename)
                if remove_mail:
                    remove_messages_by_filename_attached(server, prefixes_subject, list_filenames)
                disconnect_imap(server)
                printdh('Finalizando processamento de anexos com servidor IMAP ' + serv + '/' + str(port) + ' - ' + user)
                erro = 'f'
                msgRet = 'No. de Anexos encontrados: ' + str(i)
                responseJSON = {}
                responseJSON['erro'] = erro
                responseJSON['msgRet'] = msgRet
                responseJSON['listRet'] = listRet
                return jsonify(responseJSON)
            else:
                erro = 't'
                msgRet = 'Erro em mail.get_files_attached de conexao com servidor IMAP ' + serv + '/' + str(port) + ' - ' + user
                printdh(msgRet)
                responseJSON = {}
                responseJSON['erro'] = erro
                responseJSON['msgRet'] = msgRet
                return jsonify(responseJSON)
            #
        except Exception as e:
            erro = 't'
            msgRet = 'Erro em mail.get_files_attached'
            printdh(msgRet)
            print(e)
    #
    responseJSON = {}
    responseJSON['erro'] = erro
    responseJSON['msgRet'] = msgRet
    return jsonify(responseJSON)


def del_files_attached(request):
    msgRet = check_user_password_ws(request)
    if msgRet is not None:
        erro = 't'
    else:
        try:
            requestJSON = json.loads(gzip.decompress(base64.b64decode(request.data.decode())).decode())
            #
            serv = requestJSON['serv']
            port = int(requestJSON['port'])
            user = requestJSON['user']
            password = requestJSON['password']
            if user == 'xml@1500transportes.com.br':
                return # temporario
            #
            use_oauth2 = requestJSON['use_oauth2'].upper() == 'S'
            client_id = requestJSON['client_id']
            client_credential = requestJSON['client_credential']
            authority = requestJSON['authority']
            scope = requestJSON['scope']
            #
            prefixes_subject = None
            try:
                if requestJSON['prefixes_subject']:
                    prefixes_subject = requestJSON['prefixes_subject'].split(',')
                else:
                    prefixes_subject = None
            except Exception as e:
                prefixes_subject = None
            list_filenames = requestJSON['list_filenames'].split(',')
            #
            server = connect_imap(
                serv=serv, port=port, user=user, password=password,
                use_oauth2=use_oauth2,
                client_id=client_id,
                client_credential=client_credential,
                authority=authority,
                scope=scope
            )
            #
            if server:
                i = 0
                printdh('Iniciando remocao de emails com anexos no servidor IMAP ' + serv + '/' + str(port) + ' - ' + user + " - No. Anexos = " + str(len(list_filenames)))
                remove_messages_by_filename_attached(server, prefixes_subject, list_filenames)
                disconnect_imap(server)
                printdh('Finalizando remocao de emails com anexos no servidor IMAP ' + serv + '/' + str(port) + ' - ' + user)
                erro = 'f'
                msgRet = 'No. de Anexos removidos: ' + str(i)
                responseJSON = {}
                responseJSON['erro'] = erro
                responseJSON['msgRet'] = msgRet
                return jsonify(responseJSON)
            else:
                erro = 't'
                msgRet = 'Erro em mail.del_files_attached de conexao com servidor IMAP ' + serv + '/' + str(port) + ' - ' + user
                printdh(msgRet)
                responseJSON = {}
                responseJSON['erro'] = erro
                responseJSON['msgRet'] = msgRet
                return jsonify(responseJSON)
            #
        except Exception as e:
            erro = 't'
            msgRet = 'Erro em mail.del_files_attached'
            printdh(msgRet)
            print(e)
    #
    responseJSON = {}
    responseJSON['erro'] = erro
    responseJSON['msgRet'] = msgRet
    return jsonify(responseJSON)
