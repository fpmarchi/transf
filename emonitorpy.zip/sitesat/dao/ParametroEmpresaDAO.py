from sqlalchemy.sql import *


def getValorByDescricao(conn, descricao):
    sql = text('SELECT valor '
               'FROM parametroempresa '
               'WHERE descricao = :descricao')
    sql = sql.bindparams(descricao=descricao)
    rs = conn.execute(sql)
    dados = rs.fetchone()
    if dados is None:
        return ''
    else:
        return str(dados[0])


