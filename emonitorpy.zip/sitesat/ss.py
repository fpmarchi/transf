import requests
import json

from gerdoc import sieg
from tins import *
from multisoftware import *
from tecnospeed import tecno_speed


def callSS(nomeReduzEmpresa, codEMonitorAcao, requestJSON, requestMethod):
    url, headers, req, files, erros = processRequest(nomeReduzEmpresa, codEMonitorAcao, requestJSON)
    if erros != '':
        return '', erros
    try:
        if requestMethod and requestMethod.upper() == 'GET':
            resp = requests.get(url, data=req, headers=headers)
        elif requestMethod and requestMethod.upper() == 'PATCH':
            resp = requests.patch(url, data=req, headers=headers)
        elif requestMethod and requestMethod.upper() == 'PUT':
            resp = requests.put(url, data=req, headers=headers)
        else:
            if isAcaoArq(codEMonitorAcao):
                resp = requests.post(url, data=req, headers=headers, files=files)
            else:
                resp = requests.post(url, data=req, headers=headers)
        # PENDENTE POIS files É UMA TUPLA E NAO UM ARQUIVO DIRETO
        # if isAcaoArq(codEMonitorAcao):
        #     for file in files:
        #         file[1].close()
        #
        retcode = resp.status_code  # https://developer.mozilla.org/pt-BR/docs/Web/HTTP/Status
        ret = resp.content.decode('utf-8')
        if ret is None:
            ret = ''
        #
        if retcode == 401:
            return '', 'ACESSO NEGADO (PROVAVELMENTE DEVIDO A CREDENCIAIS INVÁLIDAS) À OPERADORA (401)'
        elif retcode == 403:
            return '', 'ACESSO NEGADO (PROVAVELMENTE DEVIDO A ERRO DE CERTIFICADO) À OPERADORA (403)' + str(headers)
        elif retcode == 404:
            return '', 'INFORMAÇÃO NÃO ENCONTRADA NO ENDEREÇO ' + url + ' (404) '
        elif retcode == 500:
            return '', 'ERRO INTERNO DO SERVIDOR DA OPERADORA DE CARTÃO (500). URL:' + url
        else:
            resp2, erros2 = processResponse(codEMonitorAcao, ret, retcode)
            return resp2, erros2
    except Exception as e:
        print('Erro Interno em callSS')
        print(e)
        return '', 'ERRO INTERNO NA CHAMADA DA AÇÃO DO SITESAT'


def isAcaoArq(codEMonitorAcao):
    return (codEMonitorAcao == ACAO_TINS_REGISTRARDOCUMENTO)


def processRequest(nomeReduzEmpresa, codEMonitorAcao, requestJSON):
    context_req: dict = {
        'url': requestJSON.get('url', ''),
        'req': json.loads(requestJSON.get('request', '')),
        'props': requestJSON.get('requestProperties', '')
    }

    # -------------------------------------------------------
    # acoes tins
    # -------------------------------------------------------
    if codEMonitorAcao == ACAO_TINS_REGISTRARDOCUMENTO:
        return requestTinsRegistrarDocumento(nomeReduzEmpresa, requestJSON)
    # -------------------------------------------------------
    # acoes multisoftware
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_MULTISOFTWARE_OBTERCTES:
        return requestObterCTes(nomeReduzEmpresa, requestJSON)
    elif codEMonitorAcao == ACAO_MULTISOFTWARE_OBTERMDFES:
        return requestObterMDFes(nomeReduzEmpresa, requestJSON)
    # -------------------------------------------------------
    # acoes tecnospeed
    # -------------------------------------------------------
    elif tecno_speed.is_recognized_action(codEMonitorAcao):
        return tecno_speed.build_request(context_req, codEMonitorAcao)
    # -------------------------------------------------------
    # acoes sieg
    # -------------------------------------------------------
    elif sieg.is_recognized_action(codEMonitorAcao):
        return sieg.build_request(context_req, codEMonitorAcao)

    #IMPORTAR_ESPECIFICO = 50152
    else:
        return '', '', '', '', ''


def processResponse(codEMonitorAcao, ret, retcode):
    response: dict = {
        'resp': ret,
        'code': retcode,
        'action_cod': codEMonitorAcao
    }
    # -------------------------------------------------------
    # acoes tins
    # -------------------------------------------------------
    if codEMonitorAcao == ACAO_TINS_REGISTRARDOCUMENTO:
        return responseTinsRegistrarDocumento(ret, retcode)
    # -------------------------------------------------------
    # acoes multisoftware
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_MULTISOFTWARE_OBTERCTES:
        return responseObterCTes(ret, retcode)
    elif codEMonitorAcao == ACAO_MULTISOFTWARE_OBTERMDFES:
        return responseObterMDFes(ret, retcode)
    # -------------------------------------------------------
    # acoes tecnospeed
    # -------------------------------------------------------
    elif tecno_speed.is_recognized_action(codEMonitorAcao):
        return tecno_speed.parse_response(response, codEMonitorAcao)
    # -------------------------------------------------------
    # acoes sieg
    # -------------------------------------------------------
    elif sieg.is_recognized_action(codEMonitorAcao):
        return sieg.parse_response(response, codEMonitorAcao)
    else:
        return '', ''
