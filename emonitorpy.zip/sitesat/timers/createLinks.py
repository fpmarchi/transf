import os
import geral

ss0='https://ss0.intersite.com.br/'
dfe1='https://dfe1.intersite.com.br/'
sat1='https://sat1.intersite.com.br/'
sat3='https://sat3.intersite.com.br/'

ss0rep='http://sitesat.intersite.com.br:36000/'
dfe1rep='http://sitesat.intersite.com.br:36001/'
sat1rep='http://sitesat.intersite.com.br:36002/'
sat3rep='http://sitesat.intersite.com.br:36003/'


def createLinks(servidor, nomeReduz, ativo, dirss, strIndex):
    #
    if servidor == 'ss0':
        url = ss0
        urlrep = ss0rep
    elif servidor == 'dfe1':
        url = dfe1
        urlrep = dfe1rep
    elif servidor == 'sat1':
        url = sat1
        urlrep = sat1rep
    elif servidor == 'sat3':
        url = sat3
        urlrep = sat3rep
    else:
        return
    #
    dirNomeReduz = dirss + nomeReduz
    if not geral.direxists(dirNomeReduz):
        os.mkdir(dirNomeReduz)
    if ativo == '':
        strIndexAtual = strIndex.replace('<#URL>', url + nomeReduz)
        geral.strtofile(dirNomeReduz+'/index.html', strIndexAtual)
        strIndexAtual = strIndex.replace('<#URL>', urlrep + nomeReduz)
        geral.strtofile(dirNomeReduz+'/index2.html', strIndexAtual)
    else: # contingencia
        strIndexAtual = strIndex.replace('<#URL>', urlrep + nomeReduz)
        geral.strtofile(dirNomeReduz+'/index.html', strIndexAtual)
        strIndexAtual = strIndex.replace('<#URL>', url + nomeReduz)
        geral.strtofile(dirNomeReduz+'/index2.html', strIndexAtual)


