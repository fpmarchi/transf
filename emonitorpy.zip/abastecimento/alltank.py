from typing import Tuple
from requests import Response

from ActionProcessor import ActionProcessor, parse_props, HttpMethod, handle_exception_factory

from geralxml import mount_xml_response


class AllTankException(Exception):
    pass


# Classe base
class AllTank(ActionProcessor):
    # INSTANCIAS
    HOST = 'https://api.layrz.com'
    TEST_HOST = 'https://api.layrz.com'

    IMPORT_SUPPLIES = 4400

    def __init__(self):
        self.add_callable_records('url', {
            self.IMPORT_SUPPLIES: self.make_url_assembler(
                '/outbound/atsrest/$user_alltank/history?date_start=$date_start&date_end=$date_end',
                method=HttpMethod.GET,
                use_template=True
            )
        })

        super().__init__()

    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        props = context_req.get('props')
        token = props.get('token')

        return {
            'Content-type': 'application/json',
            'Authorization': 'LayrzToken ' + token,
        }, ''


#
#   Códigos independentes de instancia
#
def _alltank_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a allTank:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    AllTankException,
    _alltank_exception_callback,
    any_exception_callback
)

#
#   Instancia limpa e sem configuração
#
_alltank = AllTank()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = _alltank.link_to_factory('request')
_link_to_response = _alltank.link_to_factory('response')


@_link_to_request(_alltank.IMPORT_SUPPLIES)
@_handle_exception
def _import_supplies(req: dict) -> Tuple[None, str]:
    return None, ''


@_link_to_response(_alltank.IMPORT_SUPPLIES)
@_handle_exception
def _in_import_supplies(resp: Response) -> Tuple[str, str]:
    ret = resp.json()
    ret_code = resp.status_code

    resp_data = {}

    if ret_code in [200]:
        if ret.get('status') in [200, 'OK']:
            resp_data = {
                'sucesso': True,
                'conteudo': ret.get('data')
            }
        else:
            resp_data = {
                'sucesso': False,
                'msg_erro': ret.get('errors')[0]
            }

    else:
        resp_data = {
            'sucesso': False,
            'msg_erro': 'Ocorreu um erro ao tentar Buscar os abastecimentos' + ret,
        }

    return mount_xml_response(resp_data), ''
