import base64
import logging
from enum import Enum
from typing import Tuple
from urllib.parse import urlparse, urlunparse
import sys
import time
from requests import post, Response

from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Util.Padding import unpad, pad

from ActionProcessor import Callable_cfg, parse_props
from geral import encryptMd5
from geralxml import mount_xml_response

from ActionProcessor import ActionProcessor

_log = logging.getLogger(__name__)


class HttpMethod(Enum):
    DELETE = 0
    GET = 1
    POST = 2


# Creating custom exception
class TruckPagException(Exception):
    pass


# Classe principal para configuração da ActionProcessor
class TruckPag(ActionProcessor):
    HOST = 'https://api.truckpag.com.br/'
    TEST_HOST = 'https://apihomo.truckpag.com.br/'
    # method
    AUTH = -1
    GET_TRANSACTION = 4550

    __token_cache: dict = {}

    def __init__(self, min_action: int, max_action: int):
        self.MIN_ACTION = min_action
        self.MAX_ACTION = max_action

        self.add_callable_records('url', {
            self.GET_TRANSACTION: self.make_url_assembler(
                '/Transacoes?dtini=$dtini&dtfim=$dtfim&todas=$todas',
                HttpMethod.GET,
                use_template=True
            ),
            self.AUTH: self.make_url_assembler('/auth')
        })

        request_builders: Callable_cfg = {
            self.GET_TRANSACTION: _get_transaction,
        }

        response_parsers: Callable_cfg = {
            self.GET_TRANSACTION: _get_transaction_response,
        }
        super().__init__(request_builders, response_parsers)

    def before_make_url(self):
        req = self.context.get('req')
        if not req:
            return

        if req.get('todas') is True:
            req['todas'] = 'S'
        else:
            req['todas'] = 'N'

    def get_headers(self, dict_with_props: dict):
        try:
            token = self.get_token(dict_with_props)
            headers = {'Authorization': 'Bearer ' + token}
            headers['Content-Type'] = 'application/json'
            return headers, ''
        except Exception as e:
            return '', 'Erro ao obter o token de acesso.\nDetalhes: ' + str(e)

    @parse_props
    def get_token(self, context_req: dict) -> str:
        props = context_req.get('props', {})
        usuario = props.get('usuario', '')
        senha = props.get('senha', '')
        senhamd5 = encryptMd5(senha.strip())
        if not usuario or not senha:
            raise Exception('O usuario ou senha não foram informados.')

        aes_key = PBKDF2(senha, usuario, 32, count=500, hmac_hash_module=SHA256)
        cipher = AES.new(aes_key, AES.MODE_ECB)
        headers = {}
        headers['Authorization'] = 'Basic ' + base64.b64encode(bytes(f"{usuario}:{senhamd5}", "utf-8")).decode("ascii")

        # Memória transitória em variável do sigleton da integração. Por ser um sistema multithread, pode não ser
        # muito eficiente, mas ajuda. O ideal seria o uso de um banco de memória transitória como Redis.
        usuario_hash = hash(usuario)
        (token, gen_time) = self.__token_cache.get(usuario_hash, (bytearray(), 0))

        if token and (time.time() - gen_time) < 2700:  # Se a idade for menor que 45 minutos
            token = cipher.decrypt(token)
            return unpad(token, cipher.block_size).decode('UTF-8')

        # Se não existir token em memória transitória, tentar solicitar pela Api da TruckPag
        try:
            auth_request = {
                'application_key': {
                    'email': usuario,
                    'password': senha
                }
            }

            uri = self.context.get('url')
            parsed_uri = list(urlparse(uri))
            parsed_uri[2] = ''

            local_ctx = {
                'url': urlunparse(parsed_uri),
            }
            uri = self.dispatch(self.AUTH, local_ctx, 'url')[0]
            resp = post(uri, json=auth_request, headers=headers)
        except Exception as e:
            raise Exception('Erro ao buscar token de autorização na TruckPag!\n' + str(e))

        if resp.status_code in [200,201]:
            token = resp.json().get('token', '')
            encrypt_token = cipher.encrypt(pad(token.encode('UTF-8'), cipher.block_size))

            self.__token_cache[usuario_hash] = (encrypt_token, time.time())

            return token
        elif resp.status_code == 401:
            raise Exception('Por favor verifique as credenciais de acesso para TruckPag!')
        else:
            raise Exception(resp.content.decode('utf-8'))

def url_get_transaction(url: str):
    return url, ''


# Decorators (Devem ser declarados antes do uso)
def _truckpag_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback() -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a TruckPag'


def _get_transaction() -> Tuple[None, str]:
    return None, ''


def _get_transaction_response(resp: Response):
    resp_json = resp.json()
    success = resp.status_code in [200, 201, 204]
    resp_body = {'sucesso': success}
    if success:
        resp_body['conteudo'] = resp_json
    elif 'error' in resp_json or len(resp_json) == 0:
        resp_body['sucesso'] = False
        resp_body[
            'msg_erro'] = 'O cadastro ainda não foi realizado, é necessário cadastrar antes para buscar informações'
    else:
        raise TruckPagException('Não foi possível encontrar um retorno conhecido da TruckPag')
    return mount_xml_response(resp_body), ''
