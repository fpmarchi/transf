import base64
import logging
from datetime import datetime
from json import dumps
from typing import Tuple, cast, Union

import xmltodict
from requests import Response

from ActionProcessor import ActionProcessor, Callable_cfg, parse_props, handle_exception_factory
from geral import deep_get, safe_cast, conditional_keys
from geralxml import mount_xml_response

_log = logging.getLogger(__name__)


# Define o tipo de exceção local
class X7BankException(Exception):
    pass


# Decorators (Devem ser declarados antes do uso)
_handle_exception = handle_exception_factory(
    X7BankException,
    lambda data: ('', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')),
    lambda data: ('', 'Ocorreu um erro desconhecido ao comunicar com a X7Bank')
)


# Classe principal para configuração da ActionProcessor
class X7Bank(ActionProcessor):

    BASE_URL = 'https://gateway.x7bank.com.br'
    BASE_URL_TEST = 'https://hgateway.x7bank.com.br'

    MIN_ACTION = 3700
    MAX_ACTION = 3749
    GET_TRAFFIC = 3700  # ACAO_X7BANK_OBTER_MOVIMENTACOES
    GET_INVOICES = 3701  # ACAO_X7BANK_OBTER_FATURAS
    ISSUE_CONTRACT = 3702
    LIST_CONTRACT = 3703
    CHANGE_CONTRACT_STATUS = 3704
    CONTRACT_SUPPLY = 3705

    def __init__(self):
        request_builders: Callable_cfg = {
            self.GET_TRAFFIC: _get_traffic_out,
            self.GET_INVOICES: _get_invoices_out,
            self.ISSUE_CONTRACT: _issue_contract,
            self.CHANGE_CONTRACT_STATUS: _change_contract_status,
            self.CONTRACT_SUPPLY: _change_contract_supply,
            self.LIST_CONTRACT: _list_contract
        }

        response_parsers: Callable_cfg = {
            self.GET_TRAFFIC: _movements_in,
            self.GET_INVOICES: _invoices_in,
            self.ISSUE_CONTRACT: in_issue_contract,
            self.CHANGE_CONTRACT_STATUS: in_change_contract_status,
            self.LIST_CONTRACT: in_list_contract,
            self.CONTRACT_SUPPLY: _in_contract_supply,
            self.DEFAULT_FUNCTION: _default_in
        }

        super().__init__(request_builders, response_parsers)

    @_handle_exception
    @parse_props
    def get_headers(self, dict_with_props: dict) -> Tuple[dict, str]:
        try:
            headers = {
                'x-uid': dict_with_props['props']['uid'],
                'token': dict_with_props['props']['token'],
            }

            return headers, ''
        except Exception as e:
            raise X7BankException('Erro ao obter o headers: ' + str(e))


# Funções para criação do JSON
@_handle_exception
def _get_traffic_out(req: dict) -> Tuple[str, str]:
    data = {
        'dataini': datetime.strptime(req.get('data_ini', ''), '%Y-%m-%dT%H:%M:%S.%fZ').strftime('%Y-%m-%d'),
        'datafim': datetime.strptime(req.get('data_fim', ''), '%Y-%m-%dT%H:%M:%S.%fZ').strftime('%Y-%m-%d')
    }

    return dumps(data), ''


@_handle_exception
def _get_invoices_out(req: dict) -> Tuple[str, str]:
    data = {
        'dataini': datetime.strptime(req.get('data_ini', ''), '%Y-%m-%dT%H:%M:%S.%fZ').strftime('%Y-%m-%d'),
        'datafim': datetime.strptime(req.get('data_fim', ''), '%Y-%m-%dT%H:%M:%S.%fZ').strftime('%Y-%m-%d'),
        # 'tipo_data': 'data_vencimento'
        'tipo_data': 'data_vencimento' if req.get('tipo_data') == '0' else 'data_geracao'
    }

    return dumps(data), ''


def _issue_contract(req: dict) -> Tuple[str, str]:
    data = {
        'transportadora_cpf_cnpj': req.get('transportadora_cpf_cnpj'),
        'transportadora_razao_social': req.get('transportadora_razao_social'),
        'veiculo_placa': req.get('veiculo_placa'),
        'veiculo_cpf_motorista': req.get('veiculo_cpf_motorista'),
        'veiculo_nome_motorista': req.get('veiculo_nome_motorista'),
        'veiculo_celular_motorista': req.get('veiculo_celular_motorista'),
        'contrato_valor': req.get('contrato_valor'),
        'contrato_numero_referencia': req.get('contrato_numero_referencia'),
    }

    return dumps(data), ''


def _change_contract_status(req: dict) -> Tuple[str, str]:
    data = {
        'cod_contrato': req.get('cod_contrato'),
        'status': req.get('status')
    }

    return dumps(data), ''


def _list_contract(req: dict) -> Tuple[str, str]:
    data = {
        'data_inicio': req.get('data_inicio', ''),
        'data_fim': req.get('data_fim', ''),
        'status': req.get('status', ''),
        'transportadora': req.get('transportadora', ''),
        'numero_referencia': req.get('numero_referencia', ''),
        'cod_contrato': req.get('cod_contrato', '')
    }

    return dumps(data), ''


def _change_contract_supply(req: dict) -> Tuple[str, str]:
    data = {
        **conditional_keys(
            not not req.get('cod_contrato'),
            {
                'cod_contrato': req.get('cod_contrato'),
            },
            {
                'dataini': req.get('data_inicio'),
                'datafim': req.get('data_fim'),
                'status': req.get('status')
            }
        ),
    }

    return dumps(data), ''


# Funções para tratamento de retorno
@_handle_exception
def _default_in(resp: Response):
    return mount_xml_response(resp.json()), ''


@_handle_exception
def _movements_in(resp: Response) -> Tuple[str, str]:
    ret = []
    for movement in resp.json():
        ret.append(_process_movement(movement))

    return mount_xml_response(ret), ''


def _process_movement(movement: dict) -> dict:
    def get_xml():
        if 'fullXML' in movement:
            return movement.get('fullXML', '')

        if 'xml' in movement:
            urlxml: str = movement.get('xml', '')

    inf_nfe = {}
    if movement.get('status') == "Processado":
        try:
            inf_nfe = deep_get(xmltodict.parse(get_xml()), 'nfeProc.NFe.infNFe', {})
        except (Exception,):
            pass

    provider: dict = cast(dict, movement.get('fornecedor', {}))

    itens = []
    parsed = {
        'codigo': movement.get('codigo', '0'),
        'nnf': movement.get('nnf', ''),
        'cod_nfe': movement.get('cod_nfe', ''),
        'serie_nf': movement.get('serie_nf', ''),
        'chave_nf': movement.get('chave_nf', ''),
        'cfop_nf': movement.get('cfop_nf', ''),
        'especie_nf': movement.get('especie_nf', ''),
        'data_movimento': movement.get('data_movimento', ''),
        'fornecedor': {
            'loja': provider.get('loja', ''),
            'cnpj_loja': provider.get('cnpj_loja', ''),
            'ie': provider.get('ie', ''),
            'Cidade': provider.get('Cidade', ''),
            'uf': provider.get('UF', ''),
        },
        'cnpj_faturamento': movement.get('cnpj_faturamento', ''),
        'centro_custo': movement.get('centro_custo', ''),
        'placa': movement.get('placa', ''),
        'cnpj_mot': movement.get('cnpj_mot', ''),
        'km_informado': movement.get('km_informado', ''),
        'itens': itens,
        'status': movement.get('status'),
        'xml': base64.b64encode(movement.get('fullXML', '').encode("utf-8")).decode("utf-8"),
        'cancelado': movement.get('cancelado', ''),
        'valor_bruto': x7_round(movement.get('valor_bruto')),
        'valor_liquido': x7_round(movement.get('valor_liquido')),
        'valor_descontos': x7_round(movement.get('valor_descontos') or movement.get('descontos', 0)),
        'valor_bruto_nfe': x7_round(deep_get(inf_nfe, 'total.ICMSTot.vProd', 0)),
        'valor_liquido_nfe': x7_round(deep_get(inf_nfe, 'total.ICMSTot.vNF', 0)),
        'valor_descontos_nfe': x7_round(deep_get(inf_nfe, 'total.ICMSTot.vDesc', 0)),
    }

    nfe_items: list = inf_nfe.get('det', [])
    if type(nfe_items) is not list:
        nfe_items = [nfe_items]

    if not movement.get('itens'):
        movement['itens'] = nfe_items

    vl_calculado = 0
    for index, item in enumerate(movement.get('itens', [])):
        try:
            nfe_item = _find_nfe_item(item, len(movement.get('itens', [])), nfe_items)
        except (Exception,):
            nfe_item = {}

        amount = float(nfe_item.get('vProd') or item.get('vl_total_bruto', 0))
        quantity = float(nfe_item.get('qCom') or item.get('qtde', 0))
        unitary_value = float(nfe_item.get('vUnCom') or item.get('vl_unitario', 0))
        discount = (
                           float(item.get('vl_desconto_total', 0)) + float(nfe_item.get('vDesc', 0))
                   ) * 100 / amount or 0

        item = {
            'cod_produto': item.get('cod_produto', 0),
            'seq_nota': item.get('seq_nota', 0),
            'produto': item.get('produto', ''),
            'ncm_item': item.get('ncm_item', ''),
            'cfop': nfe_item.get('CFOP', ''),
            'qtde': quantity,
            'vl_unitario': unitary_value,
            'desconto': x7_round(discount, 4),
            'vl_bruto': x7_round(item.get('vl_total_bruto', 0)),
            'vl_liquido': x7_round(amount * (1 - discount / 100)),
            'qtde_nfe': x7_round(nfe_item.get('qCom', 0), 3),
            'desconto_nfe': x7_round(nfe_item.get('vDesc', 0), 3),
            'vl_bruto_nfe': x7_round(nfe_item.get('vProd', 0), 3),
            'vl_liquido_nfe': x7_round(float(nfe_item.get('vProd', 0)) - float(nfe_item.get('vDesc', 0))),
        }

        vl_calculado += item['vl_liquido']
        itens.append(item)

    parsed['valor_calculado'] = x7_round(vl_calculado)

    return parsed


@_handle_exception
def _invoices_in(resp: Response) -> Tuple[str, str]:
    ret = []
    for invoice in resp.json():
        parsed = {}
        parsed.update(invoice)
        if 'itens' in parsed:
            parsed.pop('itens')

        parsed['contasapagar'] = []
        for movement in invoice.get('itens', []):
            parsed['contasapagar'].append(_process_invoice_movement(movement))

        ret.append(parsed)

    return mount_xml_response(ret), ''


@_handle_exception
def in_issue_contract(resp: Response) -> Tuple[str, str]:
    try:
        resp_json = resp.json()
        resp_body = {}
    except (Exception,):
        raise X7BankException('Erro no retorno fora de padrão pela X7Bank')
    if resp_json.get('retorno') == 0:
        resp_body = {
            'sucesso': False,
            'msg_erro': resp_json.get('msg')
        }
    elif resp_json.get('retorno') == 1:
        resp_body = {
            'sucesso': True,
            'conteudo': resp_json
        }
    else:
        resp_body = {
            'sucesso': False,
            'msg_erro': 'Erro ao tentar obter o retorno da X7Bank'
        }
    return mount_xml_response(resp_body), ''


@_handle_exception
def in_change_contract_status(resp: Response) -> Tuple[str, str]:
    try:
        resp_json = resp.json()
        resp_body = {}
    except (Exception,):
        raise X7BankException('Erro no retorno fora de padrão pela X7Bank')
    if resp_json.get('retorno') == 0:
        resp_body = {
            'sucesso': False,
            'msg_erro': resp_json.get('msg')
        }
    elif resp_json.get('retorno') == 1:
        resp_body = {
            'sucesso': True,
            'conteudo': resp_json
        }
    else:
        resp_body = {
            'sucesso': False,
            'msg_erro': 'Erro ao tentar obter o retorno da X7Bank'
        }
    return mount_xml_response(resp_body), ''


@_handle_exception
def in_list_contract(resp: Response) -> Tuple[str, str]:
    try:
        resp_json = resp.json()
        resp_body = {}
    except (Exception,):
        raise X7BankException('Erro no retorno fora de padrão pela X7Bank')
    if not len(resp_json):
        resp_body = {
            'sucesso': False,
            'msg_erro': 'Não foi encontrado nenhum contrato para o período ou número selecionado'
        }
    elif len(resp_json) > 0:
        resp_body = {
            'sucesso': True,
            'conteudo': resp_json
        }
    else:
        resp_body = {
            'sucesso': False,
            'msg_erro': 'Erro ao tentar obter o retorno da X7Bank'
        }
    return mount_xml_response(resp_body), ''


@_handle_exception
def _in_contract_supply(resp: Response) -> Tuple[str, str]:
    try:
        resp_json = resp.json()
        resp_body = {}
    except (Exception,):
        raise X7BankException('Erro no retorno fora de padrão pela X7Bank')
    if not len(resp_json):
        resp_body = {
            'sucesso': False,
            'msg_erro': 'Não foi encontrado nenhum abastecimento para o período ou número selecionado'
        }
    elif len(resp_json) > 0:
        resp_body = {
            'sucesso': True,
            'conteudo': resp_json
        }
    else:
        resp_body = {
            'sucesso': False,
            'msg_erro': 'Erro ao tentar obter o retorno da X7Bank'
        }
    return mount_xml_response(resp_body), ''


def _process_invoice_movement(movement: dict) -> dict:
    inf_nfe = {}
    if 'fullXML' in movement:
        try:
            inf_nfe = deep_get(xmltodict.parse(movement.get('fullXML', '')), 'nfeProc.NFe.infNFe', {})
        except (Exception,):
            pass

    itens = []
    parsed = {
        'seq': movement.get('seq', '0'),
        'cod': movement.get('cod', ''),
        'km_informado': safe_cast(movement.get('km_informado'), int, 0),
        'descricao': movement.get('descricao', ''),
        'veiculo': movement.get('veiculo', ''),
        'tipo_movimento': movement.get('tipo_movimento', ''),
        'data_abastecimento': movement.get('data_abastecimento', ''),
        'fornecedor': {
            'cnpj_loja': deep_get(inf_nfe, 'emit.CNPJ', ''),
            'ie_loja': deep_get(inf_nfe, 'emit.IE', ''),
            'uf': deep_get(inf_nfe, 'emit.IE', '')
        },
        'serie_nf': deep_get(inf_nfe, 'ide.serie', ''),
        'chave_nf': inf_nfe.get('@Id', ''),
        'cfop_nf': deep_get(inf_nfe, 'ide.natOp', ''),
        'cnpj_faturamento': deep_get(inf_nfe, 'dest.CNPJ', ''),
        'empresa': movement.get('empresa', ''),
        'cnpj': movement.get('cnpj', ''),
        'nf': movement.get('nf', ''),
        'valor_bruto_nfe': x7_round(deep_get(inf_nfe, 'total.ICMSTot.vProd', 0)),
        'valor_liquido_nfe': x7_round(deep_get(inf_nfe, 'total.ICMSTot.vNF', 0)),
        'valor_bruto_total': movement.get('valor_bruto_total', ''),
        'acrescimos': movement.get('acrescimos', ''),
        'descontos': movement.get('descontos', ''),
        'valor_liquido_total': movement.get('valor_liquido_total', ''),
        'xml': base64.b64encode(movement.get('fullXML', '').encode("utf-8")).decode("utf-8"),
        'danfe': movement.get('danfe', ''),
        'itens': itens
    }

    nfe_items: list = inf_nfe.get('det', [])
    if type(nfe_items) is not list:
        nfe_items = [nfe_items]

    vl_calculado = 0
    for index, item in enumerate(movement.get('det_itens', [])):
        try:
            nfe_item = _find_nfe_item(item, len(movement.get('det_itens', [])), nfe_items)
        except (Exception,):
            nfe_item = {}

        amount = float(nfe_item.get('vProd') or item.get('vl_total_bruto', 0))
        quantity = float(nfe_item.get('qCom') or item.get('qtde', 0))
        unitary_value = float(nfe_item.get('vUnCom') or item.get('vl_unitario', 0))
        discount = (
                           float(item.get('vl_desconto_total', 0)) + float(nfe_item.get('vDesc', 0))
                   ) * 100 / amount or 0

        item = {
            'cod_produto': item.get('cod_produto', 0),
            'seq_nota': item.get('seq_nota', ''),
            'produto': item.get('produto', ''),
            'cfop': nfe_item.get('CFOP', ''),
            'vl_unitario': unitary_value,
            'ncm_item': item.get('ncm_item', ''),
            'qtde': quantity,
            'descontos': x7_round(discount, 4),
            'vl_bruto': x7_round(item.get('vl_total_bruto', 0)),
            'vl_liquido': x7_round(amount * (1 - discount / 100)),
            'qtde_nfe': x7_round(nfe_item.get('qCom', 0), 3),
            'vl_desconto_unit': x7_round(nfe_item.get('vDesc', 0), 3),
            'valor_bruto_total': x7_round(nfe_item.get('vProd', 0), 3),
            'valor_liquido_total': x7_round(float(nfe_item.get('vProd', 0)) - float(nfe_item.get('vDesc', 0))),
        }

        vl_calculado += item['vl_liquido']
        itens.append(item)

    parsed['valor_calculado'] = x7_round(vl_calculado)

    return parsed


# Funções utilitárias
def _find_nfe_item(x7_item: dict, items_count: int, nfe_items: list):
    seq_nota = x7_item.get('seq_nota', '')

    nfe_prod_generator = (
        t.get('prod')
        for t in nfe_items
        if t.get('@nItem') == x7_item.get('seq_nota', '1')
    )
    target_item = next(nfe_prod_generator)

    if len(nfe_items) == items_count:
        return target_item

    cprod = target_item.get('cProd')
    items = [
        item['prod'] for item in nfe_items
        if item['prod'].get('cProd') == cprod
    ]

    if len(items) == 1:
        return target_item

    if items:
        items.pop(0)
        for nfe_item in items:
            target_item['vProd'] = safe_cast(target_item['vProd'], float, 0) + safe_cast(nfe_item.get('vProd'), float,
                                                                                         0)
            target_item['qCom'] = safe_cast(target_item['qCom'], float, 0) + safe_cast(nfe_item.get('qCom'), float, 0)

        target_item['vUnCom'] = safe_cast(target_item['vProd'], float, 0) / safe_cast(target_item['qCom'], float, 1)

    return target_item


def x7_round(decimal: Union[float, str], target: int = 2):
    def make_float(i, f):
        return float('.'.join((i, f)))

    if type(decimal) is str:
        if decimal.find(',') != -1:
            decimal = decimal.replace('.', '').replace(',', '.')

    if str(decimal).find('.') == -1:
        return float(decimal)

    integer, decimals = f'{decimal}'.split('.')

    if len(decimals) <= target:
        return make_float(integer, decimals)

    decimal_list = [int(s) for s in decimals[:target + 2]]
    decimal_list = decimal_list + [-1] * (target + 2 - len(decimal_list))

    vin = decimal_list[-2]
    t = decimal_list[-3]

    if vin == 5:
        if decimal_list[-1] == 0:
            if t % 2 != 0:
                decimal_list[-3] += 1
        else:
            decimal_list[-3] += 1
    elif vin > 5:
        decimal_list[-3] += 1

    decimal_list = decimal_list[:-2]

    add = 0
    decimal_list.reverse()
    for i in range(len(decimal_list)):
        decimal_list[i] += add
        if decimal_list[i] == 10:
            decimal_list[i] = 0
            add = 1
        else:
            add = 0
    decimal_list.reverse()

    integer = str(int(integer) + add)
    return make_float(integer, ''.join(map(str, decimal_list)))
