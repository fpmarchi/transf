# instancia o objeto base a ser importado
from abastecimento.polisoftware import Polisoftware
from abastecimento.x7bank import X7Bank
from abastecimento.ctasmart import Ctasmart
from abastecimento.profrota import Profrota
from alltank import AllTank
from truckpag import TruckPag

x7bank = X7Bank()
polisoftware = Polisoftware(min_action=3750, max_action=3799)
ctasmart = Ctasmart(min_action=3900, max_action=3949)
profrota = Profrota.get_instance(min_action=4100, max_action=4149)
alltank = AllTank.get_instance(min_action=4400, max_action=4449)
truckpag = TruckPag(min_action=4550, max_action=4599)
