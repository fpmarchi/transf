from geraljson import getJSON
import json

ACAO_EPTASGA_INICIO = 3500
ACAO_EPTASGA_OBTERABASTECIMENTOS = 3501
ACAO_EPTASGA_FIM = 3550

def requestEptaSgaObterAbastecimentos(reqJSON, properties):
    try:
        req = {}
        req['idEmpresa'] = properties['idEmpresa']
        req['usuario'] = properties['usuario']
        req['senha'] = properties['senha']
        req['identificadorPosto'] = ''
        data = getJSON(reqJSON, 'data')
        hora = data[11:]
        if hora == '':
            hora = '00:00:00'
        data = data[:10]+'T'+hora+'.000Z'
        req['dataGeracao'] = data
        return json.dumps(req), ''
    except Exception as e:
        print('Erro em requestRasterObterAbastecimentos')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseEptaSgaObterAbastecimentos(resp):
    try:
        ret = resp.content.decode('utf-8')
        arrayAbastecimentos = []
        arquivo = ret.split('\n')
        for linha in arquivo:
            if linha != '':
                objAbast = {}
                #campos Necessarios:
                # codFornecedor - pegar do filtro - campo obrigatorio,
                # codFilial = pegar do filtro - campo obrigatório
                # numeroNota = é o codnota, pegar do generator ou fazer um selectMax, analisar no SS,
                # serie = vai ser sempre RQ,
                # dataemi = dataAbast,
                # codUE - pegar do filtro(opcional, se não achar pegar do cadastro veículo (e se não achar no veículo?))
                # codVeiculo = pesquisa pelo identVeic(frota) (mas dá pra esquisar pela placa hein),
                # valor = valorUnitarioLitro,
                # qtde = quantidade
                # obs
                # campos que vai ser usado a principio
                #identVeic = int(linha[1:11])  tar 73003 10/2021 a procura por numero frota estava mt bagunçada pois no sistema terceiro o usuario consegue salvar caracteres alfanumericos no campo frota ex: 002JC, agora é somente por placa
                #objAbast['identVeic'] = identVeic
                dataAbast = linha[80:90]
                objAbast['dataAbast'] = dataAbast
                quantidade = float(linha[117:128].replace(',', '.'))
                objAbast['quantidade'] = quantidade
                valorUnitarioLitro = float(linha[156:162].replace(',', '.'))
                objAbast['valorUnitarioLitro'] = valorUnitarioLitro
                valorTotalAbast = float(linha[162:172].replace(',', '.'))
                objAbast['valorTotalAbast'] = valorTotalAbast
                placaVeiculo = (linha[202:212].replace('-', '')).strip()
                objAbast['placaVeiculo'] = placaVeiculo
                numeroCupom = int(linha[172:182])
                objAbast['numeroCupom'] = numeroCupom
                identProduto = int(linha[77:80])
                objAbast['identProduto'] = identProduto
                identCustomizado = linha[31:51]
                objAbast['identCustomizado'] = identCustomizado
                hodometro = int(linha[11:21])
                objAbast['hodometro'] = hodometro
                horimetro = linha[21:31]
                objAbast['horimetro'] = horimetro
                numeroEmpresa = linha[51:54]
                objAbast['numeroEmpresa'] = numeroEmpresa
                numeroFilial = linha[54:57]
                objAbast['numeroFilial'] = numeroFilial
                numeroPosto = linha[57:62]
                objAbast['numeroPosto'] = numeroPosto
                numeroTanque = linha[62:67]
                objAbast['numeroTanque'] = numeroTanque
                numeroBomba = linha[67:72]
                objAbast['numeroBomba'] = numeroBomba
                numeroBico = linha[72:77]
                objAbast['numeroBico'] = numeroBico
                horaAbast = linha[90:98]
                objAbast['horaAbast'] = horaAbast
                identFrentista = linha[98:117]
                objAbast['identFrentista'] = identFrentista
                cpfCnpjFrentista = linha[128:142]
                objAbast['cpfCnpjFrentista'] = cpfCnpjFrentista
                cpfCnpjMotorista = linha[142:156]
                objAbast['cpfCnpjMotorista'] = cpfCnpjMotorista
                encerranteBomba = linha[182:202]
                objAbast['encerranteBomba'] = encerranteBomba
                cnpjCadastradoNoPosto = linha[212:226]
                objAbast['cnpjCadastradoNoPosto'] = cnpjCadastradoNoPosto
                campoFlex1 = linha[226:236]
                objAbast['campoFlex1'] = campoFlex1
                campoFlex2 = linha[236:246]
                objAbast['campoFlex2'] = campoFlex2
                campoFlex3 = linha[256:266]
                objAbast['campoFlex3'] = campoFlex3
                arrayAbastecimentos.append(objAbast)
        return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>Dados processados com sucesso</msg><json>' + json.dumps(arrayAbastecimentos) + '</json></resp>', ''
    except Exception as e:
        print('Erro em requestRasterObterAbastecimentos')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO '+str(e)
