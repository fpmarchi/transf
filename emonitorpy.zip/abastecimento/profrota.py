# Creating custom exception
import json
from datetime import datetime
from string import Template
from typing import Tuple

from requests import Response

from dispacher import ActionProcessor
from dispacher.action_processor import HttpMethod
from dispacher.decorators import parse_props, handle_exception_factory
from dispacher.dispacher import Callable_cfg
from geral import conditional_key
from geralxml import mount_xml_response


class ProfrotaException(Exception):
    pass


# Classe principal para configuração da ActionProcessor
class Profrota(ActionProcessor):
    # INSTANCIAS
    SYNC_SUPPLY = 4100
    FETCH_INVOICE = 4101

    def __init__(self):
        self.add_callable_records('url', {
                self.SYNC_SUPPLY: (_make_url, _make_defaults('/api/frotista/abastecimento/pesquisa')),
                self.FETCH_INVOICE: (_make_url, _make_defaults('/api/frotista/nota-fiscal/pesquisa')),
        })
        super().__init__()


    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        props = context_req.get('props')
        token = props.get('token')

        return {
                   'Content-type': 'application/json',
                   'Authorization': 'Bearer' + token,
               }, ''

#
#   Códigos independentes de instancia
#
def _profrota_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a Profrota:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    ProfrotaException,
    _profrota_exception_callback,
    any_exception_callback
)


# Funções para obtenção de URLs
@_handle_exception
def _make_defaults(path: str, method: HttpMethod = HttpMethod.POST, use_template: bool = None) -> dict:
    return {
        'path': path,
        **conditional_key('method', method),
        **conditional_key('use_template', use_template)
    }


@_handle_exception
def _make_url(path: str, method: HttpMethod = HttpMethod.GET, use_template: bool = False,
              req: dict = None, url: str = '', props: dict = None) -> Tuple[str, str]:
    if props is None:
        props = {}

    ambiente = 0
    try:
        ambiente = int(props.get('ws_ambiente'))
    except (Exception,):
        pass

    base = url.strip().rstrip('/') or (Profrota.BASE_URL if ambiente == 1 else Profrota.BASE_URL_TEST)
    if use_template:
        t = Template(path)
        url = base + t.substitute(req)
    else:
        url = base + path

    return url, method.name


@_handle_exception
def _make_defaults(path: str, method: HttpMethod = HttpMethod.POST, use_template: bool = None) -> dict:
    return {
        'path': path,
        **conditional_key('method', method),
        **conditional_key('use_template', use_template)
    }


#
#   Instancia limpa e sem configuração
#
_profrota = Profrota()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = _profrota.link_to_factory('request')
_link_to_response = _profrota.link_to_factory('response')


@_link_to_request(_profrota.SYNC_SUPPLY)
@_handle_exception
def _import_supply(req: dict) -> Tuple[str, str]:

    data = {
        "dataInicial": _date_ddmmyy(req.get('data_inicial', '')),
        "dataInicialAlteracao": _date_ddmmyy(req.get('data_inicial_alteracao', '')),
        "dataFinal": _date_ddmmyy(req.get('data_final', '')),
        "dataFinalAlteracao": _date_ddmmyy(req.get('data_final_alteracao', '')),
        "pagina": req.get('quant_paginas', ''),
    }

    return json.dumps(data), ''


@_link_to_request(_profrota.FETCH_INVOICE)
@_handle_exception
def _import_invoice(req: dict) -> Tuple[str, str]:

    data = {
        "cnpjRevenda": req.get('cnpj_revenda', ''),
        "mesAnoPeriodo": req.get('ano_mes', ''),
        "pagina": req.get('numero_pagina', ''),
        "statusEmissaoNotaFiscal": req.get('status_nota_fiscal', ''),
    }

    return json.dumps(data), ''


@_link_to_response(_profrota.SYNC_SUPPLY)
@_handle_exception
def _sync_supply_response(resp: Response):
    resp_json = resp.json()
    success = resp.status_code in [200, 201, 204]
    resp_body = {'sucesso': success}
    if resp.status_code == 401:
        resp_body['sucesso'] = False
        resp_body[
            'msg_erro'] = resp_json.get('mensagens')
    elif success:
        resp_body['conteudo'] = resp_json.get('registros')

    elif 'error' in resp_json or len(resp_json) == 0:
        resp_body['sucesso'] = False
        resp_body[
            'msg_erro'] = 'O cadastro ainda não foi realizado, é necessário cadastrar antes para buscar informações'
    else:
        raise ProfrotaException('Não foi possível encontrar um retorno conhecido da Profrota')
    return mount_xml_response(resp_body), ''


@_link_to_response(_profrota.FETCH_INVOICE)
@_handle_exception
def _import_invoice_response(resp: Response):
    resp_json = resp.json()
    success = resp.status_code in [200, 201, 204]
    if resp.status_code in [400, 401] and type(resp_json) != dict:
        resp_body = {
            'sucesso': False,
            'msg_erro':  resp_json[0]
        }
    elif success:
        resp_body = {
            'sucesso': True,
            'conteudo': resp_json.get('registros')
        }
    elif type(resp_json) == dict:
        resp_body = {
            'sucesso': False,
            'msg_erro': resp_json.get('mensagens')[0]
        }
    else:
        raise ProfrotaException('Não foi possível encontrar um retorno conhecido da Profrota')
    return mount_xml_response(resp_body), ''

def _date_ddmmyy(s: str) -> str:
    try:
        return datetime.strptime(s, "%d/%m/%Y").strftime("%Y-%m-%d")
    except (Exception,):
        return ''