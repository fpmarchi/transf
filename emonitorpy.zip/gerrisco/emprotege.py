import base64
import json
from datetime import datetime
from typing import Tuple

from requests import Response

from dispacher import ActionProcessor
from dispacher.decorators import handle_exception_factory, parse_props
from geral import deep_get, static_vars, safe_cast, conditional_key
from geralxml import mount_xml_response


class EmProtegeException(Exception):
    pass


# Classe base
class EmProtege(ActionProcessor):
    HOST = 'https://sistema.emprotege.com'
    TEST_HOST = 'https://homologacao.emtechlog.com'

    SEND_DRIVER = 3950
    SEND_VEHICLE = 3951
    SEND_GROUP_ANALYSIS = 3952
    REVALIDATE_GROUP_ANALYSIS = 3953
    CHECK_GROUP_ANALYSIS = 3954

    def __init__(self):
        self.add_callable_records('url', {
            self.SEND_DRIVER: self.make_url_assembler('/api-enviar-motorista'),
            self.SEND_VEHICLE: self.make_url_assembler('/api-enviar-veiculo'),
            self.SEND_GROUP_ANALYSIS: self.make_url_assembler('/api-enviar-analise-combo'),
            self.REVALIDATE_GROUP_ANALYSIS: self.make_url_assembler('/api-revalidar-analise-combo'),
            self.CHECK_GROUP_ANALYSIS: self.make_url_assembler('/api-verificar-analise-combo')
        })

        super().__init__()

    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        props = context_req.get('props')
        user = props.get('usuario')
        password = props.get('senha')
        token_bytes: bytes = base64.b64encode(f'{user}:{password}'.encode())

        return {
                   'Authorization': f'Basic {token_bytes.decode("ascii")}',
                   'Content-type': 'application/json'
               }, ''


#
#   Códigos independentes de instancia
#

# Tratamento de exceções
def _emprotege_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a EmProtege:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    EmProtegeException,
    _emprotege_exception_callback,
    any_exception_callback
)

#
#   Códigos dependentes de instancia
#

# Instancia limpa e sem configuração (singleton)
_emprotege = EmProtege()

# Decorators da instancia
_link_to_request = _emprotege.link_to_factory('request')
_link_to_response = _emprotege.link_to_factory('response')


#
# Funções de criação dos envios
#
@_link_to_request(EmProtege.SEND_DRIVER)
@_handle_exception
def _out_send_driver(req: dict) -> Tuple[str, str]:
    req_data = {
        'cpf': req.get('mot_cpf'),
        'nome': req.get('mot_nome'),
        'perfil': 'FROTA' if req.get('mot_funcionario') == 'S' else 'TERCEIRO',
        'filiacao': req.get('mot_nomemae'),
        'naturalidade': req.get('mot_nomecidnascimento'),
        'rg': req.get('mot_rg'),
        'rguf': req.get('mot_orgaorguf'),
        'cnh': req.get('mot_cnh'),
        'numseguranca': req.get('mot_numsegcnh'),
        'categoriacnh': req.get('mot_catcnh'),
        'validadecnh': req.get('mot_datavalidcnh'),
        'datanascimento': datetime.strptime(req.get('mot_datanasc'), '%Y-%m-%d').strftime("%d/%m/%Y")
        if req.get('mot_datavalidcnh')
        else '',
        'telefone': req.get('mot_celularddd') + req.get('mot_celularnumero'),
        'tipo': 'MOTORISTA'
    }

    return json.dumps(req_data), ''


@_link_to_request(EmProtege.SEND_VEHICLE)
@_handle_exception
def _out_send_vehicle(req: dict) -> Tuple[str, str]:
    doc = req.get('prop_cnpjcpf', '').strip()
    if len(doc) == 11:
        doc = '%s%s%s.%s%s%s.%s%s%s-%s%s' % tuple(doc)
    elif len(doc) == 14:
        doc = '%s%s.%s%s%s.%s%s%s/%s%s%s%s-%s%s' % tuple(doc)

    cod_tipo_rastreador = req.get('cod_tipo_rastreador')
    id_rastreador = req.get('id_rastreador')

    if id_rastreador and not cod_tipo_rastreador:
        raise EmProtegeException('É obrigatório informar um tipo de rastreador ao informar um ID de rastreador')

    if cod_tipo_rastreador and not id_rastreador:
        raise EmProtegeException('É obrigatório informar um ID de rastreador ao informar um tipo de rastreador')

    req_data = {
        'placa': req.get('veic_placa'),
        'perfil': _get_profile(req.get('veic_propriedade')),
        'renavam': req.get('veic_renavam'),
        'chassi': req.get('veic_chassi'),
        'antt': req.get('veic_rntrc'),
        'uf': req.get('veic_uf'),
        'cor': req.get('veic_cor'),
        'marca': req.get('veic_marca'),
        'compartimento': _get_bodywork(safe_cast(req.get('cod_tipo_carreta'), int, 1)),
        'tipoveiculo': 'CAVALO' if req.get('veic_cavalo') == 'S' else 'CARRETA',
        'nomeproprietario': req.get('prop_nome'),
        'docproprietario': doc,
        'idrastreador': id_rastreador,
        'tiporastreador': _get_tracker_type(safe_cast(cod_tipo_rastreador, int, 1))
    }

    return json.dumps(req_data), ''


@_link_to_request(EmProtege.SEND_GROUP_ANALYSIS)
@_handle_exception
@static_vars(
    types={
        1: 'NORMAL',
        2: 'AVANÇADA',
        3: 'PRIME'
    },
    modes={
        1: 'NORMAL',
        2: 'BIOMETRIA',
        3: 'NAO ENVIAR'
    }
)
def _out_group_analysis(req: dict) -> Tuple[str, str]:
    modes = _out_group_analysis.modes
    types = _out_group_analysis.types

    doc = req.get('mot_cpf', '').strip()
    if len(doc) == 11:
        doc = '%s%s%s.%s%s%s.%s%s%s-%s%s' % tuple(doc)

    req_data = {
        'cpf': doc,
        'cavalo': req.get('veic_placa'),
        'carreta1': req.get('car1_placa'),
        'carreta2': req.get('car2_placa'),
        'carreta3': req.get('car3_placa'),
        'tipo': types.get(safe_cast(req.get('tipo_pesquisa'), int, 1)),
        'filial': req.get('filial'),
        'datavalid': modes.get(safe_cast(req.get('modo_analise'), int, 1)),
        'checklistVeicular': 'ENVIAR' if req.get('solicitar_checklist') == 'S' else 'NAO ENVIAR'
    }

    return json.dumps(req_data), ''


@_link_to_request(EmProtege.REVALIDATE_GROUP_ANALYSIS, EmProtege.CHECK_GROUP_ANALYSIS)
@_handle_exception
def _out_revalidate_group_analysis(req: dict) -> Tuple[str, str]:
    id_analysis = safe_cast(req.get('id_analise'), int, 0)
    if not id_analysis:
        raise EmProtegeException('É obrigatório informar o id de uma análise.')

    req_data = {
        'combo': id_analysis,
    }

    return json.dumps(req_data), ''


#
# Funções para tratamento de retorno
#

@_link_to_response(EmProtege.CHECK_GROUP_ANALYSIS)
@_handle_exception
def _in_check_group_analysis(resp: Response) -> Tuple[str, str]:
    try:
        ret: dict = deep_get(resp.json(), 'api', {})
    except (Exception,):
        raise EmProtegeException('Erro indefinido ao carregar retorno da EmProtege')

    success = ret.get('status', 0) == 1

    resp_data = {
        'sucesso': success,
    }

    if success:
        del ret['status']
        resp_data['conteudo'] = [
            {
                'entidade': 'mot' if 'cpf_motorista' in data else 'veic',
                'identificador': (data.get('cpf_motorista') or data.get('placa_veiculo', ''))
                .replace('.', '')
                .replace('-', ''),
                'cod_status': _get_status_cod(data.get('status_analise')),
                'cod_situacao': _get_situation_cod(data.get('status_analise')),
                'situacao': data.get('status_analise'),
                'validade': datetime.strptime(data['data_validade'], '%d-%m-%Y').isoformat()
                if data.get('data_validade')
                else ''
            }
            for data in list(ret.values())
            if type(data) is dict
        ]
    else:
        resp_data['msg_erro'] = ret.get('error', '') if ret.get('error') else ret.get('info', '')

    return mount_xml_response(resp_data), ''


@_link_to_response(EmProtege.DEFAULT_FUNCTION)
@_handle_exception
def _in_default(resp: Response, callable_key: int) -> Tuple[str, str]:
    try:
        ret: dict = deep_get(resp.json(), 'api', {})
    except (Exception,):
        raise EmProtegeException('Erro indefinido ao carregar retorno da EmProtege')

    sucesso = ret.get('status', 0) == 1

    resp_data = {
        'sucesso': sucesso,
    }

    if sucesso:
        resp_data['conteudo'] = {
            'msg': ret.get('info') if ret.get('info') else ret.get('aviso', ''),
            **conditional_key('id_analise', ret.get('id-analise-combo')),
            **conditional_key('id_motorista', ret.get('id-motorista')),
            **conditional_key('id_veiculo', ret.get('id-veiculo'))
        }
    elif callable_key == EmProtege.REVALIDATE_GROUP_ANALYSIS:
        resp_data['msg_erro'] = ret.get('error').replace(';', ';\n') if ret.get('error') else ret.get('info', '')
    else:
        resp_data['msg_erro'] = ret.get('error') if ret.get('error') else ret.get('info', '')

    return mount_xml_response(resp_data), ''


#
# Funções utilitárias
#
@static_vars(trackers={
    1: 'AUTOTRAC',
    2: 'AUTOSAT',
    3: 'OMNILINK',
    4: 'ONIXSAT',
    5: 'SASCAR',
    6: 'SIGHRA',
    7: 'POSITRON',
    8: 'OUTRO'
})
def _get_tracker_type(tracker_id: int):
    return _get_tracker_type.trackers.get(tracker_id, 'NAO POSSUI')


@static_vars(profiles={
    'S': 'FROTA',
    'F': 'FROTA',
    'R': 'FROTA',
    'O': 'FROTA',
    'N': 'TERCEIRO',
    'A': 'AGREGADO',
    'M': 'AGREGADO',
    'G': 'AGREGADO'
})
def _get_profile(profile_id: str):
    return _get_profile.profiles.get(profile_id)


@static_vars(bodies={
    1: 'GRADE BAIXA',
    2: 'GRANELEIRA',
    3: 'BAU',
    4: 'BAU FRIGORIFICO',
    5: 'SIDER',
    6: 'OUTRO'
})
def _get_bodywork(bodywork_id: str):
    return _get_bodywork.bodies.get(bodywork_id, 'OUTRO')


@static_vars(status={
    'APROVADO': 3,
    'AGUARDANDO': 2,
    'PENDENTE': 1,
    'APROVADO COM RESTRICAO': 2,
    'NAO INDICADO': 2,
    'REQUER ANALISE': 1
})
def _get_status_cod(situation: str):
    return _get_status_cod.status.get(situation, 1)


@static_vars(situations={
    'APROVADO': 2,
    'AGUARDANDO': 1,
    'PENDENTE': 1,
    'APROVADO COM RESTRICAO': 2,
    'NAO INDICADO': 3,
    'REQUER ANALISE': 1
})
def _get_situation_cod(situation: str):
    return _get_situation_cod.situations.get(situation, 1)
