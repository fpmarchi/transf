from geralsis import getTokenByLoginSenha
import requests
import json
from geral import pfx_to_pem, wsstrtoDDMMAAAA
from GetJson import GetJson

ACAO_SIGA_INICIO = 3550
ACAO_SIGA_GERARTICKET = 3551
ACAO_SIGA_UPLOAD = 3552
ACAO_SIGA_SOLICITARCONSULTA = 3553
ACAO_SIGA_OBTERCONSULTA = 3554
ACAO_SIGA_FIM = 3599
listTokens = [] # cache de tokens


#requestProperties tem que ser:
#login=XXX&senha=XXX

def obterTokenSiga(url, properties, pfx_path, pfx_password):
    try:
        login = properties['login']
        senha = properties['senha']
        token = getTokenByLoginSenha(login, senha, listTokens)
        if token != '':
            return token, ''
        else:
            url += 'access_token'
            headers = {}
            headers['Content-type'] = 'application/json; charset=utf-8'
            req = {}
            req['grant_type'] = 'client_credentials'
            req['client_id'] = login
            req['client_secret'] = senha
            req['scope'] = 'grt'
            #req['type'] = 'account'
            req = json.dumps(req)
            with pfx_to_pem(pfx_path, pfx_password) as cert:
                resp = requests.post(url, cert=cert, data=req, headers=headers)
            retcode = resp.status_code
            ret = resp.content.decode('utf-8')
            if retcode == 200:
                retJSON = json.loads(ret)
                retJSONSiga = GetJson(retJSON)
                getJSON = retJSONSiga.getJSON
                token = getJSON('access_token')
                expiracao = getJSON('expires_in')
                if token is None or token == '':
                    return '', 'Erro ao gerar token, tag access_token vazia: (' + str(retcode) + ')'
                else:
                    listTokens.append([login, senha, token, expiracao])
                    return token, ''
            elif retcode == 401:
                retJSON = json.loads(ret)
                retJSONSiga = GetJson(retJSON)
                getJSON = retJSONSiga.getJSON
                mensagem = getJSON('message')
                return '', '['+str(retcode)+']Erro ao gerar token: ' + mensagem
            else:
                return '', 'Erro ao gerar token: ' + ret
    except Exception as e:
        print('Erro em obterTokenSiga')
        print(e)
        return '', 'Erro ao gerar token'


def preProcessURLSiga(url, reqJSON, requestProperties, pfx_path, pfx_password, codEMonitorAcao):
    try:
        properties = {}
        if requestProperties != '':
            listProperties = list(requestProperties.split('&'))
            for property in listProperties:
                entry = property.split('=')
                properties[entry[0]] = entry[1]

        if (codEMonitorAcao == ACAO_SIGA_OBTERCONSULTA) or (codEMonitorAcao == ACAO_SIGA_GERARTICKET):
            reqJSON = reqJSON.replace('\\"', '"')
            reqJSON = json.loads(reqJSON)
            reqJSONSor = GetJson(reqJSON)
            getJSON = reqJSONSor.getJSON
            ticketId = getJSON('numliberacao')
            if (codEMonitorAcao == ACAO_SIGA_OBTERCONSULTA):
                token, erro = obterTokenSiga(url, properties, pfx_path, pfx_password)
                if erro == '' and token != '':
                    url += 'ticket/'+ticketId+'&access_token='+token
                    return url, '', 'GET'  # url, erro, metodo
                else:
                    return '', erro, ''  # url, erro, metodo
            elif (codEMonitorAcao == ACAO_SIGA_GERARTICKET):
                if ticketId != '':
                    url += 'ticket/' + ticketId
                    return url, '', 'PUT'  # url, erro, metodo
                else:
                    url += 'ticket'
                    return url, '', 'POST'  # url, erro, metodo
        else:
            if codEMonitorAcao == ACAO_SIGA_UPLOAD:
                token, erro = obterTokenSiga(url, properties, pfx_path, pfx_password)
                url += 'upload_base64'
                return url, '', 'POST'  # url, erro, metodo
            elif codEMonitorAcao == ACAO_SIGA_SOLICITARCONSULTA:
                url += 'check'
                return url, '', 'POST'  # url, erro, metodo
            else:
                return url, '', 'POST'  # url, erro, metodo
    except Exception as e:
        print('Erro em preProcessUrlSiga')
        print(e)
        return '', 'Erro ao processar dados para url!', ''

def requestSigaGerarTicket(reqJSON, properties, pfx_path, pfx_password, url):
    try:
        token, erro = obterTokenSiga(url, properties, pfx_path, pfx_password)
        if erro == '' and token != '':
            reqJSONSor = GetJson(reqJSON)
            getJSON = reqJSONSor.getJSON
            origem = getJSON('cidorig_nome') + '-' + getJSON('cidorig_uf')
            destino = getJSON('ciddest_nome') + '-' + getJSON('ciddest_uf')
            req = {}
            req['access_token'] = token
            # req['solicitante_email'] = ''
            req['motorista'] = getJSON('mot_nome')
            req['tipo'] = 'NOVA SOLICITAÇÃO'  # fixo
            req['ddr'] = 'NÃO'  # mandar fixo NÃO, segundo a SIGA não usa mais
            req['cpf'] = getJSON('mot_cpf')
            req['origem'] = origem
            req['destino'] = destino
            req['placa_cavalo'] = getJSON('veic_placa')
            if getJSON('car1_placa') != '':
                req['placa_carreta_1'] = getJSON('car1_placa')
            if getJSON('car2_placa') != '':
                req['placa_carreta_2'] = getJSON('car2_placa')
            if getJSON('car3_placa') != '':
                req['placa_carreta_3'] = getJSON('car3_placa')
            req['renavam_cavalo'] = getJSON('veic_renavam')
            req['cpfcnpjproprietario_cavalo'] = getJSON('prop_cnpjcpf')
            req['cpfcnpjportadorantt_cavalo'] = getJSON('prop_cnpjcpf') # vou mandar sem arrendatario por eqto
            # req['cpfcnpjarrendatario_cavalo'] = getJSON('conh_prop_cnpjcpf')
            req['renavam_carreta_1'] = getJSON('car1_renavam')
            req['cpfcnpjproprietario_carreta_1'] = getJSON('car1_prop_cnpjcpf')
            req['cpfcnpjportadorantt_carreta_1'] = getJSON('car1_prop_cnpjcpf')
            # req['cpfcnpjarrendatario_carreta_1'] = getJSON('conh_car1_prop_cnpjcpf')
            req['renavam_carreta_2'] = getJSON('car2_renavam')
            req['cpfcnpjproprietario_carreta_2'] = getJSON('car2_prop_cnpjcpf')
            req['cpfcnpjportadorantt_carreta_2'] = getJSON('car2_prop_cnpjcpf')
            # req['cpfcnpjarrendatario_carreta_2'] = getJSON('conh_car2_prop_cnpjcpf')
            req['renavam_carreta_3'] = getJSON('car3_renavam')
            req['cpfcnpjproprietario_carreta_3'] = getJSON('car3_prop_cnpjcpf')
            req['cpfcnpjportadorantt_carreta_3'] = getJSON('car3_prop_cnpjcpf')
            # req['cpfcnpjarrendatario_carreta_3'] = getJSON('conh_car3_prop_cnpjcpf')
            req['tipo_mercadoria'] = getJSON('descmerc')
            req['telefone'] = getJSON('mot_foneddd') + getJSON('mot_fonenumero')
            req['tomador_servicos'] = 'tomador' #colocar tomador
            # req['gr_externa'] = ''  # vou mandar sem gr externa por enquanto
            req['valor_estimada_carga'] = getJSON('valormerc')
            req['historico_transportadora'] = 'PRIMEIRA VIAGEM' # ver como fazer
            req['tempo_viagem'] = getJSON('tempoviagemdias')  # ver como fazer o certo é puxando do tempo da rota ou da viagem, puxar do filtro
            req['nome_proprietario'] = getJSON('prop_nome')
            req['telefone_proprietario'] = getJSON('prop_foneddd') + getJSON('prop_fonenumero')
            # req['observacoes_proprietario'] = ''
            req['ref_pes_nome_1'] = getJSON('mot_referencia_pessoal1_nome') if getJSON('mot_referencia_pessoal1_nome') != '' else "NENHUM"
            req['ref_pes_nome_2'] = getJSON('mot_referencia_pessoal2_nome') if getJSON('mot_referencia_pessoal2_nome') != '' else "NENHUM"
            req['ref_pes_nome_3'] = getJSON('mot_referencia_pessoal3_nome') if getJSON('mot_referencia_pessoal3_nome') != '' else "NENHUM"
            # req['ref_pes_nome_4'] = ''
            # req['ref_pes_nome_5'] = ''
            # req['ref_pes_nome_6'] = ''
            req['ref_pes_parentesco_1'] = getJSON('mot_referencia_pessoal1_parentesco') if getJSON('mot_referencia_pessoal1_parentesco') != '' else "NENHUM"
            req['ref_pes_parentesco_2'] = getJSON('mot_referencia_pessoal2_parentesco') if getJSON('mot_referencia_pessoal2_parentesco') != '' else "NENHUM"
            req['ref_pes_parentesco_3'] = getJSON('mot_referencia_pessoal3_parentesco') if getJSON('mot_referencia_pessoal3_parentesco') != '' else "NENHUM"
            # req['ref_pes_parentesco_4'] = ''
            # req['ref_pes_parentesco_5'] = ''
            # req['ref_pes_parentesco_6'] = ''
            req['ref_pes_telefone_1'] = getJSON('mot_referencia_pessoal1_telefone') if getJSON('mot_referencia_pessoal1_telefone') != '' else "NENHUM"
            req['ref_pes_telefone_2'] = getJSON('mot_referencia_pessoal2_telefone') if getJSON('mot_referencia_pessoal2_telefone') != '' else "NENHUM"
            req['ref_pes_telefone_3'] = getJSON('mot_referencia_pessoal3_telefone') if getJSON('mot_referencia_pessoal3_telefone') != '' else "NENHUM"
            # req['ref_pes_telefone_4'] = ''
            # req['ref_pes_telefone_5'] = ''
            # req['ref_pes_telefone_6'] = ''
            req['ref_pes_observacoes'] = ''
            req['ref_com_nome_1'] = getJSON('mot_referencia_profissional1_nome') if getJSON('mot_referencia_profissional1_nome') != '' else "NENHUM"
            req['ref_com_nome_2'] = getJSON('mot_referencia_profissional2_nome') if getJSON('mot_referencia_profissional2_nome') != '' else "NENHUM"
            req['ref_com_nome_3'] = getJSON('mot_referencia_profissional3_nome') if getJSON('mot_referencia_profissional3_nome') != '' else "NENHUM"
            # req['ref_com_nome_4'] = ''
            # req['ref_com_nome_5'] = ''
            # req['ref_com_nome_6'] = ''
            req['ref_com_telefone_1'] = getJSON('mot_referencia_pessoal1_telefone') if getJSON('mot_referencia_pessoal1_telefone') != '' else "NENHUM"
            req['ref_com_telefone_2'] = getJSON('mot_referencia_pessoal2_telefone') if getJSON('mot_referencia_pessoal2_telefone') != '' else "NENHUM"
            req['ref_com_telefone_3'] = getJSON('mot_referencia_pessoal3_telefone') if getJSON('mot_referencia_pessoal3_telefone') != '' else "NENHUM"
            # req['ref_com_telefone_4'] = 'NENHUM'
            # req['ref_com_telefone_5'] = 'NENHUM'
            # req['ref_com_telefone_6'] = 'NENHUM'
            req['ref_com_observacoes'] = ''
            req['motoristaendlogradouro'] = getJSON('mot_endereco')
            req['motoristaendnumero'] = getJSON('mot_numero')
            req['motoristaendbairro'] = getJSON('mot_bairro')
            req['motoristaendcomplemento'] = getJSON('mot_complemento')
            req['motoristaendcidade'] = getJSON('mot_cidadeend')
            req['motoristaendestado'] = getJSON('mot_ufend')
            req['antt_cavalo'] = "SIM" if getJSON('veic_rntrc') != '' else "NÃO"
            req['antt_carreta_1'] = "SIM" if getJSON('car1_rntrc') != '' else "NÃO"
            req['antt_carreta_2'] = "SIM" if getJSON('car1_rntrc') != '' else "NÃO"
            req['antt_carreta_3'] = "SIM" if getJSON('car1_rntrc') != '' else "NÃO"
            req['quantidade_viagem'] = '1'  # boa pergunta como vou descobrir isso pelo sistema?
            req['ultima_viagem'] = wsstrtoDDMMAAAA(getJSON('dataultimaviagem'))
            req['motorista_identidade'] = getJSON('mot_rg')
            req['motorista_identidade_emissor'] = getJSON('mot_orgaorg')
            req['motorista_data_nascimento'] = wsstrtoDDMMAAAA(getJSON('mot_datanasc')) # formato DD/MM/AAAA
            req['motorista_nome_mae'] = getJSON('mot_nomemae')
            req['motorista_cnh_registro'] = getJSON('mot_cnh')
            req['motorista_cnh_data_validade'] = wsstrtoDDMMAAAA(getJSON('mot_datavalidcnh'))
            req['motorista_cnh_categoria'] = getJSON('mot_catcnh')
            req['motorista_cnh_local_emissao'] = getJSON('mot_catcnh')
            req['motorista_cnh_formulario'] = getJSON('mot_cidadecnh')
            req['motorista_cnh_data_emissao'] = getJSON('mot_cidadecnh')
            req['motorista_cnh_controle_seguranca'] = getJSON('mot_dataprimcnh')
            req['motorista_cnh_mop_ear'] = '' # nao sei oq é isso
            return json.dumps(req), ''

        else:
            return '', erro
    except Exception as e:
        print('Erro em requestSigaGerarTicket')
        print(e)
        return '', 'Erro ao gerar envio para Siga!'


def responseSigaGerarTicket(resp):
    try:
        retcode = resp.status_code
        ret = resp.content.decode('utf-8')
        msgFinalSucesso = ''
        msgFinalErro = ''
        if (retcode == 400) :
            retJSON = json.loads(ret)
            retJSONSiga = GetJson(retJSON)
            getJSON = retJSONSiga.getJSON
            errors = getJSON('errors')
            msgFinalErro = '[400] Erro ao Gerar Ticket: '
            for erro in errors:
                msgFinalErro += '[' + erro +': ' + errors[erro] + '] '
        elif (retcode == 200) or (retcode == 201):
            retJSON = json.loads(ret)
            retJSONSiga = GetJson(retJSON)
            getJSON = retJSONSiga.getJSON
            data = getJSON('data')
            retJSONData = GetJson(data)
            getJSONData = retJSONData.getJSON
            ticketId = getJSONData('ticketid')
            numLiberacao = '<numLiberacao>' + str(ticketId) + '</numLiberacao>'
            msgFinalSucesso = '[SIGA] Ticket gerado/atualizado com sucesso! '
        if msgFinalSucesso != '':
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msgFinalSucesso + '</msg>' + numLiberacao + '</resp>', ''
        else:
            return '', msgFinalErro
    except Exception as e:
        print('Erro em responseSigaGerarTicket')
        print(e)
        return '', 'Erro ao tratar retorno da siga!'


def requestSigaUpload(reqJSON, properties, pfx_path, pfx_password, url):
    try:
        token, erro = obterTokenSiga(url, properties, pfx_path, pfx_password)
        if erro == '' and token != '':
            reqJSONSor = GetJson(reqJSON)
            getJSON = reqJSONSor.getJSON
            req = {}
            req['access_token'] = token
            req['ticketid'] = getJSON('numliberacao')
            #req['solicitante_email'] = properties['login']
            #req['gr_externa_tela'] = ''
            qtdeDocsVeic = int(getJSON('veic_qtdedocs'))
            for i in range(1, qtdeDocsVeic + 1, 1):
                nomeDoc = getJSON('veic_doc'+str(i)+'_nome')
                arq = getJSON('veic_doc'+str(i)+'_arq')
                if ('CRLV' in nomeDoc) and (not (
                  ('CAR1' in nomeDoc) or ('C1' in nomeDoc) or
                  ('CAR2' in nomeDoc) or ('C2' in nomeDoc) or
                  ('CAR3' in nomeDoc) or ('C3' in nomeDoc)
                )):
                    req['documento_cavalo'] = arq
                elif ('CRLV' in nomeDoc) and (('CAR1' in nomeDoc) or ('C1' in nomeDoc)):
                    req['documento_carreta_1'] = arq
                elif ('CRLV' in nomeDoc) and (('CAR2' in nomeDoc) or ('C2' in nomeDoc)):
                    req['documento_carreta_2'] = arq
                elif ('CRLV' in nomeDoc) and (('CAR2' in nomeDoc) or ('C2' in nomeDoc)):
                    req['documento_carreta_3'] = arq
                elif 'DETRAN' in nomeDoc:
                    req['consulta_detran_crlv'] = arq
                elif 'DENATRAN' in nomeDoc:
                    req['consulta_denatran_crlv'] = arq
                elif ('FOTO' in nomeDoc) and (not ('CONJUNTO' in nomeDoc)):
                    req['foto_cavalo'] = arq
                elif ('FOTO' in nomeDoc) and ('CONJUNTO' in nomeDoc):
                    req['foto_conjunto'] = arq
                else:
                    req['demais_documentos'] = arq
            qtdeDocsMot = int(getJSON('mot_qtdedocs'))
            for i in range(1, qtdeDocsMot + 1, 1):
                nomeDoc = getJSON('mot_doc' + str(i) + '_nome')
                arq = getJSON('mot_doc'+str(i)+'_arq')
                if 'CNH' in nomeDoc:
                    req['cnh'] = arq
                else:
                    req['demais_documentos'] = arq
            #req['tela_viagens'] = ''
            return json.dumps(req), ''
        else:
            return '', erro
    except Exception as e:
        print('Erro em requestSigaUpload')
        print(e)
        return '', 'Erro ao gerar envio para Siga!'


def responseSigaUpload(resp):
    try:
        retcode = resp.status_code
        ret = resp.content.decode('utf-8')
        msgFinalSucesso = ''
        msgFinalErro = ''
        if (retcode == 401) or (retcode == 400) or (retcode == 200) or (retcode == 201):
            retJSON = json.loads(ret)
            retJSONSiga = GetJson(retJSON)
            getJSON = retJSONSiga.getJSON
            if (retcode == 401):
                message = getJSON('message')
                msgFinalErro = '[401] Erro ao Gerar Ticket: ' + message
            elif (retcode == 400):
                msgFinalErro = ret
            elif (retcode == 200) or (retcode == 201):
                msgFinalSucesso = '['+str(retcode)+']' + 'Anexos enviados com sucesso!'
        if msgFinalSucesso != '':
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msgFinalSucesso + '</msg></resp>', ''
        else:
            return '', msgFinalErro
    except Exception as e:
        print('Erro em responseSigaUpload')
        print(e)
        return '', 'Erro ao tratar retorno da siga!'


def requestSigaSolicitarConsulta(reqJSON, properties, pfx_path, pfx_password, url):
    try:
        token, erro = obterTokenSiga(url, properties, pfx_path, pfx_password)
        if erro == '' and token != '':
            reqJSONSor = GetJson(reqJSON)
            getJSON = reqJSONSor.getJSON
            req = {}
            req['access_token'] = token
            req['motorista'] = getJSON('mot_nome')
            req['tipo'] = 'CONSULTA'
            req['ddr'] = 'NÃO'
            req['cpf'] = getJSON('mot_cpf')
            req['origem'] = getJSON('cidorig_nome') + '-' + getJSON('cidorig_uf')
            req['destino'] = getJSON('ciddest_nome') + '-' + getJSON('ciddest_uf')
            req['placa_cavalo'] = getJSON('veic_placa')
            if getJSON('car1_placa') != '':
                req['placa_carreta_1'] = getJSON('car1_placa')
            if getJSON('car2_placa') != '':
                req['placa_carreta_2'] = getJSON('car2_placa')
            if getJSON('car3_placa') != '':
                req['placa_carreta_3'] = getJSON('car3_placa')
            return json.dumps(req), ''
        else:
            return '', erro
    except Exception as e:
        print('Erro em requestSigaSolicitarConsulta')
        print(e)
        return '', 'Erro ao gerar envio para Siga!'


def responseSigaSolicitarConsulta(resp):
    try:
        retcode = resp.status_code
        ret = resp.content.decode('utf-8')
        msgFinalSucesso = ''
        msgFinalErro = ''
        if (retcode == 401) or (retcode == 400) or (retcode == 200) or (retcode == 201):
            retJSON = json.loads(ret)
            retJSONSiga = GetJson(retJSON)
            getJSON = retJSONSiga.getJSON
            if (retcode == 200) or (retcode == 201):
                data = getJSON('data')
                retJSONData = GetJson(data)
                getJSONData = retJSONData.getJSON
                ticketId = getJSONData('ticketid')
                needsupdate = getJSONData('needsupdate')
                if ticketId != '':
                    msgFinalSucesso = 'Solicitação de consulta gerada com sucesso!'
                    numLiberacao = '<numLiberacao>' + str(ticketId) + '</numLiberacao>'
                else:
                    msgFinalErro = '['+str(retcode)+']Erro! Solicitação não gerada!: '
                    if needsupdate != '':
                        msgFinalErro += 'needsUpdate ='+str(needsupdate)
            elif retcode == 400:
                errors = getJSON('errors')
                msgFinalErro = '[400] Erro ao Solicitar Consulta: '
                for erro in errors:
                    msgFinalErro += '[' + erro + ': ' + errors[erro] + '] '
            elif retcode == 401:
                message = getJSON('message')
                msgFinalErro = '[401] Erro ao Solicitar Consulta: ' + message
        if msgFinalSucesso != '':
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msgFinalSucesso + '</msg>' + numLiberacao + '</resp>', ''
        else:
            return '', msgFinalErro
    except Exception as e:
        print('Erro em responseSigaSolicitarConsulta')
        print(e)
        return '', 'Erro ao tratar retorno da siga!'


def responseSigaObterConsulta(resp):
    try:
        retcode = resp.status_code
        ret = resp.content.decode('utf-8')
        msgFinalSucesso = ''
        msgFinalErro = ''
        if (retcode == 401) or (retcode == 400) or (retcode == 200) or (retcode == 201):
            retJSON = json.loads(ret)
            retJSONSiga = GetJson(retJSON)
            getJSON = retJSONSiga.getJSON
            if (retcode == 200) or (retcode == 201):
                data = getJSON('data')
                retJSONData = GetJson(data)
                getJSONData = retJSONData.getJSON
                status = getJSONData('ticketstatus') # Open, Wait for Response,
                resultado = getJSONData('resultado')
                protocolo = getJSONData('protocolo')
                motivopendencia = getJSONData('motivo_pendencia')
                comments = getJSONData('comments')
                comentarios = ''
                for comment in comments:
                    retJSONComment = GetJson(comment)
                    getJSONComment = retJSONComment.getJSON
                    comentarios += '[COMENTÁRIO: '+getJSONComment('comment') + ']'
                if status == 'Open':
                    msgFinalSucesso += '[STATUS = Aberta] Aguarde alguns instantes e consulte novamente mais tarde' + comentarios
                else:
                    if status == 'Wait for Response':
                        msgFinalSucesso += '[STATUS = Pendente] Verifique o que precisa ser ajustado e utilize a opção "Atualizar Solicitação"'
                        msgFinalSucesso += '[RESULTADO = '+resultado+'] ' + '[PROTOCOLO = '+protocolo+']' + '[MOTIVO = ' + motivopendencia+']' + comentarios
                    elif status == 'Closed':
                        msgFinalSucesso += '[STATUS = Fechada]"'
                        msgFinalSucesso += '[RESULTADO = ' + resultado + '] ' + '[PROTOCOLO = ' + protocolo + ']' + '[MOTIVO = ' + motivopendencia + ']' + comentarios
                    else:
                        msgFinalSucesso += '[STATUS = '+status+']'
                        msgFinalSucesso += '[RESULTADO = ' + resultado + '] ' + '[PROTOCOLO = ' + protocolo + ']' + '[MOTIVO = ' + motivopendencia + ']' + comentarios

            elif retcode == 400:
                errors = getJSON('errors')
                msgFinalErro = '[400] Erro ao Solicitar Consulta: '
                for erro in errors:
                    msgFinalErro += '[' + erro + ': ' + errors[erro] + '] '
            elif retcode == 401:
                message = getJSON('message')
                msgFinalErro = '[401] Erro ao Solicitar Consulta: ' + message

        if msgFinalSucesso != '':
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msgFinalSucesso + '</msg></resp>', ''
        else:
            if msgFinalErro == '':
                msgFinalErro = 'Erro não identificado no tratamento do retorno'
            return '', msgFinalErro
    except Exception as e:
        print('Erro em responseSigaObterConsulta')
        print(e)
        return '', 'Erro ao tratar retorno da siga!'