import json
from string import Template
from typing import Tuple
from xml.sax.saxutils import escape

from requests import Response
import base64
from ActionProcessor import ActionProcessor, parse_props, HttpMethod, handle_exception_factory
from geral import *
from geralxml import mount_xml_response


class SmartLoadException(Exception):
    pass


# Classe base
class SmartLoad(ActionProcessor):
    # INSTANCIAS
    BASE_URL = 'https://smartfunctions-smartload-br.azurewebsites.net'
    BASE_URL_TEST = 'https://smartfunctions-smartload-br.azurewebsites.net'

    REGISTER_CTE = 4300
    TRANSMIT_MDFE = 4301
    CANCEL_CTE = 4302

    def __init__(self):
        self.add_callable_records('url', {
            self.REGISTER_CTE: self.make_url_assembler(
                '/averbacoes',
                extract_host=True,
                use_template=True
            ),
            self.TRANSMIT_MDFE: self.make_url_assembler(
                '/averbacoes',
                extract_host=True,
                use_template=True
            ),
            self.CANCEL_CTE: self.make_url_assembler(
                '/averbacoes',
                extract_host=True,
                use_template=True
            )
        })

        super().__init__()

    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        props = context_req.get('props')
        token = props.get('token')

        return {
            'token': token,
            'Content-type': 'text/plain',
        }, ''


#
#   Códigos independentes de instancia
#
def _smartload_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a Krona:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    SmartLoadException,
    _smartload_exception_callback,
    any_exception_callback
)


# Funções para obtenção de URLs
@_handle_exception
def _make_defaults(path: str, method: HttpMethod = HttpMethod.POST, use_template: bool = None) -> dict:
    return {
        'path': path,
        **conditional_key('method', method),
        **conditional_key('use_template', use_template)
    }

#
#   Instancia limpa e sem configuração
#
_smartload = SmartLoad()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = _smartload.link_to_factory('request')
_link_to_response = _smartload.link_to_factory('response')


@_link_to_request(_smartload.REGISTER_CTE)
@_handle_exception
def _register_cte(req: dict) -> Tuple[str, str]:
    xml_base64 = req.get('xml_cte_smart_load', '')
    xml = base64.b64decode(xml_base64).decode('utf-8')
    xml = xml.replace('\n','')
    xml = xml.replace('\r', '')
    #xml = xml.replace('<tpAmb>2</tpAmb>', '<tpAmb>1</tpAmb>')
    return xml, ''


@_link_to_request(_smartload.TRANSMIT_MDFE)
@_handle_exception
def _transmit_mdfe(req: dict) -> Tuple[str, str]:
    xml_base64 = req.get('xml_mdfe_smart_load', '')
    xml = base64.b64decode(xml_base64).decode('utf-8')
    xml = xml.replace('\n', '')
    xml = xml.replace('\r', '')
    return xml, ''


@_link_to_request(_smartload.CANCEL_CTE)
@_handle_exception
def _register_cte(req: dict) -> Tuple[str, str]:
    xml_base64 = req.get('xml_cancelar_cte_smart_load', '')
    xml = base64.b64decode(xml_base64).decode('utf-8')
    xml = xml.replace('\n','')
    xml = xml.replace('\r', '')

    return xml, ''


@_link_to_response(_smartload.REGISTER_CTE, _smartload.CANCEL_CTE, _smartload.TRANSMIT_MDFE)
def _in_register_cte(resp: Response) -> Tuple[str, str]:
    ret = resp.json()
    ret_code = resp.status_code

    if ret_code in [200, 201, 203]:
        resp_data = {
            'sucesso': True,
            'conteudo': {
                'conteudo': ret
            }
        }
    elif ret_code in [400, 403, 422]:
        resp_data = {
            'sucesso': False,
            'msg_erro': ret.get('message') + '\n'+ ret.get('solution'),
        }
    else:
        resp_data = {
            'sucesso': False,
            'msg_erro': ret.get('message')
        }

    return mount_xml_response(resp_data), ''
