from geraljson import getJSON
import geralxml

ACAO_SERASA_INICIO = 3000
ACAO_SERASA_CONSULTARPF = 3001
ACAO_SERASA_CONSULTARPJ = 3002
ACAO_GLOG_FIM = 3049

def requestSerasaConsultarPessoa(reqJSON,codEMonitorAcao):
    cnpjCpf = getJSON(reqJSON, 'cliente_cnpjcpf')
    if codEMonitorAcao == ACAO_SERASA_CONSULTARPF:
        nomeMetodo = 'INFOBUSCA_PF'
        nomeRetorno = 'retornoPF'
        nomeCampo = 'cpf'
        requestConsultar = requestSerasaConsultarPF(reqJSON)
    else:
        nomeMetodo = 'INFOBUSCA_PJ'
        nomeRetorno = 'retornoPJ'
        nomeCampo = 'cnpj'
        requestConsultar = requestSerasaConsultarPJ(reqJSON)
    reqXML = \
        '<' + nomeMetodo + ' xmlns="http://tempuri.org/">' + \
            geralxml.createtag('logon', getJSON(reqJSON, 'empcom_campoaux1')) + \
            geralxml.createtag('senha', getJSON(reqJSON, 'empcom_campoaux2')) + \
            geralxml.createtag(nomeCampo, cnpjCpf) + \
            '<' + nomeRetorno + '>' + \
                requestConsultar + \
            '</' + nomeRetorno + '>' + \
        '</' + nomeMetodo + '>'
    return reqXML, ''


def requestSerasaConsultarPF(reqJSON):
    reqXML = \
        geralxml.createtag2('nome', ' xmlns=""', 'true') + \
        geralxml.createtag2('endereco', ' xmlns=""', 'true') + \
        geralxml.createtag2('telefone', ' xmlns=""', 'true') + \
        geralxml.createtag2('datanascimento', ' xmlns=""', 'true') + \
        geralxml.createtag2('sexo', ' xmlns=""', 'true') + \
        geralxml.createtag2('nomemae', ' xmlns=""', 'true') + \
        geralxml.createtag2('situacaocadastral', ' xmlns=""', 'true') + \
        geralxml.createtag2('renda', ' xmlns=""', 'true') + \
        geralxml.createtag2('triagemrisco', ' xmlns=""', 'true') + \
        geralxml.createtag2('socioempresa', ' xmlns=""', 'true') + \
        geralxml.createtag2('profissao', ' xmlns=""', 'true') + \
        geralxml.createtag2('estadocivil', ' xmlns=""', 'true') + \
        geralxml.createtag2('escolaridade', ' xmlns=""', 'true') + \
        geralxml.createtag2('representantelegal', ' xmlns=""', 'true')
    return reqXML

def requestSerasaConsultarPJ(reqJSON):
    reqXML = \
        geralxml.createtag2('razaosocial', ' xmlns=""', 'true') + \
        geralxml.createtag2('nomefantasia', ' xmlns=""', 'true') + \
        geralxml.createtag2('dataabertura', ' xmlns=""', 'true') + \
        geralxml.createtag2('naturezajuridica', ' xmlns=""', 'true') + \
        geralxml.createtag2('cnae', ' xmlns=""', 'true') + \
        geralxml.createtag2('endereco', ' xmlns=""', 'true') + \
        geralxml.createtag2('telefone', ' xmlns=""', 'true') + \
        geralxml.createtag2('situacaocadastral', ' xmlns=""', 'true') + \
        geralxml.createtag2('porte', ' xmlns=""', 'true') + \
        geralxml.createtag2('quadrosocial', ' xmlns=""', 'true') + \
        geralxml.createtag2('representantelegal', ' xmlns=""', 'true') + \
        geralxml.createtag2('sintegra', ' xmlns=""', 'true') + \
        geralxml.createtag2('faturamento', ' xmlns=""', 'true') + \
        geralxml.createtag2('funcionarios', ' xmlns=""', 'true') + \
        geralxml.createtag2('indicadoroperacionalidade', ' xmlns=""', 'true') + \
        geralxml.createtag2('codigoibge', ' xmlns=""', 'true') + \
        geralxml.createtag2('simplesnacional', ' xmlns=""', 'true') + \
        geralxml.createtag2('triagemrisco', ' xmlns=""', 'true') + \
        geralxml.createtag2('matrizfilial', ' xmlns=""', 'true')
    return reqXML


def responseSerasaConsultarPessoa(resp,codEMonitorAcao):
    return '', resp