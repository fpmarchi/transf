import base64
import json
import logging
from typing import Tuple

import requests

from GetJson import GetJson
from consist import *
from entity import proprietario, motorista, veiculo
from geral import *
from geralxml import mount_xml_response

ACAO_TRIZY_ADDPEDIDO = 3450
ACAO_TRIZY_ADDPROP = 3451
ACAO_TRIZY_ADDMOT = 3452
ACAO_TRIZY_ADD_PROPMOTVEIC = 3453
ACAO_TRIZY_SENDCONHEC = 3454
ACAO_TRIZY_SENDMANIF = 3455
ACAO_TRIZY_SEND_ORDEMCAR = 3456
ACAO_TRIZY_GET_PROPMOTVEIC = 3457
ACAO_TRIZY_GET_COMPROVANTES = 3458
ACAO_TRIZY_GET_VIAGEMFINALIZADA = 3459
ACAO_TRIZY_CANC_ORDEMCAR = 3460
ACAO_TRIZY_CANC_PEDIDO = 3461
ACAO_TRIZY_SEND_COMPROVANTE = 3462
ACAO_TRIZY_SEND_IMAGENS = 3463
ACAO_TRIZY_GET_MOT_IMGS = 3464

ACAO_TRIZY_FIM = 3499


def preProcessRequestPropertiesTrizy(headers, requestProperties):
    props = dict(entry.split("=", 1) for entry in requestProperties.split("&"))
    headers['Authorization'] = 'Bearer ' + props.get('token', '')
    headers['Content-Type'] = 'application/json'

    return headers, ''


def requestTrizyAddPedido(reqJSON):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}
        origem = {}
        entregas = {}
        parameters = {}

        req['module'] = 'M3002API'
        req['operation'] = 'apiMultiplasEntregas'

        parameters['identificador'] = getJSON('ped_numero')
        parameters['excluir'] = '0'
        parameters['tipo'] = '2'

        nomefilial = getJSON('ped_filial_nome')
        if "INTERSITE" in nomefilial:
            parameters['agencia'] = 'Sat'  # para teste da IS
        else:
            parameters['agencia'] = getJSON('ped_codunidadeemb')
        parameters['data_carregamento'] = getJSON('ped_datacoleta')
        parameters['observacao'] = getJSON('ped_observacao')
        parameters['valor_por'] = getJSON('ped_modonegociacao')
        parameters['valor'] = getJSON('ped_precotonmot')
        parameters['peso_bruto'] = getJSON('ped_pesobruto')
        parameters['peso_bruto_min'] = getJSON('ped_pesodigitadominimo')
        parameters['peso_bruto_max'] = getJSON('ped_pesodigitado')
        parameters['pedagio_pago_embarcador'] = getJSON('ped_pedagiopagoembarq')
        parameters['cnpj_cpf_cliente'] = getJSON('ped_cliente_cnpjcpf')
        parameters[
            'lote_descricao'] = f'{getJSON("ped_numero")} - De {getJSON("ped_rem_nome")} para {getJSON("ped_dest_nome")}'

        if getJSON('ped_rem_latitude') or getJSON('ped_rem_longitude'):
            #if not getJSON('ped_rem_cnpjcpf').strip():
            origem['incompleto'] = 1
        else:
            #if not getJSON('ped_rem_cnpjcpf').strip():
            origem['incompleto'] = 0

        if getJSON('ped_rem_cidadeuf') != '' and '-' in getJSON('ped_rem_cidadeuf'):
            uf = getJSON('ped_rem_cidadeuf').rsplit('-', 1)[1].strip()
            origem['uf'] = uf if len(uf) == 2 else ''
        origem['municipio'] = getJSON('ped_rem_ibge')

        if getJSON('ped_rem_latitude') or getJSON('ped_rem_longitude'):
            origem['bairro'] = '.'
            origem['logradouro'] = '.'
            origem['numero'] = '.'
            origem['complemento'] = '.'
        else:
            origem['bairro'] = getJSON('ped_rem_bairro')
            origem['logradouro'] = getJSON('ped_rem_endereco')
            origem['numero'] = getJSON('ped_rem_numero')
            origem['complemento'] = getJSON('ped_rem_complemento')

        origem['latitude'] = getJSON('ped_rem_latitude')
        origem['longitude'] = getJSON('ped_rem_longitude')
        parameters['origem'] = origem

        entregasarray = []
        if getJSON('ped_dest_latitude') or getJSON('ped_dest_longitude'):
            #if not getJSON('ped_dest_cnpjcpf').strip():
            entregas['incompleto'] = 1
        else:
            #if not getJSON('ped_dest_cnpjcpf').strip():
            entregas['incompleto'] = 0

        entregas['ordem'] = '1'
        entregas['data'] = getJSON('ped_dataentrega')
        if getJSON('ped_dest_cidadeuf') != '' and '-' in getJSON('ped_dest_cidadeuf'):
            uf = getJSON('ped_dest_cidadeuf').rsplit('-', 1)[1].strip()
            entregas['uf'] = uf if len(uf) == 2 else ''  # Campo Grande-MS ->pegar só o MS
        entregas['municipio'] = getJSON('ped_dest_ibge')

        if getJSON('ped_dest_latitude') or getJSON('ped_dest_longitude'):
            entregas['bairro'] = '.'
            entregas['logradouro'] = '.'
            entregas['numero'] = '.'
            entregas['complemento'] = '.'
        else:
            entregas['bairro'] = getJSON('ped_dest_bairro')
            entregas['logradouro'] = getJSON('ped_dest_endereco')
            entregas['numero'] = getJSON('ped_dest_numero')
            entregas['complemento'] = getJSON('ped_dest_complemento')

        entregas['mercadoria'] = getJSON('ped_mercadoria')
        entregas['cod_ncm'] = getJSON('ped_ncm_mercadoria')
        entregas['latitude'] = getJSON('ped_dest_latitude')
        entregas['longitude'] = getJSON('ped_dest_longitude')
        entregasarray.append(entregas)
        parameters['entregas'] = entregasarray

        tipo_carroceriaArray = []
        if getJSON('ped_quantcarroceria') != '':
            quantCarroceria = int(getJSON('ped_quantcarroceria'))

            for i in range(1, quantCarroceria + 1, 1):
                tipo_carroceria = getJSON('ped_veiculo_carroceria' + str(i))
                tipo_carroceriaArray.append(tipo_carroceria)

        if tipo_carroceriaArray:
            parameters['tipo_carroceria_id'] = tipo_carroceriaArray

        tipo_carretaArray = []
        if getJSON('ped_quanttipocarreta') != '':
            quantCarreta = int(getJSON('ped_quanttipocarreta'))

            for i in range(1, quantCarreta + 1, 1):
                tipo_carreta = getJSON('ped_veiculo_tipocarreta' + str(i))
                tipo_carretaArray.append(tipo_carreta)

        if tipo_carretaArray:
            parameters['tipo_carreta_id'] = tipo_carretaArray

        req['parameters'] = parameters

        req = json.dumps(req)
        return req, ''
    except Exception as e:
        print('Erro em requestTrizyAddPedido')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO 2'


def requestTrizyCancelaPedido(data_req) -> Tuple[str, str]:
    try:
        parameters: dict = {}
        req: dict = {
            'module': 'M3002API',
            'operation': 'apiDelLote',
            'parameters': parameters
        }

        parameters['identificador'] = data_req.get('ped_numero', '')

        return json.dumps(req), ''
    except Exception as e:
        logging.warning('Trizy |> Erro ao criar requisição para operação apiDelLote:')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def requestTrizyAddCredenciamento(reqJSON):
    try:

        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        erros = consistTrizyPropMotVeic(reqJSON)
        if erros != '':
            return '', erros

        veiculo = {}
        motorista = {}
        parameters = {}
        req = {}

        req['module'] = 'M3002API'
        req['operation'] = 'apiCredenciamento'

        motorista['documento'] = getJSON('mot_cpf')
        motorista['estrangeiro'] = '0'

        motorista['sexo'] = getJSON('mot_sexo').strip() or 'M'
        motorista['nome'] = getJSON('mot_nome')
        motorista['nome_pai'] = getJSON('mot_nomepai')
        motorista['nome_mae'] = getJSON('mot_nomemae')
        motorista['pis'] = getJSON('mot_pis')
        motorista['mopp'] = getJSON('')  # ver depois
        motorista['data_nascimento'] = getJSON('mot_datanasc')
        motorista['email'] = getJSON('mot_email')
        cpfcnpjmot = getJSON('mot_cpf')
        if cpfcnpjmot != '' and len(cpfcnpjmot) > 11:
            motorista['pessoa_juridica'] = 1  # true or false
        else:
            motorista['pessoa_juridica'] = 0
        motorista['num_registro'] = getJSON('mot_numsegcnh')
        motorista['cnh'] = getJSON('mot_cnh')
        motorista['num_formulario'] = getJSON('mot_cnhformulario')
        motorista['uf_cnh'] = getJSON('mot_ufcnh')
        motorista['municipio_cnh'] = getJSON('mot_cnhcidadeibge')
        motorista['categoria'] = getJSON('mot_catcnh')
        motorista['data_validade_cnh'] = wsstrtoAAAAMMDD(getJSON('mot_datavalidcnh'))
        motorista['data_emissao_cnh'] = wsstrtoAAAAMMDD(getJSON('mot_cnhemissao'))
        motorista['primeira_habilitacao'] = wsstrtoAAAAMMDD(getJSON('mot_dataprimcnh'))
        motorista['rg'] = getJSON('mot_rg')
        motorista['orgao_emissor_rg'] = getJSON('mot_orgaorg')
        motorista['orgao_emissor_rg_uf'] = getJSON('mot_orgaorguf')
        motorista['residencia'] = getJSON('mot_codibge')
        motorista['cep'] = getJSON('mot_cep')
        motorista['uf'] = getJSON('mot_ufcidendereco')
        motorista['endereco'] = getJSON('mot_endereco')
        motorista['numero'] = getJSON('mot_numero')
        motorista['bairro'] = getJSON('mot_bairro')
        motorista['complemento'] = getJSON('mot_complemento')
        motorista['telefone'] = getJSON('mot_foneddd') + getJSON('mot_fonenumero')
        motorista['celular'] = getJSON('mot_celularddd') + getJSON('mot_celularnumero')
        motorista['uf_naturalidade'] = getJSON('mot_ufcidnascimento')
        motorista['municipio_naturalidade'] = getJSON('mot_ibgecidnascimento')
        parameters['motorista'] = motorista

        arrayveiculo = []
        veiculo['ordem'] = 1  # cavalo
        veiculo['cod_veiculo'] = getJSON('veic_placa')
        veiculo['placa'] = getJSON('veic_placa')
        veiculo['uf'] = getJSON('veic_uf')
        veiculo['ano'] = getJSON('veic_anofab')
        veiculo['renavam'] = getJSON('veic_renavam')
        veiculo['marca'] = getJSON('veic_marca')
        veiculo['modelo'] = getJSON('veic_modelo')
        veiculo['chassi'] = getJSON('veic_chassi')
        veiculo['cor_predominante'] = getJSON('veic_cor')
        veiculo['numero_eixos'] = getJSON('veic_quanteixos')
        veiculo['tipo_rastreador'] = ''
        veiculo['capacidade'] = ''
        veiculo['municipio'] = getJSON('veic_codibge')
        veiculo['tipo_carroceria'] = getJSON('veic_tipocarr')
        veiculo['tipo_carreta'] = getJSON('veic_tipoveic')
        veiculo['cnae'] = ''
        # prop
        veiculo['inscricao_estadual'] = getJSON('prop_ie')
        veiculo['atividade_fiscal'] = getJSON('')  # ver depois
        propcgc = getJSON('prop_cnpjcpf')
        if len(propcgc) > 11:
            veiculo['proprietario_tipo'] = 2  # juridico
        else:
            veiculo['proprietario_tipo'] = 1  # fisico
        veiculo['proprietario_cpf_cnpj'] = getJSON('prop_cnpjcpf')
        veiculo['proprietario_nome'] = getJSON('prop_nome')
        veiculo['proprietario_telefone'] = getJSON('prop_foneddd') + getJSON('prop_fonenumero')
        veiculo['proprietario_celular'] = getJSON('prop_celularddd') + getJSON('prop_celularnumero')
        veiculo['proprietario_endereco'] = getJSON('prop_endereco')
        veiculo['proprietario_numero'] = getJSON('prop_numero')
        veiculo['proprietario_complemento'] = getJSON('prop_complemento')
        veiculo['proprietario_bairro'] = getJSON('prop_bairro')
        veiculo['proprietario_residencia'] = getJSON('prop_codibge')
        veiculo['proprietario_uf'] = getJSON('prop_uf')
        veiculo['proprietario_cep'] = getJSON('prop_cep')
        veiculo['proprietario_pis'] = getJSON('prop_cei')
        veiculo['proprietario_email'] = getJSON('prop_email')
        veiculo['antt_responsavel'] = getJSON('prop_nome')
        veiculo['antt_cpf_cnpj'] = getJSON('prop_cnpjcpf')
        veiculo['antt_rntrc'] = getJSON('prop_rntrc')

        catantt = getJSON('prop_tipoantt')
        if catantt == 'TAC':
            veiculo['antt_categoria'] = 1  # campo numérico, valores: 1 - Autônomo, 2 - Cooperativa, 3 - Empresa
        elif catantt == 'CTC':
            veiculo['antt_categoria'] = 2
        elif catantt == 'ETC':
            veiculo['antt_categoria'] = 3

        veiculo['antt_cadastro_desde'] = getJSON('')
        veiculo['antt_valido_ate'] = wsstrtoAAAAMMDD(getJSON('prop_validaderntrc'))
        tipoprop = getJSON('prop_cnpjcpf')
        if len(tipoprop) > 11:
            veiculo['antt_tipo'] = 1
        else:
            veiculo['antt_tipo'] = 2
        arrayveiculo.append(veiculo)

        qtdCarretas = countCarretas(reqJSON)
        if qtdCarretas > 0:
            for i in range(1, qtdCarretas + 1, 1):
                carreta = {}
                carreta['ordem'] = i + 1
                carreta['cod_veiculo'] = getJSON('car' + str(i) + '_placa')
                carreta['placa'] = getJSON('car' + str(i) + '_placa')
                carreta['uf'] = getJSON('car' + str(i) + '_uf')
                carreta['ano'] = getJSON('car' + str(i) + '_anofab')
                carreta['renavam'] = getJSON('car' + str(i) + '_renavam')
                carreta['marca'] = getJSON('car' + str(i) + '_marca')
                carreta['modelo'] = getJSON('car' + str(i) + '_modelo')
                carreta['chassi'] = getJSON('car' + str(i) + '_chassi')
                carreta['cor_predominante'] = getJSON('car' + str(i) + '_cor')
                carreta['numero_eixos'] = getJSON('car' + str(i) + '_quanteixos')
                carreta['tipo_rastreador'] = ''
                carreta['capacidade'] = ''
                carreta['municipio'] = getJSON('car' + str(i) + '_codibge')
                carreta['tipo_carroceria'] = getJSON('car' + str(i) + '_tipocarr')
                carreta['tipo_carreta'] = getJSON('car' + str(i) + '_tipoveic')
                carreta['cnae'] = ''
                # prop
                carreta['inscricao_estadual'] = getJSON('car' + str(i) + '_prop_ie')
                carreta['atividade_fiscal'] = getJSON('')  # ver depois

                cgcprop = getJSON('car' + str(i) + '_prop_cnpjcpf')
                if len(cgcprop) > 11:
                    carreta['proprietario_tipo'] = 2
                else:
                    carreta['proprietario_tipo'] = 1

                carreta['proprietario_cpf_cnpj'] = getJSON('car' + str(i) + '_prop_cnpjcpf')
                carreta['proprietario_nome'] = getJSON('car' + str(i) + '_prop_nome')
                carreta['proprietario_telefone'] = getJSON('car' + str(i) + '_prop_foneddd') + getJSON(
                    'car' + str(i) + '_prop_fonenumero')
                carreta['proprietario_celular'] = getJSON('car' + str(i) + '_prop_celularddd') + getJSON(
                    'car' + str(i) + '_prop_celularnumero')
                carreta['proprietario_endereco'] = getJSON('car' + str(i) + '_prop_endereco')
                carreta['proprietario_numero'] = getJSON('car' + str(i) + '_prop_numero')
                carreta['proprietario_complemento'] = getJSON('car' + str(i) + '_prop_complemento')
                carreta['proprietario_bairro'] = getJSON('car' + str(i) + '_prop_bairro')
                carreta['proprietario_residencia'] = getJSON('car' + str(i) + '_prop_codibge')
                carreta['proprietario_uf'] = getJSON('car' + str(i) + '_prop_uf')
                carreta['proprietario_cep'] = getJSON('car' + str(i) + '_prop_cep')
                carreta['proprietario_pis'] = getJSON('car' + str(i) + '_prop_cei')
                carreta['proprietario_email'] = getJSON('car' + str(i) + '_prop_email')
                carreta['antt_responsavel'] = getJSON('car' + str(i) + '_prop_nome')
                carreta['antt_cpf_cnpj'] = getJSON('car' + str(i) + '_prop_cnpjcpf')
                carreta['antt_rntrc'] = getJSON('car' + str(i) + '_prop_rntrc')

                catantt = getJSON('car' + str(i) + '_prop_tipoantt')
                if catantt == 'TAC':
                    carreta['antt_categoria'] = 1  # campo numérico, valores: 1 - Autônomo, 2 - Cooperativa, 3 - Empresa
                elif catantt == 'CTC':
                    carreta['antt_categoria'] = 2
                elif catantt == 'ETC':
                    carreta['antt_categoria'] = 3

                carreta['antt_cadastro_desde'] = getJSON('')
                carreta['antt_valido_ate'] = wsstrtoAAAAMMDD(getJSON('car' + str(i) + '_prop_validaderntrc'))
                tipoprop = getJSON('prop_cnpjcpf')
                if len(tipoprop) > 11:  # campo numerico, valores: 1 - Pessoa física, 2 - Pessoa jurídica
                    carreta['antt_tipo'] = 2
                else:
                    carreta['antt_tipo'] = 1
                arrayveiculo.append(carreta)

        parameters['veiculos'] = arrayveiculo

        req['parameters'] = parameters

        req = json.dumps(req)
        return req, ''
    except Exception as e:
        print('Erro em requestTrizyApiCredenciamento')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO 2'


def countCarretas(reqJSON):
    jsonSor = GetJson(reqJSON)
    getJSON = jsonSor.getJSON

    i = 0
    if getJSON('car1_anofab') != '':
        i += 1
    if getJSON('car2_anofab') != '':
        i += 1
    if getJSON('car3_anofab') != '':
        i += 1

    return i


def consistTrizyPropMotVeic(reqJSON):
    # jsonSor = GetJson(reqJSON)
    # getJSON = jsonSor.getJSON
    ret = ''
    retprop = proprietario.consistCadastrarProprietario(reqJSON)
    if retprop != '':
        ret = 'PROPRIETARIO\n' + retprop
    retmot = motorista.consistCadastrarMotorista(reqJSON)
    if retmot != '':
        ret = '\nMOTORISTA\n' + retmot
    retveic = veiculo.consistCadastrarVeiculo(reqJSON, 'veic_')
    if retveic != '':
        ret = '\nVEICULO\n' + retveic

    rettmo2 = consistEmpty(reqJSON, 'mot_orgaorguf', 'uf do orgão rg')
    rettmo2 += consistEmpty(reqJSON, 'mot_datavalidcnh', 'data validade da cnh')

    ret += rettmo2

    return ret


def requestTrizyAddAcordo(reqJSON, url, requestProperties):
    try:

        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        erros = consistTrizyPropMotVeic(reqJSON)
        if erros != '':
            return '', erros

        parameters = {}
        motorista = {}
        veiculo = {}

        req, errors = getJsonTrizyAddPDF(reqJSON)

        if req != '':
            headers = {}
            headers, errors = preProcessRequestPropertiesTrizy(headers, requestProperties)
            resp = requests.post(url, data=req, headers=headers, verify=False)
            retcode = resp.status_code
            resp = resp.content.decode('utf-8')
            if retcode != 200 or retcode != 204:
                responseTrizy(req, resp)

        req = {}

        req['module'] = 'M3002API'
        req['operation'] = 'apiFechaAcordo'
        parameters['adicionar_proposta'] = 1
        parameters['reservar_motorista'] = getJSON('reservar_motorista')
        parameters['identificador'] = getJSON('ordemcar_numeropedido')
        motorista['documento'] = getJSON('mot_cpf')
        motorista['estrangeiro'] = '0'
        motorista['sexo'] = getJSON('mot_sexo').strip() or 'M'
        motorista['nome'] = getJSON('mot_nome')
        motorista['nome_pai'] = getJSON('mot_nomepai')
        motorista['nome_mae'] = getJSON('mot_nomemae')
        motorista['pis'] = getJSON('mot_pis')
        motorista['mopp'] = ''
        motorista['data_nascimento'] = getJSON('mot_datanasc')
        motorista['email'] = getJSON('mot_email')
        cpfcnpjmot = getJSON('mot_cpf')
        if cpfcnpjmot != '' and len(cpfcnpjmot) > 11:
            motorista['pessoa_juridica'] = 1  # true or false
        else:
            motorista['pessoa_juridica'] = 0
        motorista['num_registro'] = getJSON('mot_numsegcnh')
        motorista['cnh'] = getJSON('mot_cnh')
        motorista['num_formulario'] = getJSON('mot_cnhformulario')
        motorista['uf_cnh'] = getJSON('mot_ufcnh')
        motorista['municipio_cnh'] = getJSON('mot_cnhcidadeibge')
        motorista['categoria'] = getJSON('mot_catcnh')
        motorista['data_validade_cnh'] = wsstrtoAAAAMMDD(getJSON('mot_datavalidcnh'))
        motorista['data_emissao_cnh'] = wsstrtoAAAAMMDD(getJSON('mot_cnhemissao'))
        motorista['primeira_habilitacao'] = wsstrtoAAAAMMDD(getJSON('mot_dataprimcnh'))
        motorista['rg'] = getJSON('mot_rg')
        motorista['orgao_emissor_rg'] = getJSON('mot_orgaorg')
        motorista['orgao_emissor_rg_uf'] = getJSON('mot_orgaorguf')
        motorista['residencia'] = getJSON('mot_codibge')
        motorista['cep'] = getJSON('mot_cep')
        motorista['uf'] = getJSON('mot_ufcidendereco')
        motorista['endereco'] = getJSON('mot_endereco')
        motorista['numero'] = getJSON('mot_numero')
        motorista['bairro'] = getJSON('mot_bairro')
        motorista['complemento'] = getJSON('mot_complemento')
        motorista['telefone'] = getJSON('mot_foneddd') + getJSON('mot_fonenumero')
        motorista['celular'] = getJSON('mot_celularddd') + getJSON('mot_celularnumero')
        parameters['motorista'] = motorista

        arrayveiculo = []
        veiculo['ordem'] = 1  # cavalo
        veiculo['cod_veiculo'] = getJSON('veic_placa')
        veiculo['placa'] = getJSON('veic_placa')
        veiculo['uf'] = getJSON('veic_uf')
        veiculo['ano'] = getJSON('veic_anofab')
        veiculo['renavam'] = getJSON('veic_renavam')
        veiculo['marca'] = getJSON('veic_marca')
        veiculo['modelo'] = getJSON('veic_modelo')
        veiculo['chassi'] = getJSON('veic_chassi')
        veiculo['cor_predominante'] = getJSON('veic_cor')
        veiculo['numero_eixos'] = getJSON('veic_quanteixos')
        veiculo['tipo_rastreador'] = ''
        veiculo['capacidade'] = ''
        veiculo['municipio'] = getJSON('veic_codibge')
        veiculo['tipo_carroceria'] = getJSON('veic_tipocarr')
        veiculo['tipo_carreta'] = getJSON('veic_tipoveic')
        veiculo['cnae'] = ''
        # prop
        veiculo['inscricao_estadual'] = getJSON('prop_ie')
        veiculo['atividade_fiscal'] = getJSON('')  # ver depois
        propcgc = getJSON('prop_cnpjcpf')
        if len(propcgc) > 11:
            veiculo['proprietario_tipo'] = 2  # juridico
        else:
            veiculo['proprietario_tipo'] = 1  # fisico
        veiculo['proprietario_cpf_cnpj'] = getJSON('prop_cnpjcpf')
        veiculo['proprietario_nome'] = getJSON('prop_nome')
        veiculo['proprietario_telefone'] = getJSON('prop_foneddd') + getJSON('prop_fonenumero')
        veiculo['proprietario_celular'] = getJSON('prop_celularddd') + getJSON('prop_celularnumero')
        veiculo['proprietario_endereco'] = getJSON('prop_endereco')
        veiculo['proprietario_numero'] = getJSON('prop_numero')
        veiculo['proprietario_complemento'] = getJSON('prop_complemento')
        veiculo['proprietario_bairro'] = getJSON('prop_bairro')
        veiculo['proprietario_residencia'] = getJSON('prop_codibge')
        veiculo['proprietario_uf'] = getJSON('prop_uf')
        veiculo['proprietario_cep'] = getJSON('prop_cep')
        veiculo['proprietario_pis'] = getJSON('prop_cei')
        veiculo['proprietario_email'] = getJSON('prop_email')
        veiculo['antt_responsavel'] = getJSON('prop_nome')
        veiculo['antt_cpf_cnpj'] = getJSON('prop_cnpjcpf')
        veiculo['antt_rntrc'] = getJSON('prop_rntrc')

        catantt = getJSON('prop_tipoantt')
        if catantt == 'TAC':
            veiculo['antt_categoria'] = 1  # campo numérico, valores: 1 - Autônomo, 2 - Cooperativa, 3 - Empresa
        elif catantt == 'CTC':
            veiculo['antt_categoria'] = 2
        elif catantt == 'ETC':
            veiculo['antt_categoria'] = 3

        veiculo['antt_cadastro_desde'] = getJSON('')
        veiculo['antt_valido_ate'] = wsstrtoAAAAMMDD(getJSON('prop_validaderntrc'))
        tipoprop = getJSON('prop_cnpjcpf')
        if len(tipoprop) > 11:
            veiculo['antt_tipo'] = 1
        else:
            veiculo['antt_tipo'] = 2
        arrayveiculo.append(veiculo)

        qtdCarretas = countCarretas(reqJSON)
        if qtdCarretas > 0:
            for i in range(1, qtdCarretas + 1, 1):
                carreta = {}
                carreta['ordem'] = i + 1
                carreta['cod_veiculo'] = getJSON('car' + str(i) + '_placa')
                carreta['placa'] = getJSON('car' + str(i) + '_placa')
                carreta['uf'] = getJSON('car' + str(i) + '_uf')
                carreta['ano'] = getJSON('car' + str(i) + '_anofab')
                carreta['renavam'] = getJSON('car' + str(i) + '_renavam')
                carreta['marca'] = getJSON('car' + str(i) + '_marca')
                carreta['modelo'] = getJSON('car' + str(i) + '_modelo')
                carreta['chassi'] = getJSON('car' + str(i) + '_chassi')
                carreta['cor_predominante'] = getJSON('car' + str(i) + '_cor')
                carreta['numero_eixos'] = getJSON('car' + str(i) + '_quanteixos')
                carreta['tipo_rastreador'] = ''
                carreta['capacidade'] = ''
                carreta['municipio'] = getJSON('car' + str(i) + '_codibge')
                carreta['tipo_carroceria'] = getJSON('car' + str(i) + '_tipocarr')
                carreta['tipo_carreta'] = getJSON('car' + str(i) + '_tipoveic')
                carreta['cnae'] = ''
                # prop
                carreta['inscricao_estadual'] = getJSON('car' + str(i) + '_prop_ie')
                carreta['atividade_fiscal'] = getJSON('')  # ver depois

                cgcprop = getJSON('car' + str(i) + '_prop_cnpjcpf')
                if len(cgcprop) > 11:
                    carreta['proprietario_tipo'] = 2
                else:
                    carreta['proprietario_tipo'] = 1

                carreta['proprietario_cpf_cnpj'] = getJSON('car' + str(i) + '_prop_cnpjcpf')
                carreta['proprietario_nome'] = getJSON('car' + str(i) + '_prop_nome')
                carreta['proprietario_telefone'] = getJSON('car' + str(i) + '_prop_foneddd') + getJSON(
                    'car' + str(i) + '_prop_fonenumero')
                carreta['proprietario_celular'] = getJSON('car' + str(i) + '_prop_celularddd') + getJSON(
                    'car' + str(i) + '_prop_celularnumero')
                carreta['proprietario_endereco'] = getJSON('car' + str(i) + '_prop_endereco')
                carreta['proprietario_numero'] = getJSON('car' + str(i) + '_prop_numero')
                carreta['proprietario_complemento'] = getJSON('car' + str(i) + '_prop_complemento')
                carreta['proprietario_bairro'] = getJSON('car' + str(i) + '_prop_bairro')
                carreta['proprietario_residencia'] = getJSON('car' + str(i) + '_prop_codibge')
                carreta['proprietario_uf'] = getJSON('car' + str(i) + '_prop_uf')
                carreta['proprietario_cep'] = getJSON('car' + str(i) + '_prop_cep')
                carreta['proprietario_pis'] = getJSON('car' + str(i) + '_prop_cei')
                carreta['proprietario_email'] = getJSON('car' + str(i) + '_prop_email')
                carreta['antt_responsavel'] = getJSON('car' + str(i) + '_prop_nome')
                carreta['antt_cpf_cnpj'] = getJSON('car' + str(i) + '_prop_cnpjcpf')
                carreta['antt_rntrc'] = getJSON('car' + str(i) + '_prop_rntrc')

                catantt = getJSON('car' + str(i) + '_prop_tipoantt')
                if catantt == 'TAC':
                    carreta['antt_categoria'] = 1  # campo numérico, valores: 1 - Autônomo, 2 - Cooperativa, 3 - Empresa
                elif catantt == 'CTC':
                    carreta['antt_categoria'] = 2
                elif catantt == 'ETC':
                    carreta['antt_categoria'] = 3

                carreta['antt_cadastro_desde'] = getJSON('')
                carreta['antt_valido_ate'] = wsstrtoAAAAMMDD(getJSON('car' + str(i) + '_prop_validaderntrc'))
                tipoprop = getJSON('prop_cnpjcpf')
                if len(tipoprop) > 11:  # campo numerico, valores: 1 - Pessoa física, 2 - Pessoa jurídica
                    carreta['antt_tipo'] = 2
                else:
                    carreta['antt_tipo'] = 1
                arrayveiculo.append(carreta)

        parameters['veiculos'] = arrayveiculo

        req['parameters'] = parameters
        req = json.dumps(req)
        return req, ''
    except Exception as e:
        print('Erro em requestTrizyAddAcordo')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO 2 ' + str(e)


def requestTrizyCancelaAcordo(data_req: dict) -> Tuple[str, str]:
    try:
        proposta_id = 0
        try:
            proposta_id = int(data_req.get('ordemcar_proposta', 0))
        except (ValueError, TypeError):
            pass

        data = {
            'module': 'M3002API',
            'operation': 'apiCancelarAcordo',
            'parameters': {
                'proposta_id': int(proposta_id),
                'motivo': data_req.get('ordemcar_motivo', ''),
                'apagar_proposta': data_req.get('ordemcar_apagar_proposta', 0),
                'apagar_dashboard': data_req.get('ordemcar_apagar_dashboard', 0),
            }
        }

        return json.dumps(data), ''
    except Exception as e:
        logging.warning('Trizy |> Erro ao criar requisição para operação apiCancelarAcordo.')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO ' + str(e)


def requestTrizyAddProp(reqJSON):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}
        endereco = {}
        parameters = {}
        telefone = {}

        req['module'] = 'M103'
        req['operation'] = 'manipulaProprietarioX'

        # caso seja pessoa fisica
        parameters['origem_request'] = ''
        parameters['cod_pessoa'] = "null",

        parameters['nome'] = getJSON('prop_nome')
        parameters['cod_sexo'] = getJSON('prop_sexo')
        parameters['data_nascimento'] = getJSON('prop_datanasc')
        parameters['cartao_repom'] = "null"
        parameters['nome_pai'] = getJSON('prop_nomepai')
        parameters['nome_mae'] = getJSON('prop_nomemae')
        parameters['pis_pasep_nit'] = getJSON('prop_cei')

        # caso seja pessoa juridica
        parameters['inscricao_estadual'] = getJSON('prop_ie')
        parameters['cod_regime_tributario'] = 1
        parameters['tipo_lucro'] = getJSON('prop_cei')

        parameters['cnpj_cpf'] = getJSON('prop_cnpjcpf')
        parameters['responsavel_tac'] = getJSON('')
        parameters['cpf_cnpj_tac'] = getJSON('')
        parameters['tipo_tac'] = getJSON('')
        parameters['tipo_transportador'] = getJSON('prop_tipoantt')
        parameters['razao_social'] = ''
        parameters['cnae'] = ''
        parameters['cod_atividade_fiscal'] = ''
        parameters['rntrc_tac'] = ''
        parameters['data_vencimento_rntrc_tac'] = getJSON('prop_validade_rntrc')
        parameters['data_emissao_rntrc_tac'] = ''

        if getJSON('prop_foneddd') != '':
            ArrayTelefones = []
            telefone['telefone_ddd'] = getJSON('prop_foneddd')
            telefone['telefone'] = getJSON('prop_fonenumero')
            telefone['telefone_contato'] = getJSON('prop_contato')
            telefone['telefone_tipo_id'] = 1  # pegar estes codigo com a trizy
            telefone['telefone_padrao'] = getJSON('')
            ArrayTelefones.append(telefone)
            parameters['telefones'] = ArrayTelefones

        if getJSON('prop_celularddd') != '':
            ArrayTelefones2 = []
            telefone['telefone_ddd'] = getJSON('prop_celularddd')
            telefone['telefone'] = getJSON('prop_celularnumero')
            telefone['telefone_contato'] = getJSON('prop_contato')
            telefone['telefone_tipo_id'] = 1  # pegar estes codigo com a trizy
            telefone['telefone_padrao'] = getJSON('')
            ArrayTelefones2.append(telefone)
            parameters['telefones'] = ArrayTelefones2

        arrayEnderecos = []
        endereco['cod_ibge'] = getJSON('prop_codibge')
        endereco['pais_id'] = getJSON('')
        endereco['cep'] = getJSON('prop_cep')
        endereco['logradouro'] = getJSON('prop_endereco')
        endereco['numero'] = getJSON('prop_numero')
        endereco['complemento'] = getJSON('prop_complemento')
        endereco['bairro'] = getJSON('prop_bairro')
        endereco['inscricao_estadual'] = getJSON('prop_ie')
        endereco['cod_endereco_tipo'] = "null"
        endereco['endereco_padrao'] = "null"
        arrayEnderecos.append(endereco)
        parameters['enderecos'] = arrayEnderecos

        req['parameters'] = parameters

        req = json.dumps(req)
        return req, ''
    except Exception as e:
        print('Erro em requestTrizyAddPedido')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO 2'


def requestTrizyAddMot(req):
    try:
        data = {
            "module": 'M3002API',
            "operation": 'apiCadastroMotorista',
            "parameters": {
                "bairro": req.get('mot_bairro'),
                "categoria": req.get('mot_catcnh'),
                "celular": req.get('mot_celularddd', '') + req.get('mot_celularnumero', ''),
                "cep": req.get('mot_cep', ''),
                "cnh": req.get('mot_cnh', ''),
                "complemento": req.get('mot_complemento', ''),
                "cpf": req.get('mot_cpf', ''),
                "data_emissao_cnh": req.get('mot_cnhemissao', ''),
                "data_nascimento": req.get('mot_datanasc', ''),
                "data_validade_cnh": wsstrtoAAAAMMDD(req.get('mot_datavalidcnh')),
                "endereco": req.get('mot_endereco', ''),
                "nome": req.get('mot_nome', ''),
                "numero": req.get('mot_numero', ''),
                "num_formulario": req.get('mot_cnhformulario', ''),
                "orgao_emissor_rg": req.get('mot_orgaorg', ''),
                "orgao_emissor_rg_uf": req.get('mot_orgaorguf', ''),
                "pessoa_juridica": '1' if len(req.get('prop_cnpjcpf', '')) > 11 else '2',
                "primeira_habilitacao": wsstrtoAAAAMMDD(req.get('mot_dataprimcnh')),
                "residencia": req.get('mot_codibge', ''),
                "rg": req.get('mot_rg', ''),
                "sexo": req.get('mot_sexo', ''),
                "uf": req.get('mot_ufcidendereco', ''),
                "uf_cnh": req.get('mot_ufcnh', ''),

            }
        }
        return json.dumps(data), ''
    except Exception as e:
        print('Erro em responseTrizyAddPedido')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA GER. RISCO TRIZY' + str(e)


def requestTrizyAddComprovante(reqJSON, url, requestProperties):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        arquivo = ''
        pesosaida = ''
        numerointerno = ''
        descdoc = ''
        nomearquivo = ''
        tipodoc = ''
        numerodocmdfe = ''
        numerodoccte = ''
        propostaID = ''
        data_entrega = ''
        data_carregamento = ''

        if getJSON('conh_pdf') != '' or getJSON('manif_pdf') != '':
            req, errors = getJsonTrizyAddPDF(reqJSON)
            if req != '':
                headers = {}
                headers, errors = preProcessRequestPropertiesTrizy(headers, requestProperties)
                resp = requests.post(url, data=req, headers=headers, verify=False)
                retcode = resp.status_code
                resp = resp.content.decode('utf-8')
                if retcode != 200 or retcode != 204:
                    responseTrizy(req, resp)

        parameters = {}
        req = {}

        now = datetime.now()
        if getJSON('conh_xmlass') != '':
            arquivo = getJSON('conh_xmlass')
            numerododoc = getJSON('conh_numconhec')
            pesosaida = getJSON('conh_pesosaida')
            numerointerno = getJSON('conh_numero')
            descdoc = 'Cte ' + str(numerododoc) + ' Emitido em ' + now.strftime("%d/%m/%Y %H:%M:%S")
            nomearquivo = 'Cte_' + str(numerododoc) + '.xml'
            propostaID = getJSON('conh_pedidolog')
            tipodoc = 9  # 1-Comprovante, 2-CTE, 3-Ordem de Carregamento, 4-MDF-e, 5-Contrato 10-XML_MDFE 9-XML_CTE
            data_entrega = getJSON('conh_dataprevisaodescarga')
            data_carregamento = getJSON('conh_datafimcarregamento')
        elif getJSON('manif_xmlass') != '':
            arquivo = getJSON('manif_xmlass')
            numerododoc = getJSON('manif_numeromanif')
            pesosaida = getJSON('manif_pesosaida')
            numerointerno = getJSON('manif_numero')
            descdoc = 'MDFe ' + str(numerododoc) + ' Emitido em ' + now.strftime("%d/%m/%Y %H:%M:%S")
            nomearquivo = 'MDFe_' + str(numerododoc) + '.xml'
            propostaID = getJSON('manif_pedidolog')
            tipodoc = 10
        elif getJSON('ordemcar_pdf') != '':
            arquivo = getJSON('ordemcar_pdf')
            numerododoc = getJSON('ordemcar_numeropedido')
            pesosaida = '0'
            numerointerno = getJSON('ordemcar_numeropedido')
            descdoc = 'OrdemCar ' + str(numerododoc) + ' Emitido em ' + now.strftime("%d/%m/%Y %H:%M:%S")
            nomearquivo = 'OrdemCar_' + str(numerododoc) + '.pdf'
            propostaID = getPropostaId(getJSON('ordemcar_pedidolog'))
            tipodoc = 3
        else:
            return '', 'Nenhum arquivo encontrado'

        req['module'] = 'M3002API'
        req['operation'] = 'apiEnvioComprovante'
        parameters['proposta_id'] = propostaID
        parameters['descricao'] = descdoc
        parameters['nome_arquivo'] = nomearquivo
        parameters['tipo_documento'] = tipodoc
        parameters['arquivo'] = arquivo
        parameters['num_cte'] = numerodoccte
        parameters['num_mdfe'] = numerodocmdfe
        parameters['peso_carregado'] = pesosaida
        parameters['id_externo'] = numerointerno
        if data_entrega:
            parameters['data_entrega'] = _format_iso_from_date(data_entrega)
        if data_carregamento:
            parameters['data_carregamento'] = _format_iso_from_date(data_carregamento)
        req['parameters'] = parameters

        req = json.dumps(req)
        return req, ''
    except Exception as e:
        print('Erro em responseTrizyEnvioComprovante')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA GER. RISCO TRIZY' + str(e)


def getJsonTrizyAddPDF(reqJSON):
    try:

        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        parameters = {}
        req = {}

        arquivo = ''
        pesosaida = ''
        numerointerno = ''
        descdoc = ''
        nomearquivo = ''
        tipodoc = ''
        numerodocmdfe = ''
        numerodoccte = ''
        propostaID = ''
        data_entrega = ''
        data_carregamento = ''

        now = datetime.now()
        if getJSON('conh_pdf') != '':
            arquivo = getJSON('conh_pdf')
            numerododoc = getJSON('conh_numconhec')
            pesosaida = getJSON('conh_pesosaida')
            numerointerno = getJSON('conh_numero')
            descdoc = 'Cte ' + str(numerododoc) + ' Emitido em ' + now.strftime("%d/%m/%Y %H:%M:%S")
            nomearquivo = 'Cte_' + str(numerododoc) + '.pdf'
            propostaID = getJSON('conh_pedidolog')
            tipodoc = 2  # 1-Comprovante, 2-CTE, 3-Ordem de Carregamento, 4-MDF-e, 5-Contrato 10-XML_MDFE 9-XML_CTE
            data_entrega = getJSON('conh_datafimdescarga')
            data_carregamento = getJSON('conh_datafimcarregamento')
        elif getJSON('manif_pdf') != '':
            arquivo = getJSON('manif_pdf')
            numerododoc = getJSON('manif_numeromanif')
            pesosaida = getJSON('manif_pesosaida')
            numerointerno = getJSON('manif_numero')
            descdoc = 'MDFe ' + str(numerododoc) + ' Emitido em ' + now.strftime("%d/%m/%Y %H:%M:%S")
            nomearquivo = 'MDFe_' + str(numerododoc) + '.pdf'
            propostaID = getJSON('manif_pedidolog')
            tipodoc = 4
        elif getJSON('ordemcar_pdf') != '':
            arquivo = getJSON('ordemcar_pdf')
            numerododoc = getJSON('ordemcar_codigo')
            pesosaida = getJSON('ordemcar_pesosaida')
            numerointerno = getJSON('ordemcar_numeropedido')
            descdoc = 'OrdemCar ' + str(numerododoc) + ' Emitido em ' + now.strftime("%d/%m/%Y %H:%M:%S")
            nomearquivo = 'OrdemCar_' + str(numerododoc) + '.pdf'
            propostaID = getJSON(
                'ordemcar_ordemcli')  # getPropostaId(getJSON('ordemcar_pedidolog')) alterado a pedido da Gabriela
            tipodoc = 3
        else:
            return '', 'Nenhum arquivo encontrado'

        req['module'] = 'M3002API'
        req['operation'] = 'apiEnvioComprovante'
        parameters['proposta_id'] = propostaID
        parameters['descricao'] = descdoc
        parameters['nome_arquivo'] = nomearquivo
        parameters['tipo_documento'] = tipodoc
        parameters['arquivo'] = arquivo
        if getJSON('conh_pdf') != '':
            parameters['num_cte'] = numerododoc
        if getJSON('manif_pdf') != '':
            parameters['num_mdfe'] = numerododoc
        parameters['peso_carregado'] = pesosaida
        parameters['id_externo'] = numerointerno
        if data_entrega:
            parameters['data_entrega'] = _format_iso_from_date(data_entrega)
        if data_carregamento:
            parameters['data_carregamento'] = _format_iso_from_date(data_carregamento)
        req['parameters'] = parameters

        req = json.dumps(req)
        return req, ''
    except Exception as e:
        print('Erro em responseTrizy')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DO REQUEST PARA GER. RISCO TRIZY ' + str(e)


def requestTrizyGetCredenciamento(reqJSON):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}
        parameters = {}
        filterArray = []
        filter = {}

        req['module'] = 'M3002API'
        req['operation'] = 'getCredenciamento'
        filter['operation'] = '='
        filter['selector'] = 'documento'
        filter['value'] = getJSON('mot_cpf')
        filterArray.append(filter)
        parameters['filter'] = filterArray
        req['parameters'] = parameters

        req = json.dumps(req)
        return req, ''
    except Exception as e:
        print('Erro em responseTrizy')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DO REQUEST PARA GER. RISCO TRIZY ' + str(e)


def getPropostaId(proposta):
    proposta = proposta.split(':')
    proposta = proposta[1].strip(" ")
    return proposta


def requestGetComprovantes(reqJSON):
    try:
        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}
        parameters = {}

        req['module'] = 'M3002API'
        req['operation'] = 'apiGetComprovantes'
        parameters['proposta_id'] = getJSON('proposta')
        req['parameters'] = parameters

        req = json.dumps(req)
        return req, ''
    except Exception as e:
        print('Erro requst getcomprovante')
        return '',


def requestGetViagemFinalizada(reqJSON):
    try:

        jsonSor = GetJson(reqJSON)
        getJSON = jsonSor.getJSON

        req = {}
        parameters = {}
        propostasArray = []
        proposta = {}

        req['module'] = 'M3002API'
        req['operation'] = 'apiGetViagemFinalizada'
        proposta['propostas'] = getJSON('proposta')
        propostasArray.append(proposta)
        parameters['propostas'] = propostasArray
        req['parameters'] = parameters

        req = json.dumps(req)

        return req, ''
    except Exception as e:
        print('Erro request getViagemFinalizada')
        return '',


# 1 = CNH 2 = DOCUMENTO 3 = ANTT 4 = FOTO 6 = VEICULO
@static_vars(origins={
    'V': {
        'CRLV': (2, 1),
        'FOTO': (6, 1),
        'CRLVC1': (2, 1),
        'FOTOC1': (6, 1),
        'CRLVC2': (2, 1),
        'FOTOC2': (6, 1),
        'CRLVC3': (2, 1),
        'FOTOC3': (6, 1),
        'CRLVC4': (2, 1),
        'FOTOC4': (6, 1)
    },
    'M': {
        'CNH': (1, 1),
        'CNHV': (1, 2),
        'FOTO': (5, 1),
        'RG': (2, 1),
        'RGV': (2, 2)
    }
})
def get_json_trizy_send_imagem(req: list, url: str, request_properties: str):
    communications = []
    result = {
        'sucesso': True,
        'conteudo': communications
    }

    for req_item in req:
        origin = get_json_trizy_send_imagem.origins.get(req_item.get('origem'))

        if not origin:
            return '', 'Erro ao obter origem do documento'

        for documento in req_item.get('documentos', []):
            tipo, orientacao = origin.get(documento.get('identificador'), (0, 0))

            req_data = {
                'module': 'M3002API',
                'operation': 'apiInsImagemCredenciamento',
                'parameters': {
                    'documento': req_item.get('documento', ''),
                    'placa': req_item.get('placa', ''),
                    'tipo': tipo,
                    'orientacao': orientacao,
                    'arquivo': documento.get('conteudo')
                }
            }

            if req_data != '':
                headers = {}
                headers, errors = preProcessRequestPropertiesTrizy(headers, request_properties)
                resp = requests.post(url, json=req_data, headers=headers, verify=False)
                retcode = resp.status_code
                resp = resp.json()

                result['sucesso'] = result['sucesso'] and resp.get('success', False)
                if retcode == 200 and resp.get('code') == 200:
                    msg = f'{documento.get("nome", "")}: Sucesso'
                else:
                    msg = f'{documento.get("nome", "")}: Erro'

                communications.append({
                    'msg': msg,
                    'request': json.dumps(req_data, indent=4),
                    'resposnse': json.dumps(resp, indent=4)
                })

    return '', json.dumps(result, indent=4)


def getJsonTrizyGetMotImgs(req: dict):
    try:
        req_data = {
            'module': 'M3002API',
            'operation': 'apiGetImagemMotorista',
            'parameters': {
                'documento': req.get('mot_cpf')
            }
        }

        return json.dumps(req_data), ''

    except (Exception,) as e:
        print('Erro request apiGetImagemMotorista: ' + str(e))
        return '', 'Erro em apiGetImagemMotorista: ' + str(e)


def responseGetViagemFinalizada(resp):
    try:
        ret = resp.content.decode('utf-8')
        root = json.loads(ret)
        jsonResp = GetJson(root)
        getJSON = jsonResp.getJSON

        message = ''

        success = getJSON('success')
        if success:
            if getJSON('result') != '':
                return '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><msg>' + ret + '</msg></resp>', ''
        else:
            if getJSON('message') != '':
                message = getJSON('message')
            return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><msg>' + message + '</msg></resp>'

    except Exception as e:
        print('Erro request getViagemFinalizada')
        return '',


def responseGetComprovante(resp):
    try:

        ret = resp.content.decode('utf-8')
        root = json.loads(ret)
        jsonResp = GetJson(root)
        getJSON = jsonResp.getJSON

        success = getJSON('success')
        if success:
            result = getJSON('result')

            final = ''
            if "documentos" in result:

                documentos = result["documentos"]
                req = {}
                files = []
                for i in range(0, len(documentos), 1):
                    arq = documentos[i]
                    foto = base64.b64decode(arq['arquivo'])
                    nomearq = arq['nome']
                    nomearq = nomearq.replace(' ', '')

                    arqFoto = '/sistemas/emonitorpy/tmp/' + nomearq
                    with open(arqFoto, "wb") as img_file:
                        img_file.write(foto)

                    with open('/sistemas/emonitorpy/tmp/' + nomearq, "rb") as image_file:
                        imgBase64 = base64.b64encode(image_file.read())

                        file = {
                            'doc_' + str(i): imgBase64.decode("ISO-8859-1"),
                            'nomearq': nomearq
                        }

                        files.append(file)

                req['comprovantes'] = files
                final = json.dumps(req)

            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + final + '</msg></resp>', ''
        else:
            if getJSON('message') != '':
                message = getJSON('message')
                return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><msg>' + message + '</msg></resp>'




    except Exception as e:
        print('Erro request getViagemFinalizada')
        return '',


def responseTrizy(req, resp):
    try:
        # arqresp = arqresp.content.decode('utf-8')

        root = json.loads(resp)
        jsonResp = GetJson(root)
        getJSON = jsonResp.getJSON

        proposta_id = ''
        motorista_id = ''
        documento_id = ''

        success = getJSON('success')
        if success:
            if getJSON('result') != '':
                result = getJSON('result')
                message = ''

                if "mensagem" in result:
                    message = result['mensagem']
                if "proposta_id" in result:
                    proposta_id = result['proposta_id']
                if "motorista_id" in result:
                    motorista_id = result['motorista_id']
                if "documento_id" in result:
                    documento_id = result['documento_id']

                if proposta_id != '':
                    return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + message + '</msg> <proposta_id>' + str(
                        proposta_id) + '</proposta_id></resp>', ''
                elif motorista_id != '':
                    return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + message + '</msg> <motorista_id>' + str(
                        motorista_id) + '</motorista_id></resp>', ''
                elif documento_id != '':
                    return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + message + '</msg> <documento_id>' + str(
                        documento_id) + '</documento_id></resp>', ''
                elif message != '':
                    return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' \
                           + message + '</msg></resp>', ''
        else:
            if getJSON('message') != '':
                message = getJSON('message')
                return '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><msg>' + message + '</msg></resp>', ''

    except Exception as e:
        print('Erro em responseTrizy')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA GER. RISCO TRIZY ' + str(e)


def resposeTrizyGetCredenciamento(resp):
    try:
        def filter_by_order(element):
            return element['ordem_veiculo']

        root = json.loads(resp)
        data_list: list = deep_get(root, 'result.data', [])

        data: dict
        for data in data_list:
            vehicles: list = data.get('veiculos', [])
            vehicles.sort(key=filter_by_order)

        if root.get('success'):
            return mount_xml_response(root), ''

    except Exception as e:
        print('Erro em responseTrizy')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA GER. RISCO TRIZY ' + str(e)


def resposeTrizyGetMotImgs(resp):
    try:
        root = json.loads(resp)
        imagens: list = deep_get(root, 'result.imagens', [])

        if root.get('success') and root.get('code') == 200:
            # Remover o if quando a Trizy consertar o retorno da API
            result = [
                img
                for img in imagens
                if img.get('foto_bucket') and img.get('foto_bucket', '').startswith('https:')
                   and not img.get('foto_bucket', '').endswith('oraclecloud.com')
            ]

            img: dict
            for img in result:
                img['ext'] = img.get('foto_bucket', '.').rsplit('.', 1)[1]
                img['data'] = base64.b64encode(requests.get(img.get('foto_bucket')).content).decode('ascii')

            return mount_xml_response(result), ''

        return '', 'Não foi possivel processar o retorno'

    except Exception as e:
        print('Erro em resposeTrizyGetMotImgs')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA GER. RISCO TRIZY ' + str(e)


def _format_iso_from_date(date_: str):
    try:
        return datetime.strptime(date_, '%Y-%m-%dT%H:%M:%S.%fZ').strftime('%d/%m/%Y %H:%M:%S')
    except (Exception,):
        return ''