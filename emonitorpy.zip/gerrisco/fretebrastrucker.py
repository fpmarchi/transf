from typing import Tuple
from urllib.parse import urlparse, urlunparse

from requests import Response, post

from dispacher import ActionProcessor
from dispacher.action_processor import HttpMethod
from dispacher.decorators import handle_exception_factory, parse_props
from geral import deep_get
from geralxml import mount_xml_response


class FreteBrasTruckerException(Exception):
    pass


class FreteBrasTrucker(ActionProcessor):
    HOST = 'https://openapi-trucker-profile.fretebras.com.br'
    TEST_HOST = 'https://openapi-trucker-profile.fretebras.dev.br'

    GENERATE_TOKEN = 3680
    GET_TRUCKER_PROFILE = 3681

    def __init__(self):
        super().__init__()

        self.add_callable_records('url', {
            self.GENERATE_TOKEN: self.make_url_assembler('/oauth/token'),
            self.GET_TRUCKER_PROFILE: self.make_url_assembler('/profile/$cpf_mot', HttpMethod.GET, use_template=True),
        })

    __token_cache: dict = {}

    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        props = context_req.get('props', {})
        user = props.get('usuario', '')
        password = props.get('senha', '')

        url = self.context.get('url')
        parsed_uri = list(urlparse(url))
        parsed_uri[2] = ''

        local_ctx = {
            'url': urlunparse(parsed_uri),
            'props': props
        }
        url = self.dispatch(self.GENERATE_TOKEN, local_ctx, 'url')[0]

        try:
            if not user or not password:
                return {}, 'O usuario ou senha não foram informados!'

            headers = {'Content-type': 'application/json'}

            token = _get_token(url + '', props, self.__token_cache)
            headers['Authorization'] = f'Bearer {token}'
            return headers, ''

        except(Exception,):
            return {}, 'Por favor verifique as credenciais de acesso para FreteBras Trucker!'


#
#   Códigos independentes de instancia
#

# Tratamento de exceções
def _fretebrastrucker_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a FreteBras Trucker:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    FreteBrasTruckerException,
    _fretebrastrucker_exception_callback,
    any_exception_callback
)

#
#   Códigos dependentes de instancia
#

# Instancia limpa e sem configuração (singleton)
_fretebrastrucker = FreteBrasTrucker()

# Decorators da instancia
_link_to_request = _fretebrastrucker.link_to_factory('request')
_link_to_response = _fretebrastrucker.link_to_factory('response')


# Login paragerar o token Bearer para realizar as autenticações
@_link_to_request(_fretebrastrucker.GET_TRUCKER_PROFILE)
@_handle_exception
def _out_send_(req: dict):
    return {}, ''


#
# Tratamento de retornos
@_link_to_response(_fretebrastrucker.DEFAULT_FUNCTION)
@_handle_exception
def _in_default(resp: Response) -> Tuple[str, str]:
    ret = resp.json()

    try:
        if 'cpf' in ret and ret.get:
            resp_data = {
                'sucesso': True,
                'conteudo': ret
            }
        elif '' == '':
            resp_data = {
                'sucesso': False,
                'msg_erro': ret
            }
        else:
            resp_data = {
                'sucesso': False,
                'msg_erro': deep_get(ret, 'msg')
            }
    except Exception as e:
        resp_data = {
            'sucesso': False,
            'msg_erro': 'Ocorreu um erro desconhecido ao tentar retornar as informações do EmonitorPy:\n' + str(e)
        }

    return mount_xml_response(resp_data), ''


@_handle_exception
# Funções utilitárias
def _get_token(url: str, data: dict, cache: dict) -> str:
    username = data.get('usuario', '')
    password = data.get('senha', '')

    if not username or not password:
        raise Exception('O e-mail, senha ou segredo não foram informados.')

    if not url:
        raise FreteBrasTruckerException('Não foi possível obter a URL de para requisitar o token.')

    try:
        auth_request = {
            'username': username,
            'password': password,
        }

        resp = post(url, json=auth_request)
    except Exception as e:
        raise FreteBrasTruckerException('Erro ao buscar token de autorização na FreteBras!\n' + str(e))

    if resp.status_code == 200:
        token = resp.json().get('token', '')

        return token
    else:
        raise FreteBrasTruckerException('Erro ao obter token: ' + resp.content.decode('utf-8'))
