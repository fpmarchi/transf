import base64
import json
from datetime import datetime
from string import Template
from typing import Tuple

from requests import Response

from ActionProcessor import ActionProcessor, HttpMethod, handle_exception_factory, parse_props
from geral import conditional_key, static_vars
from geralxml import mount_xml_response


class RondonException(Exception):
    pass


# Classe base
class Rondonline(ActionProcessor):
    # INSTANCIAS
    BASE_URL = 'https://ap.rondonline.com.br/api/consulta'
    BASE_URL_TEST = 'https://ap.rondonline.com.br/api/consulta'

    AUTONOMOUS_POLICY_CONSULTATION = 3850
    AGGREGATE_POLICY_CONSULTATION = 3851
    FLEET_POLICY_CONSULTATION = 3852
    INDIVIDUAL_POLICY_CONSULTATION = 3853
    COMPANY_POLICY_CONSULTATION = 3854
    VEHICLE_POLICY_CONSULTATION = 3855
    RESULT_CONSULTATION = 3856
    EDIT_CONSULTATION = 3857

    def __init__(self):

        self.add_callable_records('url', {
            self.AUTONOMOUS_POLICY_CONSULTATION: (_make_url, _make_defaults('/politica-autonomo')),
            self.AGGREGATE_POLICY_CONSULTATION: (_make_url, _make_defaults('/politica-agregado')),
            self.FLEET_POLICY_CONSULTATION: (_make_url, _make_defaults('/politica-frota')),
            self.INDIVIDUAL_POLICY_CONSULTATION: (_make_url, _make_defaults('/politica-individual')),
            self.COMPANY_POLICY_CONSULTATION: (_make_url, _make_defaults('/politica-empresa')),
            self.VEHICLE_POLICY_CONSULTATION: (_make_url, _make_defaults('/politica-veiculo')),
            self.RESULT_CONSULTATION: (_make_url, _make_defaults('/$protocolo', HttpMethod.GET, True)),
            self.EDIT_CONSULTATION: (_make_url, _make_defaults('/edit/$rondonline_protocolo', use_template=True))
        })

        super().__init__()

    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        props = context_req.get('props')
        user = props.get('usuario')
        password = props.get('senha')
        token_bytes: bytes = base64.b64encode(f'{user}:{password}'.encode())

        return {
                   'Authorization': f'Basic {token_bytes.decode("ascii")}',
                   'Content-type': 'application/json'
               }, ''


#
#   Códigos independentes de instancia
#
def _rondon_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a Rondonline:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    RondonException,
    _rondon_exception_callback,
    any_exception_callback
)


# Funções para obtenção de URLs
@_handle_exception
def _make_defaults(path: str, method: HttpMethod = HttpMethod.POST, use_template: bool = None) -> dict:
    return {
        'path': path,
        **conditional_key('method', method),
        **conditional_key('use_template', use_template)
    }


@_handle_exception
def _make_url(path: str, method: HttpMethod = HttpMethod.GET, use_template: bool = False,
              req: dict = None, url: str = '', props: dict = None) -> Tuple[str, str]:
    if props is None:
        props = {}

    ambiente = 0
    try:
        ambiente = int(props.get('ws_ambiente'))
    except (Exception,):
        pass

    base = url.strip().rstrip('/') or (Rondonline.BASE_URL if ambiente == 1 else Rondonline.BASE_URL_TEST)
    if use_template:
        t = Template(path)
        url = base + t.substitute(req)
    else:
        url = base + path

    return url, method.name


#
#   Instancia limpa e sem configuração
#
_rondonline = Rondonline()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = _rondonline.link_to_factory('request')
_link_to_response = _rondonline.link_to_factory('response')


@_link_to_request(
    Rondonline.AUTONOMOUS_POLICY_CONSULTATION,
    Rondonline.AGGREGATE_POLICY_CONSULTATION,
    Rondonline.FLEET_POLICY_CONSULTATION
)
@_handle_exception
def _out_politica_conjunto(req: dict) -> Tuple[str, str]:

    number_cel = _number_cel(req.get('mot_celularddd', ''), req.get('mot_celularnumero', ''))
    number_cel_corp =  _number_cel(req.get('mot_celular_corporativo_ddd', ''), req.get('mot_celular_corporativo_numero', ''))

    cel_to_send = _number_choise(number_cel, number_cel_corp)

    req_data = {
        'cpf_cnpj': req.get('mot_cpf', ''),
        'nome': req.get('mot_nome', ''),
        'naturalidade': req.get('mot_nomecidnascimento', '') + ' - ' + req.get('mot_ufcidnascimento', ''),
        'dtNascimento': _date_ddmmyy(req.get('mot_datanasc', '')),
        'mae': req.get('mot_nomemae', 'N/A'),
        'pai': req.get('mot_nomepai', 'N/A'),
        **conditional_key('vitimologia', req.get('certify_vitimologia', ''), not not req.get('certify_vitimologia', '')),
        'rg': req.get('mot_rg', ''),
        'rgEmissor': _check_issuing_agency(req.get('mot_orgaorg', '')),
        'rgUf': req.get('mot_orgaorguf', ''),
        'rgDtEmissao': req.get('mot_datarg', ''),
        'cnh': req.get('mot_cnh', ''),
        'cnhCategoria': req.get('mot_catcnh', ''),
        'cnhUf': req.get('mot_ufcnh', ''),
        'cnhValidade': req.get('mot_datavalidcnh', ''),
        'cnhCodigoSeguranca': req.get('mot_numsegcnh', ''),
        'cnhRenach': req.get('mot_renachcnh'),
        'cnhPrimeiraEmissao': req.get('mot_dataprimcnh', ''),
        'enderecoCep': req.get('mot_cep', ''),
        'enderecoUf': req.get('mot_ufcidendereco', ''),
        'enderecoCidade': req.get('mot_nomecidendereco', ''),
        'enderecoRua': req.get('mot_endereco', ''),
        'enderecoBairro': req.get('mot_bairro', ''),
        'enderecoNumero': req.get('mot_numero', ''),
        'enderecoComplemento': req.get('mot_complemento', ''),
        # **conditional_key('contatoResidencial', number_fone, not not number_fone),
        'contatoCelular1': cel_to_send,


        'usuario_criacao': req.get('veic_usuario_corrente', ''),

        'v1_placa': req.get('veic_placa', ''),
        'v1_placaUf': req.get('veic_uf', ''),
        'v1_placaCidade': req.get('veic_nomecidade', ''),
        'v1_chassi': req.get('veic_chassi', ''),
        'v1_renavam': req.get('veic_renavam', ''),
        'v1_anoFabrica': req.get('veic_anofab', ''),
        'v1_anoModelo': req.get('veic_anomod', ''),
        'v1_tipoVeiculo': 2,
        'v1_tipoCarroceria': req.get('veic_tipocarr', ''),

        'v1_proprietarioCpfCnpj': req.get('prop_cnpjcpf', ''),
        'v1_proprietarioRazaoSocial': req.get('prop_nome', ''),
        'v1_proprietarioNomeFantasia': req.get('prop_nome', ''),
        'v1_proprietarioRntrc': req.get('prop_rntrc', ''),
        'v1_proprietarioFone': req.get('prop_celularddd', '') + req.get('prop_celularnumero', ''),
        'v1_proprietarioEndereco': req.get('prop_endereco', ''),
        'v1_proprietarioObservacao': req.get('prop_obs', ''),
    }

    for i in [1, 2]:
        x = str(i)
        y = str(i + 1)

        if not req.get(f'car{x}_placa'):
            continue
        req_data.update({
            'v' + y + '_placa': req.get('car' + x + '_placa', ''),
            'v' + y + '_placaUf': req.get('car' + x + '_uf', ''),
            'v' + y + '_placaCidade': req.get('car' + x + '_nomecidade', ''),
            'v' + y + '_chassi': req.get('car' + x + '_chassi', ''),
            'v' + y + '_renavam': req.get('car' + x + '_renavam', ''),
            'v' + y + '_anoFabrica': req.get('car' + x + '_anofab', ''),
            'v' + y + '_anoModelo': req.get('car' + x + '_anomod', ''),
            'v' + y + '_tipoVeiculo': 2,
            'v' + y + '_tipoCarroceria': req.get('car' + x + '_tipocarr', ''),

            'v' + y + '_proprietarioCpfCnpj': req.get('prop_cnpjcpf', ''),
            'v' + y + '_proprietarioRazaoSocial': req.get('prop_nome', ''),
            'v' + y + '_proprietarioNomeFantasia': req.get('prop_nome', ''),
            'v' + y + '_proprietarioRntrc': req.get('prop_rntrc', ''),
            'v' + y + '_proprietarioFone': req.get('prop_celularddd', '') + req.get('prop_celularnumero', ''),
            'v' + y + '_proprietarioEndereco': req.get('prop_endereco', ''),
            'v' + y + '_proprietarioObservacao': req.get('prop_obs', ''),
        })

    return json.dumps(req_data), ''


@_link_to_request(Rondonline.INDIVIDUAL_POLICY_CONSULTATION)
@_handle_exception
def _out_politica_individual(req: dict) -> Tuple[str, str]:
    req_data = {
        'cpf_cnpj': req.get('mot_cpf', ''),
        'nome': req.get('mot_nome', ''),
        'naturalidade': req.get('mot_nomecidnascimento', '') + ' - ' + req.get('mot_ufcidnascimento', ''),
        'dtNascimento': _date_ddmmyy(req.get('mot_datanasc', '')),
        'mae': req.get('mot_nomemae', 'N/A'),
        'pai': req.get('mot_nomepai', 'N/A'),
        **conditional_key('vitimologia', req.get('certify_vitimologia', ''), not not req.get('certify_vitimologia', '')),
        'rg': req.get('mot_rg', ''),
        'rgEmissor': _check_issuing_agency(req.get('mot_orgaorg', '')),
        'rgUf': req.get('mot_orgaorguf', ''),
        'rgDtEmissao': req.get('mot_datarg', ''),
        'enderecoCep': req.get('mot_cep', ''),
        'enderecoUf': req.get('mot_ufcidendereco', ''),
        'enderecoCidade': req.get('mot_nomecidendereco', ''),
        'enderecoRua': req.get('mot_endereco', ''),
        'enderecoBairro': req.get('mot_bairro', ''),
        'enderecoNumero': req.get('mot_numero', ''),
        'enderecoComplemento': req.get('mot_complemento', ''),
        'contatoCelular1': _number_cel(req.get('mot_celularddd', ''), req.get('mot_celularnumero', '')),
        'usuario_criacao': req.get('mot_usuario_corrente', ''),
    }
    return json.dumps(req_data), ''


@_link_to_request(Rondonline.COMPANY_POLICY_CONSULTATION)
@_handle_exception
def _out_politica_empresa(req: dict) -> Tuple[str, str]:
    req_data = {
        'cpf_cnpj': req.get('prop_cnpjcpf', ''),
        'nome': req.get('prop_nome', ''),
        'nome_fantasia': req.get('prop_nome', ''),
        'enderecoCep': req.get('prop_cep', ''),
        'enderecoUf': req.get('prop_uf', ''),
        'enderecoCidade': req.get('prop_cidade', ''),
        'enderecoRua': req.get('prop_endereco', ''),
        'enderecoBairro': req.get('prop_bairro', ''),
        'enderecoNumero': req.get('prop_numero', ''),
        'enderecoComplemento': req.get('prop_complemento', ''),
        'contatoCelular1': _number_cel(req.get('prop_celularddd', ''), req.get('prop_celularnumero', '')),
        'usuario_criacao': req.get('prop_usuario_corrente', ''),
    }

    return json.dumps(req_data), ''


@_link_to_request(Rondonline.VEHICLE_POLICY_CONSULTATION)
@_handle_exception
def _out_politica_veiculo(req: dict) -> Tuple[str, str]:
    req_data = {
        'placa': req.get('veic_placa', ''),
        'placaUf': req.get('veic_uf', ''),
        'placaCidade': req.get('veic_nomecidade', ''),
        'chassi': req.get('veic_chassi', ''),
        'renavam': req.get('veic_renavam', ''),
        'anoFabrica': req.get('veic_anofab', ''),
        'anoModelo': req.get('veic_anomod', ''),
        'tipoVeiculo': 2,
        'tipoCarroceria': req.get('veic_tipoveic', ''),
        'usuario_criacao': req.get('veic_usuario_corrente', ''),
    }

    return json.dumps(req_data), ''


@_link_to_request(Rondonline.EDIT_CONSULTATION)
@_handle_exception
def _out_edit_consultation(req: dict) -> Tuple[str, str]:

    action = req.get('rondonline_acao_origem')
    if not _rondonline.is_recognized_action(action):
        return '', 'Não foi possível determinar a origem da consulta'

    req_data = _rondonline.build_request(_rondonline.context, action)[0]

    return req_data, ''


@_link_to_request(Rondonline.DEFAULT_FUNCTION)
@_handle_exception
def _out_default() -> Tuple[None, str]:
    return None, ''


@_link_to_response(Rondonline.RESULT_CONSULTATION)
@_handle_exception
def _find_resultado_consulta(resp: Response) -> Tuple[str, str]:
    def _find_campo_apelido(campo):
        return {
           'naturalidade': 'cidade_nascimento'
        }.get(campo, campo)

    resp_json = resp.json()
    success = resp.status_code in [200, 201, 204]
    resp_body = {'sucesso': success}
    resp_json['descricao_status'] = _check_status_result(resp_json['status'])
    resp_json['motivo'] = resp_json.get('motivo') or ''
    resp_json['validade'] = datetime.strptime(resp_json['validade'], '%Y-%m-%d').isoformat()\
        if resp_json.get('validade') else ''
    if success:
        if 'erros' in resp_json and resp_json.get('erros'):
            resp_json['inconsistencias'] = [
                {
                    'campo': _find_campo_apelido(k) or ' - ',
                    'descricao': '\n'.join(v) or ''
                }
                for k, v in resp_json.get('erros', {}).items()
            ]
        resp_body['conteudo'] = resp_json
    else:
        raise RondonException('Não foi possível encontrar um retorno conhecido da Rondonline')
    return mount_xml_response(resp_body), ''


#
# FUNCOES DE FORMATAÇÃO DE SINTAXE
#


# CONVERTE 2000-02-19 PARA 19/02/2000
def _date_ddmmyy(s: str) -> str:
    try:
        return datetime.strptime(s, "%Y-%m-%d").strftime("%d/%m/%Y")
    except (Exception,):
        return ''


def _number_cel(ddd: str, number: str) -> str:
    if number:
        trace = '-'
        number_part1 = number[0:5]
        number_part2 = number[5:9]
        number_complet = '(' + ddd + ') ' + number_part1 + trace + number_part2
        return number_complet
    else:
        ''


#
# funcoes de processamento de resposta
#
@_link_to_response(Rondonline.DEFAULT_FUNCTION)
@_handle_exception
def _in_rondon_response(resp: Response) -> Tuple[str, str]:
    resp_json: dict = resp.json()
    status_code = resp.status_code
    if status_code in [200, 201]:
        resp_body = {
            'sucesso': True,
            'conteudo': resp_json
        }
    elif status_code == 422:
        resp_body = {
            'sucesso': False,
        }

        if 'error' in resp_json:
            resp_body['msg_erro'] = 'Por favor, verifique a situação da consulta.\nResposta da Rondonline: '\
                                    + resp_json.get('error', 'Não foi possível obter o erro')
        else:
            resp_body['erros'] = [
                {
                    'campo': k or ' - ',
                    'descricao': ", ".join(v) or ''
                }
                for k, v in resp_json.items()
            ]

    elif status_code == 405:
        resp_body = {
            'sucesso': False,
            'msg_erro': resp_json.get('error', '')
        }
    else:
        raise RondonException('Não foi possível encontrar um retorno conhecido da Rondonline')

    return mount_xml_response(resp_body), ''


@static_vars(orgao=[
    'SSP',
    'PM',
    'PC',
    'CNT',
    'DIC',
    'CTPS',
    'FGTS',
    'IFP',
    'IPF',
    'IML',
    'MTE',
    'MMA',
    'MAE',
    'MEX',
    'POF',
    'POM',
    'SES',
    'SJS',
    'SJTS'
],
    alias={'SESP': 'SSP'}
)
def _check_issuing_agency(orgao: str) -> str:
    print(orgao)
    aliases: dict = _check_issuing_agency.alias
    for k, v in aliases.items():
        if k in orgao:
            return v

    emitters = _check_issuing_agency.orgao
    for emitter in emitters:
        if emitter in orgao:
            return emitter
    return 'ZZZ'


@static_vars(status={
    0: 'Processando',
    1: 'Em Acordo',
    2: 'Em Desacordo',
    3: 'Correção',
},
)
def _check_status_result(statu: int) -> str:
    status: dict = _check_status_result.status
    return status.get(statu, 'Desconhecido')

def _number_choise(number_cel, number_cel_corp) -> str:
    if number_cel:
        return number_cel
    elif number_cel_corp:
        return number_cel_corp
    else:
        return ''

