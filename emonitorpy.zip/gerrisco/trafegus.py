import base64
import json
import re
from typing import Tuple

from requests import Response

from dispacher import ActionProcessor
from dispacher.action_processor import HttpMethod
from dispacher.decorators import handle_exception_factory, parse_props
from geral import conditional_key, remove_accents
from geralxml import mount_xml_response


# Exceção customizada
class TrafegusException(Exception):
    pass


#   Códigos independentes de instancia
#
def _trafegus_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def _any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a FreteBras:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    TrafegusException,
    _trafegus_exception_callback,
    _any_exception_callback
)


# Classe base
class Trafegus(ActionProcessor):
    HOST = 'http://begcloud.com'
    TEST_HOST = 'http://168.138.250.157'
    BASE_PATH = '/ws_rest/public/api'

    # MIN: 3850, MAX: 3899
    SEARCH_PGR = 3100
    SEND_TRIP = 3101
    SEARCH_ROUTE = 3102
    SEND_DRIVER = 3103
    SEND_VEHICLE = 3104
    SEND_CARRIER = 3105
    UPDATE_TRAVEL_STATUS = 3106

    # O método de cache em memoria não é o ideal, pois o EMPY é multithreading.
    # Uma boa opção seria utilizar uma ferramenta de cache como o Redis.
    __token_cache = None
    species_cache = {}
    price_type_cache = {}
    vehicle_cache = {}
    bodywork_cache = {}

    def __init__(self):
        self.__token_cache = {}
        # Params
        self.extract_host = True

        self.add_callable_records('url', {
            self.SEARCH_PGR: self.make_url_assembler(
                '/pgr?UltCodigo=${ult_cod}&Documento=${transp_cnpj}',
                HttpMethod.GET,
                use_template=True
            ),
            self.SEND_TRIP: self.make_url_assembler('/viagem'),
            self.SEARCH_ROUTE: self.make_url_assembler('/rota?UltCodigo=$ult_cod', HttpMethod.GET, use_template=True),
            self.SEND_DRIVER: self.make_url_assembler('/motorista'),
            self.SEND_VEHICLE: self.make_url_assembler('/veiculo'),
            self.SEND_CARRIER: self.make_url_assembler('/transportador'),
            self.UPDATE_TRAVEL_STATUS: self.make_url_assembler('/viagem/$id_viagem', HttpMethod.PUT, use_template=True),
        })

        super().__init__()

    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        props = context_req.get('props')
        user = props.get('usuario')
        password = props.get('senha')
        app = props.get('app_id', '1')

        token_bytes: bytes = base64.b64encode(f'{user}:{password}'.encode())

        return {
            'Authorization': f'Basic {token_bytes.decode("ascii")}',
            'Content-type': 'application/json',
            'X-App-Trafegus': app
        }, ''


#
#   Instancia limpa e sem configuração
#
trafegus = Trafegus()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = trafegus.link_to_factory('request')
_link_to_response = trafegus.link_to_factory('response')


# Funções para obtenção de envios
@_link_to_request(trafegus.SEND_TRIP)
@_handle_exception
def _send_trip_body(req: dict) -> Tuple[str, str]:
    trips = []

    body = {
        'vincularEmpresaLocal': False,
        'viagem': trips
    }

    if type(req) is dict:
        req = [req]

    for context in req:
        trip = {
            'documento_transportador': context.get('conh_prop_cnpjcpf', ''),
            'viag_ttra_codigo': int(context.get('conh_tipotransporte', 0)) or None,
            'viag_pgpg_codigo': context.get('conh_pgr'),
            'veiculos': [
                {
                    'placa': context.get('conh_veic_placa', '')
                }
            ],
            'motoristas': [
                {
                    'cpf_moto': context.get('conh_mot_cpf', '')
                }
            ],
            'viag_valor_carga': context.get('conh_valormerc', ''),

        }
        if context.get('conh_rota_cod'):
            trip['rota_codigo'] = context.get('conh_rota_cod', 0)
        else:
            trip.update({
                'origem': {
                    'vloc_descricao': context.get('conh_rem_nome', ''),
                    'logradouro': context.get('conh_rem_endereco', ''),
                    'complemento': context.get('conh_rem_complemento', ''),
                    'cep': context.get('conh_rem_cep', ''),
                    'numero': context.get('conh_rem_numero', ''),
                    'bairro': context.get('conh_rem_bairro', ''),
                    'cida_descricao_ibge': context.get('conh_rem_nomecid', ''),
                    'sigla_estado': context.get('conh_rem_ufcid', ''),
                    'pais': context.get('conh_rem_pais', ''),
                    'documento': context.get('conh_rem_cnpjcpf', ''),
                    **conditional_key(
                        'refe_latitude',
                        context.get('conh_rem_latitude'),
                        context.get('conh_rem_latitude') != ''
                    ),
                    **conditional_key(
                        'refe_longitude',
                        context.get('conh_rem_longitude'),
                        context.get('conh_rem_longitude') != ''
                    )
                },
                'destino': {
                    'vloc_descricao': context.get('conh_dest_nome', ''),
                    'logradouro': context.get('conh_dest_endereco', ''),
                    'complemento': context.get('conh_dest_complemento', ''),
                    'cep': context.get('conh_dest_cep', ''),
                    'numero': context.get('conh_dest_numero', ''),
                    'bairro': context.get('conh_dest_bairro', ''),
                    'cida_descricao_ibge': context.get('conh_dest_nomecid', ''),
                    'sigla_estado': context.get('conh_dest_ufcid', ''),
                    'pais': context.get('conh_dest_pais', ''),
                    'documento': context.get('conh_dest_cnpjcpf', ''),
                    **conditional_key(
                        'refe_latitude',
                        context.get('conh_dest_latitude'),
                        context.get('conh_dest_latitude') != ''
                    ),
                    **conditional_key(
                        'refe_longitude',
                        context.get('conh_dest_longitude'),
                        context.get('conh_dest_longitude') != ''
                    )
                }
            })

        trips.append(trip)

    return json.dumps(body), ''


@_link_to_request(trafegus.SEND_DRIVER)
@_handle_exception
def _send_driver_body(req: dict) -> Tuple[str, str]:
    body = {
        'motorista': [
            {
                'cpf_motorista': req.get('mot_cpf', ''),
                'nome': req.get('mot_nome', ''),
                'rg': req.get('mot_rg', ''),
                'logradouro': req.get('mot_endereco', ''),
                'cep': req.get('mot_cep', ''),
                'numero': req.get('mot_numero', ''),
                'complemento': req.get('mot_complemento', ''),
                'bairro': req.get('mot_bairro', ''),
                'cidade': req.get('mot_cidadeend', ''),
                'sigla_estado': req.get('mot_ufend', ''),
                'pais': req.get('mot_pais', '')
            }]
    }

    return json.dumps(body), ''


@_link_to_request(trafegus.SEND_VEHICLE)
@_handle_exception
def _send_vehicle_body(req: dict) -> Tuple[str, str]:
    tipo_veiculo = remove_accents(req.get('cod_tipo_veic', '')).upper()

    if req.get('veic_uf'):
        req['veic_nomecidade'] = f'{req.get("veic_nomecidade", "")} - {req.get("veic_uf", "")}'

    body = {
        'veiculo': [
            {
                'placa': req.get('veic_placa', ''),
                'renavam': req.get('veic_renavam', ''),
                'marca': req.get('veic_marca', ''),
                'tipo_veiculo': tipos_veiculo.get(tipo_veiculo, 0),
                'chassi': req.get('veic_chassi', ''),
                'modelo': req.get('veic_modelo', ''),
                'ano_fabricacao': req.get('veic_anofab', 0),
                'cor': req.get('veic_cor', ''),
                'cidade_emplacamento': req.get('veic_nomecidade', '').rsplit(' - ', 1)[0].strip(),
                'sigla_estado': (' - ' + req.get('veic_nomecidade', ' - ')).rsplit(' - ', 1)[1].strip()[-2:],
                'pais': req.get('veic_pais', '')
            }]
    }

    return json.dumps(body), ''


@_link_to_request(trafegus.SEND_CARRIER)
@_handle_exception
def _send_carrier_body(req: dict) -> Tuple[str, str]:
    body = {
        'transportador': [
            {
                'documento_transportador': req.get('prop_cnpjcpf', ''),
                'tipo_pessoa': 'pjur' if len(req.get('prop_cnpjcpf', '')) > 11 else 'pfis',
                'nome': req.get('prop_nome', ''),
                'ie_rg': req.get('prop_rg') or req.get('prop_ie', ''),
                'logradouro': req.get('prop_endereco', ''),
                'cep': req.get('prop_cep', ''),
                'numero': req.get('prop_numero', ''),
                'complemento': req.get('prop_complemento', ''),
                'bairro': req.get('prop_bairro', ''),
                'cidade': req.get('prop_cidade', ''),
                'sigla_estado': req.get('prop_uf', ''),
                'pais': req.get('prop_pais', '')
            }]
    }

    return json.dumps(body), ''


@_link_to_request(trafegus.UPDATE_TRAVEL_STATUS)
@_handle_exception
def _update_travel_status(req: dict) -> Tuple[str, str]:
    body = {
        'status_viagem': {
            'id_novo_status': req.get('status_viagem', ''),
        }
    }

    return json.dumps(body), ''


@_link_to_request(trafegus.DEFAULT_FUNCTION)
@_handle_exception
def _default_body() -> Tuple[None, str]:
    return None, ''


# Processamento de respostas
fix_pattern = re.compile(r'\\u0022([^"]+)\\u0022')


@_link_to_response(trafegus.DEFAULT_FUNCTION)
@_handle_exception
def _default_resp(resp: Response) -> Tuple[str, str]:
    json_str = fix_pattern.sub(r'\1', resp.text)
    ret = json.loads(json_str)

    error = ret.get('error')
    if type(error) is dict and error.get('viag_pgpg_codigo'):
        ret['error'] = [
            {
                'campo': ' - ',
                'mensagem': v or ''
            }
            for v in error.get('viag_pgpg_codigo').values()
        ]
    if type(error) is dict:
        ret['error'] = [
            {
                'campo': k,
                'mensagem': ','.join(v.values())
            }
            for k, v in error.items()
        ]
    elif type(error) is list and len(error) > 0:
        ret['error'] = [
            {
                'campo': e.get('campo') or ' - ',
                'mensagem': e.get('mensagem') or ''
            }
            for e in ret.get('error', [])
        ]
    elif type(error) is str:
        ret['error'] = [{'campo': '-', 'mensagem': error}]

    return mount_xml_response(ret), ''


tipos_veiculo = {
    'CARRETA': 1,
    'CAVALO': 2,
    'TRUCK': 3,
    'MOTO': 4,
    'UTILITARIO DE CARGA': 5,
    'UTILITARIO DE PASSEIO': 6,
    'TOCO': 7,
}
