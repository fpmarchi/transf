import datetime
import json
from string import Template
# Exceção customizada
from typing import Tuple
from requests import Response
from ActionProcessor import ActionProcessor, handle_exception_factory, parse_props, HttpMethod
from GetJson import GetJson
from entity import proprietario, motorista, veiculo
from geral import conditional_key, static_vars
from geraljson import getJSON
from geralxml import *
from geralxml import mount_xml_response

ACAO_RONDON_INICIO = 3200
ACAO_RONDON_CADASTRARPROPRIETARIO = 3201
ACAO_RONDON_CADASTRARMOTORISTA = 3202
ACAO_RONDON_CADASTRARVEICULO = 3203
ACAO_RONDON_CADASTRARCARRETA1 = 3204
ACAO_RONDON_CADASTRARCARRETA2 = 3205
ACAO_RONDON_CADASTRARCARRETA3 = 3206
ACAO_RONDON_CADASTRARCONHECIMENTO = 3211
ACAO_RONDON_MOTORISTA_FOTO = 3212
ACAO_RONDON_MOTORISTA_FOTOCNH = 3213
ACAO_RONDON_FIM = 3249

def consistRondonCadastrarProprietario(reqJSON):
    # PENDENTE CHECAR CAMPOS OBRIGATORIOS GENERICOS NO METODO ABAIXO QUE FICA NO opcartao
    ret = proprietario.consistCadastrarProprietario(reqJSON)
    # PENDENTE CHECAR CONSISTENCIAS ESPECIFICAS DA RONDON
    # ret = ret + outro erro
    return ret


def consistRondonCadastrarMotorista(reqJSON):
    # PENDENTE CHECAR CAMPOS OBRIGATORIOS GENERICOS NO METODO ABAIXO QUE FICA NO opcartao
    ret = motorista.consistCadastrarMotorista(reqJSON)
    # PENDENTE CHECAR CONSISTENCIAS ESPECIFICAS DA RONDON
    # ret = ret + outro erro
    return ret


def preProcessRequestPropertiesRondon(headers, requestProperties):
    entry = requestProperties.split('=')
    token = entry[1]
    headers['Authorization'] = 'Bearer ' + token

    return headers, ''


def consistRondonCadastrarVeiculo(reqJSON, codEMonitorAcao):
    if codEMonitorAcao == ACAO_RONDON_CADASTRARVEICULO:
        prefixTag = 'veic_'
    elif codEMonitorAcao == ACAO_RONDON_CADASTRARCARRETA1:
        prefixTag = 'car1_'
    elif codEMonitorAcao == ACAO_RONDON_CADASTRARCARRETA2:
        prefixTag = 'car2_'
    elif codEMonitorAcao == ACAO_RONDON_CADASTRARCARRETA3:
        prefixTag = 'car3_'
    # PENDENTE CHECAR CAMPOS OBRIGATORIOS GENERICOS NO METODO ABAIXO QUE FICA NO opcartao
    ret = veiculo.consistCadastrarVeiculo(reqJSON, prefixTag)
    # PENDENTE CHECAR CONSISTENCIAS ESPECIFICAS DA RONDON
    if codEMonitorAcao == ACAO_RONDON_CADASTRARVEICULO:
        isPF = len(getJSON(reqJSON, 'prop_cnpjcpf')) == 11
        resp = getJSON(reqJSON, 'prop_contato')
        tipoCarreta = getJSON(reqJSON, prefixTag + 'tipocarr')
        tipoRastreador = getJSON(reqJSON, prefixTag + 'tiporastreador')
        if (not isPF) and (resp == ''):
            ret += '- Contato no cadastro do Proprietário deve ser informado!\n'
        if tipoCarreta == '':
            ret += '- Tipo de Carroceria deve ser informada!\n'
        if tipoCarreta != '' and getTipoCarreta(tipoCarreta) == '':
            ret += '- Tipo de Carroceria não identificada, informe uma das opções disponibilizadas pela GR Rondon\n'
        if tipoRastreador == '':
            ret += '- Tipo de Rastreador deve ser informado!\n'
        if tipoRastreador != '' and getTipoRastreador(tipoRastreador) == '':
            ret += '- Tipo de Rastreador não identificado, informe uma das opções disponibilizadas pela GR Rondon\n'
    return ret


def requestRondonCadastrarProprietario(reqJSON):
    jsonSor = GetJson(reqJSON)
    getJSON = jsonSor.getJSON

    erros = consistRondonCadastrarProprietario(reqJSON)
    if getJSON('prop_celularnumero') != '':
        telefone = getJSON('prop_celularddd') + getJSON('prop_celularnumero')
    else:
        telefone = getJSON('prop_foneddd') + getJSON('prop_fonenumero')
    if erros != '':
        return '', erros

    jsonSor = GetJson(reqJSON)
    getJSON = jsonSor.getJSON

    prop = {}
    prop['CPF_CNPJ'] = getJSON('prop_cnpjcpf')
    prop['NOME'] = getJSON('prop_nome')
    prop['TELEFONE'] = telefone
    prop['TELEFONE_RESIDENCIAL'] = getJSON('prop_foneddd') + getJSON('prop_fonenumero')
    prop['TELEFONE_CELULAR'] = getJSON('prop_celular')
    prop['EMAIl'] = getJSON('prop_email')
    prop['UF'] = getCodUF(getJSON('prop_uf'))
    prop['CIDADE'] = getJSON('prop_cidade')

    req = json.dumps(prop), ''

    return req


def requestRondonCadastrarMotorista(reqJSON):
    jsonSor = GetJson(reqJSON)
    getJSON = jsonSor.getJSON

    erros = consistRondonCadastrarMotorista(reqJSON)
    if erros != '':
        return '', erros
    dataNasc = getJSON('mot_datanasc')
    dataNascFormatada = dataNasc[8:10] + '/' + dataNasc[5:7] + '/' + dataNasc[0:4]
    nomeMot = getJSON('mot_nome')
    qra = nomeMot.strip().split(' ')[0]  # qra = apelido ou primeiro nome

    mot = {}

    mot['CPF'] = getJSON('mot_cpf')
    mot['NOME'] = nomeMot
    mot['QRA'] = qra
    mot['DATA_NASCIMENTO'] = dataNascFormatada
    mot['NOME_MAE'] = getJSON('mot_nomemae')
    mot['RG_NUMERO'] = getJSON('mot_rg')
    mot['RG_ORGAO_EMISSOR'] = getJSON('mot_orgaorg')
    mot['CNH_CODIGO'] = getJSON('mot_cnhformulario')
    mot['CNH_NUMERO_REGISTRO'] = getJSON('mot_cnh')
    mot['CNH_UF'] = getCodUF(getJSON('mot_ufcnh'))
    mot['CNH_CATEGORIA'] = getCodCatCNH(getJSON('mot_catcnh'))
    mot['CNH_VALIDADE'] = getJSON('mot_datavalidcnh')
    mot['ENDERECO_RUA'] = getJSON('mot_endereco')
    mot['ENDERECO_NUMERO'] = getJSON('mot_numero')
    mot['ENDERECO_UF'] = getCodUF(getJSON('mot_ufcidendereco'))
    mot['ENDERECO_CIDADE'] = getJSON('mot_nomecidendereco')
    mot['ENDERECO_COMPLEMENTO'] = getJSON('mot_complemento')
    mot['ENDERECO_CEP'] = getJSON('mot_cep')
    mot['ENDERECO_BAIRRO'] = getJSON('mot_bairro')
    mot['CONTATO_TELEFONE'] = getJSON('mot_foneddd') + getJSON('mot_fonenumero')
    mot['CONTATO_CELULAR'] = getJSON('mot_celularddd') + getJSON('mot_celularnumero')
    mot['REFERENCIA_PROFISSIONAL1_NOME'] = getJSON('mot_referencia_profissional1_nome')
    mot['REFERENCIA_PROFISSIONAL1_TELEFONE'] = getJSON('mot_referencia_profissional1_telefone')
    mot['REFERENCIA_PROFISSIONAL2_NOME'] = getJSON('mot_referencia_profissional2_nome')
    mot['REFERENCIA_PROFISSIONAL2_TELEFONE'] = getJSON('mot_referencia_profissional2_telefone')
    mot['REFERENCIA_PESSOAL1_NOME'] = getJSON('mot_referencia_pessoal1_nome')
    mot['REFERENCIA_PESSOAL1_TELEFONE'] = getJSON('mot_referencia_pessoal1_telefone')
    mot['REFERENCIA_PESSOAL2_NOME'] = getJSON('mot_referencia_pessoal2_nome')
    mot['REFERENCIA_PESSOAL2_TELEFONE'] = getJSON('mot_referencia_pessoal2_telefone')

    req = json.dumps(mot)
    return req, ''


def getTipoVeic(tipo):
    if tipo == 'TRUCK':
        return '0'
    elif tipo == 'CARRETA':
        return '1'
    elif tipo == 'CAVALO':
        return '2'
    elif tipo == 'BITREM':
        return '3'
    elif tipo == 'BITRUCK':
        return '4'
    else:
        return '2'


def getCorVeic(cor):
    if 'AMAREL' in cor:
        return '0'
    elif 'AZUL' in cor:
        return '1'
    elif 'BEGE' in cor:
        return '2'
    elif 'BRANC' in cor:
        return '3'
    elif 'CINZA' in cor:
        return '4'
    elif 'DOURAD' in cor:
        return '5'

    elif 'GREN' in cor:
        return '6'
    elif 'LARANJA' in cor:
        return '7'
    elif 'MARROM' in cor:
        return '8'
    elif 'PRATA' in cor:
        return '9'
    elif 'PRET' in cor:
        return '10'
    elif 'ROSA' in cor:
        return '11'
    elif 'ROX' in cor:
        return '12'
    elif 'VERDE' in cor:
        return '13'
    elif 'VERMELH' in cor:
        return '14'
    elif 'FANTASIA' in cor:
        return '15'
    else:
        return ''


def getTipoCombustivel(tipo):
    if 'ALCOOL' in tipo:
        return '1'
    elif 'GASOLINA' in tipo:
        return '2'
    elif 'GNV' in tipo:
        return '3'
    elif 'FLEX' in tipo:
        return '4'
    elif (not ('DIESEL' in tipo)) and (tipo != ''):
        return '5'
    else:
        return '0'


def getTipoCarreta(tipo):
    if 'ABERT' in tipo:
        return '0'
    elif 'FECHAD' in tipo:
        return '1'
    elif 'SIDER' in tipo:
        return '2'
    elif 'PRANCHA' in tipo:
        return '3'
    elif 'TANQUE' in tipo:
        return '4'
    elif 'BASCULANTE' in tipo:
        return '5'
    elif 'CAVALO' in tipo:
        return ''
    else:
        return '6'


def getTipoRastreador(tipo):
    if 'SEM EQUIPAMENTO' in tipo:
        return '0'
    if 'AUTOTRAC' in tipo:
        return '1'
    elif 'CONTROL LOC' in tipo:
        return '2'
    elif 'CONTROLSAT' in tipo:
        return '3'
    elif 'ITURAN' in tipo:
        return '4'
    elif 'JABURSAT' in tipo:
        return '5'
    elif 'OMNILINK' in tipo:
        return '6'
    elif 'RODOSIS' in tipo:
        return '7'
    elif 'SASCAR' in tipo:
        return '8'
    elif 'SPY' in tipo:
        return '9'
    elif 'RCF' in tipo:
        return '10'
    elif 'CIELO' in tipo:
        return '11'
    elif 'LOCALIZADOR' in tipo:
        return '12'
    elif 'VOLKSNET' in tipo:
        return '13'
    elif 'SIGHRA' in tipo:
        return '14'
    elif 'LINKER' in tipo:
        return '15'
    elif 'POSITRON' in tipo:
        return '16'
    elif 'AUTOSAT' in tipo:
        return '17'
    elif 'ONIXSAT' in tipo:
        return '18'
    elif 'OMNILOC' in tipo:
        return '19'
    elif 'APLICATIVO RONDONMOBILE' in tipo:
        return '20'
    elif 'HPS TECNOLOGIA' in tipo:
        return '21'
    elif 'LINK FULL SAT' in tipo:
        return '22'
    elif 'ISCA' in tipo:
        return '23'
    elif 'LINK MONITORAMENTO' in tipo:
        return '24'
    else:
        return ''


def getNomeResp(reqJSON):
    nomeResp = getJSON(reqJSON, 'prop_contato')
    isPF = len(getJSON(reqJSON, 'prop_cnpjcpf')) == 11
    if nomeResp != '':
        return nomeResp
    elif isPF:
        return getJSON(reqJSON, 'prop_nome')
    else:
        return ''


def getFoneRespVeic(reqJson):
    celular = getJSON(reqJson, 'prop_celularnumero')
    if celular != '':
        return getJSON(reqJson, 'prop_celularddd') + celular
    else:
        return getJSON(reqJson, 'prop_celularddd') + getJSON(reqJson, 'prop_celularddd')


def requestRondonCadastrarVeiculo(reqJSON, codEMonitorAcao):
    jsonSor = GetJson(reqJSON)
    getJSON = jsonSor.getJSON

    erros = consistRondonCadastrarVeiculo(reqJSON, codEMonitorAcao)
    if codEMonitorAcao == ACAO_RONDON_CADASTRARVEICULO:
        prefixTag = 'veic_'
    elif codEMonitorAcao == ACAO_RONDON_CADASTRARCARRETA1:
        prefixTag = 'car1_'
    elif codEMonitorAcao == ACAO_RONDON_CADASTRARCARRETA2:
        prefixTag = 'car2_'
    elif codEMonitorAcao == ACAO_RONDON_CADASTRARCARRETA3:
        prefixTag = 'car3_'
    if erros != '':
        return '', erros

    veic = {}

    mct = getJSON(prefixTag + 'numeromct')
    veic['PLACA'] = getJSON(prefixTag + 'placa')
    veic['PLACA_UF'] = getCodUF(getJSON(prefixTag + 'uf'))
    veic['PLACA_CIDADE'] = getJSON(prefixTag + 'nomecidade')
    veic['CHASSI'] = getJSON(prefixTag + 'chassi')
    veic['RENAVAM'] = getJSON(prefixTag + 'renavam')
    veic['MARCA'] = getJSON(prefixTag + 'marca')
    veic['MODELO'] = getJSON(prefixTag + 'modelo')
    veic['ANO_FABRICACAO'] = getJSON(prefixTag + 'anofab')
    veic['ANO_MODELO'] = getJSON(prefixTag + 'anomod')
    veic['TIPO_VEICULO'] = getTipoVeic(getJSON(prefixTag + 'tipoveic'))
    veic['COR'] = getCorVeic(getJSON(prefixTag + 'cor'))

    if codEMonitorAcao == ACAO_RONDON_CADASTRARVEICULO:
        veic['TIPO_COMBUSTIVEL'] = getTipoCombustivel(getJSON(prefixTag + 'tipocombustivel'))
        veic['RESPONSAVEL_NOME'] = getNomeResp(reqJSON)
        veic['RESPONSAVEL_TELEFONE'] = getFoneRespVeic(reqJSON)
        veic['TIPO_RASTREADOR'] = getTipoRastreador(getJSON(prefixTag + 'tiporastreador'))

    if getTipoVeic(getJSON(prefixTag + 'tipoveic')) == '1':
        veic['TIPO_CARRETA'] = getTipoCarreta(getJSON(prefixTag + 'tipocarr'))  # "car1_tipocarr

    if mct != '':
        veic['MCT'] = getJSON(prefixTag + 'numeromct')
    veic['PROPRIETARIO_CPF_CNPJ'] = getJSON('prop_cnpjcpf')

    req = json.dumps(veic)
    return req, erros


def requestRondonMotoristaFoto(reqJson):
    try:
        arq = getJSON(reqJson, 'arq')
        foto = base64.b64decode(arq)
        arqFoto = '/sistemas/emonitorpy/tmp/rondon_fotomot.jpg'
        with open(arqFoto, "wb") as img_file:
            img_file.write(foto)

        fotoDescriptor = open(arqFoto, 'rb')
        files = [
            ('file', fotoDescriptor)
        ]
        return {}, '', files
    except Exception as e:
        print('Erro em requestRondonMotoristaFoto')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO', []


def requestRondonMotoristaFotoCnh(reqJson):
    try:
        arq = getJSON(reqJson, 'arq')
        foto = base64.b64decode(arq)
        arqFoto = '/sistemas/emonitorpy/tmp/rondon_fotomotcnh.jpg'
        with open(arqFoto, "wb") as img_file:
            img_file.write(foto)

        fotoDescriptor = open(arqFoto, 'rb')
        files = [
            ('file', fotoDescriptor)
        ]
        return {}, '', files
    except Exception as e:
        print('Erro em requestRondonMotoristaFotoCnh')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO', []


def responseRondonCadastrarProprietario(resp):
    retcode = resp.status_code
    msg = ''
    if retcode == 201:
        ret = resp.content.decode('utf-8')
        root = json.loads(ret)
        atualizado = getJSON(root, 'atualizado')
        if atualizado:
            msg = 'PROPRIETARIO ATUALIZADO COM SUCESSO'
        else:
            msg = 'PROPRIETARIO CADASTRADO COM SUCESSO'
        return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msg + '</msg></resp>', ''

    elif retcode == 202:
        msg = '[HOMOLOG]PROPRIETARIO CADASTRADO COM SUCESSO'
    elif retcode == 208:
        msg = 'DADOS EM ANÁLISE'
    elif retcode == 409:
        msg = 'JÁ EXISTENTE E LIBERADO'

    if msg != '':
        return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msg + '</msg></resp>', ''

    elif retcode == 422:
        return responseRondonCadastrarGeral(resp)
    elif retcode == 500:
        return '', 'ERRO INTERNO NA GERENCIADORA DE RISCO. FAVOR ENTRAR EM CONTATO COM ELA.'
    else:
        return '', 'ERRO NÃO PREVISTO PELA GERENCIADORA DE RISCO: ' + str(retcode)


def responseRondonCadastrarMotorista(resp):
    retcode = resp.status_code
    msg = ''
    if retcode == 201:
        ret = resp.content.decode('utf-8')
        root = json.loads(ret)
        atualizado = getJSON(root, 'atualizado')
        if atualizado:
            msg = 'MOTORISTA ATUALIZADO COM SUCESSO'
        else:
            msg = 'MOTORISTA CADASTRADO COM SUCESSO'
        return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msg + '</msg></resp>', ''

    elif retcode == 202:
        msg = '[HOMOLOG]CADASTRADO COM SUCESSO', ''
    elif retcode == 208:
        msg = 'DADOS EM ANÁLISE'
    elif retcode == 409:
        msg = 'JÁ EXISTENTE E LIBERADO', ''

    if msg != '':
        return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msg + '</msg></resp>', ''

    elif retcode == 422:
        return responseRondonCadastrarGeral(resp)
    elif retcode == 500:
        return '', 'ERRO INTERNO NA GERENCIADORA DE RISCO. FAVOR ENTRAR EM CONTATO COM ELA.'
    else:
        return '', 'ERRO NÃO PREVISTO PELA GERENCIADORA DE RISCO: ' + str(retcode)
    # return responseRondonCadastrarGeral(resp)


def responseRondonCadastrarVeiculo(resp):
    retcode = resp.status_code
    msg = ''
    if retcode == 201:
        ret = resp.content.decode('utf-8')
        root = json.loads(ret)
        atualizado = getJSON(root, 'atualizado')
        if atualizado:
            msg = 'VEÍCULO ATUALIZADO COM SUCESSO'
        else:
            msg = 'VEÍCULO CADASTRADO COM SUCESSO'
        return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msg + '</msg></resp>', ''

    elif retcode == 202:
        msg = '[HOMOLOG]CADASTRADO COM SUCESSO'
    elif retcode == 208:
        msg = 'DADOS EM ANÁLISE'
    elif retcode == 409:
        msg = 'JÁ EXISTENTE E LIBERADO'

    if msg != '':
        return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msg + '</msg></resp>', ''

    elif retcode == 422:
        return responseRondonCadastrarGeral(resp)
    elif retcode == 500:
        return '', 'ERRO INTERNO NA GERENCIADORA DE RISCO. FAVOR ENTRAR EM CONTATO COM ELA.'


    else:
        return '', 'ERRO NÃO PREVISTO PELA GERENCIADORA DE RISCO: ' + str(retcode)


def responseRondonCadastrarConhecimento(resp):
    return responseRondonCadastrarGeral(resp)


def responseRondonCadastrarGeral(resp):
    try:
        errors = resp.json()
        msg = ''
        for key in errors:
            msg += key + ':'
            for error in errors[key]:
                if error == 'proprietário não encontrado.':
                    msg += "%s\n" % error + '- Cadastre o proprietário na GR Rondon!'
                else:
                    msg += "%s\n" % error

        return '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><msg>' + msg + '</msg></resp>', ''
    except Exception as e:
        print('Erro em responseRondonCadastrarGeral')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA GERENCIADORA DE RISCO'


def responseRondonMotoristaFoto(resp):
    retcode = resp.status_code

    msgSuccess = ''
    msgError = ''
    if retcode == 201:
        msgSuccess = 'FOTO DO MOTORISTA ENVIADA COM SUCESSO!'
    elif retcode == 202:
        msgSuccess = '[HOMOLOG]FOTO DO MOTORISTA ENVIADA COM SUCESSO!'
    elif retcode == 208:
        msgSuccess = 'REGISTRO EM ANÁLISE'
    elif retcode == 400:
        msgError = 'ANEXO NÃO PERMITIDO'
    elif retcode == 404:
        msgError = 'REGISTRO NÃO ENCONTRADO'
    elif retcode == 409:
        msgError = 'REGISTRO JÁ EXISTENTE E LIBERADO'
    elif retcode == 412:
        msgError = 'REGISTRO NÃO ESTÁ COM A SITUAÇÃO AG. DOCUMENTO'
    elif retcode == 422:
        return responseRondonCadastrarGeral(resp)
    elif retcode == 500:
        return '', 'ERRO INTERNO NA GERENCIADORA DE RISCO. FAVOR ENTRAR EM CONTATO COM A MESMA.'

    if msgError != '':
        return '', msgError
    elif msgSuccess != '':
        return msgSuccess, ''
    else:
        return '', 'ERRO NÃO PREVISTO PELA GERENCIADORA DE RISCO: ' + str(retcode)


def responseRondonMotoristaCnh(resp):
    retcode = resp.status_code
    if retcode == 201:
        return 'FOTO DO MOTORISTA ENVIADA COM SUCESSO!', ''
    elif retcode == 202:
        return '[HOMOLOG]FOTO DO MOTORISTA ENVIADA COM SUCESSO!', ''
    elif retcode == 208:
        return '', 'REGISTRO EM ANÁLISE'
    elif retcode == 400:
        return 'ANEXO NÃO PERMITIDO', ''
    elif retcode == 404:
        return 'REGISTRO NÃO ENCONTRADO', ''
    elif retcode == 409:
        return 'REGISTRO JÁ EXISTENTE E LIBERADO', ''
    elif retcode == 412:
        return 'REGISTRO NÃO ESTÁ COM A SITUAÇÃO AG. DOCUMENTO', ''
    elif retcode == 422:
        return responseRondonCadastrarGeral(resp)
    elif retcode == 500:
        return '', 'ERRO INTERNO NA GERENCIADORA DE RISCO. FAVOR ENTRAR EM CONTATO COM ELA.'
    else:
        return '', 'ERRO NÃO PREVISTO PELA GERENCIADORA DE RISCO: ' + str(retcode)


def getCodUF(uf):
    switcher = {
        "OP": "0",
        "EX": "0",
        "AC": "1",
        "AL": "2",
        "AP": "3",
        "AM": "4",
        "BA": "5",
        "CE": "6",
        "DF": "7",
        "ES": "8",
        "GO": "9",
        "MA": "10",
        "MT": "11",
        "MS": "12",
        "MG": "13",
        "PA": "14",
        "PB": "15",
        "PR": "16",
        "PE": "17",
        "PI": "18",
        "RJ": "19",
        "RN": "20",
        "RS": "21",
        "RO": "22",
        "RR": "23",
        "SC": "24",
        "SP": "25",
        "SE": "26",
        "TO": "27",
        "SD": "28",
        "BL": "29",
    }
    return switcher.get(uf, '99')


def getCodCatCNH(cat):
    switcher = {
        "A": "0",
        "B": "1",
        "C": "2",
        "D": "3",
        "E": "4",
        "AB": "5",
        "AC": "6",
        "AD": "7",
        "AE": "8",
        "MOPP": "9",
    }
    return switcher.get(cat, '99')


def preProcessURLRondon(url, req):
    return url + '?' + req.decode("utf-8"), ''
