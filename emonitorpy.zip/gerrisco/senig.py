import base64
from typing import Tuple

import xmltodict
from requests import Response

from ActionProcessor import ActionProcessor, parse_props, handle_exception_factory
from geral import *
from geralxml import mount_xml_response, xml_from_dict


class SenigException(Exception):
    pass


# Classe base
class Senig(ActionProcessor):
    # INSTANCIAS
    HOST = 'http://servsenigwin.virtuaserver.com.br'
    TEST_HOST = 'http://servsenigwin.virtuaserver.com.br'
    BASE_PATH = '/wsdl/WebAppAverba.exe/soap/IWebAppAverba'

    REGISTER_CTE = 4350
    REGISTER_MDFE = 4351
    CANCEL_CTE = 4352

    def __init__(self):
        self.add_callable_records('url', {
            self.DEFAULT_FUNCTION: self.make_url_assembler()
        })

        super().__init__()

    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        return {
            'Content-type': 'text/xml',
        }, ''


#
#   Códigos independentes de instancia
#
def _senig_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a Senig:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    SenigException,
    _senig_exception_callback,
    any_exception_callback
)

#
#   Instancia limpa e sem configuração
#
_senig = Senig()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = _senig.link_to_factory('request')
_link_to_response = _senig.link_to_factory('response')


@_link_to_request(_senig.REGISTER_CTE)
@_handle_exception
def _register_cte(req: dict) -> Tuple[str, str]:
    xml_base64 = req.get('xml_cte_senig', '')
    xml = base64.b64decode(xml_base64).decode('utf-8')
    xml = xml.replace('\n', '')
    xml = xml.replace('\r', '')
    # xml = xml.replace('<tpAmb>2</tpAmb>', '<tpAmb>1</tpAmb>')

    soap: dict = {
        'soapenv:Envelope': {
            '@xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance',
            '@xmlns:xsd': 'http://www.w3.org/2001/XMLSchema',
            '@xmlns:soapenv': 'http://schemas.xmlsoap.org/soap/envelope/',
            '@xmlns:urn': 'urn:WebAppAverbaIntf-IWebAppAverba',

            'soapenv:Header': '',
            'soapenv:Body': {
                'urn:EnviaXMLRet': {
                    '@soapenv:encodingStyle': 'http://schemas.xmlsoap.org/soap/encoding/',
                    'fFileSend': {
                        '@xsi:type': 'xsd:string',
                        '#value': xml,
                    },
                    'cCNPJ': {
                        '@xsi:type': 'xsd:string',
                        '#value': req.get('cnpj_empresa', ''),
                    },
                    'cNumCTE': {
                        '@xsi:type': 'xsd:string',
                        '#value': req.get('num_cte', ''),
                    }
                }

            }
        }
    }

    return xml_from_dict(soap, indent=True, prolog=True), ''


@_link_to_request(_senig.REGISTER_MDFE)
@_handle_exception
def _register_mdfe(req: dict) -> Tuple[str, str]:
    xml_base64 = req.get('xml_mdfe_senig', '')
    xml = base64.b64decode(xml_base64).decode('utf-8')
    xml = xml.replace('\n', '')
    xml = xml.replace('\r', '')
    # xml = xml.replace('<tpAmb>2</tpAmb>', '<tpAmb>1</tpAmb>')

    soap: dict = {
        'soapenv:Envelope': {
            '@xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance',
            '@xmlns:xsd': 'http://www.w3.org/2001/XMLSchema',
            '@xmlns:soapenv': 'http://schemas.xmlsoap.org/soap/envelope/',
            '@xmlns:urn': 'urn:WebAppAverbaIntf-IWebAppAverba',

            'soapenv:Header': '',
            'soapenv:Body': {
                'urn:EnviaManifesto': {
                    '@soapenv:encodingStyle': 'http://schemas.xmlsoap.org/soap/encoding/',
                    'fFileSend': {
                        '@xsi:type': 'xsd:string',
                        '#value': xml,
                    },
                    'cCNPJ': {
                        '@xsi:type': 'xsd:string',
                        '#value': req.get('cnpj_empresa', ''),
                    }
                }
            }
        }
    }

    return xml_from_dict(soap, indent=True, prolog=True), ''


@_link_to_request(_senig.CANCEL_CTE)
@_handle_exception
def _cancel_register_cte(req: dict) -> Tuple[str, str]:
    xml_base64 = req.get('xml_cte_senig', '')
    xml = base64.b64decode(xml_base64).decode('utf-8')
    xml = xml.replace('\n', '')
    xml = xml.replace('\r', '')
    # xml = xml.replace('<tpAmb>2</tpAmb>', '<tpAmb>1</tpAmb>')

    soap: dict = {
        'soapenv:Envelope': {
            '@xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance',
            '@xmlns:xsd': 'http://www.w3.org/2001/XMLSchema',
            '@xmlns:soapenv': 'http://schemas.xmlsoap.org/soap/envelope/',
            '@xmlns:urn': 'urn:WebAppAverbaIntf-IWebAppAverba',

            'soapenv:Header': '',
            'soapenv:Body': {
                'urn:EnviaXMLCANRet': {
                    '@soapenv:encodingStyle': 'http://schemas.xmlsoap.org/soap/encoding/',
                    'fFileSend': {
                        '@xsi:type': 'xsd:string',
                        '#value': xml,
                    },
                    'cCNPJ': {
                        '@xsi:type': 'xsd:string',
                        '#value': req.get('cnpj_empresa', ''),
                    },
                    'cNumCTE': {
                        '@xsi:type': 'xsd:string',
                        '#value': req.get('num_cte', ''),
                    }
                }

            }
        }
    }

    return xml_from_dict(soap, indent=True, prolog=True), ''


@_link_to_response(_senig.REGISTER_CTE)
def _in_register_cte(resp: Response) -> Tuple[str, str]:
    ret = xmltodict.parse(resp.text)
    ret = deep_get(ret, 'SOAP-ENV:Envelope.SOAP-ENV:Body.NS1:EnviaXMLRetResponse.return.#text', '')
    ret = deep_get(xmltodict.parse(ret), 'soapenv:Envelope.soapenv:Body.return')

    resp_data = {}

    error = deep_get(ret, 'listaMensagem.dDetErr', '')

    if not error:
        resp_data = {
            'sucesso': True,
            'conteudo': {
                'protocol': re.sub(r'^{|}$', '', ret.get('cProtocolo')),
                'dt_rec': ret.get('dtRec'),
                'status': deep_get(ret, 'listaMensagem.cStatus'),
            }
        }
    elif error:
        resp_data = {
            'sucesso': False,
            'msg_erro': deep_get(ret, 'listaMensagem.cStatus') + '\n' + deep_get(ret, 'listaMensagem.dDetErr'),
        }

    return mount_xml_response(resp_data), ''


@_link_to_response(_senig.CANCEL_CTE)
def _in_cancel_register_cte(resp: Response) -> Tuple[str, str]:
    ret = xmltodict.parse(resp.text)
    ret = deep_get(ret, 'SOAP-ENV:Envelope.SOAP-ENV:Body.NS1:EnviaXMLCANRetResponse.return.#text', '')
    ret = deep_get(xmltodict.parse(ret), 'soapenv:Envelope.soapenv:Body.return')

    resp_data = {}

    error = deep_get(ret, 'listaMensagem.dDetErr', '')

    if not error:
        resp_data = {
            'sucesso': True,
            'conteudo': {
                'protocol': re.sub(r'^{|}$', '', ret.get('cProtocolo')),
                'dt_rec': ret.get('dtRec'),
                'status': deep_get(ret, 'listaMensagem.cStatus'),
            }
        }
    elif error:
        resp_data = {
            'sucesso': False,
            'msg_erro': deep_get(ret, 'listaMensagem.cStatus') + '\n' + deep_get(ret, 'listaMensagem.dDetErr'),
        }

    return mount_xml_response(resp_data), ''


@_link_to_response(_senig.REGISTER_MDFE)
def _in_register_mdfe(resp: Response) -> Tuple[str, str]:
    ret = xmltodict.parse(resp.text)
    ret = deep_get(ret, 'SOAP-ENV:Envelope.SOAP-ENV:Body.NS1:EnviaManifestoResponse.return.#text', '')
    ret = deep_get(xmltodict.parse(ret), 'soapenv:Envelope.soapenv:Body.return')

    resp_data = {}

    error = deep_get(ret, 'listaMensagem.dDetErr', '')

    if not error:
        resp_data = {
            'sucesso': True,
            'conteudo': {
                'protocol': re.sub(r'^{|}$', '', ret.get('cProtocolo')),
                'dt_rec': ret.get('dtRec'),
                'status': deep_get(ret, 'listaMensagem.cStatus'),
            }
        }
    elif error:
        resp_data = {
            'sucesso': False,
            'msg_erro': deep_get(ret, 'listaMensagem.cStatus') + '\n' + deep_get(ret, 'listaMensagem.dDetErr'),
        }

    return mount_xml_response(resp_data), ''
