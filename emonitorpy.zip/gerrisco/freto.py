import time
from typing import Tuple

from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Util.Padding import unpad, pad
from requests import post

from ActionProcessor import ActionProcessor, handle_exception_factory, HttpMethod, parse_props
from geralxml import mount_xml_response


# Exceção customizada
class FretoException(Exception):
    pass


# Classe base
class Freto(ActionProcessor):
    BASE_URL = 'https://qa.freto.com/IntegrationAPI'

    CREATE_LOAD_OFFER = 3650
    INACTIVATE_LOAD_OFFER = 3651
    UPDATE_LOAD_OFFER = 3652
    CHECK_CARRIER_GROUPS = 3653
    CHECK_DRIVER_BY_CPF = 3654
    CHECK_LOAD_TYPES = 3655
    CHECK_VEHICLE_BY_LICENSE_PLATE = 3656

    def __init__(self):
        super().__init__()

        self.add_callable_records('url', {
            self.CREATE_LOAD_OFFER: (_make_url, {'path': '/v2/LoadOffer/Create'}),
            self.INACTIVATE_LOAD_OFFER: (_make_url, {'path': '/v2/LoadOffer/Inactivate'}),
            self.UPDATE_LOAD_OFFER: (_make_url, {'path': '/v2/LoadOffer/Update'}),
            self.CHECK_CARRIER_GROUPS: (_make_url, {'path': '/v2/Carrier/CheckGroups', 'method': HttpMethod.GET}),
            self.CHECK_DRIVER_BY_CPF: (_make_url, {'path': '/v2/Driver/CheckByCPF'}),
            self.CHECK_LOAD_TYPES: (_make_url, {'path': '/v2/LoadOffer/CheckLoadTypes', 'method': HttpMethod.GET}),
            self.CHECK_VEHICLE_BY_LICENSE_PLATE: (_make_url, {'path': '/v2/Vehicle/CheckByLicensePlate'})
        })

    def obter_token(self, props: dict, url: str) -> dict:
        user = props.get('usuario')
        password = props.get('senha')

        body = ''.join([
            user,
            password
        ])

        try:
            resp = post(self.BASE_URL + '/Token', data=body)
        except Exception as e:
            raise Exception('Erro ao buscar token de autorização da FreteBras!\n' + str(e))

        if resp.status_code == 200:
            token = resp.json().get('access_token', '')

            return {'Authorization': token}
        else:
            raise Exception('Não foi possível realizar a autenticação na FreteBras.')


#
#   Códigos independentes de instancia
#
def _freto_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a Freto'


_handle_exception = handle_exception_factory(
    FretoException,
    _freto_exception_callback,
    any_exception_callback
)


# Funções para obtenção de URLs
@_handle_exception
def _make_url(path: str, method: HttpMethod = HttpMethod.POST) -> Tuple[str, str]:
    url = freto.BASE_URL + path
    return url, method.name


#
#   Instancia limpa e sem configuração
#
freto = Freto()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = freto.link_to_factory('request')
_link_to_response = freto.link_to_factory('response')


# Funções para obtenção de envios
@_handle_exception
@_link_to_request(freto.CREATE_LOAD_OFFER)
def _create_load_offer_body(req: dict) -> Tuple[str, str]:
    body = {
        'LoadTypeId': 0,
        'Schedule': [
            {
                'Date': '2021-11-09T11:59:13.114Z',
                'TotalLoading': 0
            }
        ],
        'FreightValue': 0,
        'PricingTypeId': 0,
        'AdvancePayment': 0,
        'VehicleTypes': [
            0
        ],
        'VehicleBodyTypes': [
            0
        ],
        'PromotionStartDate': '2021-11-09T11:59:13.114Z',
        'Name': 'string',
        'UseGR': True,
        'IsActive': True,
        'InternalShipperCode': 'string',
    }

    return mount_xml_response(body), ''


@_handle_exception
@_link_to_request(freto.INACTIVATE_LOAD_OFFER)
def _inactivate_load_offer_body(req: dict) -> Tuple[str, str]:
    body = 'LoadOfferId=' + req.get('id_oferta', '')
    return body, ''


@_handle_exception
@_link_to_request(freto.UPDATE_LOAD_OFFER)
def _update_load_offer_body(req: dict) -> Tuple[str, str]:
    body = {
        'LoadTypeId': 0,
        'Schedule': [
            {
                'Date': '2021-11-09T11:59:13.114Z',
                'TotalLoading': 0
            }
        ],
        'FreightValue': 0,
        'PricingTypeId': 0,
        'AdvancePayment': 0,
        'VehicleTypes': [
            0
        ],
        'VehicleBodyTypes': [
            0
        ],
        'PromotionStartDate': '2021-11-09T11:59:13.114Z',
        'Name': 'string',
        'UseGR': True,
        'IsActive': True,
        'InternalShipperCode': 'string',
    }

    return mount_xml_response(body), ''


@_handle_exception
@_link_to_request(freto.CHECK_DRIVER_BY_CPF)
def _check_driver_by_cpf_body(req: dict) -> Tuple[str, str]:
    body = 'Cpf=' + req.get('mot_cpf', '')
    return body, ''


@_handle_exception
@_link_to_request(freto.CHECK_VEHICLE_BY_LICENSE_PLATE)
def _check_vehicle_by_license_plate_body(req: dict) -> Tuple[str, str]:
    body = 'LicensePlate=' + req.get('veic_placa', '')
    return body, ''


@_handle_exception
@_link_to_request(freto.DEFAULT_FUNCTION)
def _default_body(req: dict) -> Tuple[str, str]:
    return '', 'Não implementado'


# Funções para tratamento de retorno
@_handle_exception
@_link_to_response(freto.DEFAULT_FUNCTION)
def _create_load_offer() -> Tuple[str, str]:
    return '', 'Não implementado'
