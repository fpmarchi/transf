from enum import Enum
from string import Template
from typing import Callable, Tuple, Union, Dict
from urllib.parse import urlparse, urlunparse

from .dispacher import Dispacher, Callable_cfg


class HttpMethod(Enum):
    DELETE = 0
    GET = 1
    POST = 2
    PUT = 3
    PATCH = 4


class ActionProcessor(Dispacher):
    HOST: Union[str, Dict[str, Union[str, Tuple[str, str]]]] = ''
    TEST_HOST: Union[str, Dict[str, Union[str, Tuple[str, str]]]] = ''
    BASE_PATH = ''
    TEST_BASE_PATH = ''
    # Parameters
    extract_host = False

    def __init__(self, request_builders: Callable_cfg = None, response_parsers: Callable_cfg = None):
        if request_builders:
            self.add_callable_records('request', request_builders)

        if response_parsers:
            self.add_callable_records('response', response_parsers)

    def build_request(self, context_req: dict, action_cod: int):
        return self.dispatch(action_cod, context_req, 'request')

    def parse_response(self, response: Union[str, dict], action_cod: int):
        return self.dispatch(action_cod, response, 'response')

    def before_make_url(self):
        pass

    # Funções para obtenção de URLs
    def make_url_assembler(
            self, path='', method=HttpMethod.POST,
            use_template=False, host_slug='', extract_host=False

    ) -> Tuple[Callable, dict]:

        def read_default_host(env: int):
            host = self.HOST if env == 1 else self.TEST_HOST

            if host_slug and type(host) is dict:
                host = host.get(host_slug)

                if type(host) is tuple:
                    return host
                else:
                    return host, ''

            return host, ''

        def url_assembler(req: dict = None, url='', props: dict = None, extract_host_=False):
            self.before_make_url()

            environment = 0
            try:
                environment = int(props.get('ws_ambiente'))
            except (Exception,):
                pass

            host, base_path = read_default_host(environment)

            url = url.strip(' /')
            if url:
                parsed_uri = urlparse(url)
                if parsed_uri.path != '':
                    if not extract_host_:
                        return url, method.name

                    host = urlunparse(parsed_uri._replace(path='', params='', query='', fragment=''))
                else:
                    host = url

            base = '{host}{post_host}'.format(
                host=host,
                post_host=base_path or self.BASE_PATH if environment == 1
                else base_path or self.TEST_BASE_PATH or self.BASE_PATH
            )
            if use_template:
                t = Template(path)
                url = base + t.substitute(req)
            else:
                url = base + path

            return url, method.name

        return url_assembler, {
            'extract_host_': extract_host or self.extract_host
        }
