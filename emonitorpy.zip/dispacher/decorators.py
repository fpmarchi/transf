import re
import sys
from datetime import datetime
from functools import wraps
from traceback import extract_stack
from typing import Type, Callable, Any


class EmpyError(Exception):

    def __init__(self, msg, log_msg=None):
        self.msg = msg

        if not log_msg:
            self.log_msg = msg
        else:
            self.log_msg = log_msg

        super().__init__(self.msg)


def handle_exception_factory(ex: Type[Exception] = None, expected_cb: Callable[[dict], Any] = None,
                             unexpected_cb: Callable[[dict], Any] = None) -> Callable:
    def default_return(data: dict):
        return None, f'Exceção interceptada: {data.get("ex_name", "desconhecido")}' \
                     f' - {data.get("ex_message", "Mensagem não recuperada")}'

    if not expected_cb:
        expected_cb = default_return

    def handle_exception(func) -> Callable:
        @wraps(func)
        def handle_exception_wrapper(*args, **kwargs) -> Any:
            # error
            try:
                return func(*args, **kwargs)
            except Exception as e:
                _, _, exc_tb = sys.exc_info()
                stack = extract_stack(exc_tb.tb_frame)
                wrapper_name = handle_exception_wrapper.__code__.co_name

                is_expected = ex and isinstance(e, ex)
                if not is_expected and (sum(wrapper_name == frame.name for frame in stack) > 1) and not unexpected_cb:
                    raise e

                ex_data = {
                    'ex': e,
                    'ex_name': type(e).__name__,
                    'ex_message': str(e),
                    'default_return': default_return
                }

                now = datetime.now()
                debug = f'Exceção interceptada em {now.strftime("%Y-%m-%d %H:%M:%S")}:\n'

                prefix = 'Origem'
                while exc_tb.tb_next:
                    exc_tb = exc_tb.tb_next
                    frame_code = exc_tb.tb_frame.f_code

                    if wrapper_name == frame_code.co_name:
                        continue

                    if not exc_tb.tb_next:
                        prefix = 'Raiz'

                    debug += f'\t{prefix}: {frame_code.co_name} => {frame_code.co_filename}:{exc_tb.tb_lineno}.\n'
                    prefix = 'Call'

                debug += f'\tDetalhes: {ex_data["ex_name"]} - {getattr(e, "log_msg", ex_data["ex_message"])}'

                print(debug, file=sys.stderr)

                if is_expected:
                    return expected_cb(ex_data)
                elif unexpected_cb:
                    return unexpected_cb(ex_data)
                else:
                    return default_return(ex_data)

        return handle_exception_wrapper

    return handle_exception


def parse_props(function: Callable) -> Callable:
    props_pattern = re.compile(r'&(?=\w+=)')

    @wraps(function)
    def parse_props_wrapper(*args, **kwargs):
        for context in args:
            if (type(context) is dict) and (type(context.get('props')) is str):
                entries: list = props_pattern.split(context.get('props', ''))

                context['props'] = dict(
                    entry.split('=', 1)
                    for entry in entries
                    if entry.find('=') > 0
                )

        return function(*args, **kwargs)

    return parse_props_wrapper
