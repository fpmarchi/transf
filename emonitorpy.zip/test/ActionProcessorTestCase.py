import unittest

from dispacher import ActionProcessor
from dispacher.action_processor import HttpMethod


class ActionProcessorTestCase(unittest.TestCase):
    def setUp(self):
        self.integration = ExampleIntegration()
        self.integration.MIN_ACTION = 1
        self.integration.MAX_ACTION = 10

    def test_singleton_storage(self):
        ref1 = ExampleIntegration.get_instance(1, 10)
        ref2 = ExampleIntegration.get_instance(1, 10)

        self.assertIs(ref1, ref2)

    def test_make_url_assembler(self):
        assembler = self.integration.make_url_assembler('/path')

        self.assertTrue(callable(assembler[0]))
        self.assertIs(type(assembler[1]), dict)

    def test_basic_url_assembler(self):
        integration = ExampleIntegration()
        integration.MIN_ACTION = 1
        integration.MAX_ACTION = 10

        integration.HOST = 'http://prodhost'
        integration.TEST_HOST = 'http://testhost'

        integration.add_callable_records('url', {
            1: integration.make_url_assembler('/path'),
        })

        uri, method = integration.dispatch(1, {'props': 'ws_ambiente=1'}, 'url')

        self.assertEqual(uri, 'http://prodhost/path')
        self.assertEqual(method, 'POST')

        uri, method = integration.dispatch(1, {'props': 'ws_ambiente=0'}, 'url')

        self.assertEqual(uri, 'http://testhost/path')
        self.assertEqual(method, 'POST')

    def test_url_assembler_with_multiples_hosts(self):
        integration = ExampleIntegration()
        integration.MIN_ACTION = 1
        integration.MAX_ACTION = 10

        integration.HOST = {
            'slug1': 'http://prodhost1',
            'slug2': 'http://prodhost2',
        }
        integration.TEST_HOST = {
            'slug1': 'http://testhost1',
            'slug2': ('http://testhost2', '/base'),
        }

        integration.add_callable_records('url', {
            1: integration.make_url_assembler('/path1', host_slug='slug1'),
            2: integration.make_url_assembler('/path2', host_slug='slug2', method=HttpMethod.GET)
        })

        uri1, method1 = integration.dispatch(1, {'props': 'ws_ambiente=1'}, 'url')
        uri2, method2 = integration.dispatch(2, {'props': 'ws_ambiente=1'}, 'url')

        self.assertEqual(uri1, 'http://prodhost1/path1')
        self.assertEqual(method1, 'POST')
        self.assertEqual(uri2, 'http://prodhost2/path2')
        self.assertEqual(method2, 'GET')

        uri1, method1 = integration.dispatch(1, {'props': 'ws_ambiente=0'}, 'url')
        uri2, method2 = integration.dispatch(2, {'props': 'ws_ambiente=0'}, 'url')

        self.assertEqual(uri1, 'http://testhost1/path1')
        self.assertEqual(method1, 'POST')
        self.assertEqual(uri2, 'http://testhost2/base/path2')
        self.assertEqual(method2, 'GET')


class ExampleIntegration(ActionProcessor):
    pass
