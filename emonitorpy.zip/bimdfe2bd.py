import sys
from sqlalchemy.sql import *


from metadata import getEnginePGLight, getConnPG
from dao import *
from geral import wsstrtoAAAAMMDD
import geralsis


args = sys.argv[1:]
#args = ['01/01/2022','30/07/2022']
dataIni = wsstrtoAAAAMMDD(args[0])
dataFim = wsstrtoAAAAMMDD(args[1])

# engineEMonitor = getEnginePGLight(geralsis.prop, 'EMonitor')
# connPG = getConnPG(engineEMonitor)
#
# sql = text('SELECT '
#            'codemonitorspool, datains, arqxmlresp '
#            'FROM emonitorspool '
#            'WHERE status = 4 '
#            'AND codemonitoracao = 211 '
#            'AND datains BETWEEN \'' + dataIni + '\' AND \'' + dataFim + '\' '
#            'ORDER BY datains')
# dados = connPG.execute(sql).fetchall()
# i = 0
# size = len(dados)
# for rec in dados:
#     i += 1
#     print('Processando ' + str(i) + '/' + str(size) + ' - ' + str(rec['codemonitorspool']))
#     insBiMdfeDist(False, connPG, rec['arqxmlresp'], rec['codemonitorspool'])
#
# if connPG is not None:
#     connPG.close()
#
# exit(0)


