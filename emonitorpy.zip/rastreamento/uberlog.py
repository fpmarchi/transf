import json
from string import Template
from typing import Tuple

from requests import Response

from ActionProcessor import ActionProcessor, parse_props, HttpMethod, handle_exception_factory
from geral import *
from geralxml import mount_xml_response


class UberlogException(Exception):
    pass


# Classe base
class Uberlog(ActionProcessor):
    # INSTANCIAS
    BASE_URL = 'https://ssw.inf.br/api/'
    BASE_URL_TEST = 'https://ssw.inf.br/api/'

    AUTHENTICATE_USER = 4250
    SEND_OCCURRENCE = 4251

    def __init__(self):
        self.add_callable_records('url', {
            self.AUTHENTICATE_USER: (_make_url, _make_defaults('/generateToken')),
            self.SEND_OCCURRENCE: (_make_url, _make_defaults('/ocorrenciaParceiro')),
        })

        super().__init__()

    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        props = context_req.get('props')
        token = props.get('token')

        return {
            'authorization': token,
            'Content-type': 'application/json',
        }, ''


#
#   Códigos independentes de instancia
#
def _uberlog_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a Uberlog:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    UberlogException,
    _uberlog_exception_callback,
    any_exception_callback
)


# Funções para obtenção de URLs
@_handle_exception
def _make_defaults(path: str, method: HttpMethod = HttpMethod.POST, use_template: bool = None) -> dict:
    return {
        'path': path,
        **conditional_key('method', method),
        **conditional_key('use_template', use_template)
    }


@_handle_exception
def _make_url(path: str, method: HttpMethod = HttpMethod.GET, use_template: bool = False,
              req: dict = None, url: str = '', props: dict = None) -> Tuple[str, str]:
    if props is None:
        props = {}

    ambiente = 0
    try:
        ambiente = int(props.get('ws_ambiente'))
    except (Exception,):
        pass

    base = url.strip().rstrip('/') or (Uberlog.BASE_URL if ambiente == 1 else Uberlog.BASE_URL_TEST)
    if use_template:
        t = Template(path)
        url = base + t.substitute(req)
    else:
        url = base + path

    return url, method.name


@_handle_exception
def _make_defaults(path: str, method: HttpMethod = HttpMethod.POST, use_template: bool = None) -> dict:
    return {
        'path': path,
        **conditional_key('method', method),
        **conditional_key('use_template', use_template)
    }


#
#   Instancia limpa e sem configuração
#
_uberlog = Uberlog()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = _uberlog.link_to_factory('request')
_link_to_response = _uberlog.link_to_factory('response')


@_link_to_request(_uberlog.AUTHENTICATE_USER)
@_handle_exception
def _add_driver(req: dict, props: dict) -> Tuple[str, str]:
    data = {
        "domain": req.get('aux1', ''),
        "username": props.get('usuario', ''),
        "password": props.get('senha', ''),
        "cnpj_edi": req.get('con_cnpj_filial', ''),
    }

    return json.dumps(data), ''


@_link_to_request(_uberlog.SEND_OCCURRENCE)
@_handle_exception
def _add_driver(req: dict) -> Tuple[str, str]:
    data = {
        "cnpjRemetente": req.get('con_cnpj_filial', ''),
        "nf": {
            'serieNFe': req.get('serie_nfe', ''),
            'numeroNFe': int(req.get('numero_nfe', '')),
            'chaveNFe': req.get('chave_nfe', ''),
            'pedido': req.get('pedido_nfe', ''),
        },
        "cte": {
            'chaveCTe': req.get('chave_cte', ''),
        },
        "ocorrencia": {
            'dataHoraEvento': req.get('oco_data_hora', ''),
            'codigo': req.get('cod_envio', ''),
            'descricao': _verif_description(req.get('cod_envio', '')),
            'complemento': req.get('oco_obs', ''),
            'unidade': req.get('', ''),
            'imagem': req.get('', ''),
            'latitude': req.get('', ''),
            'longitude': req.get('', ''),
            'placaAgregado': req.get('', ''),
            'dataHoraAgendamento': req.get('', ''),
        },
    }

    return json.dumps(data), ''


@_link_to_response(_uberlog.AUTHENTICATE_USER, _uberlog.SEND_OCCURRENCE)
def _find_resultado_consulta(resp: Response) -> Tuple[str, str]:
    try:
        ret_code = resp.status_code
        resp = resp.json()
        resp_body = {}
    except (Exception,):
        raise UberlogException('Erro no retorno fora de padrão pela UberLog')

    # if ret_code == 401 or ret_code == 400:
    #     resp_data = {
    #         'sucesso': True,
    #         'conteudo': {
    #             "descricao": "OCORRENCIA PROCESSADA COM SUCESSO",
    #             "numeroNFe": "35191151914620000177550020000322361001919140",
    #             "chaveCTe": "35191151914620000177550020000322361001919140",
    #             "dataHora": "2019-11-07T00:20:54:000-03:00",
    #             "protocolo": "1807190015813979"
    #         }
    #     }
    #
    # elif PARA TESTE

    if ret_code == 401:
        resp_data = {
            'sucesso': False,
            'msg_erro': resp.get('message'),
        }
    elif ret_code == 400:
        resp_data = {
            'sucesso': False,
            'msg_erro': resp.get('descricao'),
        }
    elif ret_code in [200, 201]:
        resp_data = {
            'sucesso': True,
            'conteudo': resp,
        }
    else:
        resp_data = {
            'sucesso': False,
            'conteudo': resp,
        }

    return mount_xml_response(resp_data), ''


def _verif_description(cod_description):
    if cod_description == '1':
        return 'MERCADORIA ENTREGUE'
    elif cod_description == '2':
        return 'MERCADORIA PRE-ENTREGUE (MOBILE)'
    elif cod_description == '3':
        return 'MERCADORIA DEVOLVIDA AO REMETENTE'
    elif cod_description == '4':
        return 'DESTINATARIO RETIRA'
    elif cod_description == '5':
        return 'CLIENTE ALEGA MERCAD DESACORDO C/ PEDIDO'
    elif cod_description == '7':
        return 'CHEGADA NO CLIENTE DESTINATÁRIO'
    elif cod_description == '9':
        return 'DESTINATARIO DESCONHECIDO'
    elif cod_description == '10':
        return 'LOCAL DE ENTREGA NAO LOCALIZADO'
    elif cod_description == '11':
        return 'LOCAL DE ENTREGA FECHADO/AUSENTE'
    elif cod_description == '13':
        return 'ENTREGA PREJUDICADA PELO HORARIO'
    elif cod_description == '14':
        return 'NOTA FISCAL ENTREGUE'
    elif cod_description == '15':
        return 'ENTREGA AGENDADA PELO CLIENTE'
    elif cod_description == '16':
        return 'ENTREGA AGUARDANDO INSTRUCOES'
    elif cod_description == '18':
        return 'MERCAD REPASSADA P/ PROX TRANSPORTADORA'
    elif cod_description == '20':
        return 'CLIENTE ALEGA FALTA DE MERCADORIA'
    elif cod_description == '23':
        return 'CLIENTE ALEGA MERCADORIA AVARIADA'
    elif cod_description == '25':
        return 'REMETENTE RECUSA RECEBER DEVOLUÇÃO'
    elif cod_description == '26':
        return 'AGUARDANDO AUTORIZACAO P/ DEVOLUCAO'
    elif cod_description == '27':
        return 'DEVOLUCAO AUTORIZADA'
    elif cod_description == '28':
        return 'AGUARDANDO AUTORIZACAO P/ REENTREGA'
    elif cod_description == '29':
        return 'REENTREGA AUTORIZADA'
    elif cod_description == '31':
        return 'PRIMEIRA TENTATIVA DE ENTREGA'
    elif cod_description == '32':
        return 'SEGUNDA TENTATIVA DE ENTREGA'
    elif cod_description == '33':
        return 'TERCEIRA TENTATIVA DE ENTREGA'
    elif cod_description == '34':
        return 'MERCADORIA EM CONFERENCIA NO CLIENTE'
    elif cod_description == '35':
        return 'AGUARDANDO AGENDAMENTO DO CLIENTE'
    elif cod_description == '36':
        return 'MERCAD EM DEVOLUCAO EM OUTRA OPERACAO'
    elif cod_description == '37':
        return 'ENTREGA REALIZADA COM RESSALVA'
    elif cod_description == '38':
        return 'CLIENTE RECUSA/NAO PODE RECEBER MERCAD'
    elif cod_description == '39':
        return 'CLIENTE RECUSA PAGAR O FRETE'
    elif cod_description == '40':
        return 'FRETE DO CTRC DE ORIGEM RECEBIDO'
    elif cod_description == '45':
        return 'CARGA SINISTRADA PENDÊNCIA'
    elif cod_description == '48':
        return 'EDI FOI RECEPCIONADO MAS A MERCADORIA NÃO'
    elif cod_description == '50':
        return 'FALTA DE MERCADORIA'
    elif cod_description == '51':
        return 'SOBRA DE MERCADORIA'
    elif cod_description == '52':
        return 'FALTA DE DOCUMENTACAO'
    elif cod_description == '53':
        return 'MERCADORIA AVARIADA'
    elif cod_description == '54':
        return 'EMBALAGEM AVARIADA'
    elif cod_description == '55':
        return 'CARGA ROUBADA'
    elif cod_description == '56':
        return 'MERCAD RETIDA PELA FISCALIZACAO'
    elif cod_description == '57':
        return 'GREVE OU PARALIZACAO'
    elif cod_description == '58':
        return 'MERCAD LIBERADA PELA FISCALIZACAO'
    elif cod_description == '59':
        return 'VEICULO AVARIADO/SINISTRADO'
    elif cod_description == '60':
        return 'VIA INTERDITADA'
    elif cod_description == '61':
        return 'MERCADORIA CONFISCADA PELA FISCALIZAÇÃO'
    elif cod_description == '62':
        return 'VIA INTERDITADA POR FATORES NATURAIS'
    elif cod_description == '65':
        return 'NOTIFIC REMET DE ENVIO NOVA MERCAD'
    elif cod_description == '66':
        return 'NOVA MERCAD ENVIADA PELO REMETENTE'
    elif cod_description == '72':
        return 'COLETA COMANDADA'
    elif cod_description == '73':
        return 'AGUARDANDO DISPONIBILIDADE DE BALSA'
    elif cod_description == '74':
        return 'PRIMEIRA TENTATIVA DE COLETA'
    elif cod_description == '75':
        return 'SEGUNDA TENTATIVA DE COLETA'
    elif cod_description == '76':
        return 'TERCEIRA TENTATIVA DE COLETA'
    elif cod_description == '77':
        return 'COLETA CANCELADA'
    elif cod_description == '78':
        return 'COLETA REVERSA REALIZADA'
    elif cod_description == '79':
        return 'COLETA REVERSA AGENDADA'
    elif cod_description == '80':
        return 'MERCADORIA RECEBIDA PARA TRANSPORTE'
    elif cod_description == '82':
        return 'SAIDA DE UNIDADE'
    elif cod_description == '83':
        return 'CHEGADA EM UNIDADE'
    elif cod_description == '84':
        return 'CHEGADA NA UNIDADE'
    elif cod_description == '85':
        return 'SAIDA PARA ENTREGA'
    elif cod_description == '86':
        return 'ESTORNO DE BAIXA/ENTREGA ANTERIOR'
    elif cod_description == '87':
        return 'DISPONIVEL NO LOCKER'
    elif cod_description == '88':
        return 'RESGATE DE MERCADORIA SOLICITADA PELO CLIENTE'
    elif cod_description == '91':
        return 'MERCADORIA EM INDENIZACAO'
    elif cod_description == '92':
        return 'MERCADORIA INDENIZADA'
    elif cod_description == '93':
        return 'CTRC EMITIDO PARA EFEITO DE FRETE'
    elif cod_description == '94':
        return 'CTRC SUBSTITUIDO'
    elif cod_description == '95':
        return 'PREVISÃO DE ENTREGA ALTERADA'
    elif cod_description == '99':
        return 'CTRC BAIXADO/CANCELADO'
    else:
        ''
