import datetime
from geral import datetostr, dbdatetimezero, dbdatetimelim, defstrtodate, incdatetimeactual, datetimeactualtostr
from geralsis import prop, getOutrasInstalacoes, isDuplInst, getCamposInst
from metadata import getEnginePGLight, getConnPG
import dao


isDebug = False


def printMsg(msg):
    debug = False
    if debug:
        print(datetimeactualtostr() + ' - ' + msg + ' ...')
    else:
        print(datetimeactualtostr() + ' - ' + msg + ' ...', file=open('/sistemas/emonitorpy/log/biautors.log', 'a'))

            
def processBiAutors(dataProc):
    #
    dataIni = dbdatetimezero(dataProc)
    dataFim = dbdatetimelim(dataProc)
    listTipo = {'N','C','M','S'}
    #
    printMsg('Iniciando o processamento de BIAUTORS em ' + datetostr(dataProc))
    with getConnPG(getEnginePGLight(prop, 'EMonitor')) as conn: # IMPORTANTE: tem que rodar em ate 5 minutos devido a property maxCheckoutConnPool
        listInstalacoes = getOutrasInstalacoes()
        ctInstalacoes = 0
        for instalacao in listInstalacoes:
            # if isDuplInst(instalacao, listInstalacoes):
            #     continue # somente fazia sentido no arquivo emonitor.properties... no BD PG como tem tabela instemp com PK codinstalacao+codempresa, nao faz sentido
            inst, emp = getCamposInst(instalacao)
            ctInstalacoes += 1
            # if inst == '':
            #     printMsg(str(ctInstalacoes) + '. Instalacao ' + instalacao + ' ja processada!')  # erro de configuracao do arquivo de properties
            #     continue
            printMsg(str(ctInstalacoes) + '. Processando Instalacao ' + instalacao)
            for tipo in listTipo:
                ct = dao.ctBiAutors(conn, inst, emp, tipo, dataIni, dataFim)
                if ct > 0:
                    dao.delBiAutors(conn, inst, emp, tipo, dataProc)
                    if dao.insBiAutors(conn, inst, emp, tipo, dataProc, ct):
                        printMsg('... ' + str(ct) + ' documentos autorizados do tipo ' + tipo)
                    else:
                        printMsg('... Erro ao gravar documentos autorizados do tipo ' + tipo)
    #
    printMsg('Terminando o processamento de BIAUTORS em ' + datetostr(dataProc))


def processBiSistemaExt(dataProc):
    #
    dataIni = dbdatetimezero(dataProc)
    dataFim = dbdatetimelim(dataProc)
    SISTEMAEXT_TIPO_WHATSAPP = 10000
    listTipo = {SISTEMAEXT_TIPO_WHATSAPP}
    #
    printMsg('Iniciando o processamento de BISISTEMAEXT em ' + datetostr(dataProc))
    with getConnPG(getEnginePGLight(prop, 'EMonitor')) as conn: # IMPORTANTE: tem que rodar em ate 5 minutos devido a property maxCheckoutConnPool
        listInstalacoes = getOutrasInstalacoes()
        ctInstalacoes = 0
        for instalacao in listInstalacoes:
            # if isDuplInst(instalacao, listInstalacoes):
            #     continue # somente fazia sentido no arquivo emonitor.properties... no BD PG como tem tabela instemp com PK codinstalacao+codempresa, nao faz sentido
            inst, emp = getCamposInst(instalacao)
            ctInstalacoes += 1
            # if inst == '':
            #     printMsg(str(ctInstalacoes) + '. Instalacao ' + instalacao + ' ja processada!')  # erro de configuracao do arquivo de properties
            #     continue
            printMsg(str(ctInstalacoes) + '. Processando Instalacao ' + instalacao)
            for tipo in listTipo:
                ct = dao.ctBiSistemaExt(conn, inst, emp, tipo, dataIni, dataFim)
                if ct > 0:
                    dao.delBiSistemaExt(conn, inst, emp, tipo, dataProc)
                    if dao.insBiSistemaExt(conn, inst, emp, tipo, dataProc, ct):
                        printMsg('... ' + str(ct) + ' registros processados do tipo ' + str(tipo))
                    else:
                        printMsg('... Erro ao gravar registros processados do tipo ' + str(tipo))
    #
    printMsg('Terminando o processamento de BISISTEMAEXT em ' + datetostr(dataProc))


if isDebug:
    dataIni = defstrtodate('26/03/2023')
    dataFim = datetime.date.today()
    delta = datetime.timedelta(days=1)
    dataProc = dataIni
    while dataProc < dataFim:
        processBiAutors(dataProc)
        processBiSistemaExt(dataProc)
        dataProc += delta
else:
    dataProc = incdatetimeactual(-1)
    processBiAutors(dataProc)
    processBiSistemaExt(dataProc)

