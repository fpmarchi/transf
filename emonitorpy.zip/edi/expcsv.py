from sqlalchemy import create_engine, Table, Column, Integer, String, DateTime, MetaData, ForeignKey, BLOB, TEXT
from sqlalchemy.sql import *

################# CODIGO DE TESTE
# firewall-cmd --add-rich-rule 'rule family="ipv4" service name="firebird" source address="179.214.167.181" accept'
# firewall-cmd --zone=public --list-all
# firewall-cmd --remove-rich-rule 'rule family="ipv4" service name="firebird" source address="179.214.167.181" accept'

isLocal = True
SEP = ','
if isLocal:
    senha = 'masterkey'
    alias = '/sistemas/websafbd/websaf.fdb'
else:
    senha = 'ironman30'
    alias = '/sistemas/websaf/bd/websaf.fdb'
conn = create_engine('firebird+fdb://sysdba:' + senha + '@localhost/' + alias + '?charset=ISO-8859-1', pool_size=1, max_overflow=5)

sql = 'select ' \
      'f.codforn, f.tipopessoa, f.cpfcnpj, f.rgie, f.razaosocial, f.contato, f.endereco, f.complender, f.bairro, f.cep, ' \
      'm.descricao as nomecidade, m.coduf, m.codsiafi, f.fone1, f.fone2, f.email, ' \
      'td.descricao as tipodesp, gd.descricao as grupodesp, f.valormensal, f.diavenc, f.recorrente, f.obs ' \
      'from forn as f ' \
      'join munic as m on f.codmunic = m.codmunic ' \
      'join tipocp as td on f.codtipocp = td.codtipocp ' \
      'join grupocp as gd on td.codgrupocp = gd.codgrupocp ' \
      'where f.ativo = \'S\' ' \
      'order by f.razaosocial, f.codforn'
fields = [
    'codforn', 'tipopessoa', 'cpfcnpj', 'rgie', 'razaosocial', 'contato', 'endereco', 'complender', 'bairro', 'cep',
    'nomecidade', 'coduf', 'codsiafi', 'fone1', 'fone2', 'email',
    'tipodesp', 'grupodesp', 'valormensal', 'diavenc', 'recorrente', 'obs'
]
fileRet = '/home/edilmar/forn.csv'

rs = conn.execute(text(sql))
dados = rs.fetchall()
listRet = list()
for rec in dados:
    for field in fields:
        listRet.append(rec[field].decode('iso8859-1') + SEP)
    listRet.append('\r\n')
open(fileRet, 'w').write(''.join(listRet))



