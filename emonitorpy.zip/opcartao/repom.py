'''
Sequencia de testes SOR+EMPY:
1) Cadastrar Prop, e posteriormente gravar manualmente o numero do cartao informado pela Repom, dependendo se o CIOT vai ter favorecido Prop
2) Cadastrar Mot, e posteriormente gravar manualmente o numero do cartao informado pela Repom, dependendo se o CIOT vai ter favorecido Mot
3) Cadastrar Veic
4) Consultar Roteiro (se nao achar, tem que fazer o passo 5 antes)
5) Solicitar Roteiro
- cadastrar rota antes no SS, e vincular na viagem, clicando em Gravar na tela de PagConhec
- antes de solicitar na Repom, tem que informar tambem o pseudo-campo "Percurso Cad. Rota", que é uma descricao livre, mas nao é um campo de BD
- ao solicitar na Repom, o processo pode VPRCardNumberdemorar ate 15 minutos
- executar passo 4 novamente para setar codigos externos da rota e do percurso, alem do KM Previsto, na tabela Rota
6) Consultar Valor do Pedagio (tem que ter uma rota previamente cadastrada no SS e com codigos de rota e percurso da Repom)
6) Consultar Operacoes
7) Emitir Contrato
8) Cancelar Contrato
9) Emitir Contrato Completo
10) Interromper Contrato
PENDENTE: Nao foi feito o modulo completo CIOT pois prop/mot precisam cadastrar o numero do cartao fisico antes... pensar em alguma forma de automatizar com o SOR no futuro
http://qa.repom.com.br/Repom.Frete.WebAPI/HelpApi/index
file:///home/edilmar/Documentos/Swagger%20UI.html#/
https://qa.repom.com.br/Repom.Frete.AnttAvulso.Service/helpapi/index.html

http://qa.repom.com.br/Repom.Relatorio.WebApi/HelpApi/#/
https://cms.repom.com.br/pages/viewpage.action?pageId=24120584#RepomRelat%C3%B3rios-Documenta%C3%A7%C3%A3odeIntegra%C3%A7%C3%A3o-DescrCamposRetornoCon

'''

import json
from typing import Tuple

import requests
from requests import Response

from dispacher import ActionProcessor
from dispacher.action_processor import HttpMethod
from dispacher.decorators import handle_exception_factory
from entity import proprietario, motorista, veiculo, conhecimento
from geral import *
from geraljson import *
from geralxml import *
from consist import *
from geralsis import getTokenByCnpjCpf

ACAO_REPOM_INICIO = 1150
ACAO_REPOM_AUTENTICARUSUARIO = 1150
ACAO_REPOM_CADASTRARPROPRIETARIO = 1151
ACAO_REPOM_CADASTRARMOTORISTA = 1152
ACAO_REPOM_CADASTRARVEICULO = 1153
ACAO_REPOM_CADASTRARCARRETA1 = 1154
ACAO_REPOM_CADASTRARCARRETA2 = 1155
ACAO_REPOM_CADASTRARCARRETA3 = 1156
ACAO_REPOM_ATUALIZARPROPRIETARIO = 1157
ACAO_REPOM_ATUALIZARMOTORISTA = 1158
ACAO_REPOM_GERARMODCOMPVEIC = 1159  # SEM IMPLEMENTACAO POR ENQTO COMPLETO... PENSAR MELHOR NO FLUXO DE DADOS QUE TEM QUE SER ENVIADOS, NA SEQUENCIA DE TRABALHO DO USUARIO
ACAO_REPOM_GERARMODCOMPCIOT = 1160
ACAO_REPOM_EMITIRCONTRATO = 1161
ACAO_REPOM_CONSULTAROPERACOES = 1162
ACAO_REPOM_CANCELARCONTRATO = 1163
ACAO_REPOM_INTERROMPERCONTRATO = 1164
ACAO_REPOM_CONSULTARCONTRATO = 1165
ACAO_REPOM_CONSULTARSTATUSCONTRATO = 1166
ACAO_REPOM_QUITARCONTRATO = 1167
ACAO_REPOM_CONSULTARROTEIRO = 1168
ACAO_REPOM_SOLICITARROTEIRO = 1169
ACAO_REPOM_SOLICITAR_ROTEIRO_AUTOMATICO_IDA_VOLTA = 1170
ACAO_REPOM_CONSULTARROTEIROINFORMADO = 1171
ACAO_REPOM_ADICIONARMOVIMENTO = 1172
ACAO_REPOM_ATUALIZARVEICULO = 1173
ACAO_REPOM_ATUALIZARCARRETA1 = 1174
ACAO_REPOM_ATUALIZARCARRETA2 = 1175
ACAO_REPOM_ATUALIZARCARRETA3 = 1176
ACAO_REPOM_VINCULAR_CARTAO = 1177
ACAO_REPOM_CONSULTAR_VINCULO_CARTAO = 1178
ACAO_REPOM_SOLICITAR_ROTEIRO_AUTOMATICO = 1179
ACAO_REPOM_CONSULTARVALORPEDAGIO = 1180
ACAO_REPOM_EMITIRCONTRATOGRATUITO = 1181
ACAO_REPOM_CANCELARCONTRATOGRATUITO = 1183
ACAO_REPOM_BUSCAR_DOCUMENTOS_CHECKLIST = 1184
ACAO_REPOM_CONSULTA_ESTADO_OPERACAO = 1185
ACAO_REPOM_QUITARCONTRATOGRATUITO = 1187
ACAO_REPOM_BAIXAR_DOCUMENTO_PAGAMENTO = 1190

# deixar uma margem de codigos para nao misturar
ACAO_REPOM_CONCILIACAO_FINANCEIRA_DATA = 1191
ACAO_REPOM_CONCILIACAO_CONTABIL_DATA = 1192
ACAO_REPOM_EMITE_FINANCEIRO_2 = 1194
ACAO_REPOM_PAGAMENTO_AUTORIZACAO = 1195
ACAO_REPOM_PAGAMENTO_AUTORIZACAO_CANCELAMENTO = 1196
ACAO_REPOM_FIM = 1199


class RepomException(Exception):
    pass


class Repom(ActionProcessor):
    HOST = 'https://www.repom.com.br'
    TEST_HOST = 'https://qa.repom.com.br'
    BASE_PATH = '/Repom.Frete.WebAPI'

    # Actions
    JOIN_FUEL_BENEFIT_HIRED_DRIVER = 1177
    GET_FUEL_BENEFIT_HIRED_DRIVER = 1178
    ADD_ROUTE_REQUEST_AUTOMATIC = 1179
    ADD_ROUTE_REQUEST_AUTOMATIC_ROUND_TRIP = 1170
    DOCUMENT_CHECKLIST_SEARCH = 1184
    CONSULT_STATE_OPERATION = 1185
    ADD_MOVEMENT = 1189
    ADD_DOWNLOAD_PAYMENT_FILE = 1190
    GET_OPEN_INVOICES = 1191

    ADD_PAYMENT_AUTHORIZATION = 1195
    ADD_PAYMENT_AUTHORIZATION_CANCELLATION = 1196

    def __init__(self):
        super().__init__()

        self.add_callable_records('url', {
            self.JOIN_FUEL_BENEFIT_HIRED_DRIVER: self.make_url_assembler(
                '/ShippingFuelBenefit/JoinHiredDriverCard$postfix',
                HttpMethod.PATCH,
                extract_host=True,
                use_template=True
            ),
            self.GET_FUEL_BENEFIT_HIRED_DRIVER: self.make_url_assembler(
                '/ShippingFuelBenefit/GetByHiredDriverNationalId/$prop_cnpjcpf/$mot_cpf$postfix',
                HttpMethod.GET,
                extract_host=True,
                use_template=True
            ),
            self.ADD_PAYMENT_AUTHORIZATION: self.make_url_assembler(
                '/PaymentAuthorization$postfix',
                HttpMethod.POST,
                extract_host=True,
                use_template=True
            ),
            self.ADD_PAYMENT_AUTHORIZATION_CANCELLATION: self.make_url_assembler(
                '/PaymentAuthorization/Cancel$postfix',
                HttpMethod.PATCH,
                extract_host=True,
                use_template=True
            ),
            self.ADD_ROUTE_REQUEST_AUTOMATIC: self.make_url_assembler(
                '/RouteRequest/RouteRequestAutomatic$postfix',
                HttpMethod.POST,
                extract_host=True,
                use_template=True
            ),
            self.ADD_ROUTE_REQUEST_AUTOMATIC_ROUND_TRIP: self.make_url_assembler(
                '/RouteRequest/RouteRequestAutomatic$postfix',
                HttpMethod.POST,
                extract_host=True,
                use_template=True
            ),
            self.ADD_MOVEMENT: self.make_url_assembler(
                '/Shipping/AddMovement/$id_viagem$postfix',
                HttpMethod.PATCH,
                extract_host=True,
                use_template=True
            ),
            self.DOCUMENT_CHECKLIST_SEARCH: self.make_url_assembler(
                '/Shipping/DocumentCheckLists/$postfix',
                HttpMethod.GET,
                extract_host=True,
                use_template=True
            ),
            self.CONSULT_STATE_OPERATION: self.make_url_assembler(
                '/Shipping/StatusProcessing/ByOperationKey/{$id_operation_key}/$postfix',
                HttpMethod.GET,
                extract_host=True,
                use_template=True
            ),
            self.ADD_DOWNLOAD_PAYMENT_FILE: self.make_url_assembler(
                '/ShippingPayment/DownloadPaymentFile/$shipping_id/$postfix',
                HttpMethod.GET,
                extract_host=True,
                use_template=True
            ),
            self.GET_OPEN_INVOICES: self.make_url_assembler(
                '/Statement/Billing/GetByCustomerStartDateEndDate/$data_ini/$data_fim/$status',
                HttpMethod.GET,
                extract_host=True,
                use_template=True
            ),
        })

    def before_make_url(self):
        req = self.context.get('req')
        if not req:
            return

        version = req.get('repom_api_versao', '').strip()
        if version == '2.3':
            req['postfix'] = '?x-api-version=2.3'
        else:
            req['postfix'] = '?x-api-version=2.0'


#
#   Códigos independentes de instancia
#


# Tratamento de exceções
def _repom_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def _any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a Repom:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    RepomException,
    _repom_exception_callback,
    _any_exception_callback
)

#
#   Instancia limpa e sem configuração
#
_repom = Repom()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = _repom.link_to_factory('request')
_link_to_response = _repom.link_to_factory('response')


@_link_to_request(_repom.JOIN_FUEL_BENEFIT_HIRED_DRIVER)
@_handle_exception
def _out_join_fuel_benefit_hired_driver(req: dict):
    req_body = {
        'CardNumber': req.get('num_cartao'),
        'HiredNationalID': req.get('prop_cnpjcpf'),
        'DriverNationalId': req.get('mot_cpf')
    }

    return json.dumps(req_body), ''


@_link_to_response(_repom.JOIN_FUEL_BENEFIT_HIRED_DRIVER)
@_handle_exception
def _in_join_fuel_benefit_hired_driver(resp: Response):
    retcode = resp.status_code
    if retcode in [200, 240]:
        return xml_from_dict({
            'resp': {
                'erro': 'f',
                'msg': 'Vinculo realizado com sucesso'
            }
        }, prolog=True), ''
    else:
        return xml_from_dict({
            'resp': {
                'erro': 'f',
                'msg': 'Ocorreu um erro ao vincular o cartão ao motorista e proprietário'
            }
        }, prolog=True), ''


@_link_to_request(_repom.ADD_PAYMENT_AUTHORIZATION)
@_handle_exception
def _out_add_payment_authorization(req: dict):
    req_body = [{
        'ShippingId': req.get('ShippingId'),
        'Identifier': req.get('Identifier'),
        'Branch': req.get('Branch'),
        'BranchCode': req.get('BranchCode'),
        'PaymentDate': _date_ddmmyy(req.get('PaymentDate'))[0],
    }]

    return json.dumps(req_body), ''


@_link_to_request(_repom.ADD_PAYMENT_AUTHORIZATION_CANCELLATION)
@_handle_exception
def _out_add_payment_authorization_cancellation(req: dict):
    req_body = [{
        'ShippingId': req.get('ShippingId'),
        'Identifier': req.get('Identifier'),
        'Branch': req.get('Branch'),
        'BranchCode': req.get('BranchCode'),
    }]

    return json.dumps(req_body), ''


@_link_to_request(_repom.DOCUMENT_CHECKLIST_SEARCH, _repom.CONSULT_STATE_OPERATION, _repom.ADD_DOWNLOAD_PAYMENT_FILE)
@_handle_exception
def _search_repom(req: dict):
    req_body = {}

    return '{}', ''


@_link_to_response(_repom.DOCUMENT_CHECKLIST_SEARCH)
@_handle_exception
def _in_document_checklist_search(resp: Response):
    retcode = resp.status_code
    resp = resp.json()
    resp_data = ''

    if retcode == 200:
        resp_data = {
            'sucesso': True,
            'conteudo': resp.get('Result'),
        }
    else:
        resp_data = {
            'sucesso': False,
            'msg_erro': 'Ocorreu algum erro ao tentar consultar os documentos do checklist'
        }
    return mount_xml_response(resp_data), ''


@_link_to_response(_repom.CONSULT_STATE_OPERATION)
@_handle_exception
def _in_consult_state_operation(resp: Response):
    retcode = resp.status_code
    resp = resp.json().get('Result', '')
    resp_data = ''
    results = resp.get('Results', '')[0]
    status = results.get('Status', '')
    if retcode == 200:
        if status == 'Error':
            resp_data = {
                'sucesso': False,
                'erros': [
                    {
                        'campo': deep_get(erro, 'ErrorCode') or '',
                        'descricao': deep_get(erro, 'Message') or ''
                    }
                    for erro in results.get('Errors', [])
                ]
            }
        elif status == 'Pending' or status == 'Processing':
            resp_data = {
                'sucesso': True,
                'conteudo': {
                    'conteudo': 'Por favor, aguarde alguns minutos e tente o método CONSULTAR STATUS CIOT, pois o processamento ainda está pendente!',
                    'pendente': True
                }
            }
        elif status == 'Finished':
            resp_data = {
                'sucesso': True,
                'conteudo': {
                    'conteudo': 'Ciot gerado com sucesso, será processado e realizada a tentativa de consulta!' + '\nCaso não retornar o Ciot, Consulte novamente!',
                    'pendente': False
                }
            }
    else:
        resp_data = {
            'sucesso': True,
            'msg_erro': 'Ocorreu algum erro ao tentar consultar a chave de operação' + resp.get('OperationKey', '')
        }
    return mount_xml_response(resp_data), ''


@_link_to_response(_repom.ADD_PAYMENT_AUTHORIZATION, _repom.ADD_PAYMENT_AUTHORIZATION_CANCELLATION)
@_handle_exception
def _in_add_payment_authorization(resp: Response):
    retcode = resp.status_code
    resp = resp.json()
    resp_data = ''
    if retcode == 400:
        if resp.get('Errors')[0].get('Message') != None:
            resp_data = {
                'sucesso': False,
                'msg_erro': resp.get('Errors')[0].get('Message') or ''
            }
    elif retcode == 200:
        resp_data = {
            'sucesso': True,
            'conteudo': resp.get('Result')[0],
        }
    return mount_xml_response(resp_data), ''


@_link_to_response(_repom.ADD_DOWNLOAD_PAYMENT_FILE)
@_handle_exception
def _in_add_download_payment_file(resp: Response):
    retcode = resp.status_code
    resp = base64.b64encode(resp.content)
    resp_data = ''

    if retcode == 200:
        resp_data = {
            'sucesso': True,
            'conteudo': {
                'documento': resp.decode('ascii'),
            }
        }
    else:
        resp_data = {
            'sucesso': False,
            'msg_erro': 'O documento de comprovante de quitação não foi encontrado'
        }
    return mount_xml_response(resp_data), ''


@_link_to_request(_repom.ADD_ROUTE_REQUEST_AUTOMATIC, _repom.ADD_ROUTE_REQUEST_AUTOMATIC_ROUND_TRIP)
@_handle_exception
def _out_add_route_request_automatic(req: dict):
    ida_volta = req.get('BranchCode') == '1'

    req_body = {
        'BranchCode': req.get('rot_codfilial'),
        'OriginIBGECode': req.get('rot_codibgeorig'),
        'DestinyIBGECode': req.get('rot_codibgedest'),
        'RoundTrip': ida_volta,
        'TraceIdentifier': req.get('rot_codrota'),
        'RouteStopIBGE': req.get('cods_ibge_paradas') or [
            cod_ibge
            for cod_ibge in [
                req.get('cod_ibge_repom1'),
                req.get('cod_ibge_repom2'),
                req.get('cod_ibge_repom3'),
                req.get('cod_ibge_repom4'),
                req.get('cod_ibge_repom5')
            ]
            if cod_ibge is not None
        ],
    }

    return json.dumps(req_body), ''


@_link_to_response(_repom.ADD_ROUTE_REQUEST_AUTOMATIC, _repom.ADD_ROUTE_REQUEST_AUTOMATIC_ROUND_TRIP)
@_handle_exception
def _in_add_route_request_automatic(resp: Response):
    retcode = resp.status_code
    resp = resp.json()
    resp_data = ''
    if retcode >= 400:
        resp_data = {
            'sucesso': False,
            'erros': [
                {
                    'campo': '-',
                    'descricao': erro.get('Message') or ''
                }
                for erro in resp.get('Errors', [])
            ]
        }
    elif retcode in [200]:
        resp_data = {
            'sucesso': True,
            'conteudo': resp.get('Data')
        }
    return mount_xml_response(resp_data), ''


@_link_to_response(_repom.GET_OPEN_INVOICES)
@_handle_exception
def _in_add_route_request_automatic(resp: Response):
    code = resp.status_code
    resp = resp.json()
    if code == 200:
        result = deep_get(resp, 'Result')

        content = result.get('Data', [])
        if content or not result.get('Errors'):
            resp_data = {
                'sucesso': True,
                'conteudo': content
            }
        else:
            resp_data = {
                'sucesso': False,
                'msg_erro': result.get('Errors')[0].get('Message', 'Erro desconhecido')
            }
    else:
        resp_data = {
            'sucesso': False,
            'msg_erro': 'Não foi possível obter as faturas da Repom'
        }

    return mount_xml_response(resp_data), ''


@_link_to_request(_repom.ADD_MOVEMENT)
@_handle_exception
def _out_add_movement(req: dict):
    req_body = {
        'Identifier': req.get('tipo_mov'),
        'Value': req.get('valor_quebra')
    }

    return json.dumps(req_body), ''


@_link_to_response(_repom.ADD_MOVEMENT)
@_handle_exception
def _in_add_movement(resp: Response):
    retcode = resp.status_code
    json_resp = resp.json()
    if retcode == 200:
        return mount_xml_response(
            {
                'sucesso': True,
                'conteudo': {
                    'msg': 'Movimentação inserida com sucesso'
                }
            },
            prolog=True
        ), ''
    else:
        if 'Errors' in json_resp:
            erros = json_resp.get('Errors')
            msg_ret = erros.get('Message')
        else:
            msg_ret = 'Erro ao enviar p valor de quebra a viagem'

        return mount_xml_response(
            {
                'sucesso': False,
                'conteudo': {
                    'msg_erro': msg_ret
                }
            },
            prolog=True
        ), ''


@_link_to_response(_repom.GET_FUEL_BENEFIT_HIRED_DRIVER)
@_handle_exception
def _in_get_fuel_benefit_hired_driver(resp: Response):
    retcode = resp.status_code
    if retcode in [200, 240]:
        return xml_from_dict({
            'resp': {
                'erro': 'f',
                'msg': 'Existe um vínculo para esse motorista e proprietário'
            }
        }, prolog=True), ''
    else:
        return xml_from_dict({
            'resp': {
                'erro': 'f',
                'msg': 'Não existe um vínculo para esse motorista e proprietário'
            }
        }, prolog=True), ''


@_link_to_request(_repom.DEFAULT_FUNCTION)
@_handle_exception
def _out_default() -> Tuple[None, str]:
    return None, ''


@_link_to_response(_repom.DEFAULT_FUNCTION)
@_handle_exception
def _in_default(resp: Response) -> Tuple[str, str]:
    return mount_xml_response(resp.json()), ''


#
#   Implementação antiga
#


# O método de cache local, pois o EMPY é multithreading.
# Uma boa opção seria utilizar uma ferramenta de cache como o Redis.
listTokens = []
listTokensRel = []


def preProcessRequestPropertiesRepom(cert, codEMonitorAcao, url, requestProperties, headers):
    # para cada comunicacao com a Repom, precisa gerar um token, ou usar um valido da variavel de cache local listTokens
    if 'API/' in url:
        url = url[0:url.rindex('API/') + 4] + 'token'
    elif 'api/' in url:
        url = url[0:url.rindex('api/') + 4] + 'token'
    else:
        url = url[0:url.rindex('/') + 1] + 'token'
    isFrete = "REPOM.FRETE" in url.upper()

    #

    pattern = re.compile(r'&(?=\w+=)')
    if isFrete:
        req = {'grant_type': 'password'}
        listProperties = pattern.split(requestProperties)
        cnpjcpf = ''
        for property in listProperties:
            entry = property.split('=', 1)
            if entry[0] == 'login':
                req['username'] = entry[1]
            elif entry[0] == 'senha':
                req['password'] = entry[1]
            elif entry[0] == 'cnpjcpf':
                req['partner'] = entry[1]
                cnpjcpf = entry[1]
        # verificar se o token esta no cache local
        token = getTokenByCnpjCpf(cnpjcpf, listTokens)
        if token != '':
            # print('token do cache = ' + token)
            headers['Authorization'] = 'Bearer ' + token
            return headers, ''
        #
        resp = requests.post(url, cert=cert, data=req, headers=headers)
        retcode = resp.status_code
        ret = resp.content.decode('utf-8')
        if retcode == 200:
            root = json.loads(ret)
            token = getJSON(root, 'access_token')
            if token is None or token == '':
                return headers, 'ERRO DE GERAR TOKEN VAZIO NO SERVIDOR DA OPERADORA DE CARTÃO (' + str(retcode) + ')'
            else:
                # print('token novo = ' + token)
                listTokens.append([cnpjcpf, token, timems()])
                headers['Authorization'] = 'Bearer ' + token
                return headers, ''
        elif retcode == 401:
            print(resp.content.decode('utf-8'))
            return headers, 'USUARIO E SENHA INVALIDOS (' + str(retcode) + ' - ' + ret + ')'
        else:
            print(resp.content.decode('utf-8'))
            return headers, 'ERRO INTERNO DE GERAR TOKEN NO SERVIDOR DA OPERADORA DE CARTÃO (' + str(
                retcode) + ' - ' + ret + ')'
    else:
        headers['Content-type'] = 'application/json-patch+json'
        headers['x-api-version'] = '1.0'
        req = '{'
        listProperties = pattern.split(requestProperties)
        cnpjcpf = ''
        for property in listProperties:
            entry = property.split('=', 1)
            if entry[0] == 'login':
                req += '"usuario": "' + entry[1] + '",'
            elif entry[0] == 'senha':
                req += '"senha": "' + entry[1] + '"'
            elif entry[0] == 'cnpjcpf':
                cnpjcpf = entry[1]
        req += '}'
        # verificar se o token esta no cache local
        token = getTokenByCnpjCpf(cnpjcpf, listTokensRel)
        if token != '':
            # print('tokenRel do cache = ' + token)
            headers['Content-type'] = 'application/json; charset=utf-8'
            headers['Authorization'] = 'Bearer ' + token
            return headers, ''
        #
        resp = requests.post(url, cert=cert, data=req, headers=headers)
        retcode = resp.status_code
        if retcode == 200:
            ret = resp.content.decode('utf-8')
            root = json.loads(ret)
            token = getJSON(root, 'accessToken')
            if token is None or token == '':
                return headers, 'ERRO DE GERAR TOKEN VAZIO NO SERVIDOR DA OPERADORA DE CARTÃO (' + str(retcode) + ')'
            else:
                # print('tokenRel novo = ' + token)
                listTokensRel.append([cnpjcpf, token, timems()])
                headers['Content-type'] = 'application/json; charset=utf-8'
                headers['Authorization'] = 'Bearer ' + token
                return headers, ''
        else:
            ret = resp.content.decode('utf-8')
            print(resp.content.decode('utf-8'))
            return headers, 'ERRO INTERNO DE GERAR TOKEN NO SERVIDOR DA OPERADORA DE CARTÃO (' + str(retcode) + ')'


def preProcessURLRepom(cert, codEMonitorAcao, url, headers, req, numTent):
    id = ''
    numero = ''
    # se for uma dessas acoes, pode ser que o SOR ja tenha o ShippingID
    if codEMonitorAcao == ACAO_REPOM_CANCELARCONTRATO or codEMonitorAcao == ACAO_REPOM_INTERROMPERCONTRATO:
        req = req.replace('\\"', '"')
        reqJSON = json.loads(req)
        id = getJSON(reqJSON, 'conh_id')
        numero = getJSON(reqJSON, 'conh_numero')
    elif codEMonitorAcao == ACAO_REPOM_EMITIRCONTRATO:
        req = req.replace('\\"', '"')
        reqJSON = json.loads(req)[0]  # PENDENTE ALTERAR QUANDO TIVER MAIS VIAGENS
        numero = getJSON(reqJSON, 'Identifier')
    if id != '':  # ja veio com o ShippingID e pode seguir com a acao principal
        if codEMonitorAcao == ACAO_REPOM_CANCELARCONTRATO:
            return url + 'Shipping/Cancel/' + id, ''
        elif codEMonitorAcao == ACAO_REPOM_INTERROMPERCONTRATO:
            return url + 'Shipping/Interruption/' + id, ''
    else:  # se nao tem o ShippingID, tem que fazer uma consulta anterior a acao principal
        print('REPOM: Tentativa ' + str(numTent) + ' de obter ShippingID/CIOT da Viagem ' + numero)
        urlConsultarContrato = url + requestRepomConsultarContrato(cert, codEMonitorAcao, url, headers, req)
        resp = requests.get(urlConsultarContrato, cert=cert, data=req, headers=headers)
        retcode = resp.status_code
    if retcode == 200:
        ret = resp.content.decode('utf-8')
        root = getJSON(json.loads(ret), 'Result')
        if codEMonitorAcao == ACAO_REPOM_EMITIRCONTRATO:
            return root  # pois sera processado no responseRepomEmitirContrato
        id = str(root['ShippingId'])
        if id is None or id == '':
            return '', 'ERRO AO OBTER ID DE VIAGEM VAZIO NO SERVIDOR DA OPERADORA DE CARTÃO (' + str(retcode) + ')'
        else:
            if codEMonitorAcao == ACAO_REPOM_CANCELARCONTRATO:
                return url + 'Shipping/Cancel/' + id, ''
            elif codEMonitorAcao == ACAO_REPOM_INTERROMPERCONTRATO:
                return url + 'Shipping/Interruption/' + id, ''
            return '', 'ERRO DE AÇÃO SEM IMPLEMENTAÇÃO DE PREPROCESSAMENTO DE URL'
    else:
        if codEMonitorAcao == ACAO_REPOM_EMITIRCONTRATO:
            return str(retcode)  # pois sera processado no responseRepomEmitirContrato
        else:
            return '', 'VIAGEM NÃO ENCONTRADA NO SERVIDOR DA OPERADORA DE CARTÃO (' + str(retcode) + ')'


def getCountry(pais):
    if pais is None or pais == '':
        return 'Brazil'
    pais = removeAccents(pais.upper())
    if pais == 'ARGENTINA':
        return 'Argentina'
    elif pais == 'CHILE':
        return 'Chile'
    else:  # POR ENQTO NAO TEM OUTROS PAISES
        return 'Brazil'


def getHiredType(isPF):
    if isPF:
        return 'Person'
    else:
        return 'Company'


def getSimplesNacional(tipo):
    if tipo == '0':
        return 'true'
    else:
        return 'false'


def getGender(sexo):
    if sexo == 'M':
        return 'Male'
    elif sexo == 'F':
        return 'Female'
    else:
        return 'Uninformed'


def getVehicleClassification(isCavalo):
    if isCavalo:
        return 'Traction'
    else:
        return 'Implement'


def getVehicleType(isCavalo):
    # usa createelemnum para poder setar como null sem aspas, entao no caso de cavalo tem que por aspas
    if isCavalo:
        return '"Truck"'
    else:
        return 'null'


def getPhoneType(fonenumero):
    if len(fonenumero) == 8:
        return 'Fixed'
    else:
        return 'Cell'


def getVehicleAxles(quanteixos):
    if quanteixos.strip():
        return 'Axle' + quanteixos.zfill(2)
    else:
        return ''


def consistRepomCadastrarProprietario(reqJSON):
    ret = proprietario.consistCadastrarProprietario(reqJSON)
    # PENDENTE CHECAR CONSISTENCIAS ESPECIFICAS DA REPOM
    # ret += 'outro erro'
    return ret


def requestRepomCadastrarProprietario(reqJSON):
    try:
        reqJSON['prop_rntrc'] = padlzero(getJSON(reqJSON, 'prop_rntrc'), 9)
        erros = consistRepomCadastrarProprietario(reqJSON)
        if erros != '':
            return '', erros
        #
        if getJSON(reqJSON,
                   'prop_integrador') == '':  # este caso somente ocorre no processamento de modulo completo, onde pode ter alguns cadastros que nao serao feitos
            return '', ''
        #
        isPF = len(getJSON(reqJSON, 'prop_cnpjcpf')) == 11
        # PENDENTE MANDAR VARIOS FONES
        if isPF:
            foneddd = getJSON(reqJSON, 'prop_celularddd')
            fonenumero = getJSON(reqJSON, 'prop_celularnumero')
            fonetipo = getPhoneType(fonenumero)
            if foneddd == '' or fonenumero == '' or foneddd == '00':
                foneddd = getJSON(reqJSON, 'prop_foneddd')
                fonenumero = getJSON(reqJSON, 'prop_fonenumero')
                fonetipo = getPhoneType(fonenumero)
            dadosPessoa = \
                createelemtree('HiredPessoaFisica') + \
                '{' + \
                createelem('INSS', getJSON(reqJSON, 'prop_cei')) + \
                createelem2('RG', getJSON(reqJSON, 'prop_rg'), '') + \
                '}'
            dadosPessoa2 = \
                createelemtree('HiredPersonalInformation') + \
                '{' + \
                createelem('Name', removeAccents(getJSON(reqJSON, 'prop_nome')[0:50])) + \
                createelem('BirthDate', getJSON(reqJSON, 'prop_datanasc') + 'T00:00:00.000Z') + \
                createelemnum('LegalDependents', '0') + \
                createelem2('Gender', getGender(getJSON(reqJSON, 'prop_sexo')), '') + \
                '}'
        else:
            foneddd = getJSON(reqJSON, 'prop_foneddd')
            fonenumero = getJSON(reqJSON, 'prop_fonenumero')
            fonetipo = getPhoneType(fonenumero)
            if foneddd == '' or fonenumero == '' or foneddd == '00':
                foneddd = getJSON(reqJSON, 'prop_celularddd')
                fonenumero = getJSON(reqJSON, 'prop_celularnumero')
                fonetipo = getPhoneType(fonenumero)
            dadosPessoa = \
                createelemtree('HiredPessoaJuridica') + \
                '{' + \
                createelem('InscricaoEstadual', getJSON(reqJSON, 'prop_ie')) + \
                createelemnum('InscricaoMunicipal', 'null') + \
                createelem('NomeFantasia', removeAccents(getJSON(reqJSON, 'prop_nome')[0:50])) + \
                createelem2('OptanteSimplesNacional', getSimplesNacional(getJSON(reqJSON, 'prop_tipotributacao')), '') + \
                '}'
            dadosPessoa2 = \
                createelemtree('CompanyInformation') + \
                '{' + \
                createelem2('CompanyName', removeAccents(getJSON(reqJSON, 'prop_nome')[0:50]), '') + \
                '}'
        reqJSONRepom = \
            '{' + \
            createelem('Country', getCountry(getJSON(reqJSON, 'prop_pais'))) + \
            createelem('HiredType', getHiredType(isPF)) + \
            createelem('NationalId', getJSON(reqJSON, 'prop_cnpjcpf')) + \
            createelem('Email', getJSON(reqJSON, 'prop_email')) + \
            createelemtree('Phones') + '[' \
                                       '{' + \
            createelem('AreaCode', foneddd) + \
            createelem('Number', fonenumero) + \
            createelem('Preferential', 'true') + \
            createelem2('TypeId', fonetipo, '') + \
            '}' + \
            '],' + \
            createelemtree('BrazilianSettings') + \
            '{' + \
            createelem('RNTRC', getJSON(reqJSON, 'prop_rntrc')) + \
            dadosPessoa + \
            '},' + \
            createelemtree('Address') + \
            '{' + \
            createelem('Street', removeAccents(getJSON(reqJSON, 'prop_endereco'))) + \
            createelem('Number', removeAccents(getJSON(reqJSON, 'prop_numero'))) + \
            createelem('Complement', removeAccents(getJSON(reqJSON, 'prop_complemento'))) + \
            createelem('Neighborhood', removeAccents(getJSON(reqJSON, 'prop_bairro'))) + \
            createelem2('ZipCode', clearNoASCII(getJSON(reqJSON, 'prop_cep')), '') + \
            '},' + \
            dadosPessoa2
        if reqJSON.get('prop_percadto'):
            reqJSONRepom += ',' + createelem2('FuelVoucherPercentage', getJSON(reqJSON, 'prop_percadto'), '')
        else:
            reqJSONRepom += ',' + '"FuelVoucherPercentage": null'
        reqJSONRepom = reqJSONRepom + '}'
        return reqJSONRepom, ''
    except Exception as e:
        print('Erro em requestRepomCadastrarProprietario')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRepomAtualizaProprietario(reqJSON):
    try:
        erros = consistRepomCadastrarProprietario(reqJSON)
        if erros != '':
            return '', erros

        req = {}
        Phone = []
        phones = {}
        req['Email'] = getJSON(reqJSON, 'prop_email')

        foneddd = getJSON(reqJSON, 'prop_foneddd')
        fonenumero = getJSON(reqJSON, 'prop_fonenumero')
        fonetipo = getPhoneType(fonenumero)
        if foneddd == '' or fonenumero == '' or foneddd == '00':
            foneddd = getJSON(reqJSON, 'prop_celularddd')
            fonenumero = getJSON(reqJSON, 'prop_celularnumero')
            fonetipo = getPhoneType(fonenumero)

        phones['AreaCode'] = foneddd
        phones['Number'] = fonenumero
        phones['Preferential'] = True
        phones['TypeId'] = fonetipo
        Phone.append(phones)
        req['Phones'] = Phone

        BrazilianSettings = {}
        BrazilianSettings['RNTRC'] = reqJSON.get('prop_rntrc').zfill(9)

        HiredPessoaFisica = {}
        HiredPessoaFisica['INSS'] = getJSON(reqJSON, 'prop_cei')
        HiredPessoaFisica['RG'] = getJSON(reqJSON, 'prop_rg')
        BrazilianSettings['HiredPessoaFisica'] = HiredPessoaFisica

        HiredPessoaJuridica = {}
        HiredPessoaJuridica['InscricaoEstadual'] = getJSON(reqJSON, 'prop_ie')
        HiredPessoaJuridica['InscricaoMunicipal'] = 'null'
        HiredPessoaJuridica['NomeFantasia'] = removeAccents(getJSON(reqJSON, 'prop_nome')[0:50])
        HiredPessoaJuridica['OptanteSimplesNacional'] = getSimplesNacional(getJSON(reqJSON, 'prop_tipotributacao'))
        BrazilianSettings['HiredPessoaJuridica'] = HiredPessoaJuridica
        req['BrazilianSettings'] = BrazilianSettings

        Address = {}
        Address['Street'] = removeAccents(getJSON(reqJSON, 'prop_endereco'))
        Address['Number'] = removeAccents(getJSON(reqJSON, 'prop_numero'))
        Address['Complement'] = removeAccents(getJSON(reqJSON, 'prop_complemento'))
        Address['Neighborhood'] = removeAccents(getJSON(reqJSON, 'prop_bairro'))
        Address['ZipCode'] = clearNoASCII(getJSON(reqJSON, 'prop_cep'))
        req['Address'] = Address

        CompanyInformation = {}
        CompanyInformation['CompanyName'] = getJSON(reqJSON, 'prop_nome')
        req['CompanyInformation'] = CompanyInformation

        HiredPersonalInformation = {}
        HiredPersonalInformation['Name'] = removeAccents(getJSON(reqJSON, 'prop_nome')[0:50])
        HiredPersonalInformation['BirthDate'] = getJSON(reqJSON, 'prop_datanasc') + 'T00:00:00.000Z'
        HiredPersonalInformation['LegalDependents'] = '0'
        HiredPersonalInformation['Gender'] = getGender(getJSON(reqJSON, 'prop_sexo'))
        req['HiredPersonalInformation'] = HiredPersonalInformation

        api_version: str = reqJSON.get('repom_api_versao', '')
        if api_version.strip() == '2.3' and reqJSON.get('prop_percadto'):
            req['FuelVoucherPercentage'] = getJSON(reqJSON, 'prop_percadto')

        req = json.dumps(req)

        return req, ''
    except Exception as e:
        print('Erro em request Atualizaprop')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRepomAtualizaMotorista(reqJSON):
    try:

        erros = consistRepomCadastrarMotorista(reqJSON)
        if erros != '':
            return '', erros

        req = {}
        Phone = []

        foneddd = getJSON(reqJSON, 'mot_celularddd')
        fonenumero = getJSON(reqJSON, 'mot_celularnumero')
        fonetipo = getPhoneType(fonenumero)
        if foneddd == '' or fonenumero == '' or foneddd == '00':
            foneddd = getJSON(reqJSON, 'mot_foneddd')
            fonenumero = getJSON(reqJSON, 'mot_fonenumero')
            fonetipo = getPhoneType(fonenumero)

        req['DriverLicenseNumber'] = getJSON(reqJSON, 'mot_cnh')

        adress = {}
        adress['Street'] = removeAccents(getJSON(reqJSON, 'mot_endereco'))
        adress['Number'] = removeAccents(getJSON(reqJSON, 'mot_numero'))
        adress['Complement'] = removeAccents(getJSON(reqJSON, 'mot_complemento'))
        adress['Neighborhood'] = removeAccents(getJSON(reqJSON, 'mot_bairro'))
        adress['ZipCode'] = clearNoASCII(getJSON(reqJSON, 'mot_cep'))
        req['Address'] = adress

        phones = {}
        phones['AreaCode'] = foneddd
        phones['Number'] = fonenumero
        phones['Preferential'] = True
        phones['TypeId'] = fonetipo
        Phone.append(phones)
        req['Phones'] = Phone

        DriverPersonal = {}
        DriverPersonal['BirthDate'] = getJSON(reqJSON, 'mot_datanasc') + 'T00:00:00.000Z'
        DriverPersonal['Name'] = removeAccents(getJSON(reqJSON, 'mot_nome')[0:50])
        DriverPersonal['Gender'] = getGender(getJSON(reqJSON, 'mot_sexo'))
        req['DriverPersonalInformation'] = DriverPersonal

        req = json.dumps(req)

        return req, ''
    except Exception as e:
        print('Erro em requestRepomCadastrarMotorista')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def consistRepomCadastrarMotorista(reqJSON):
    ret = motorista.consistCadastrarMotorista(reqJSON)
    # PENDENTE CHECAR CONSISTENCIAS ESPECIFICAS DA REPOM
    # ret += 'outro erro'
    return ret


def requestRepomCadastrarMotorista(reqJSON):
    try:
        erros = consistRepomCadastrarMotorista(reqJSON)
        if erros != '':
            return '', erros
        #
        if getJSON(reqJSON,
                   'mot_integrador') == '':  # este caso somente ocorre no processamento de modulo completo, onde pode ter alguns cadastros que nao serao feitos
            return '', ''
        # PENDENTE MANDAR VARIOS FONES
        foneddd = getJSON(reqJSON, 'mot_celularddd')
        fonenumero = getJSON(reqJSON, 'mot_celularnumero')
        fonetipo = getPhoneType(fonenumero)
        if foneddd == '' or fonenumero == '' or foneddd == '00':
            foneddd = getJSON(reqJSON, 'mot_foneddd')
            fonenumero = getJSON(reqJSON, 'mot_fonenumero')
            fonetipo = getPhoneType(fonenumero)
        dadosPessoa2 = \
            createelemtree('DriverPersonalInformation') + \
            '{' + \
            createelem('Name', removeAccents(getJSON(reqJSON, 'mot_nome')[0:50])) + \
            createelem('BirthDate', getJSON(reqJSON, 'mot_datanasc') + 'T00:00:00.000Z') + \
            createelem2('Gender', getGender(getJSON(reqJSON, 'mot_sexo')), '') + \
            '}'
        reqJSONRepom = \
            '{' + \
            createelem('Country', getCountry(getJSON(reqJSON, 'mot_pais'))) + \
            createelem('NationalId', getJSON(reqJSON, 'mot_cpf')) + \
            createelem('DriverLicenseNumber', getJSON(reqJSON, 'mot_cnh')) + \
            createelemtree('Phones') + '[' \
                                       '{' + \
            createelem('AreaCode', foneddd) + \
            createelem('Number', fonenumero) + \
            createelem('Preferential', 'true') + \
            createelem2('TypeId', fonetipo, '') + \
            '}' + \
            '],' + \
            createelemtree('Address') + \
            '{' + \
            createelem('Street', removeAccents(getJSON(reqJSON, 'mot_endereco'))) + \
            createelem('Number', removeAccents(getJSON(reqJSON, 'mot_numero'))) + \
            createelem('Complement', removeAccents(getJSON(reqJSON, 'mot_complemento'))) + \
            createelem('Neighborhood', removeAccents(getJSON(reqJSON, 'mot_bairro'))) + \
            createelem2('ZipCode', clearNoASCII(getJSON(reqJSON, 'mot_cep')), '') + \
            '},' + \
            dadosPessoa2 + \
            '}'
        return reqJSONRepom, ''
    except Exception as e:
        print('Erro em requestRepomCadastrarMotorista')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def consistRepomCadastrarVeiculo(reqJSON, prefixTag):
    ret = veiculo.consistCadastrarVeiculo(reqJSON, prefixTag)
    # dados do proprietario nao sao enviados para todas as operadoras
    ret += consistDigit(reqJSON, 'prop_cnpjcpf', 'CNPJ/CPF do Proprietário', [11, 14])
    rntrc = getJSON(reqJSON, 'prop_rntrc')
    if rntrc == '000000000':
        ret += ' [RNTRC do Proprietário vazio!]'
    else:
        ret += consistDigit(reqJSON, 'prop_rntrc', 'RNTRC do Proprietário', [9])
    ret += consistGTZero(reqJSON, prefixTag + 'quanteixos', 'Eixos', [])
    return ret


def requestRepomCadastrarVeiculo(reqJSON, codEMonitorAcao):
    try:
        isCavalo = False
        if codEMonitorAcao == ACAO_REPOM_CADASTRARVEICULO:
            isCavalo = True
            prefixTag = 'veic_'
        elif codEMonitorAcao == ACAO_REPOM_CADASTRARCARRETA1:
            prefixTag = 'car1_'
        elif codEMonitorAcao == ACAO_REPOM_CADASTRARCARRETA2:
            prefixTag = 'car2_'
        else:  # if codEMonitorAcao == ACAO_REPOM_CADASTRARCARRETA3:
            prefixTag = 'car3_'
        #
        reqJSON['prop_rntrc'] = padlzero(getJSON(reqJSON, 'prop_rntrc'), 9)
        erros = consistRepomCadastrarVeiculo(reqJSON, prefixTag)
        if erros != '':
            return '', erros
        #
        if getJSON(reqJSON,
                   prefixTag + 'integrador') == '':  # este caso somente ocorre no processamento de modulo completo, onde pode ter alguns cadastros que nao serao feitos
            return '', ''
        #
        isPF = len(getJSON(reqJSON, 'prop_cnpjcpf')) == 11
        if isPF:
            dadosPessoa = ''
            # tem uma virgula inicial para que o Type nao fique com virgula perdida se for PJ
            dadosPessoa2 = ',' + \
                           createelemtree('VehiclePersonalInformation') + \
                           '{' + \
                           createelem2('Name', removeAccents(getJSON(reqJSON, 'prop_nome')[0:50]), '') + \
                           '}'
        else:
            # tem uma virgula inicial para que o RNTRC nao fique com virgula perdida se for PF
            dadosPessoa = ',' + \
                          createelemtree('VehiclePessoaJuridica') + \
                          '{' + \
                          createelem2('NomeFantasia', removeAccents(getJSON(reqJSON, 'prop_nome')[0:50]), '') + \
                          '}'
            dadosPessoa2 = ''
        reqJSONRepom = \
            '{' + \
            createelem('Country', getCountry(getJSON(reqJSON, prefixTag + 'pais'))) + \
            createelem('LicensePlate', getJSON(reqJSON, prefixTag + 'placa')) + \
            createelem('VehicleClassification', getVehicleClassification(isCavalo)) + \
            createelem('VehicleCategory', 'HeavyCommercial') + \
            createelem('VehicleAxles', getJSON(reqJSON, prefixTag + 'quanteixos')) + \
            createelemnum('Type', getVehicleType(isCavalo)) + \
            createelemtree('VehicleOwner') + \
            '{' + \
            createelem('Country', getCountry(getJSON(reqJSON, 'prop_pais'))) + \
            createelem('NationalId', getJSON(reqJSON, 'prop_cnpjcpf')) + \
            createelemtree('BrazilianSettings') + \
            '{' + \
            createelem2('RNTRC', getJSON(reqJSON, 'prop_rntrc'), '') + \
            dadosPessoa + \
            '},' + \
            createelem2('Type', getHiredType(isPF), '') + \
            dadosPessoa2 + \
            '}' + \
            '}'
        return reqJSONRepom, ''
    except Exception as e:
        print('Erro em requestRepomCadastrarVeiculo')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRepomAtualizaVeiculo(reqJSON, codEMonitorAcao):
    try:
        isCavalo = False
        if codEMonitorAcao == ACAO_REPOM_ATUALIZARVEICULO:
            isCavalo = True
            prefixTag = 'veic_'
        elif codEMonitorAcao == ACAO_REPOM_ATUALIZARCARRETA1:
            prefixTag = 'car1_'
        elif codEMonitorAcao == ACAO_REPOM_ATUALIZARCARRETA2:
            prefixTag = 'car2_'
        else:
            prefixTag = 'car3_'

        reqJSON['prop_rntrc'] = padlzero(getJSON(reqJSON, 'prop_rntrc'), 9)
        erros = consistRepomCadastrarVeiculo(reqJSON, prefixTag)
        if erros != '':
            return '', erros

        # Este caso somente ocorre no processamento de modulo completo,
        # onde pode ter alguns cadastros que nao serao feitos
        if getJSON(reqJSON, prefixTag + 'integrador') == '':
            return '', ''

        isPF = len(getJSON(reqJSON, 'prop_cnpjcpf')) == 11
        nome_prop = removeAccents(getJSON(reqJSON, 'prop_nome')[0:50])
        veicle_owner = {
            'Country': getCountry(getJSON(reqJSON, 'prop_pais')),
            'NationalId': getJSON(reqJSON, 'prop_cnpjcpf'),
            'BrazilianSettings': {
                'RNTRC': getJSON(reqJSON, 'prop_rntrc'),
            },
            'Type': getHiredType(isPF)
        }

        if isPF:
            veicle_owner['VehiclePersonalInformation'] = {
                'Name': nome_prop
            }
        else:
            veicle_owner['BrazilianSettings']['VehiclePessoaJuridica'] = {
                'NomeFantasia': nome_prop
            }

        request_repom = {
            'VehicleCategory': 'HeavyCommercial',
            'VehicleAxles': getVehicleAxles(getJSON(reqJSON, prefixTag + 'quanteixos')),
            'VehicleClassification': getVehicleClassification(isCavalo),
            'VehicleOwner': veicle_owner
        }

        if isCavalo:
            request_repom['Type'] = getVehicleType(isCavalo).replace('"', '')

        return json.dumps(request_repom), ''
    except Exception as e:
        print('Erro em requestRepomCadastrarVeiculo')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRepomConsultarRoteiro(req):
    try:
        # metodo GET
        req = req.replace('\\"', '"')
        reqJSON = json.loads(req)
        return 'Route/ByIBGE/' + getJSON(reqJSON, 'rot_codibgeorig') + '/' + getJSON(reqJSON,
                                                                                     'rot_codibgedest') + '/' + getJSON(
            reqJSON, 'rot_quanteixos')
    except Exception as e:
        print('Erro em requestRepomConsultarRoteiro')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRepomConsultarRoteiroInformado(req):
    try:
        # metodo GET
        req = req.replace('\\"', '"')
        reqJSON = json.loads(req)
        return 'Routerequest/' + getJSON(reqJSON, 'rot_codrota')
    except Exception as e:
        print('Erro em requestRepomConsultarRoteiroInformado')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def consistRepomSolicitarRoteiro(reqJSON):
    # POR ENQTO NAO TEM ENTITY ROTEIRO E CONSISTENCIA GENERICA
    ret = ''
    #
    ret += consistDigit(reqJSON, 'rot_codfilial', 'Filial', [])
    ret += consistDigit(reqJSON, 'rot_codrota', 'Rota', [])
    ret += consistDigit(reqJSON, 'rot_codibgeorig', 'Código do IBGE da Cidade de Origem', [7])
    ret += consistDigit(reqJSON, 'rot_codibgedest', 'Código do IBGE da Cidade de Dest', [7])
    ret += consistEmpty(reqJSON, 'rot_descperc', 'Descrição do Percurso')
    return ret


def getShippingPaymentPlaceType(localpagto):
    if localpagto == '1':
        return 'GasStation'
    else:
        return 'Branch'


def requestRepomSolicitarRoteiro(reqJSON):
    try:
        erros = consistRepomSolicitarRoteiro(reqJSON)
        if erros != '':
            return '', erros
        #
        if getJSON(reqJSON, 'rot_idavolta') == '0':
            ida_volta = 'false'
        else:
            ida_volta = 'true'
        #
        pref = getJSON(reqJSON, 'rot_pref')
        rotaCidades = ''
        if not pref is None and pref != '':
            if pref.endswith('^'):
                pref = pref[0:len(pref) - 1]
            listRotaCidade = list(pref.split('^'))
            rotaCidades += ',' + createelemtree('PreferredWays') + '['
            ctRotaCidade = 1
            lenRotaCidade = len(listRotaCidade)
            for rotaCidade in listRotaCidade:
                if rotaCidade.endswith('@'):
                    rotaCidade = rotaCidade[0:len(rotaCidade) - 1]
                listCampos = list(rotaCidade.split('@'))
                if len(listCampos) == 2:
                    rodovia = ' (' + listCampos[1] + ')'
                else:
                    rodovia = ''
                rotaCidades += \
                    '{' + \
                    createelem2('HighwayNames', (str(ctRotaCidade) + '-' + listCampos[0] + rodovia)[0:100], '') + \
                    '}'
                if ctRotaCidade < lenRotaCidade:
                    rotaCidades += ','
                ctRotaCidade += 1
            rotaCidades += ']'
        #
        reqJSONRepom = \
            '{' + \
            createelem('BranchIdentifier', getJSON(reqJSON, 'rot_codfilial')) + \
            createelem('OriginIBGECode', getJSON(reqJSON, 'rot_codibgeorig')) + \
            createelem('DestinyIBGECode', getJSON(reqJSON, 'rot_codibgedest')) + \
            createelemnum('RoundTrip', ida_volta) + \
            createelem('Note', removeAccents(getJSON(reqJSON, 'rot_descperc'))) + \
            createelem('TraceIdentifier', getJSON(reqJSON, 'rot_codrota')) + \
            createelem2('ShippingPaymentPlaceType', getShippingPaymentPlaceType(getJSON(reqJSON, 'rot_localpagto')),
                        '') + \
            rotaCidades + \
            '}'
        return reqJSONRepom, ''
    except Exception as e:
        print('Erro em requestRepomSolicitarRoteiro')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRepomConsultarValorPedagio(req):
    try:
        # metodo GET
        req = req.replace('\\"', '"')
        reqJSON = json.loads(req)
        return 'Route/ByTraceIdentifier/' + getJSON(reqJSON, 'rot_codrota') + '/' + getJSON(reqJSON, 'rot_quanteixos')
    except Exception as e:
        print('Erro em requestRepomConsultarValorPedagio')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRepomConsultarOperacoes(req):
    try:
        # metodo GET
        req = req.replace('\\"', '"')
        reqJSON = json.loads(req)
        return 'Operation'
    except Exception as e:
        print('Erro em requestRepomConsultarValorPedagio')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def consistRepomEmitirContrato(reqJSON):
    # PENDENTE CHECAR CAMPOS OBRIGATORIOS GENERICOS NO METODO ABAIXO QUE FICA NO opcartao
    ret = conhecimento.consistCadastrarConhecimento(reqJSON)
    # PENDENTE CHECAR CONSISTENCIAS ESPECIFICAS DA REPOM
    ret += consistEmpty(reqJSON, 'conh_numerocartao', 'Número do cartão')
    if getJSON(reqJSON, 'conh_tpambop') == '0':
        ret += consistEmptyOrDefault(reqJSON, 'conh_kmrodado', 'KM Padrão', '0')
    if getJSON(reqJSON, 'conh_modalidadecontrato') != '1':  ##1 = apenas frete. Se for apenas frete não precisa de rota
        ret += consistEmptyOrDefault(reqJSON, 'conh_codextrota', 'Código Externo da Rota', '0')
        ret += consistEmptyOrDefault(reqJSON, 'conh_codextperc', 'Código Externo do Percurso da Rota', '0')

    return ret


def getReceiverType(isPFDest):
    if isPFDest:
        return 'Person'
    else:
        return 'Company'


def getImposto(sImposto, nomeImposto):
    imposto = float(sImposto)
    return \
            '{' + \
            createelem('Type', nomeImposto) + \
            createelemnum2('Value', sImposto, '') + \
            '}'


def requestRepomEmitirContrato(reqJSON, url):

    def get_billing_break_value(sat_id: str) -> str:
        if sat_id == 'I':
            return 1
        elif sat_id in ['P', 'F', 'H', 'X', 'Z']:
            return 2

        return 0

    try:
        erros = consistRepomEmitirContrato(reqJSON)
        if erros != '':
            return '', erros
        #
        if getJSON(reqJSON,
                   'conh_integrador') == '':  # este caso somente ocorre no processamento de modulo completo, onde pode ter alguns cadastros que nao serao feitos
            return '', ''
        #
        if getJSON(reqJSON, 'conh_enviarpedagio') == 'S':
            issue = 'true'
            if getJSON(reqJSON, 'conh_ida_volta') == 'S':
                ida_volta = 'true'
            else:
                ida_volta = 'false'
        else:
            issue = 'false'
            ida_volta = 'false'

        if getJSON(reqJSON, 'conh_dataprevisaodescarga') != '':
            dataPrevisaoDescarga = getJSON(reqJSON, 'conh_dataprevisaodescarga')
        else:
            hj = date.today()
            dataPrevisaoDescarga = date.fromordinal(hj.toordinal() + 30)
            dataPrevisaoDescarga = dbdatetostr(dataPrevisaoDescarga)
        dadosPedagio = createelemtree('VPR') + '{'
        dadosPedagio += \
            createelemnum('Issue', issue) + \
            createelemnum('VPROneWay', ida_volta) + \
            createelemnum('VPRSuspendedAxleNumber', '0') + \
            createelemnum2('VPRReturnSuspendedAxleNumber', '0', '')
        dadosPedagio += '},'
        dadosVeiculos = createelemtree('Vehicles') + '['
        dadosVeiculos += \
            '{' + \
            createelem('Country', getCountry(getJSON(reqJSON, 'conh_veic_pais'))) + \
            createelem2('LicensePlate', getJSON(reqJSON, 'conh_veic_placa'), '') + \
            '}'
        if getJSON(reqJSON, 'conh_veic_placacarreta1') != '':
            dadosVeiculos += \
                ',{' + \
                createelem('Country', getCountry(getJSON(reqJSON, 'conh_veic_paiscarreta1'))) + \
                createelem2('LicensePlate', getJSON(reqJSON, 'conh_veic_placacarreta1'), '') + \
                '}'
        if getJSON(reqJSON, 'conh_veic_placacarreta2') != '':
            dadosVeiculos += \
                ',{' + \
                createelem('Country', getCountry(getJSON(reqJSON, 'conh_veic_paiscarreta2'))) + \
                createelem2('LicensePlate', getJSON(reqJSON, 'conh_veic_placacarreta2'), '') + \
                '}'
        if getJSON(reqJSON, 'conh_veic_placacarreta3') != '':
            dadosVeiculos += \
                ',{' + \
                createelem('Country', getCountry(getJSON(reqJSON, 'conh_veic_paiscarreta3'))) + \
                createelem2('LicensePlate', getJSON(reqJSON, 'conh_veic_placacarreta3'), '') + \
                '}'
        dadosVeiculos += '],'

        AccountingAdjustments = []

        flagDescontaSeguro1 = getJSON(reqJSON, 'conh_descsegurosaldomot')
        flagDescontaSeguro2 = getJSON(reqJSON, 'conh_descseguro2saldomot')

        if getJSON(reqJSON, 'conh_outrosdescontosmot') != '':
            outrosDescMot = float(getJSON(reqJSON, 'conh_outrosdescontosmot'))
        else:
            outrosDescMot = 0

        if getJSON(reqJSON, 'conh_outrosdescontosmot2') != '':
            outrosDescMot2 = float(getJSON(reqJSON, 'conh_outrosdescontosmot2'))
        else:
            outrosDescMot2 = 0

        if getJSON(reqJSON, 'conh_valorseguro') != '':
            seguro = float(getJSON(reqJSON, 'conh_valorseguro'))
        else:
            seguro = 0

        if getJSON(reqJSON, 'conh_valorseguro2') != '':
            seguro2 = float(getJSON(reqJSON, 'conh_valorseguro2'))
        else:
            seguro2 = 0

        if flagDescontaSeguro1 == 'S' and seguro > 0:
            objAjustesContabeis = {}
            objAjustesContabeis['Identifier'] = 'Seguro'
            objAjustesContabeis['Value'] = seguro
            AccountingAdjustments.append(objAjustesContabeis)
        if flagDescontaSeguro2 == 'S' and seguro2 > 0:
            objAjustesContabeis = {}
            objAjustesContabeis['Identifier'] = 'Seguro2'
            objAjustesContabeis['Value'] = seguro2
            AccountingAdjustments.append(objAjustesContabeis)
        if outrosDescMot > 0:
            objAjustesContabeis = {}
            objAjustesContabeis['Identifier'] = 'OutrosDescontos'
            objAjustesContabeis['Value'] = outrosDescMot
            AccountingAdjustments.append(objAjustesContabeis)
        if outrosDescMot2 > 0:
            objAjustesContabeis = {}
            objAjustesContabeis['Identifier'] = 'OutrosDescontos2'
            objAjustesContabeis['Value'] = outrosDescMot2
            AccountingAdjustments.append(objAjustesContabeis)
        movimentos = json.dumps(AccountingAdjustments)
        movimentos = createelemtree('AccountingAdjustments') + movimentos + ','
        qtdeNfs = int(strtonum(getJSON(reqJSON, 'conh_ctnfs'), '0'))
        documents = []

        chaveCte = getJSON(reqJSON, 'conh_ctechave')
        if chaveCte != '':
            doc = {
                'BranchCode': getJSON(reqJSON, 'conh_filial_codigo'),
                'DocumentType': 'CTE',
                'Series': getJSON(reqJSON, 'conh_serie'),
                'Number': getJSON(reqJSON, 'conh_numconhec'),
                'EletronicKey': chaveCte,
                **conditional_key('CheckDocument', True, reqJSON.get('repom_documento_checklist', [])),
                **conditional_key('DocumentCheckLists', [
                    {
                        'Id': check.get('id'),
                        'PaymentBlock': check.get('block_payment'),
                    }
                    for check in reqJSON.get('repom_documento_checklist', [])
                    if check.get('tipo_documento') == 'CTE'
                ], ),

                **conditional_key('DeliveryLocationType', 'anywhere', reqJSON.get('repom_documento_checklist', []))
            }

            documents.append(doc)

        for i in range(1, qtdeNfs + 1, 1):
            objNf = {}

            tipoDoc = getJSON(reqJSON, 'conh_tipodocnf' + str(i))

            objNf['BranchCode'] = getJSON(reqJSON, 'conh_filial_codigo')

            if tipoDoc == '2':
                document_type = 'NFe'
            else:
                document_type = 'OCC'

            objNf['DocumentType'] = document_type

            objNf['Series'] = getJSON(reqJSON, 'conh_serienf' + str(i))
            objNf['Number'] = getJSON(reqJSON, 'conh_numnf' + str(i))

            if tipoDoc == '2':
                objNf['EletronicKey'] = getJSON(reqJSON, 'conh_chavenf' + str(i))

            if list(filter(lambda x: x.get('tipo_documento') == document_type.upper(),
                           reqJSON.get('repom_documento_checklist', []))):
                objNf['CheckDocument'] = len(reqJSON.get('repom_documento_checklist', [])) > 0
                objNf['DocumentCheckLists'] = [
                    {
                        'Id': check.get('id'),
                        'PaymentBlock': check.get('block_payment')
                    }
                    for check in reqJSON.get('repom_documento_checklist', [])
                    if check.get('tipo_documento') == document_type.upper()
                ]

                objNf['DeliveryLocationType'] = 'anywhere'

            documents.append(objNf)

        documentos = json.dumps(documents)
        documentos = createelemtree('Documents') + documentos + ','

        dadosImpostos = ',' + createelemtree('Taxes') + '['  # pois como é a ultima tag, tem que forcar a virgula antes
        enviaimp = getJSON(reqJSON, 'conh_enviaimp')

        desconta_imp = getJSON(reqJSON, 'conh_descontainsssaldomot')

        if (enviaimp == '' or enviaimp == 'S') or (desconta_imp == 'S'):
            # somente enviar os impostos se o SOR que faz os calculos e nao a Repom
            dadosImpostos += getImposto(getJSON(reqJSON, 'conh_impirrf'), 'IRRF') + ','
            dadosImpostos += getImposto(getJSON(reqJSON, 'conh_impsest'), 'SEST') + ','
            dadosImpostos += getImposto(getJSON(reqJSON, 'conh_impsenat'), 'SENAT') + ','
            dadosImpostos += getImposto(getJSON(reqJSON, 'conh_impinss'), 'INSS')
        dadosImpostos += ']'  # ultimo grupo de tags, nao mandar virgula
        #
        isPFDest = getJSON(reqJSON, 'conh_dest_cnpjcpf') == 11
        dadosRota = ''
        if getJSON(reqJSON,
                   'conh_modalidadecontrato') != '1':  ##1 = apenas frete. Se for apenas frete não precisa de rota
            dadosRota += createelemnum('BrazilianRouteTraceCode', getJSON(reqJSON, 'conh_codextperc'))
            dadosRota += createelemnum('BrazilianRouteRouteCode', getJSON(reqJSON, 'conh_codextrota'))

        # poderia mandar varios conhecimentos, por isso o [{...}]
        reqJSONRepom = \
            '[{' + \
            createelem('Identifier', getJSON(reqJSON, 'conh_numero')) + \
            createelem('Country', getCountry(getJSON(reqJSON, 'conh_pais'))) + \
            createelem('HiredCountry', getCountry(getJSON(reqJSON, 'conh_prop_pais'))) + \
            createelem('HiredNationalId', getJSON(reqJSON, 'conh_prop_cnpjcpf')) + \
            createelem('OperationIdentifier', getJSON(reqJSON, 'conh_operacao'))

        if reqJSON.get('conh_pedagiotag') != 'S':
            reqJSONRepom += createelemnum('CardNumber', getJSON(reqJSON, 'conh_numerocartao'))

        perc_adto = safe_cast(getJSON(reqJSON, 'conh_percadto'), float, 0)
        valor_frete_mot = safe_cast(getJSON(reqJSON, 'conh_valorfretemot'), float, 0) * perc_adto / 100

        reqJSONRepom += dadosRota + \
                        createelem('IssueDate', getJSON(reqJSON, 'conh_datahoraemissao') + '.000Z') + \
                        createelemnum('TotalFreightValue', getJSON(reqJSON, 'conh_valorviagem')) + \
                        createelemnum('TotalLoadWeight', getJSON(reqJSON, 'conh_pesosaida')) + \
                        createelemnum('TotalLoadValue', getJSON(reqJSON, 'conh_valormerc')) + \
                        createelemnum('AdvanceMoneyValue', getJSON(reqJSON, 'conh_valoradiant')) + \
                        dadosPedagio + \
                        createelemtree('ShippingPayment') + '{' + \
                        createelem('ExpectedDeliveryDate', dataPrevisaoDescarga + 'T00:00:00.000Z') + \
                        createelem2('ExpectedDeliveryLocationType', 'Branch', '') + \
                        '},' + \
                        createelemtree('Drivers') + '[{' + \
                        createelem('Country', getCountry(getJSON(reqJSON, 'conh_mot_pais'))) + \
                        createelem('NationalId', getJSON(reqJSON, 'conh_mot_cpf')) + \
                        createelemnum2('Main', 'true', '') + \
                        '}],' + \
                        documentos + \
                        dadosVeiculos + \
                        movimentos + \
                        createelem('BranchCode', getJSON(reqJSON, 'conh_filial_codigo')) + \
                        createelem('LoadBrazilianNCM', getJSON(reqJSON, 'conh_ncm')) + \
                        createelem('LoadBrazilianANTTCodeType', '5' if '2.3' in url else 'GeneralCargo') + \
                        createelemtree('ShippingReceiver') + '{' + \
                        createelem('Country', getCountry(getJSON(reqJSON, 'conh_dest_pais'))) + \
                        createelem('NationalId', getJSON(reqJSON, 'conh_dest_cnpjcpf')) + \
                        createelem('Name', removeAccents(getJSON(reqJSON, 'conh_dest_nome')[0:50])) + \
                        createelem2('ReceiverType', getReceiverType(isPFDest), '') + \
                        '},' + \
                        createelem('BrazilianIBGECodeSource', getJSON(reqJSON, 'conh_codibgeorig')) + \
                        createelem('BrazilianIBGECodeDestination', getJSON(reqJSON, 'conh_codibgedest')) + \
                        createelem('BrazilianCEPSource', getJSON(reqJSON, 'conh_ceporig')) + \
                        createelem('BrazilianCEPDestination', getJSON(reqJSON, 'conh_cepdest')) + \
                        createelemnum2('TravelledDistance', getJSON(reqJSON, 'conh_kmprevistoperc'), '') + \
                        dadosImpostos + ',' \
                                        '"ShippingFuel": { ' + \
                        createelem('FuelCardNumber', getJSON(reqJSON, 'conh_cartaoadto')) + \
                        f'"FuelValue": {str(round_by_abnt(valor_frete_mot))}}}'

        if 'repom_documento_checklist' in reqJSON:
            reqJSONRepom += f',"BillingBreak": "{get_billing_break_value(reqJSON.get("conh_tipodesc"))}",' + \
                            f'"ToleranceBreak": {safe_cast(reqJSON.get("conh_valortoler"), float, 0)},' + \
                            f'"FreightBreak": true'

        reqJSONRepom += '}]'
        ''' copiado da efrete... nao achei campo pra colocar na repom
        obsCredenc = ''
        if getJSON(reqJSON,'conh_params_exigeticketdescarga') == '':
            obsCredenc = obsCredenc + '<obj:string>DOCUMENTO REQUERIDO: TICKET BALANÇA</obj:string>'
        if getJSON(reqJSON,'conh_params_exigecaonhotodacte') == '':
            obsCredenc = obsCredenc + '<obj:string>DOCUMENTO REQUERIDO: CANHOTO DACTE</obj:string>'
        if getJSON(reqJSON,'conh_params_exigecanhotonfe') == '':
            obsCredenc = obsCredenc + '<obj:string>DOCUMENTO REQUERIDO: CANHOTO NFE</obj:string>'
        '''
        return reqJSONRepom, ''
    except Exception as e:
        print('Erro em requestRepomEmitirContrato')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


# metodo abaixo por enqto sem acao no SOR, usado apenas para pegar os possiveis erros
def requestRepomConsultarStatusContrato(cert, codEMonitorAcao, url, headers, id):
    try:
        removeShipping = url.endswith('Shipping')
        if removeShipping:
            url += '/StatusProcessing/ByIdentifier/' + id
        else:
            url += 'Shipping/StatusProcessing/ByIdentifier/' + id
        req = ''
        #
        resp = requests.get(url, cert=cert, data=req, headers=headers)
        retcode = resp.status_code
        if retcode == 200:
            ret = resp.content.decode('utf-8')
            root = json.loads(ret)
            root2 = root['Result']
            # status = getJSON(root2, 'Status')
            # print(status)
            errors = getJSON(root2, 'Errors')
            msgResp = ''
            for error in errors:
                msgResp += ' - ' + error['Message'] + ' (' + str(error['ErrorCode']) + ')'
            if msgResp is None:
                msgResp = ''
            return msgResp
        elif retcode == 404:
            return 'VIAGEM NÃO ENCONTRADA'
        else:
            return 'ERRO INTERNO AO PROCESSAR STATUS DE PROCESSAMENTO DE CONTRATO NO SERVIDOR DA OPERADORA DE CARTÃO (' + str(
                retcode) + ')'
    except Exception as e:
        print('Erro em requestRepomConsultarStatusContrato')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRepomConsultarContrato(cert, codEMonitorAcao, url, headers, req):
    try:
        removeShipping = url.endswith('Shipping')
        # ACAO_REPOM_CONSULTARCONTRATO, ACAO_REPOM_CANCELARCONTRATO ou ACAO_REPOM_INTERROMPERCONTRATO => req = JSON vindo do SOR
        # ACAO_REPOM_EMITIRCONTRATO => req = vetor de JSON gerado no EMPY
        req = req.replace('\\"', '"')
        reqJSON = json.loads(req)
        if isinstance(reqJSON, list):  # PENDENTE MUDAR LOGICA QUANDO TIVER VARIAS VIAGENS => ACAO_REPOM_EMITIRCONTRATO
            id = getJSON(reqJSON[0], 'Identifier')
        else:  # PENDENTE MUDAR LOGICA QUANDO TIVER VARIAS VIAGENS => ACAO_REPOM_CANCELARCONTRATO ou ACAO_REPOM_INTERROMPERCONTRATO
            id = getJSON(reqJSON, 'conh_numero')
        #
        msgResp = requestRepomConsultarStatusContrato(cert, codEMonitorAcao, url, headers, id)
        if msgResp != '':  # PENDENTE NA VERDADE JA DEVERIA RETORNAR UM ERRO
            if removeShipping:
                return '/ByIdentifier/' + id
            else:
                return 'Shipping/ByIdentifier/' + id
        #
        if removeShipping:
            return '/ByIdentifier/' + id
        else:
            return 'Shipping/ByIdentifier/' + id
    except Exception as e:
        print('Erro em requestRepomConsultarStatusContrato')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRepomQuitarContrato(reqJSON):
    try:
        pesoChegada = float(getJSON(reqJSON, 'conh_pesochegada'))
        if pesoChegada == 0:
            status = 'Dismissed'
        else:
            status = 'Delivered'
        # reqJSONRepom = \
        #     '{' + \
        #         createelem('BranchCode', getJSON(reqJSON,'conh_filial_codigo')) + \
        #         createelemnum('ShippingID', getJSON(reqJSON,'conh_id')) + \
        #         createelemnum('TotalUnloadWeight', getJSON(reqJSON,'conh_pesochegada')) + \
        #         createelemtree('Documents') + '[{' + \
        #             createelem('Number', getJSON(reqJSON,'conh_numconhec')) + \
        #             createelem('Series', getJSON(reqJSON,'conh_serie')) + \
        #             createelem('BranchCode', getJSON(reqJSON,'conh_filial_codigo')) + \
        #             createelem('DocumentType', 'CTE') + \
        #             createelem2('DocumentStatus', status, '') + \
        #         '}]' + \
        #     '}'
        objQuitarContrato = {}

        objQuitarContrato['BranchCode'] = getJSON(reqJSON, 'conh_filial_codigo')
        objQuitarContrato['ShippingID'] = getJSON(reqJSON, 'conh_id')
        objQuitarContrato['TotalUnloadWeight'] = getJSON(reqJSON, 'conh_pesochegada')
        # objQuitarContrato.append(objQuitarContrato)
        qtdeNfs = int(strtonum(getJSON(reqJSON, 'conh_ctnfs'), '0'))
        documents = []
        for i in range(1, qtdeNfs + 1, 1):
            objNf = {}
            objNf['Number'] = getJSON(reqJSON, 'conh_numnf' + str(i))
            objNf['Series'] = getJSON(reqJSON, 'conh_serienf' + str(i))
            objNf['BranchCode'] = getJSON(reqJSON, 'conh_filial_codigo')
            tipoDoc = getJSON(reqJSON, 'conh_tipodocnf' + str(i))
            if tipoDoc == '2':
                objNf['DocumentType'] = 'NFe'
            else:
                objNf['DocumentType'] = 'OCC'

            objNf['DocumentStatus'] = status
            documents.append(objNf)
        #
        numConhec = getJSON(reqJSON, 'conh_numconhec')
        if numConhec != '':
            objConh = {}
            objConh['Number'] = getJSON(reqJSON, 'conh_numconhec')
            objConh['Series'] = getJSON(reqJSON, 'conh_serie')
            objConh['BranchCode'] = getJSON(reqJSON, 'conh_filial_codigo')
            objConh['DocumentType'] = 'CTE'
            objConh['DocumentStatus'] = status
            documents.append(objConh)
            objQuitarContrato['Documents'] = documents
        #
        return json.dumps(objQuitarContrato), ''
    except Exception as e:
        print('Erro em requestRepomQuitarContrato')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRepomConciliacaoContabilData(cert, codEMonitorAcao, url, headers, req):
    try:
        req = req.replace('\\"', '"')
        reqJSON = json.loads(req)
        dataInicial = getJSON(reqJSON, 'dataInicial')
        dataFinal = getJSON(reqJSON, 'dataFinal')
        return 'Statement/Accounting/GetByCustomerDateInicialDateFinal/' + dataInicial + '/' + dataFinal
    except Exception as e:
        print('Erro em requestRepomConciliacaoContabilData')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRepomEmiteFinanceiro(cert, codEMonitorAcao, url, headers, req):
    try:
        req = req.replace('\\"', '"')
        reqJSON = json.loads(req)
        dataInicial = getJSON(reqJSON, 'startDate')
        dataFinal = getJSON(reqJSON, 'endDate')
        return 'Statement/Financial/GetByCustomerStartDateEndDate/' + dataInicial + '/' + dataFinal
    except Exception as e:
        print('Erro em requestRepomEmiteFinanceiro')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseRepomCadastrarProprietario(resp):
    return responseRepomCadastrarGeral(resp)


def responseRepomCadastrarMotorista(resp):
    return responseRepomCadastrarGeral(resp)


def responseRepomCadastrarVeiculo(resp):
    return responseRepomCadastrarGeral(resp)


def responseRepomConsultarRoteiro(resp):
    try:
        retcode = resp.status_code
        if retcode == 200:
            ret = resp.content.decode('utf-8')
            listResult = json.loads(ret)['Result']
            ret = ''
            for result in listResult:
                ret += '<roteiro>'
                ret += createtag('roteiro_codigointerno', getJSON(result, 'TraceIdentifier'))
                ret += createtag('roteiro_codigo', str(getJSON(result, 'RouteCode')))
                ret += createtag('percurso_codigo', str(getJSON(result, 'TraceCode')))
                ret += createtag('percurso_descricao', getJSON(result, 'Name').upper())
                ret += createtag('percurso_km', str(getJSON(result, 'Distance')))
                ida_volta = getJSON(result, 'RoundTrip')
                if ida_volta:
                    ret += createtag('roteiro_idavolta', '1')
                else:
                    ret += createtag('roteiro_idavolta', '0')
                ret += '</roteiro>'
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + str(
                len(listResult)) + ' rota(s) encontrada(s)' + '</msg>' + ret + '</resp>', ''
        else:
            return '', 'ERRO DE REQUISIÇAO NA OPERADORA (' + str(retcode) + ')'
    except Exception as e:
        print('Erro em responseRepomConsultarRoteiro')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseRepomConsultarRoteiroInformado(resp):
    try:
        retcode = resp.status_code
        if retcode == 200:

            ret = resp.content.decode('utf-8')
            result = json.loads(ret)['Result']
            status = getJSON(result, 'Status')
            msg = ''
            if status == 'Pending':
                msg = 'Rota ainda não Cadastrada pela Repom. Aguarde alguns instantes e consulte novamente!'
            elif status == 'AwaitingReview':
                msg = 'Rota solicitada com sucesso!'
            elif status == 'Finished':
                msg = 'Solicitação de rota atendida!'

            ret = ''
            ret += '<roteiro>'
            ret += createtag('roteiro_codigointerno', getJSON(result, 'TraceIdentifier'))
            ret += createtag('roteiro_codigo', str(getJSON(result, 'RouteCode')))
            ret += createtag('percurso_codigo', str(getJSON(result, 'TraceCode')))
            ret += createtag('status', getJSON(result, 'Status'))
            ret += createtag('motivo_reprovacao', str(getJSON(result, 'DisapprovalReason')))
            ret += createtag('motivo_reprovacao_codigo', str(getJSON(result, 'DisapprovalReasonCode')))
            ret += '</roteiro>'
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msg + '</msg>' + ret + '</resp>', ''
        else:
            return '', 'ERRO DE REQUISIÇAO NA OPERADORA (' + str(retcode) + ')'
    except Exception as e:
        print('Erro em responseRepomConsultarRoteiroInformado')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseRepomSolicitarRoteiro(resp):
    return responseRepomCadastrarGeral(resp)


def responseRepomConsultarValorPedagio(resp):
    try:
        retcode = resp.status_code
        if retcode == 200:
            ret = resp.content.decode('utf-8')
            result = json.loads(ret)['Result']
            ret = createtag('valor_total_vpr', str(getJSON(result, 'TotalVPRValue')))
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>Valor do Pedágio encontrado para a Rota informada' + '</msg>' + ret + '</resp>', ''
        else:
            return '', 'ERRO DE REQUISIÇAO NA OPERADORA (' + str(retcode) + ')'
    except Exception as e:
        print('Erro em responseRepomConsultarValorPedagio')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseRepomConsultarOperacoes(resp):
    try:
        retcode = resp.status_code
        if retcode == 200:
            ret = resp.content.decode('utf-8')
            listResult = json.loads(ret)['Result']
            ret = ''
            for result in listResult:
                ret += '<operacao>'
                ret += createtag('operacao_codigo', getJSON(result, 'OperationIdentifier'))
                ret += createtag('operacao_descricao', getJSON(result, 'Name').upper())
                ret += '</operacao>'
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + str(
                len(listResult)) + ' oper. encontrada(s)' + '</msg>' + ret + '</resp>', ''
        else:
            return '', 'ERRO DE REQUISIÇAO NA OPERADORA (' + str(retcode) + ')'
    except Exception as e:
        print('Erro em responseRepomConsultarOperacoes')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseRepomEmitirContrato(resp, cert, url, headers, req):
    try:
        retcode = resp.status_code
        if retcode == 201:
            id = ''
            ciot = ''
            valorPedagio = ''
            ret = resp.content.decode('utf-8')
            root = json.loads(ret)
            msg = getJSON(root, 'Response')['Message']
            if 'OperationKey: ' in msg:
                numTent = 1
                while numTent <= 10:  # ate 10 tentativas => 20 segundos
                    time.sleep(2)  # esperar 2 segundos antes de consultar contrato
                    root2 = preProcessURLRepom(cert, ACAO_REPOM_EMITIRCONTRATO, url, headers, req, numTent)
                    if isinstance(root2, str):
                        if int(root2) != 404:  # nao encontrado mas pode ser que apareca depois
                            return '', 'CIOT NÃO ENCONTRADO NA RESPOSTA DA OPERADORA DE CARTÃO (Consulta pelo Número Interno vazia!)'
                        else:
                            numTent += 1
                            continue
                    #
                    try:
                        # somente tem Errors se foi chamado ACAO_REPOM_CONSULTARSTATUSCONTRATO ao inves de ACAO_REPOM_CONSULTARCONTRATO
                        errors = getJSON(root2, 'Errors')
                        msgResp = ''
                        for error in errors:
                            msgResp += ' - ' + error['Message'] + ' (' + str(error['ErrorCode']) + ')'
                        if msgResp is None:
                            msgResp = ''
                        if msgResp != '':
                            return '', ' [' + msgResp + ']'
                    except Exception as e:
                        msgResp = ''
                    #
                    id = str(root2['ShippingId'])
                    ciot = root2['CIOT']
                    if ciot != '':
                        valorPedagio = createtag('valor_total_vpr', str(root2['VPRValue']))
                        break
                    else:
                        listOC = root2['Occurences']
                        if len(listOC) > 0:
                            ret = ''
                            for oc in listOC:
                                ret += ' [' + getJSON(oc, 'Detail') + ']'
                            return '', ret
                    numTent += 1
                if ciot != '':
                    ciotResp = '<processo_transporte_codigo>' + id + '</processo_transporte_codigo>' + '<ciot>' + ciot + '</ciot>' + valorPedagio
                    return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + 'Cadastrado com sucesso' + '</msg>' + ciotResp + '</resp>', ''
                else:
                    return '', 'CIOT NÃO ENCONTRADO NA RESPOSTA DA OPERADORA DE CARTÃO APÓS VÁRIAS TENTATIVAS DE CONSULTA'
            else:
                return '', 'CIOT NÃO ENCONTRADO NA RESPOSTA DA OPERADORA DE CARTÃO (Chave da Operação vazia!)'
        else:
            return responseRepomCadastrarGeral(resp)
    except Exception as e:
        print('Erro em responseRepomEmitirContrato')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseRepomConsultarContrato(resp):
    try:
        retcode = resp.status_code
        if retcode == 200:
            ret = resp.content.decode('utf-8')
            root = json.loads(ret)
            root2 = root['Result']
            #
            try:
                # somente tem Errors se foi chamado ACAO_REPOM_CONSULTARSTATUSCONTRATO ao inves de ACAO_REPOM_CONSULTARCONTRATO
                errors = getJSON(root2, 'Errors')
                msgResp = ''
                for error in errors:
                    msgResp += ' - ' + error['Message'] + ' (' + str(error['ErrorCode']) + ')'
                if msgResp is None:
                    msgResp = ''
                if msgResp != '':
                    return '', ' [' + msgResp + ']'
            except Exception as e:
                msgResp = ''
            #
            id = str(root2['ShippingId'])
            ciot = root2['CIOT']
            if ciot != '' or id != '':
                valorPedagio = createtag('valor_total_vpr', str(root2['VPRValue']))
                ciotResp = '<processo_transporte_codigo>' + id + '</processo_transporte_codigo>' + '<ciot>' + ciot + '</ciot>' + valorPedagio
                return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + 'Cadastrado com sucesso' + '</msg>' + ciotResp + '</resp>', ''
            else:
                listOC = root2['Occurences']
                if len(listOC) > 0:
                    ret = ''
                    for oc in listOC:
                        ret += ' [' + getJSON(oc, 'Detail') + ']'
                    return '', ret
                else:
                    return '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><msg>' + 'CIOT NÃO ENCONTRADO E SEM OCORRÊNCIAS REGISTRADAS' + '</msg></resp>', ''
        elif retcode == 404:
            return '', 'VIAGEM NÃO ENCONTRADA'
        else:
            return '', 'MENSAGEM DE ERRO DA OPERADORA NÃO ENCONTRADA (' + str(retcode) + ')'
    except Exception as e:
        print('Erro em responseRepomConsultarContrato')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseRepomQuitarContrato(resp):
    return responseRepomCadastrarGeral(resp)


def responseRepomCancelarContrato(resp):
    return responseRepomCadastrarGeral(resp)


def responseRepomInterromperContrato(resp):
    return responseRepomCadastrarGeral(resp)


def getAccountingManagementType(accountingManagementType):
    if accountingManagementType == 0:
        return 2  # debito, para ficar mesmo padrao da tabela Transacao
    else:
        return 1  # credito


def responseRepomConciliacaoContabilData(resp):
    try:
        retcode = resp.status_code
        if retcode == 200:
            ret = resp.content.decode('utf-8')
            root = json.loads(ret)
            listaViagens = root['responseResult']
            arrayViagens = []
            for viagem in listaViagens:
                objViagem = {}
                objViagem['numero'] = viagem['clientContractCode']
                objViagem['numViagOpCartao'] = viagem['repomContractCode']
                objViagem['tipoEvento'] = viagem['accountingTransactionType']
                objViagem['codEvento'] = viagem[
                    'accountingTransactionCode']  # codigo na Repom para a operacao, 0000000000 (tipo 2), ou um numero de 10 posicoes (tipo 1 ou 3)
                objViagem['descEvento'] = removeAccents(viagem['accountingTransactionDescription']).upper()
                objViagem['tipoTrans'] = getAccountingManagementType(viagem['accountingManagementType'])
                objViagem['valor'] = viagem['accountingTransactionValue']
                objViagem['data'] = datetostr(wsstrtodate(viagem['accountingTransactionDate']))
                objViagem['cnpjCpfForn'] = viagem['supplierNationalID']
                objViagem['nomeForn'] = removeAccents(viagem['supplierName']).upper()
                objViagem['pesoChegada'] = viagem['deliveryWeight']
                arrayViagens.append(objViagem)
            retFinal = {}
            retFinal['viagens'] = arrayViagens
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>Dados processados com sucesso</msg><json>' + json.dumps(
                retFinal) + '</json></resp>', ''
        elif retcode == 400:
            ret = resp.content.decode('utf-8')
            root = json.loads(ret)
            message = getJSON(root, 'message')
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><msg>' + message + '</msg><json></json></resp>', ''
        else:
            return '', 'MENSAGEM DE ERRO DA OPERADORA NÃO ENCONTRADA (' + str(retcode) + ')'
    except Exception as e:
        print('Erro em responseRepomConciliacaoContabilData')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseRepomEmiteFinanceiro(resp):
    try:
        retcode = resp.status_code
        if retcode == 200:
            ret = resp.content.decode('utf-8')
            root = json.loads(ret)
            listaViagens = root['responseResult']
            arrayViagens = []

            for viagem in listaViagens:
                objViagem = {}

                objViagem['identificador'] = viagem.get('identifier', '')
                objViagem['numViagOpCartao'] = viagem.get('repomContractCode', '')
                objViagem['numero'] = viagem.get('clientContractCode', '')
                objViagem['codFilial'] = viagem.get('clientBranchCode', '')
                objViagem['tipoEvento'] = viagem.get('financialTransactionType', '')
                objViagem['descEvento'] = removeAccents(viagem.get('financialTransactionTypeDescription', '')).upper()
                objViagem['tipoTrans'] = viagem.get('financialManagementType', '')
                objViagem['valor'] = viagem.get('financialTransactionValue', '')
                objViagem['data'] = datetostr(wsstrtodate(viagem.get('financialTransactionDate', '')))
                objViagem['dataPagamento'] = datetostr(wsstrtodate(viagem.get('financialTransactionPaymentDate', '')))
                objViagem['boletoBancario'] = viagem.get('bankSlip', '')
                objViagem['boletoBancValor'] = viagem.get('bankSlipValue', '')
                objViagem['codLotePag'] = viagem.get('paymentBatchCode', '')
                objViagem['IdTransacao'] = viagem.get('transactionID', '')
                arrayViagens.append(objViagem)
            retFinal = {}
            retFinal['viagens'] = arrayViagens
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>Dados processados com sucesso</msg><json>' + json.dumps(
                retFinal) + '</json></resp>', ''
        elif retcode == 400:
            ret = resp.content.decode('utf-8')
            root = json.loads(ret)
            message = getJSON(root, 'message')
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><msg>' + message + '</msg><json></json></resp>', ''
        else:
            return '', 'MENSAGEM DE ERRO DA OPERADORA NÃO ENCONTRADA (' + str(retcode) + ')'
    except Exception as e:
        print('Erro em responseRepomConciliacaoContabilData')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseRepomCadastrarGeral(resp):
    try:
        retcode = resp.status_code
        if retcode in [200, 201, 204]:
            ret = resp.content.decode('utf-8')
            msg = getJSON(json.loads(ret), 'Response')['Message'] if ret else ''

            if msg == 'Vehicle created successfully':
                msg = 'Veículo cadastrado com sucesso!'
            elif msg == 'Driver created successfully':
                msg = 'Motorista cadastrado com sucesso!'
            elif msg == ' created successfully':
                msg = 'Proprietário cadastrado com sucesso!'
            elif msg == 'RouteRequest created successfully':
                msg = 'Rota Solicitada com sucesso!'
            elif not msg:
                msg = 'Operação realizada com sucesso!'
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msg + '</msg></resp>', ''
        else:
            ret = resp.content.decode('utf-8')
            root = json.loads(ret)
            errors = getJSON(root, 'Errors')
            msgResp = ''
            msgNormal = ''
            for error in errors:
                if error['Message'] == 'repomfrete: Prestador já existente.':
                    msgAux = 'Proprietário já cadastrado com sucesso!'
                elif error['Message'] == 'repomfrete: Já existe um motorista com este CPF.':
                    msgAux = 'Motorista já cadastrado com sucesso!'
                elif 'Já existe um veiculo com a placa' in error['Message']:
                    msgAux = 'Veículo já cadastrado com sucesso!'
                else:
                    msgAux = ''
                if msgAux != '':
                    msgNormal += msgAux + ' '
                msgResp += ' - ' + error['Message'] + ' (' + str(error['ErrorCode']) + ')' + '\n ' + msgAux
            if msgNormal != '':
                return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msgNormal + '</msg></resp>', ''
            else:
                if msgResp is None or msgResp == '':
                    msgResp = 'MENSAGEM DE ERRO DA OPERADORA NÃO ENCONTRADA (' + str(retcode) + ')'
                return '', msgResp
    except Exception as e:
        print('Erro em responseRepomCadastrarGeral')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRepomAdicionarMovimento(reqJSON):
    try:
        diferencaDeFrete = float(getJSON(reqJSON, 'conh_diferencadefrete'))
        req = {}
        req['Identifier'] = '2'
        req['Value'] = diferencaDeFrete
        return json.dumps(req), ''
    except Exception as e:
        print('Erro em requestRepomAdicionarMovimento')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseRepomAtualizaProp(resp):
    retcode = resp.status_code
    if retcode == 204:
        return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>Proprietario atualizado com sucesso</msg></resp>', ''
    else:
        return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><msg>Ocorreu um erro ao atualizar o proprietário</msg></resp>'


def responseRepomAtualizaMot(resp):
    retcode = resp.status_code
    if retcode == 204:
        return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>Motorista atualizado com sucesso</msg></resp>', ''
    else:
        return '', '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><msg>Ocorreu um erro ao atualizar o motorista</msg></resp>'


def requestRepomUrlAdicionarMovimento(req):
    try:
        req = req.replace('\\"', '"')
        reqJSON = json.loads(req)
        return 'Shipping/AddMovement/' + getJSON(reqJSON, 'conh_id')
    except Exception as e:
        print('Erro em requestRepomUrlAdicionarMovimento')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRepomUrlAtualizaProp(req):
    try:
        req = req.replace('\\"', '"')
        reqJSON = json.loads(req)

        url_postfix = ''
        api_version: str = reqJSON.get('repom_api_versao', '')
        if api_version.strip() == '2.3':
            url_postfix = '?x-api-version=2.3'

        return 'Hired/55/' + getJSON(reqJSON, 'prop_cnpjcpf') + url_postfix
    except Exception as e:
        print('Erro em requestRepomUrlAtualizaProp')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRepomUrlAtualizaMot(req):
    try:
        req = req.replace('\\"', '"')
        reqJSON = json.loads(req)
        return 'Driver/55/' + getJSON(reqJSON, 'mot_cpf')
    except Exception as e:
        print('Erro em requestRepomUrlAtualizaMot')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRepomUrlAtualizaVeic(req, prefix):
    try:
        req = req.replace('\\"', '"')
        reqJSON = json.loads(req)
        return 'Vehicle/55/' + getJSON(reqJSON, prefix + 'placa')
    except Exception as e:
        print('Erro em requestRepomUrlAtualizaVeic')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def requestRepomUrlAtualizaContrato(req):
    try:
        req = req.replace('\\"', '"')
        reqJSON = json.loads(req)
        if reqJSON.get('conh_percadto'):
            return '?x-api-version=2.3'
        else:
            return ''
    except Exception as e:
        print('Erro em requestRepomUrlAtualizaContrato')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseRepomAdicionarMovimento(resp):
    return responseRepomCadastrarGeral(resp)


def requestRepomEmitirContratoGratuito(reqJSON):
    return ''


def responseRepomEmitirContratoGratuito(resp, cert, url, headers, req):
    return ''


def _date_ddmmyy(s: str) -> str:
    try:
        return datetime.strptime(s, '%d/%m/%Y %H:%M:%S').strftime('%Y-%m-%dT%H:%M:%S'),  # [:-4] +'Z',
    except (Exception,):
        return ''
