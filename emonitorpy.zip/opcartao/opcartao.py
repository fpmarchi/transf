# opcartao
from flask import jsonify
from json import JSONDecodeError
from os import system

import geral
import geralsockets

import m3risk
from abastecimento import x7bank, polisoftware, ctasmart, profrota, alltank, truckpag
from abastecimento.eptasga import *
from cargobank import *
from ciotpag import ciot_pag
from dispacher.decorators import EmpyError
from efrete import *
from extratta import *
from gerrisco import fretebras, trafegus, carguero, raster, rondonline, m3risk, emprotege, krona, ffgr, sigagr, sisger, \
    smartload, senig, angellira, porto_seguro, fretebrastrucker
from grlog import *
from mensageria import maxbot, leadsfy
from pagbem import *
from raster import *
from rastreamento.tracker import tracker
from rastreamento import mytracking
from rastreamento import uberlog
from repom import *
from rodobank import *
from rodobens import *
from rondon import *
from serasa import *
from siga import *
from transsat import *
from trizy import *
from vale_pedagio import _efretehub
from . import tipfrete, ffdigital, nddcargo, repom, ffcred, pozidigital

# acoes text/xml
ACAO_OPERADORASEMCHAVEPUB_ENVIODIRETOTEXTXML = 605
ACAO_OPERADORACOMCHAVEPUB_ENVIODIRETOTEXTXML = 606
# acoes application/xml
ACAO_OPERADORASEMCHAVEPUB_ENVIODIRETOAPPXML = 607
ACAO_OPERADORACOMCHAVEPUB_ENVIODIRETOAPPXML = 608
# acoes text/json
ACAO_OPERADORASEMCHAVEPUB_ENVIODIRETOTEXTJSON = 609
ACAO_OPERADORACOMCHAVEPUB_ENVIODIRETOTEXTJSON = 610
# acoes application/json
ACAO_OPERADORASEMCHAVEPUB_ENVIODIRETOAPPJSON = 611
ACAO_OPERADORACOMCHAVEPUB_ENVIODIRETOAPPJSON = 612
# acoes base64
ACAO_OPERADORASEMCHAVEPUB_ENVIODIRETOAPPJSONBASE64 = 613
ACAO_OPERADORACOMCHAVEPUB_ENVIODIRETOAPPJSONBASE64 = 614
ACAO_OPERADORASEMCHAVEPUB_ENVIODIRETOAPPXMLBASE64 = 615
ACAO_OPERADORACOMCHAVEPUB_ENVIODIRETOAPPXMLBASE64 = 616

# acao somente para retornar o token
ACAO_AUTENTICA_BASIC_MD5 = 617
ACAO_AUTENTICA_BASIC_SEMVERIFCERT = 618

# timeout em segundos
CONNECTTIMEOUTWS = 10
READTIMEOUTWS = 180


class OpCartaoException(EmpyError):
    pass


def _opcartao_exception_callback(data: dict) -> Tuple[str, str, str, str]:
    return '', data.get("ex_message", "Mensagem não recuperada"), '', ''


def _opcartao_unexpected_exception_callback(data: dict) -> Tuple[str, str, str, str]:
    # NUNCA MODIFICAR
    msg_error = 'Ocorreu um erro inesperado ao comunicar com  Operadora de Cartão!\n' \
                'Por favor, se o problema persistir, entre em contato com o suporte.'

    return '', msg_error, '', ''


_handle_exception = handle_exception_factory(
    OpCartaoException,
    _opcartao_exception_callback,
    _opcartao_unexpected_exception_callback
)


@_handle_exception
def call_envio_opcartao(pfx_path, pfx_password, codInstalacao, codEmpresa, codEMonitorAcao, apenasGerarArq, url, req,
                        action, requestMethod, requestProperties):
    erros = ''
    # checar pela acao se tem que gerar dados para a operadora especifica
    reqAux = req
    files = {}
    if isAcaoToProcess(codEMonitorAcao):
        if isAcaoArq(codEMonitorAcao):
            req, erros, files = processRequestOpCartao(
                codEMonitorAcao,
                req,
                requestProperties,
                pfx_path,
                pfx_password,
                url
            )
        else:
            if not porto_seguro.is_recognized_action(codEMonitorAcao):
                req, erros = processRequestOpCartao(codEMonitorAcao, req, requestProperties, pfx_path, pfx_password, url)
            else:
                arqreq = '/sistemas/emonitorpy/tmp/req'\
                    + str(codInstalacao) + '_' + str(codEmpresa) + '_' + str(codEMonitorAcao) + '.json'
                arqresp = '/sistemas/emonitorpy/tmp/resp'\
                    + str(codInstalacao) + '_' + str(codEmpresa) + '_' + str(codEMonitorAcao) + '.json'

                context_data = {
                    'req': json.loads(req),
                    'url': url,
                    'props': requestProperties,
                    'arq_req': arqreq,
                    'arq_resp': arqresp,
                    'acao': codEMonitorAcao
                }

                data = porto_seguro.build_request(context_data, codEMonitorAcao)
                if len(data) == 2:
                    data = (*data, '', '')

                return data

        # if (codEMonitorAcao >= ACAO_RONDON_INICIO) and (codEMonitorAcao <= ACAO_RONDON_FIM) and (not isAcaoArq(codEMonitorAcao)):
        #     req = req.encode(encoding='utf-8')
        if erros != '':
            return '', erros, '', ''

        # este caso somente ocorre no processamento de modulo completo,
        # onde pode ter alguns cadastros que nao serao feitos
        elif req == '' and codEMonitorAcao != tracker.ACAO_TRACKER_BUSCAULTIMAPOSICAO:
            return '', '', '', ''
        elif apenasGerarArq == 't':
            return req, '', '', ''
    else:
        try:
            if isAcaoBase64(codEMonitorAcao):
                req = base64.b64decode(req).decode('utf-8', errors="ignore")
                mapping = dict.fromkeys(range(32))
                req = req.translate(mapping)
        except Exception as e:
            raise OpCartaoException('Erro ao processar os dados recebidos')

    # enviar requisicao e aguardar resposta usando o certificado do cliente
    with pfx_to_pem(pfx_path, pfx_password) as cert:
        headers = {}
        if not isAcaoArq(codEMonitorAcao):
            headers['Content-type'] = getContentType(codEMonitorAcao) + 'charset=utf-8'
        if action != '':
            headers['SOAPAction'] = action
        if requestProperties != '':
            # PENDENTE requestProperties nao pode ter = e & como conteudo valido, pois sao separadores de campos
            if hasPreProcessRequestProperties(codEMonitorAcao):
                headers, erros = preProcessRequestProperties(cert, codEMonitorAcao, url, requestProperties, headers)
                if erros != '':
                    return '', erros, '', ''
            else:
                if processRequestProperties(codEMonitorAcao):
                    listProperties = list(requestProperties.split('&'))
                    for property in listProperties:
                        entry = property.split('=')
                        headers[entry[0]] = entry[1]
        url, requestMethod = preProcessURLRequestMethod(cert, codEMonitorAcao, url, requestMethod, headers, req,
                                                        reqAux, pfx_path, pfx_password, requestProperties)
        if url == '':
            # se der erro ao tentar preprocessar, url retorna vazia e requestMethod retorna o erro
            return '', requestMethod, '', ''
        try:
            if requestMethod and requestMethod.upper() == 'GET':
                resp = requests.get(url, cert=cert, data=req, headers=headers, timeout=READTIMEOUTWS)
            elif requestMethod and requestMethod.upper() == 'PATCH':
                resp = requests.patch(url, cert=cert, data=req, headers=headers, timeout=READTIMEOUTWS)
            elif requestMethod and requestMethod.upper() == 'PUT':
                resp = requests.put(url, cert=cert, data=req, headers=headers, timeout=READTIMEOUTWS)
            elif requestMethod and requestMethod.upper() == 'DELETE':
                resp = requests.delete(url, cert=cert, data=req, headers=headers, timeout=READTIMEOUTWS)
            else:
                if isAcaoArq(codEMonitorAcao):
                    resp = requests.post(url, cert=cert, data=req, headers=headers, timeout=READTIMEOUTWS, files=files)
                elif codEMonitorAcao == ACAO_AUTENTICA_BASIC_SEMVERIFCERT or \
                        ('e-nfs.com.br' in url) or ('api.centi.com.br' in url):
                    resp = requests.post(url, cert=cert, data=req, headers=headers, timeout=READTIMEOUTWS, verify=False)
                else:
                    resp = requests.post(url, cert=cert, data=req, headers=headers, timeout=READTIMEOUTWS)
        except requests.exceptions.ReadTimeout as e:
            raise OpCartaoException(
                ' Houve uma demora na resposta da OPERADORA!'
                ' Por favor aguarde 5 minutos, se o problema persistir,'
                ' entre em contato com o SUPORTE DA OPERADORA'
            )

        if (isAcaoArq(codEMonitorAcao) and (sigagr.SEND_DOCUMENT != codEMonitorAcao) and (not leadsfy.is_recognized_action(codEMonitorAcao))):
            for file in files:
                file[1].close()
        retcode = resp.status_code  # https://developer.mozilla.org/pt-BR/docs/Web/HTTP/Status

        if  codEMonitorAcao == repom.ADD_DOWNLOAD_PAYMENT_FILE:
            ret = base64.b64encode(resp.content)
        else:
            ret = resp.content.decode('utf-8')
        #
        if isAcaoJSON(codEMonitorAcao):
            arqreq = '/sistemas/emonitorpy/tmp/req' + str(codInstalacao) + '_' + str(codEmpresa) + '_' + str(
                codEMonitorAcao) + '.json'
            arqresp = '/sistemas/emonitorpy/tmp/resp' + str(codInstalacao) + '_' + str(codEmpresa) + '_' + str(
                codEMonitorAcao) + '.json'
        else:
            arqreq = '/sistemas/emonitorpy/tmp/req' + str(codInstalacao) + '_' + str(codEmpresa) + '_' + str(
                codEMonitorAcao) + '.xml'
            arqresp = '/sistemas/emonitorpy/tmp/resp' + str(codInstalacao) + '_' + str(codEmpresa) + '_' + str(
                codEMonitorAcao) + '.xml'
        #
        if nddcargo.is_recognized_action(codEMonitorAcao) or smartload.is_recognized_action(codEMonitorAcao) or senig.is_recognized_action(codEMonitorAcao) or angellira.is_recognized_action(codEMonitorAcao):
            strtofile(arqreq, escape(req))
        elif sisger.is_recognized_action(codEMonitorAcao) or porto_seguro.is_recognized_action(codEMonitorAcao) or leadsfy.is_recognized_action(codEMonitorAcao) or fretebrastrucker.is_recognized_action(codEMonitorAcao):
            strtofile(arqreq, str(req))
        elif isAcaoToProcess(codEMonitorAcao) and (not isAcaoArq(codEMonitorAcao)):
            strtofile(arqreq, req)
        else:
            strtofile(arqreq, str(req))
        if ret is None:
            ret = ''
        if codEMonitorAcao == repom.ADD_DOWNLOAD_PAYMENT_FILE:
            strtofile(arqresp, ret.decode('ascii'))
        elif x7bank.GET_INVOICES == codEMonitorAcao or x7bank.GET_TRAFFIC == codEMonitorAcao:
            strtofile(arqresp, escape(ret))
        else:
            strtofile(arqresp, ret)
        #
        if isAcaoToProcess(codEMonitorAcao):
            if (retcode == 401) and (
                    not (ACAO_SIGA_UPLOAD == codEMonitorAcao)
                    and not (profrota.is_recognized_action(codEMonitorAcao))
                    and not (uberlog.is_recognized_action(codEMonitorAcao))
                    and not (m3risk.is_recognized_action(codEMonitorAcao))
            ):
                return '', 'ACESSO NEGADO (PROVAVELMENTE DEVIDO A CREDENCIAIS INVÁLIDAS) À OPERADORA (401)', arqreq, arqresp
            elif retcode == 403 and not sisger.is_recognized_action(codEMonitorAcao) and not smartload.is_recognized_action(codEMonitorAcao):
                return '', 'ACESSO NEGADO (PROVAVELMENTE DEVIDO A ERRO DE CERTIFICADO) À OPERADORA (403)' + str(
                    headers), arqreq, arqresp
            elif retcode == 404:
                if ACAO_RODOBANK_INICIO <= codEMonitorAcao <= ACAO_RODOBANK_FIM:
                    return responseErrorRodobank(ret, arqreq, arqresp)
                else:
                    return '', 'INFORMAÇÃO NÃO ENCONTRADA NO ENDEREÇO ' + url + ' (404) ', arqreq, arqresp
            elif retcode == 500:
                if ACAO_EFRETE_INICIO <= codEMonitorAcao <= ACAO_EFRETE_FIM:
                    return responseEFreteErro500(req, ret, arqreq, arqresp)
                elif ACAO_TRIZY_ADDPEDIDO <= codEMonitorAcao <= ACAO_TRIZY_FIM:
                    return (*responseTrizy(req, ret), arqreq, arqresp)
                elif ACAO_RODOBANK_INICIO <= codEMonitorAcao <= ACAO_RODOBANK_FIM:
                    return responseErrorRodobank(ret, arqreq, arqresp)
                elif codEMonitorAcao == ACAO_CARGOBANK_PEDAGIO_CANCELARPEDAGIO:
                    return responseTratarErro500Cargobank(ret, arqreq, arqresp)
                elif ffgr.REQUEST_INSURANCE_PROFILE == codEMonitorAcao:
                    return (*processResponseOpCartao(cert, codEMonitorAcao, url, headers, req, ret, resp, reqAux,
                                                            requestProperties),  arqreq, arqresp)
                else:
                    return '', 'ERRO INTERNO DO SERVIDOR DA OPERADORA DE CARTÃO (500). URL:' + url, arqreq, arqresp
            else:
                resp2, erros2 = processResponseOpCartao(cert, codEMonitorAcao, url, headers, req, ret, resp, reqAux,
                                                        requestProperties)
                return resp2, erros2, arqreq, arqresp
        else:
            return ret, '', arqreq, arqresp


def isAcaoToProcess(codEMonitorAcao):
    return (codEMonitorAcao >= 1000 and codEMonitorAcao <= 5000)


def isAcaoNoProcess(codEMonitorAcao):
    return codEMonitorAcao >= ACAO_RONDON_INICIO and codEMonitorAcao < ACAO_RONDON_MOTORISTA_FOTO


def isAcaoArq(codEMonitorAcao):
    return (codEMonitorAcao == ACAO_RONDON_MOTORISTA_FOTO) or \
        (codEMonitorAcao == ACAO_RONDON_MOTORISTA_FOTOCNH) or \
        (codEMonitorAcao == sigagr.SEND_DOCUMENT) or \
        leadsfy.is_recognized_action(codEMonitorAcao)


def isAcaoBase64(codEMonitorAcao):
    return (codEMonitorAcao == ACAO_OPERADORACOMCHAVEPUB_ENVIODIRETOAPPJSONBASE64) or \
        (codEMonitorAcao == ACAO_OPERADORASEMCHAVEPUB_ENVIODIRETOAPPJSONBASE64) or \
        (codEMonitorAcao == ACAO_OPERADORACOMCHAVEPUB_ENVIODIRETOAPPXMLBASE64) or \
        (codEMonitorAcao == ACAO_OPERADORASEMCHAVEPUB_ENVIODIRETOAPPXMLBASE64)


def isAcaoJSON(codEMonitorAcao):
    return (codEMonitorAcao >= ACAO_REPOM_INICIO and codEMonitorAcao <= ACAO_REPOM_FIM) or \
        (codEMonitorAcao >= ACAO_PAGBEM_INICIO and codEMonitorAcao <= ACAO_PAGBEM_FIM) or \
        (codEMonitorAcao >= ACAO_EXTRATTA_INICIO and codEMonitorAcao <= ACAO_EXTRATTA_FIM) or \
        (codEMonitorAcao >= ACAO_TRANSSAT_INICIO and codEMonitorAcao <= ACAO_TRANSSAT_FIM) or \
        (codEMonitorAcao >= ACAO_EPTASGA_INICIO and codEMonitorAcao <= ACAO_EPTASGA_FIM) or \
        (codEMonitorAcao >= ACAO_TRIZY_ADDPEDIDO and codEMonitorAcao <= ACAO_TRIZY_FIM) or \
        (codEMonitorAcao >= ACAO_SIGA_INICIO and codEMonitorAcao <= ACAO_SIGA_FIM) or \
        (codEMonitorAcao >= ACAO_RONDON_INICIO and codEMonitorAcao <= ACAO_RONDON_FIM) or \
        (codEMonitorAcao >= ACAO_RODOBANK_INICIO and codEMonitorAcao <= ACAO_RODOBANK_FIM) or \
        (codEMonitorAcao >= ACAO_CARGOBANK_INICIO and codEMonitorAcao <= ACAO_CARGOBANK_FIM) or \
        (sigagr.is_recognized_action(codEMonitorAcao)) or \
        (codEMonitorAcao == ACAO_OPERADORASEMCHAVEPUB_ENVIODIRETOTEXTJSON) or \
        (codEMonitorAcao == ACAO_OPERADORACOMCHAVEPUB_ENVIODIRETOTEXTJSON) or \
        (codEMonitorAcao == ACAO_OPERADORASEMCHAVEPUB_ENVIODIRETOAPPJSON) or \
        (codEMonitorAcao == ACAO_OPERADORACOMCHAVEPUB_ENVIODIRETOAPPJSON) or \
        (codEMonitorAcao == ACAO_OPERADORACOMCHAVEPUB_ENVIODIRETOAPPJSONBASE64) or \
        (codEMonitorAcao == ACAO_OPERADORASEMCHAVEPUB_ENVIODIRETOAPPJSONBASE64) or \
        (m3risk.is_recognized_action(codEMonitorAcao)) or \
        (ffdigital.is_recognized_action(codEMonitorAcao)) or \
        (codEMonitorAcao == ACAO_OPERADORASEMCHAVEPUB_ENVIODIRETOAPPJSONBASE64) or \
        (sisger.is_recognized_action(codEMonitorAcao)) or \
        (ffcred.is_recognized_action(codEMonitorAcao))


def hasPreProcessRequestProperties(codEMonitorAcao):
    return (codEMonitorAcao >= ACAO_REPOM_INICIO and codEMonitorAcao <= ACAO_REPOM_FIM) or \
        (codEMonitorAcao >= ACAO_PAGBEM_INICIO and codEMonitorAcao <= ACAO_PAGBEM_FIM) or \
        (codEMonitorAcao >= ACAO_TRANSSAT_INICIO and codEMonitorAcao <= ACAO_TRANSSAT_FIM) or \
        (codEMonitorAcao >= ACAO_TRIZY_ADDPEDIDO and codEMonitorAcao <= ACAO_TRIZY_FIM) or \
        (codEMonitorAcao >= ACAO_AUTENTICA_BASIC_MD5) or \
        (codEMonitorAcao >= ACAO_RONDON_INICIO and codEMonitorAcao <= ACAO_RONDON_FIM) or \
        (codEMonitorAcao >= ACAO_RODOBANK_INICIO and codEMonitorAcao <= ACAO_RODOBANK_FIM) or \
        (codEMonitorAcao >= ACAO_CARGOBANK_INICIO and codEMonitorAcao <= ACAO_CARGOBANK_FIM) or \
        codEMonitorAcao == ACAO_AUTENTICA_BASIC_SEMVERIFCERT or \
        x7bank.is_recognized_action(codEMonitorAcao) or \
        tracker.is_recognized_action(codEMonitorAcao) or \
        m3risk.is_recognized_action(codEMonitorAcao) or \
        truckpag.is_recognized_action(codEMonitorAcao)


def processRequestProperties(codEMonitorAcao):
    return not ((codEMonitorAcao >= ACAO_RASTER_INICIO and codEMonitorAcao <= ACAO_RASTER_FIM) or
                (codEMonitorAcao >= ACAO_EPTASGA_INICIO and codEMonitorAcao <= ACAO_EPTASGA_FIM) or
                (codEMonitorAcao >= ACAO_SIGA_INICIO and codEMonitorAcao <= ACAO_SIGA_FIM) or
                (codEMonitorAcao >= ACAO_RODOBENS_INICIO and codEMonitorAcao <= ACAO_RODOBENS_FIM) or
                (codEMonitorAcao >= ACAO_RONDON_INICIO and codEMonitorAcao <= ACAO_RONDON_FIM))


def preProcessRequestPropertiesBasicMd5(headers, requestProperties):
    try:
        properties = {}
        if requestProperties != '':
            listProperties = list(requestProperties.split('&'))
            for prop in listProperties:
                entry = prop.split('=')
                properties[entry[0]] = entry[1]

            usuario = properties['usuario']
            senha = properties['senha']
            senhamd5 = encryptMd5(senha)

            headers['Authorization'] = 'Basic ' + base64.b64encode(
                bytes(f"{usuario}:{senhamd5}", "utf-8")
            ).decode("ascii")
    except Exception as e:
        raise OpCartaoException('Erro ao criar header de autorização: Basic')

    return headers, ''


def preProcessRequestProperties(cert, codEMonitorAcao, url, requestProperties, headers):
    # Usado pelas integrações baseadas na ActionProcessor (SigaGr)
    context_req = {
        'props': requestProperties,
        'url': url,
        'acao': codEMonitorAcao
    }

    if codEMonitorAcao >= ACAO_REPOM_INICIO and codEMonitorAcao <= ACAO_REPOM_FIM:
        return preProcessRequestPropertiesRepom(cert, codEMonitorAcao, url, requestProperties, headers)
    elif codEMonitorAcao >= ACAO_PAGBEM_INICIO and codEMonitorAcao <= ACAO_PAGBEM_FIM:
        return preProcessRequestPropertiesPagBem(cert, codEMonitorAcao, url, requestProperties, headers)
    elif codEMonitorAcao >= ACAO_TRANSSAT_INICIO and codEMonitorAcao <= ACAO_TRANSSAT_FIM:
        return preProcessRequestPropertiesTransSat(headers, requestProperties)
    # elif codEMonitorAcao >= ACAO_M3RISK_INICIO and codEMonitorAcao <= ACAO_M3RISK_FIM:
    # return preProcessRequestPropertiesM3risk(headers, requestProperties)
    elif codEMonitorAcao >= ACAO_TRIZY_ADDPEDIDO and codEMonitorAcao <= ACAO_TRIZY_FIM:
        return preProcessRequestPropertiesTrizy(headers, requestProperties)
    elif codEMonitorAcao in [ACAO_AUTENTICA_BASIC_MD5, ACAO_AUTENTICA_BASIC_SEMVERIFCERT]:
        return preProcessRequestPropertiesBasicMd5(headers, requestProperties)
    elif codEMonitorAcao >= ACAO_RONDON_INICIO and codEMonitorAcao <= 3213:  # verificar depois
        return preProcessRequestPropertiesRondon(headers, requestProperties)
    elif codEMonitorAcao >= ACAO_RODOBANK_INICIO and codEMonitorAcao <= ACAO_RODOBANK_FIM:
        return preProcessRequestPropertiesRodobank(headers, requestProperties)
    elif codEMonitorAcao >= ACAO_CARGOBANK_PEDAGIO_CRIARROTA and codEMonitorAcao <= ACAO_CARGOBANK_PEDAGIO_CANCELARPEDAGIO:
        return preProcessRequestPropertiesCargobank(headers, requestProperties)
    elif carguero.is_recognized_action(codEMonitorAcao):
        return carguero.get_headers(context_req)
    elif ciot_pag.is_recognized_action(codEMonitorAcao):
        return ciot_pag.get_headers(context_req)
    elif emprotege.is_recognized_action(codEMonitorAcao):
        return emprotege.get_headers(context_req)
    elif fretebras.is_recognized_action(codEMonitorAcao):
        return fretebras.get_headers(context_req, codEMonitorAcao)
    elif m3risk.is_recognized_action(codEMonitorAcao):
        return m3risk.get_headers(context_req)
    elif mytracking.is_recognized_action(codEMonitorAcao):
        return mytracking.get_headers(context_req)
    elif rondonline.is_recognized_action(codEMonitorAcao):
        return rondonline.get_headers(context_req)
    elif sigagr.is_recognized_action(codEMonitorAcao):
        return sigagr.get_headers(context_req, codEMonitorAcao)
    elif tracker.is_recognized_action(codEMonitorAcao):
        return tracker.get_headers(context_req)
    elif trafegus.is_recognized_action(codEMonitorAcao):
        return trafegus.get_headers(context_req)
    elif x7bank.is_recognized_action(codEMonitorAcao):
        return x7bank.get_headers(context_req)
    elif tipfrete.is_recognized_action(codEMonitorAcao):
        return tipfrete.get_headers()
    elif krona.is_recognized_action(codEMonitorAcao):
        return krona.get_headers(context_req)
    elif profrota.is_recognized_action(codEMonitorAcao):
        return profrota.get_headers(context_req)
    elif ffgr.is_recognized_action(codEMonitorAcao):
        return ffgr.get_headers()
    elif sisger.is_recognized_action(codEMonitorAcao):
        return sisger.get_headers(context_req)
    elif uberlog.is_recognized_action(codEMonitorAcao):
        return uberlog.get_headers(context_req)
    elif smartload.is_recognized_action(codEMonitorAcao):
        return smartload.get_headers(context_req)
    elif senig.is_recognized_action(codEMonitorAcao):
        return senig.get_headers(context_req)
    elif alltank.is_recognized_action(codEMonitorAcao):
        return alltank.get_headers(context_req)
    elif angellira.is_recognized_action(codEMonitorAcao):
        return angellira.get_headers(context_req)
    elif porto_seguro.is_recognized_action(codEMonitorAcao):
        return porto_seguro.get_headers(context_req)
    elif truckpag.is_recognized_action(codEMonitorAcao):
        return truckpag.get_headers(context_req)
    elif ffcred.is_recognized_action(codEMonitorAcao):
        return ffcred.get_headers(context_req)
    elif leadsfy.is_recognized_action(codEMonitorAcao):
        return leadsfy.get_headers(context_req)
    elif pozidigital.is_recognized_action(codEMonitorAcao):
        return pozidigital.get_headers(context_req)
    elif fretebrastrucker.is_recognized_action(codEMonitorAcao):
        return fretebrastrucker.get_headers(context_req)
    elif _efretehub.is_recognized_action(codEMonitorAcao):
        return _efretehub.get_headers(context_req)
    else:
        return headers, ''


def preProcessURLRequestMethod(cert, codEMonitorAcao, url, requestMethod, headers, req, reqAux, pfx_path, pfx_password,
                               requestProperties):
    # Usado pelas integrações baseadas na ActionProcessor
    context = {
        'url': url,
        'req': req,
        'props': requestProperties,
        'req_method': requestMethod
    }

    try:
        context['req'] = json.loads(reqAux)
    except (Exception,):
        context['req'] = {}

    # -------------------------------------------------------
    # acoes repom
    # -------------------------------------------------------
    if codEMonitorAcao == ACAO_REPOM_CONSULTARROTEIRO:
        url += requestRepomConsultarRoteiro(req)
        return url, 'GET'
    elif codEMonitorAcao == ACAO_REPOM_CONSULTARROTEIROINFORMADO:
        url += requestRepomConsultarRoteiroInformado(req)
        return url, 'GET'
    elif codEMonitorAcao == ACAO_REPOM_CONSULTARVALORPEDAGIO:
        url += requestRepomConsultarValorPedagio(req)
        return url, 'GET'
    elif codEMonitorAcao == ACAO_REPOM_CONSULTAROPERACOES:
        url += requestRepomConsultarOperacoes(req)
        return url, 'GET'
    elif codEMonitorAcao == ACAO_REPOM_ADICIONARMOVIMENTO:
        url += requestRepomUrlAdicionarMovimento(reqAux)
        return url, 'PATCH'
    elif codEMonitorAcao == ACAO_REPOM_ATUALIZARPROPRIETARIO:
        url += requestRepomUrlAtualizaProp(reqAux)
        return url, 'PUT'
    elif codEMonitorAcao == ACAO_REPOM_ATUALIZARMOTORISTA:
        url += requestRepomUrlAtualizaMot(reqAux)
        return url, 'PUT'
    elif codEMonitorAcao == ACAO_REPOM_ATUALIZARVEICULO:
        url += requestRepomUrlAtualizaVeic(reqAux, 'veic_')
        return url, 'PUT'
    elif codEMonitorAcao == ACAO_REPOM_ATUALIZARCARRETA1:
        url += requestRepomUrlAtualizaVeic(reqAux, 'car1_')
        return url, 'PUT'
    elif codEMonitorAcao == ACAO_REPOM_ATUALIZARCARRETA2:
        url += requestRepomUrlAtualizaVeic(reqAux, 'car2_')
        return url, 'PUT'
    elif codEMonitorAcao == ACAO_REPOM_ATUALIZARCARRETA3:
        url += requestRepomUrlAtualizaVeic(reqAux, 'car3_')
        return url, 'PUT'
    # elif codEMonitorAcao == ACAO_REPOM_PAGAMENTO_AUTORIZACAO:
    #     url += request_repom_url_pagamento_autorizacao(reqAux, '')
    #     return url, 'POST'
    # elif codEMonitorAcao == ACAO_REPOM_PAGAMENTO_AUTORIZACAO_CANCELAMENTO:
    #     url += request_repom_url_pagamento_autorizacao_cancelar(reqAux, '')
    #     return url, 'PATCH'
    # elif codEMonitorAcao == ACAO_REPOM_EMITIRCONTRATO:
    #     url += requestRepomUrlAtualizaContrato(reqAux)
    #     return url, 'POST'
    elif codEMonitorAcao == ACAO_REPOM_CANCELARCONTRATO or codEMonitorAcao == ACAO_REPOM_INTERROMPERCONTRATO:
        url, erro = preProcessURLRepom(cert, codEMonitorAcao, url, headers, req, 1)
        if erro == '':
            return url, 'PATCH'
        else:
            return '', erro
    # elif codEMonitorAcao == ACAO_REPOM_CONSULTARSTATUSCONTRATO:
    #     url += requestRepomConsultarStatusContrato(cert, codEMonitorAcao, url, headers, req)
    #     return url, 'GET'
    elif codEMonitorAcao == ACAO_REPOM_CONSULTARCONTRATO:
        url += requestRepomConsultarContrato(cert, codEMonitorAcao, url, headers, req)
        return url, 'GET'
    elif codEMonitorAcao == ACAO_REPOM_CONCILIACAO_CONTABIL_DATA:
        url += requestRepomConciliacaoContabilData(cert, codEMonitorAcao, url, headers, req)
        return url, 'GET'
    elif codEMonitorAcao == ACAO_REPOM_EMITE_FINANCEIRO_2:
        url += requestRepomEmiteFinanceiro(cert, codEMonitorAcao, url, headers, req)
        return url, 'GET'
    # Repom por meio da ActionProcessor
    elif repom.is_recognized_action(codEMonitorAcao, None, ['url']):
        return repom.dispatch(codEMonitorAcao, context, 'url')
    # -------------------------------------------------------
    # acoes pagbem
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_PAGBEM_CADASTRAR_CONTRATANTE or codEMonitorAcao == ACAO_PAGBEM_ENVIAR_RECALCULO_IMPOSTOS:
        url, erro = preProcessURLPagBem(cert, codEMonitorAcao, url, headers, reqAux, 1)
        if erro == '':
            return url, 'PUT'
        else:
            return '', erro
    elif codEMonitorAcao == ACAO_PAGBEM_RELATORIO_FINANCEIRO_DATA or codEMonitorAcao == ACAO_PAGBEM_CONCILIACAO_FINANCEIRA_DATA or codEMonitorAcao == ACAO_PAGBEM_CONSULTAR_ABASTECIMENTOS or codEMonitorAcao == ACAO_PAGBEM_BAIXAR_RECIBO_VALE_PEDAGIO:
        url, erro = preProcessURLPagBem(cert, codEMonitorAcao, url, headers, req, 1)
        if erro == '':
            return url, 'GET'
        else:
            return '', erro
    # -------------------------------------------------------
    # acoes SIGA
    # -------------------------------------------------------
    elif codEMonitorAcao > ACAO_SIGA_INICIO and codEMonitorAcao < ACAO_SIGA_FIM:
        url, erro, metodo = preProcessURLSiga(url, reqAux, requestProperties, pfx_path, pfx_password, codEMonitorAcao)
        if erro == '':
            return url, metodo
        else:
            return '', erro

    # --------------------------------------------------------
    # cargobank   ACAO_CARGOBANK_PEDAGIO_CANCELARPEDAGIO
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_CARGOBANK_PEDAGIO_CANCELARPEDAGIO:
        url, erro = preProcessUrlCargobank(url, reqAux)
        if erro == '':
            return url, 'POST'
        else:
            return '', erro

    # Carguero
    elif carguero.is_recognized_action(codEMonitorAcao):
        return carguero.dispatch(codEMonitorAcao, context, 'url')

    # CIOTPAG
    elif codEMonitorAcao >= ciot_pag.ACAO_CIOTPAG_CANCELAR_OPTRANSP and codEMonitorAcao <= ciot_pag.ACAO_CIOTPAG_RETIFICAR_OPTRANSP:
        return url, 'PUT'

    # EmProtege
    elif emprotege.is_recognized_action(codEMonitorAcao):
        return emprotege.dispatch(codEMonitorAcao, context, 'url')

    # FreteBras
    elif fretebras.is_recognized_action(codEMonitorAcao):
        return fretebras.dispatch(codEMonitorAcao, context, 'url')

    # M3Risk
    elif m3risk.is_recognized_action(codEMonitorAcao):
        return m3risk.dispatch(codEMonitorAcao, context, 'url')

    # MaxBot
    elif maxbot.is_recognized_action(codEMonitorAcao):
        return maxbot.get_url(), 'POST'

    # MyTracking
    elif mytracking.is_recognized_action(codEMonitorAcao):
        return mytracking.dispatch(codEMonitorAcao, context, 'url')

    # NddCargo
    elif nddcargo.is_recognized_action(codEMonitorAcao):
        return nddcargo.dispatch(codEMonitorAcao, context, 'url')

    # FFDigital
    elif ffdigital.is_recognized_action(codEMonitorAcao):
        return ffdigital.dispatch(codEMonitorAcao, context, 'url')

    # Polisoftware
    elif polisoftware.is_recognized_action(codEMonitorAcao):
        return polisoftware.dispatch(codEMonitorAcao, context, 'url')

    # Rondonline
    elif rondonline.is_recognized_action(codEMonitorAcao):
        return rondonline.dispatch(codEMonitorAcao, context, 'url')

    # SigaGr
    elif sigagr.is_recognized_action(codEMonitorAcao):
        return sigagr.dispatch(codEMonitorAcao, context, 'url')

    # TipFrete
    elif tipfrete.is_recognized_action(codEMonitorAcao):
        return tipfrete.dispatch(codEMonitorAcao, context, 'url')

    # Trafegus
    elif trafegus.is_recognized_action(codEMonitorAcao):
        return trafegus.dispatch(codEMonitorAcao, context, 'url')

    # CTASmart
    elif ctasmart.is_recognized_action(codEMonitorAcao):
        return ctasmart.dispatch(codEMonitorAcao, context, 'url')

    elif truckpag.is_recognized_action(codEMonitorAcao):
        return truckpag.dispatch(codEMonitorAcao, context, 'url')

    # Krona
    elif krona.is_recognized_action(codEMonitorAcao):
        return krona.dispatch(codEMonitorAcao, context, 'url')

    # ProFrota
    elif profrota.is_recognized_action(codEMonitorAcao):
        return profrota.dispatch(codEMonitorAcao, context, 'url')

    # FFGr
    elif ffgr.is_recognized_action(codEMonitorAcao):
        return ffgr.dispatch(codEMonitorAcao, context, 'url')

    # Sisger
    elif sisger.is_recognized_action(codEMonitorAcao):
        return sisger.dispatch(codEMonitorAcao, context, 'url')

    # UberLog
    elif uberlog.is_recognized_action(codEMonitorAcao):
        return uberlog.dispatch(codEMonitorAcao, context, 'url')

    # SmartLoag
    elif smartload.is_recognized_action(codEMonitorAcao):
        return smartload.dispatch(codEMonitorAcao, context, 'url')

    # Senig
    elif senig.is_recognized_action(codEMonitorAcao):
        return senig.dispatch(codEMonitorAcao, context, 'url')

    # AllTank
    elif alltank.is_recognized_action(codEMonitorAcao):
        return alltank.dispatch(codEMonitorAcao, context, 'url')

    # AlgelLira
    elif angellira.is_recognized_action(codEMonitorAcao):
        return angellira.dispatch(codEMonitorAcao, context, 'url')

    # Porto Seguro
    elif porto_seguro.is_recognized_action(codEMonitorAcao):
        return porto_seguro.dispatch(codEMonitorAcao, context, 'url')

    # FFCred
    elif ffcred.is_recognized_action(codEMonitorAcao):
        return ffcred.dispatch(codEMonitorAcao, context, 'url')

    # Leadsfy
    elif leadsfy.is_recognized_action(codEMonitorAcao):
        return leadsfy.dispatch(codEMonitorAcao, context, 'url')

    # Pozi Digital
    elif pozidigital.is_recognized_action(codEMonitorAcao):
        return pozidigital.dispatch(codEMonitorAcao, context, 'url')

    #FreteBras Trucker
    elif fretebrastrucker.is_recognized_action(codEMonitorAcao):
        return fretebrastrucker.dispatch(codEMonitorAcao, context, 'url')

    # Efrete Vale Pedagio
    elif _efretehub.is_recognized_action(codEMonitorAcao):
        return _efretehub.dispatch(codEMonitorAcao, context, 'url')

    # -------------------------------------------------------
    # default nao fazer nada
    # -------------------------------------------------------
    else:
        return url, requestMethod


def getContentType(codEMonitorAcao):
    # if isAcaoNoProcess(codEMonitorAcao):
    #     return 'application/x-www-form-urlencoded; '
    if isAcaoArq(codEMonitorAcao):
        return 'multipart/form-data;'
    elif isAcaoJSON(codEMonitorAcao):
        return 'application/json; '
    elif codEMonitorAcao == ACAO_OPERADORASEMCHAVEPUB_ENVIODIRETOAPPXML or codEMonitorAcao == ACAO_OPERADORACOMCHAVEPUB_ENVIODIRETOAPPXML:
        return 'application/xml; '
    else:
        return 'text/xml; '


def setURLTipoCadastro(codEMonitorAcao, url):
    # -------------------------------------------------------
    # acoes efrete
    # -------------------------------------------------------
    if codEMonitorAcao == ACAO_EFRETE_CADASTRARPROPRIETARIO:
        return url + 'ProprietariosService.asmx'
    elif codEMonitorAcao == ACAO_EFRETE_CADASTRARMOTORISTA:
        return url + 'MotoristasService.asmx'
    elif codEMonitorAcao == ACAO_EFRETE_CADASTRARVEICULO or \
            codEMonitorAcao == ACAO_EFRETE_CADASTRARCARRETA1 or \
            codEMonitorAcao == ACAO_EFRETE_CADASTRARCARRETA2 or \
            codEMonitorAcao == ACAO_EFRETE_CADASTRARCARRETA3:
        return url + 'VeiculosService.asmx'
    elif codEMonitorAcao == ACAO_EFRETE_CADASTRARCONHECIMENTO or \
            codEMonitorAcao == ACAO_EFRETE_OBTERPDFCONHECIMENTO or \
            codEMonitorAcao == ACAO_EFRETE_CANCELARCONHECIMENTO:
        return url + 'PefService.asmx'
    # -------------------------------------------------------
    # acoes pamcard
    # -------------------------------------------------------
    # -------------------------------------------------------
    # acoes repom
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_REPOM_CADASTRARPROPRIETARIO:
        return url + 'Hired'
    elif codEMonitorAcao == ACAO_REPOM_CADASTRARMOTORISTA:
        return url + 'Driver'
    elif codEMonitorAcao == ACAO_REPOM_CADASTRARVEICULO or \
            codEMonitorAcao == ACAO_REPOM_CADASTRARCARRETA1 or \
            codEMonitorAcao == ACAO_REPOM_CADASTRARCARRETA2 or \
            codEMonitorAcao == ACAO_REPOM_CADASTRARCARRETA3:
        return url + 'Vehicle'
    elif codEMonitorAcao == ACAO_REPOM_SOLICITARROTEIRO:
        return url + 'RouteRequest'
    elif codEMonitorAcao == ACAO_REPOM_EMITIRCONTRATO:
        return url + 'Shipping'
    elif codEMonitorAcao == ACAO_REPOM_QUITARCONTRATO:
        return url + 'ShippingPayment'
    elif codEMonitorAcao == ACAO_REPOM_EMITIRCONTRATOGRATUITO:
        return url + 'DeclareTransportOperation'
    # -------------------------------------------------------
    # acoes pagbem
    # -------------------------------------------------------
    # -------------------------------------------------------
    # acoes siga
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_SIGA_GERARTICKET:
        return url + 'ticket'
    elif codEMonitorAcao == ACAO_SIGA_UPLOAD:
        return url + 'upload'
    elif codEMonitorAcao == ACAO_SIGA_SOLICITARCONSULTA:
        return url + 'check'
    # -------------------------------------------------------
    # default nao fazer nada
    # -------------------------------------------------------
    else:
        return ''


def callEnvioOpCartaoModCompCiotPorAcao(pfx_path, pfx_password, codInstalacao, codEmpresa, codEMonitorAcao,
                                        apenasGerarArq, url, req, action, requestMethod, requestProperties):
    url = setURLTipoCadastro(codEMonitorAcao, url)  # pegar a URL especifica da acao
    return call_envio_opcartao(pfx_path, pfx_password, codInstalacao, codEmpresa, codEMonitorAcao, apenasGerarArq, url,
                               req, action, requestMethod, requestProperties)


@_handle_exception
def call_envio_opcartao_mod_comp_ciot(pfx_path, pfx_password, codInstalacao, codEmpresa, codEMonitorAcao,
                                      apenasGerarArq, url, req, action, requestMethod, requestProperties):
    temModComp = False
    arqreq = ''
    arqresp = ''
    #

    errosprop = ''
    errosmot = ''
    errosveic = ''
    erroscar1 = ''
    erroscar2 = ''
    erroscar3 = ''
    errosconh = ''
    respconh = ''

    if codEMonitorAcao == ACAO_EFRETE_GERARMODCOMPCIOT:
        temModComp = True
        respprop, errosprop, arqreq, arqresp = callEnvioOpCartaoModCompCiotPorAcao(
            pfx_path, pfx_password,
            codInstalacao, codEmpresa,
            ACAO_EFRETE_CADASTRARPROPRIETARIO,
            apenasGerarArq, url, req, action,
            requestMethod, requestProperties
        )
        respmot, errosmot, arqreq, arqresp = callEnvioOpCartaoModCompCiotPorAcao(
            pfx_path, pfx_password, codInstalacao,
            codEmpresa,
            ACAO_EFRETE_CADASTRARMOTORISTA,
            apenasGerarArq, url, req, action,
            requestMethod, requestProperties
        )
        respveic, errosveic, arqreq, arqresp = callEnvioOpCartaoModCompCiotPorAcao(
            pfx_path, pfx_password,
            codInstalacao, codEmpresa,
            ACAO_EFRETE_CADASTRARVEICULO,
            apenasGerarArq, url, req, action,
            requestMethod, requestProperties
        )
        respcar1, erroscar1, arqreq, arqresp = callEnvioOpCartaoModCompCiotPorAcao(
            pfx_path, pfx_password,
            codInstalacao, codEmpresa,
            ACAO_EFRETE_CADASTRARCARRETA1,
            apenasGerarArq, url, req, action,
            requestMethod, requestProperties
        )
        respcar2, erroscar2, arqreq, arqresp = callEnvioOpCartaoModCompCiotPorAcao(
            pfx_path, pfx_password,
            codInstalacao, codEmpresa,
            ACAO_EFRETE_CADASTRARCARRETA2,
            apenasGerarArq, url, req, action,
            requestMethod, requestProperties
        )
        respcar3, erroscar3, arqreq, arqresp = callEnvioOpCartaoModCompCiotPorAcao(
            pfx_path, pfx_password,
            codInstalacao, codEmpresa,
            ACAO_EFRETE_CADASTRARCARRETA3,
            apenasGerarArq, url, req, action,
            requestMethod, requestProperties
        )
        respconh, errosconh, arqreq, arqresp = callEnvioOpCartaoModCompCiotPorAcao(
            pfx_path, pfx_password,
            codInstalacao, codEmpresa,
            ACAO_EFRETE_CADASTRARCONHECIMENTO,
            apenasGerarArq, url, req, action,
            requestMethod, requestProperties
        )
    #
    elif codEMonitorAcao == ACAO_REPOM_GERARMODCOMPCIOT:
        temModComp = True
        respprop, errosprop, arqreq, arqresp = callEnvioOpCartaoModCompCiotPorAcao(
            pfx_path, pfx_password,
            codInstalacao, codEmpresa,
            ACAO_REPOM_CADASTRARPROPRIETARIO,
            apenasGerarArq, url, req, action,
            requestMethod, requestProperties
        )
        respmot, errosmot, arqreq, arqresp = callEnvioOpCartaoModCompCiotPorAcao(
            pfx_path, pfx_password, codInstalacao,
            codEmpresa,
            ACAO_REPOM_CADASTRARMOTORISTA,
            apenasGerarArq, url, req, action,
            requestMethod, requestProperties
        )
        respveic, errosveic, arqreq, arqresp = callEnvioOpCartaoModCompCiotPorAcao(
            pfx_path, pfx_password,
            codInstalacao, codEmpresa,
            ACAO_REPOM_CADASTRARVEICULO,
            apenasGerarArq, url, req, action,
            requestMethod, requestProperties
        )
        respcar1, erroscar1, arqreq, arqresp = callEnvioOpCartaoModCompCiotPorAcao(
            pfx_path, pfx_password,
            codInstalacao, codEmpresa,
            ACAO_REPOM_CADASTRARCARRETA1,
            apenasGerarArq, url, req, action,
            requestMethod, requestProperties
        )
        respcar2, erroscar2, arqreq, arqresp = callEnvioOpCartaoModCompCiotPorAcao(
            pfx_path, pfx_password,
            codInstalacao, codEmpresa,
            ACAO_REPOM_CADASTRARCARRETA2,
            apenasGerarArq, url, req, action,
            requestMethod, requestProperties
        )
        respcar3, erroscar3, arqreq, arqresp = callEnvioOpCartaoModCompCiotPorAcao(
            pfx_path, pfx_password,
            codInstalacao, codEmpresa,
            ACAO_REPOM_CADASTRARCARRETA3,
            apenasGerarArq, url, req, action,
            requestMethod, requestProperties
        )
        # respconh, errosconh, arqreq, arqresp = callEnvioOpCartaoModCompCiotPorAcao(pfx_path, pfx_password, codInstalacao, codEmpresa, ACAO_REPOM_EMITIRCONTRATO, apenasGerarArq, url, req, action, requestMethod, requestProperties)
        respconh, errosconh, arqreq, arqresp = '', 'DEU ERRO', '', ''
        #
    if temModComp:
        erros = ''
        gerouciot = True
        if errosprop != '':
            erros += '\nERRO PROP.: ' + errosprop
        if errosmot != '':
            erros += '\nERRO MOT.: ' + errosmot
        if errosveic != '':
            erros += '\nERRO VEIC.: ' + errosveic
        if erroscar1 != '':
            erros += '\nERRO CAR.1: ' + erroscar1
        if erroscar2 != '':
            erros += '\nERRO CAR.2: ' + erroscar2
        if erroscar3 != '':
            erros += '\nERRO CAR.3: ' + erroscar3
        if errosconh != '':
            gerouciot = False
            erros += '\nERRO CONH.: ' + errosconh
        if gerouciot:
            return respconh, '', arqreq, arqresp
        else:
            return '', erros, arqreq, arqresp
    else:
        return '', 'MÓDULO COMPLETO NÃO IMPLEMENTADO PARA ESTA OPERADORA DE CARTÃO', arqreq, arqresp


def processRequestOpCartao(codEMonitorAcao, req, requestProperties, pfx_path, pfx_password, url):
    try:
        req = req.replace('\\"', '"')
        reqJSON = ''
        if req:
            reqJSON = json.loads(req)

    except JSONDecodeError as ex:
        show_range = 20
        before_text = repr(ex.doc[max(ex.pos - show_range, 0): ex.pos]).strip("'")
        after_text = repr(ex.doc[ex.pos + 1:min(ex.pos + show_range + 1, len(ex.doc))]).strip("'")

        raise OpCartaoException(
            'Erro ao processar o JSON enviado ao EmonitorPy',
            f'A{codEMonitorAcao}: Erro ao ler o json. '
            f'Linha: {ex.lineno}, '
            f'Coluna: {ex.colno}, '
            f'Caractere: {ex.doc[ex.pos]}, ' +
            f'Trecho: {before_text}\033[1;97;41m{ex.doc[ex.pos]}\033[0;0m{after_text}'
        )

    context_data = {
        'req': reqJSON,
        'url': url,
        'props': requestProperties,
        'pfx_path': pfx_path,
        'pfx_password': pfx_password,
        'acao': codEMonitorAcao
    }

    try:
        pattern = re.compile(r'&(?=\w+=)')
        properties = {}
        if requestProperties != '':
            listProperties = list(pattern.split(requestProperties))
            for prop in listProperties:
                entry = prop.split('=')
                properties[entry[0]] = entry[1]
    except (Exception,):
        raise OpCartaoException('Erro ao processar as propriedades recebidas')

    ########################################################
    # OPERADORAS DE CARTAO
    ########################################################
    # -------------------------------------------------------
    # acoes efrete
    # -------------------------------------------------------
    if codEMonitorAcao == ACAO_EFRETE_CADASTRARPROPRIETARIO:
        return requestEFreteCadastrarProprietario(reqJSON)
    elif codEMonitorAcao == ACAO_EFRETE_CADASTRARMOTORISTA:
        return requestEFreteCadastrarMotorista(reqJSON)
    elif codEMonitorAcao == ACAO_EFRETE_CADASTRARVEICULO or \
            codEMonitorAcao == ACAO_EFRETE_CADASTRARCARRETA1 or \
            codEMonitorAcao == ACAO_EFRETE_CADASTRARCARRETA2 or \
            codEMonitorAcao == ACAO_EFRETE_CADASTRARCARRETA3:
        return requestEFreteCadastrarVeiculo(reqJSON, codEMonitorAcao)
    elif codEMonitorAcao == ACAO_EFRETE_CADASTRARCONHECIMENTO:
        return requestEFreteCadastrarConhecimento(reqJSON)
    elif codEMonitorAcao == ACAO_EFRETE_OBTERPDFCONHECIMENTO:
        return requestEFreteObterPdfConhecimento(reqJSON)
    elif codEMonitorAcao == ACAO_EFRETE_CANCELARCONHECIMENTO:
        return requestEFreteCancelarConhecimento(reqJSON)
    # -------------------------------------------------------
    # acoes pamcard
    # -------------------------------------------------------
    # -------------------------------------------------------
    # acoes repom
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_REPOM_CADASTRARPROPRIETARIO:
        return requestRepomCadastrarProprietario(reqJSON)
    elif codEMonitorAcao == ACAO_REPOM_CADASTRARMOTORISTA:
        return requestRepomCadastrarMotorista(reqJSON)
    elif codEMonitorAcao == ACAO_REPOM_CADASTRARVEICULO or \
            codEMonitorAcao == ACAO_REPOM_CADASTRARCARRETA1 or \
            codEMonitorAcao == ACAO_REPOM_CADASTRARCARRETA2 or \
            codEMonitorAcao == ACAO_REPOM_CADASTRARCARRETA3:
        return requestRepomCadastrarVeiculo(reqJSON, codEMonitorAcao)
    elif codEMonitorAcao == ACAO_REPOM_ATUALIZARVEICULO or \
            codEMonitorAcao == ACAO_REPOM_ATUALIZARCARRETA1 or \
            codEMonitorAcao == ACAO_REPOM_ATUALIZARCARRETA2 or \
            codEMonitorAcao == ACAO_REPOM_ATUALIZARCARRETA3:
        return requestRepomAtualizaVeiculo(reqJSON, codEMonitorAcao)
    elif codEMonitorAcao == ACAO_REPOM_ATUALIZARPROPRIETARIO:
        return requestRepomAtualizaProprietario(reqJSON)
    elif codEMonitorAcao == ACAO_REPOM_ATUALIZARMOTORISTA:
        return requestRepomAtualizaMotorista(reqJSON)
    elif codEMonitorAcao == ACAO_REPOM_SOLICITARROTEIRO:
        return requestRepomSolicitarRoteiro(reqJSON)
    elif codEMonitorAcao == ACAO_REPOM_EMITIRCONTRATO:
        return requestRepomEmitirContrato(reqJSON, url)
    elif codEMonitorAcao == ACAO_REPOM_QUITARCONTRATO:
        return requestRepomQuitarContrato(reqJSON)
    elif codEMonitorAcao == ACAO_REPOM_ADICIONARMOVIMENTO:
        return requestRepomAdicionarMovimento(reqJSON)
    elif codEMonitorAcao == ACAO_REPOM_EMITIRCONTRATOGRATUITO:
        return requestRepomEmitirContratoGratuito(reqJSON)
    # Repom por meio da ActionProcessor
    elif repom.is_recognized_action(codEMonitorAcao, None, ['url']):
        return repom.build_request(context_data, codEMonitorAcao)

    # -------------------------------------------------------
    # acoes target
    # -------------------------------------------------------
    # -------------------------------------------------------
    # acoes pagbem
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_PAGBEM_CADASTRAR_CONTRATANTE:
        return requestPagBemCadastrarProprietario(reqJSON)
    elif codEMonitorAcao == ACAO_PAGBEM_ENVIAR_RECALCULO_IMPOSTOS:
        return requestPagBemEnviarRecalculoImpostos(reqJSON)
    ########################################################
    # GERENCIADORAS DE RISCO
    ########################################################
    # -------------------------------------------------------
    # acoes rondon
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_RONDON_CADASTRARPROPRIETARIO:
        return requestRondonCadastrarProprietario(reqJSON)
    elif codEMonitorAcao == ACAO_RONDON_CADASTRARMOTORISTA:
        return requestRondonCadastrarMotorista(reqJSON)
    elif codEMonitorAcao == ACAO_RONDON_CADASTRARVEICULO or \
            codEMonitorAcao == ACAO_RONDON_CADASTRARCARRETA1 or \
            codEMonitorAcao == ACAO_RONDON_CADASTRARCARRETA2 or \
            codEMonitorAcao == ACAO_RONDON_CADASTRARCARRETA3:
        return requestRondonCadastrarVeiculo(reqJSON, codEMonitorAcao)
    elif codEMonitorAcao == ACAO_RONDON_MOTORISTA_FOTO:
        return requestRondonMotoristaFoto(reqJSON)
    elif codEMonitorAcao == ACAO_RONDON_MOTORISTA_FOTOCNH:
        return requestRondonMotoristaFotoCnh(reqJSON)
    # elif codEMonitorAcao == ACAO_RONDON_CADASTRARCONHECIMENTO:
    #     return requestRondonCadastrarConhecimento(reqJSON)
    # ----------------------------------------------------------
    # acoes EXTRATTA
    # ----------------------------------------------------------
    elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARPROPRIETARIO:
        return requestExtrattaCadastrarProprietario(reqJSON, properties)
    elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARVEICULO:
        return requestExtrattaCadastrarVeiculo(reqJSON, properties, codEMonitorAcao)
    elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARCARRETA1:
        return requestExtrattaCadastrarVeiculo(reqJSON, properties, codEMonitorAcao)
    elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARCARRETA2:
        return requestExtrattaCadastrarVeiculo(reqJSON, properties, codEMonitorAcao)
    elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARCARRETA3:
        return requestExtrattaCadastrarVeiculo(reqJSON, properties, codEMonitorAcao)
    elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARMOTORISTA:
        return requestExtrattaCadastrarMotorista(reqJSON, properties)
    elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARCLIENTE or \
            codEMonitorAcao == ACAO_EXTRATTA_CADASTRARREMETENTE or \
            codEMonitorAcao == ACAO_EXTRATTA_CADASTRARDESTINATARIO:
        return requestExtrattaCadastrarCliente(reqJSON, properties)
    elif codEMonitorAcao == ACAO_EXTRATTA_VINCULARCARTAOPROP:
        return requestExtrattaVincularCartaoProp(reqJSON, properties)
    elif codEMonitorAcao == ACAO_EXTRATTA_VINCULARCARTAOMOT:
        return requestExtrattaVincularCartaoMot(reqJSON, properties)
    elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARVIAGEM:
        return requestExtrattaCadastrarViagem(reqJSON, properties)
    elif codEMonitorAcao == ACAO_EXTRATTA_AJUSTEFINANCEIRO:
        return requestExtrattaAjusteFinanceiro(reqJSON, properties)
    elif codEMonitorAcao == ACAO_EXTRATTA_BAIXARVIAGEM:
        return requestExtrattaBaixarViagem(reqJSON, properties)
    elif codEMonitorAcao == ACAO_EXTRATTA_CANCELARVIAGEM:
        return requestExtrattaCancelarViagem(reqJSON, properties)
    elif codEMonitorAcao == ACAO_EXTRATTA_CONSULTAPEDAGIO:
        return requestExtrattaConsultaPedagio(reqJSON, properties)

    # -------------------------------------------------------
    # acoes RODOBANK
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_RODOBANK_CADASTRARPROPRIETARIO:
        return requestRodobankAddProp(reqJSON, properties)
    elif codEMonitorAcao == ACAO_RODOBANK_CADASTRARMOTORISTA:
        return requestRodobankAddMot(reqJSON, properties)
    elif codEMonitorAcao == ACAO_RODOBANK_CADASTRARVEICULO or \
            codEMonitorAcao == ACAO_RODOBANK_CADASTRARCARRETA1 or \
            codEMonitorAcao == ACAO_RODOBANK_CADASTRARCARRETA2 or \
            codEMonitorAcao == ACAO_RODOBANK_CADASTRARCARRETA3:
        return requestRodobankAddVeic(reqJSON, properties, codEMonitorAcao)
    elif codEMonitorAcao == ACAO_RODOBANK_INSERIR_ROTA:
        return requestRodobankInsertRoute(reqJSON, properties)
    elif codEMonitorAcao == ACAO_RODOBANK_CONSULTAR_ROTA:
        return requestRodobankGetRoute(reqJSON, properties)
    elif codEMonitorAcao == ACAO_RODOBANK_EMITE_CONTRATO:
        return requestRodobankNewContract(reqJSON, properties)
    elif codEMonitorAcao == ACAO_RODOBANK_OBTERCUSTO_ROTA:
        return requestRodobankObterCustoRota(reqJSON, properties)
    elif codEMonitorAcao == ACAO_RODOBANK_INTERROMPER_CONTRATO:
        return requestRodobankInterruptContract(reqJSON, properties)
    elif codEMonitorAcao == ACAO_RODOBANK_CANCELAR_CONTRATO:
        return requestRodobankCancelContract(reqJSON, properties)
    # -------------------------------------------------------
    # acoes GRLOG
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_GRLOG_CADASTRARMOTORISTA:
        return requestGrLogCadastrarMotorista(reqJSON, properties)
    elif codEMonitorAcao == ACAO_GRLOG_CADASTRARVEICULO:
        return requestGrLogCadastrarVeiculo(reqJSON, properties)
    elif codEMonitorAcao == ACAO_GRLOG_CONSULTARAPIDA:
        return requestGrLogConsultaRapida(reqJSON, properties)
    elif codEMonitorAcao == ACAO_GRLOG_PESQUISACONJUNTO:
        return requestGrLogPesquisaConjunto(reqJSON, properties)
    elif codEMonitorAcao == ACAO_GRLOG_CONSULTACONJUNTO:
        return requestGrLogConsultaConjunto(reqJSON, properties)
    elif codEMonitorAcao == ACAO_GRLOG_CADASTRARCARRETA or \
            codEMonitorAcao == ACAO_GRLOG_CADASTRARCARRETA2 or \
            codEMonitorAcao == ACAO_GRLOG_CADASTRARCARRETA3:
        return requestGrLogCadastrarCarreta(reqJSON, properties, codEMonitorAcao)
    elif codEMonitorAcao == ACAO_GRLOG_GET_TIPO_CARROCERIA:
        return requestGrLogGetTipoCarroceria()
    # -------------------------------------------------------
    # acoes RASTER
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_RASTER_GETCIDADES:
        return request_raster_get_cidades(reqJSON, properties)
    elif codEMonitorAcao == ACAO_RASTER_SETCONJUNTO:
        return request_raster_set_conjunto(reqJSON, properties)
    elif codEMonitorAcao == ACAO_RASTER_SETSOLICITACAOPESQUISACONSULTA:
        return request_raster_set_solicitacao_pesquisa_consulta(reqJSON, properties)
    elif codEMonitorAcao == ACAO_RASTER_GETRESULTADOPESQUISACONSULTA:
        return request_raster_get_resultado_pesquisa_consulta(reqJSON, properties)
    elif codEMonitorAcao == ACAO_RASTER_GETDOCUMENTOPESQUISACONSULTA:
        return request_raster_get_documento_pesquisa_consulta(reqJSON, properties)
    elif codEMonitorAcao == ACAO_RASTER_SETSOLICITACAOPESQUISACONSULTACONJUNTO:
        return request_raster_set_solicitacao_pesquisa_consulta_conjunto(reqJSON, properties)
    elif codEMonitorAcao == ACAO_RASTER_GETRESULTADOPESQUISACONSULTACONJUNTO:
        return request_raster_get_resultado_pesquisa_consulta_conjunto(reqJSON, properties)
    elif raster.is_recognized_action(codEMonitorAcao):
        return raster.build_request(context_data, codEMonitorAcao)
    # -------------------------------------------------------
    # acoes TRANSSAT
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_TRANSSAT_SOLICITAR_MONITORAMENTO:
        return requestTransSatSolMonitoramento(reqJSON)
    # -------------------------------------------------------
    # acoes EPTASGA
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_EPTASGA_OBTERABASTECIMENTOS:
        return requestEptaSgaObterAbastecimentos(reqJSON, properties)
    # -------------------------------------------------------
    # acoes RODOBENS
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_RODOBENS_CADASTRARVEICULO:
        return requestRodobensSalvaVeiculo(reqJSON, properties)
    elif codEMonitorAcao == ACAO_RODOBENS_CADASTRARPROPRIETARIO \
            or codEMonitorAcao == ACAO_RODOBENS_CADASTRARMOTORISTA:
        return requestRodobensCadastrarPessoa(reqJSON, properties, codEMonitorAcao)
    elif codEMonitorAcao == ACAO_RODOBENS_SOLICITARMONITORAMENTO:
        return requestRodobensSalvaSM(reqJSON, properties)
    # -------------------------------------------------------
    # acoes serasa
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_SERASA_CONSULTARPF or codEMonitorAcao == ACAO_SERASA_CONSULTARPJ:
        return requestSerasaConsultarPessoa(reqJSON, codEMonitorAcao)
    # -------------------------------------------------------
    # acoes m3risk
    # -------------------------------------------------------
    # elif m3risk.recognize_request(codEMonitorAcao):
    #    return m3risk.build_request(context_data, codEMonitorAcao)
    # -------------------------------------------------------
    # acoes MaxBot
    # -------------------------------------------------------
    elif maxbot.is_recognized_action(codEMonitorAcao):
        return maxbot.build_request(context_data, codEMonitorAcao)
    # --------------------------------------------------------
    # acao trizy
    # --------------------------------------------------------
    elif codEMonitorAcao == ACAO_TRIZY_ADDPEDIDO:
        return requestTrizyAddPedido(reqJSON)
    elif codEMonitorAcao == ACAO_TRIZY_ADDPROP:
        return requestTrizyAddProp(reqJSON)
    elif codEMonitorAcao == ACAO_TRIZY_ADDMOT:
        return requestTrizyAddMot(reqJSON)
    elif codEMonitorAcao == ACAO_TRIZY_ADD_PROPMOTVEIC:
        return requestTrizyAddCredenciamento(reqJSON)
    elif codEMonitorAcao == ACAO_TRIZY_SENDCONHEC or codEMonitorAcao == ACAO_TRIZY_SENDMANIF:
        return requestTrizyAddComprovante(reqJSON, url, requestProperties)
    elif codEMonitorAcao == ACAO_TRIZY_SEND_ORDEMCAR:
        return requestTrizyAddAcordo(reqJSON, url, requestProperties)
    elif codEMonitorAcao == ACAO_TRIZY_GET_PROPMOTVEIC:
        return requestTrizyGetCredenciamento(reqJSON)
    elif codEMonitorAcao == ACAO_TRIZY_GET_COMPROVANTES:
        return requestGetComprovantes(reqJSON)
    elif codEMonitorAcao == ACAO_TRIZY_GET_VIAGEMFINALIZADA:
        return requestGetViagemFinalizada(reqJSON)
    elif codEMonitorAcao == ACAO_TRIZY_CANC_ORDEMCAR:
        return requestTrizyCancelaAcordo(reqJSON)
    elif codEMonitorAcao == ACAO_TRIZY_CANC_PEDIDO:
        return requestTrizyCancelaPedido(reqJSON)
    elif codEMonitorAcao == ACAO_TRIZY_SEND_COMPROVANTE:
        return getJsonTrizyAddPDF(reqJSON)
    elif codEMonitorAcao == ACAO_TRIZY_SEND_IMAGENS:
        return get_json_trizy_send_imagem(reqJSON, url, requestProperties)
    elif codEMonitorAcao == ACAO_TRIZY_GET_MOT_IMGS:
        return getJsonTrizyGetMotImgs(reqJSON)

    # ----------------------------------------------------------
    # acoes cargobank
    # ----------------------------------------------------------
    elif codEMonitorAcao == ACAO_CARGOBANK_EMITE_CIOT:
        return requestCargobank_GerarCiot(reqJSON, properties)
    elif codEMonitorAcao == ACAO_CARGOBANK_CANCELAR_CIOT:
        return requestCargobank_CancelarCiot(reqJSON, properties)
    elif codEMonitorAcao == ACAO_CARGOBANK_FINALIZAR_CIOT:
        return requestCargobank_FinalizarCiot(reqJSON, properties)
    elif codEMonitorAcao == ACAO_CARGOBANK_QUITAR_CIOT:
        return requestCargobank_QuitarCiot(reqJSON, properties)
    elif codEMonitorAcao == ACAO_CARGOBANK_PEDAGIO_CRIARROTA:
        return requestCargobank_CriarRota(reqJSON)
    elif codEMonitorAcao == ACAO_CARGOBANK_PEDAGIO_CONSULTARVALORROTA:
        return requestCargobank_ConsultaValorRota(reqJSON)
    elif codEMonitorAcao == ACAO_CARGOBANK_PEDAGIO_EMITIRPEDAGIO:
        return requestCargobank_EmitirPedagio(reqJSON)
    elif codEMonitorAcao == ACAO_CARGOBANK_PEDAGIO_CANCELARPEDAGIO:
        return requestCargobank_CancelarPedagio(reqJSON)

    # --------------------------------------------------------
    # acoes siga
    # --------------------------------------------------------
    elif codEMonitorAcao == ACAO_SIGA_GERARTICKET:
        return requestSigaGerarTicket(reqJSON, properties, pfx_path, pfx_password, url)
    elif codEMonitorAcao == ACAO_SIGA_UPLOAD:
        return requestSigaUpload(reqJSON, properties, pfx_path, pfx_password, url)
    elif codEMonitorAcao == ACAO_SIGA_SOLICITARCONSULTA:
        return requestSigaSolicitarConsulta(reqJSON, properties, pfx_path, pfx_password, url)

    # Carguero
    elif carguero.is_recognized_action(codEMonitorAcao):
        return carguero.build_request(context_data, codEMonitorAcao)

    # acoes ciotpag
    elif ciot_pag.is_recognized_action(codEMonitorAcao):
        return ciot_pag.build_request(context_data, codEMonitorAcao)

    # EmProtege
    elif emprotege.is_recognized_action(codEMonitorAcao):
        return emprotege.build_request(context_data, codEMonitorAcao)

    # FreteBras
    elif fretebras.is_recognized_action(codEMonitorAcao):
        return fretebras.build_request(context_data, codEMonitorAcao)

    # M3Risk
    elif m3risk.is_recognized_action(codEMonitorAcao):
        return m3risk.build_request(context_data, codEMonitorAcao)

    # MyTracking
    elif mytracking.is_recognized_action(codEMonitorAcao):
        return mytracking.build_request(context_data, codEMonitorAcao)

    # NddCargo
    elif nddcargo.is_recognized_action(codEMonitorAcao):
        return nddcargo.build_request(context_data, codEMonitorAcao)

    # FFDigital
    elif ffdigital.is_recognized_action(codEMonitorAcao):
        return ffdigital.build_request(context_data, codEMonitorAcao)

    # Polisoftware
    elif polisoftware.is_recognized_action(codEMonitorAcao):
        return polisoftware.build_request(context_data, codEMonitorAcao)

    # Rondonline
    elif rondonline.is_recognized_action(codEMonitorAcao):
        return rondonline.build_request(context_data, codEMonitorAcao)

    # SigaSr
    elif sigagr.is_recognized_action(codEMonitorAcao):
        return sigagr.build_request(context_data, codEMonitorAcao)

    # Tracker
    elif tracker.is_recognized_action(codEMonitorAcao):
        return tracker.build_request(context_data, codEMonitorAcao)

    # Trafegus
    elif trafegus.is_recognized_action(codEMonitorAcao):
        return trafegus.build_request(context_data, codEMonitorAcao)

    # TipFrete
    elif tipfrete.is_recognized_action(codEMonitorAcao):
        return tipfrete.build_request(context_data, codEMonitorAcao)

    # X7bank
    elif x7bank.is_recognized_action(codEMonitorAcao):
        return x7bank.build_request(context_data, codEMonitorAcao)

    # CTASmart
    elif ctasmart.is_recognized_action(codEMonitorAcao):
        return ctasmart.build_request(context_data, codEMonitorAcao)

    # TruckPag
    elif truckpag.is_recognized_action(codEMonitorAcao):
        return truckpag.build_request(context_data, codEMonitorAcao)

    # Krona
    elif krona.is_recognized_action(codEMonitorAcao):
        return krona.build_request(context_data, codEMonitorAcao)

    # ProFrota
    elif profrota.is_recognized_action(codEMonitorAcao):
        return profrota.build_request(context_data, codEMonitorAcao)

    # FFGr
    elif ffgr.is_recognized_action(codEMonitorAcao):
        return ffgr.build_request(context_data, codEMonitorAcao)

    # Sisger
    elif sisger.is_recognized_action(codEMonitorAcao):
        return sisger.build_request(context_data, codEMonitorAcao)

    # UberLog
    elif uberlog.is_recognized_action(codEMonitorAcao):
        return uberlog.build_request(context_data, codEMonitorAcao)

    # SmartLoad
    elif smartload.is_recognized_action(codEMonitorAcao):
        return smartload.build_request(context_data, codEMonitorAcao)

    # Senig
    elif senig.is_recognized_action(codEMonitorAcao):
        return senig.build_request(context_data, codEMonitorAcao)

    # AllTank
    elif alltank.is_recognized_action(codEMonitorAcao):
        return alltank.build_request(context_data, codEMonitorAcao)

    # AngelLira
    elif angellira.is_recognized_action(codEMonitorAcao):
        return angellira.build_request(context_data, codEMonitorAcao)

    # Porto Seguro
    elif porto_seguro.is_recognized_action(codEMonitorAcao):
        return porto_seguro.build_request(context_data, codEMonitorAcao)

    # FFCred
    elif ffcred.is_recognized_action(codEMonitorAcao):
        return ffcred.build_request(context_data, codEMonitorAcao)

    # Leadsfy
    elif leadsfy.is_recognized_action(codEMonitorAcao):
        return leadsfy.build_request(context_data, codEMonitorAcao)

    # Pozi Digital
    elif pozidigital.is_recognized_action(codEMonitorAcao):
        return pozidigital.build_request(context_data, codEMonitorAcao)

    # FreteBras Trucker
    elif fretebrastrucker.is_recognized_action(codEMonitorAcao):
        return fretebrastrucker.build_request(context_data, codEMonitorAcao)

    # Efrete Vale Pedagio
    elif _efretehub.is_recognized_action(codEMonitorAcao):
        return _efretehub.build_request(context_data, codEMonitorAcao)
    # -------------------------------------------------------
    # retornar req apenas para processar acoes do tipo GET
    # -------------------------------------------------------
    return req, ''


def processResponseOpCartao(cert, codEMonitorAcao, url, headers, req, ret, resp, reqAux, requestProperties):
    # Usado pelas integrações baseadas na ActionProcessor
    context_resp = {
        'req': req,
        'req_in': reqAux,
        'resp': resp,
        'url': url,
        'acao': codEMonitorAcao,
        'props': requestProperties
    }
    ########################################################
    # OPERADORAS DE CARTAO
    ########################################################
    # -------------------------------------------------------
    # acoes efrete
    # -------------------------------------------------------
    if codEMonitorAcao == ACAO_EFRETE_CADASTRARPROPRIETARIO:
        return responseEFreteCadastrarProprietario(ret)
    elif codEMonitorAcao == ACAO_EFRETE_CADASTRARMOTORISTA:
        return responseEFreteCadastrarMotorista(ret)
    elif codEMonitorAcao == ACAO_EFRETE_CADASTRARVEICULO or \
            codEMonitorAcao == ACAO_EFRETE_CADASTRARCARRETA1 or \
            codEMonitorAcao == ACAO_EFRETE_CADASTRARCARRETA2 or \
            codEMonitorAcao == ACAO_EFRETE_CADASTRARCARRETA3:
        return responseEFreteCadastrarVeiculo(ret)
    elif codEMonitorAcao == ACAO_EFRETE_CADASTRARCONHECIMENTO:
        return responseEFreteCadastrarConhecimento(ret)
    elif codEMonitorAcao == ACAO_EFRETE_OBTERPDFCONHECIMENTO:
        return responseEFreteObterPdfConhecimento(ret)
    elif codEMonitorAcao == ACAO_EFRETE_CANCELARCONHECIMENTO:
        return responseEFreteCancelarConhecimento(ret)
    # -------------------------------------------------------
    # acoes pamcard
    # -------------------------------------------------------
    # -------------------------------------------------------
    # acoes repom
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_REPOM_CADASTRARPROPRIETARIO:
        return responseRepomCadastrarProprietario(resp)
    elif codEMonitorAcao == ACAO_REPOM_CADASTRARMOTORISTA:
        return responseRepomCadastrarMotorista(resp)
    elif codEMonitorAcao == ACAO_REPOM_CADASTRARVEICULO or \
            codEMonitorAcao == ACAO_REPOM_CADASTRARCARRETA1 or \
            codEMonitorAcao == ACAO_REPOM_CADASTRARCARRETA2 or \
            codEMonitorAcao == ACAO_REPOM_CADASTRARCARRETA3:
        return responseRepomCadastrarVeiculo(resp)
    elif codEMonitorAcao == ACAO_REPOM_ATUALIZARVEICULO or \
            codEMonitorAcao == ACAO_REPOM_ATUALIZARCARRETA1 or \
            codEMonitorAcao == ACAO_REPOM_ATUALIZARCARRETA2 or \
            codEMonitorAcao == ACAO_REPOM_ATUALIZARCARRETA3:
        return responseRepomCadastrarVeiculo(resp)
    elif codEMonitorAcao == ACAO_REPOM_CONSULTARROTEIRO:
        return responseRepomConsultarRoteiro(resp)
    elif codEMonitorAcao == ACAO_REPOM_CONSULTARROTEIROINFORMADO:
        return responseRepomConsultarRoteiroInformado(resp)
    elif codEMonitorAcao == ACAO_REPOM_SOLICITARROTEIRO:
        return responseRepomSolicitarRoteiro(resp)
    elif codEMonitorAcao == ACAO_REPOM_CONSULTARVALORPEDAGIO:
        return responseRepomConsultarValorPedagio(resp)
    elif codEMonitorAcao == ACAO_REPOM_CONSULTAROPERACOES:
        return responseRepomConsultarOperacoes(resp)
    elif codEMonitorAcao == ACAO_REPOM_EMITIRCONTRATO:
        return responseRepomEmitirContrato(resp, cert, url, headers, req)
    elif codEMonitorAcao == ACAO_REPOM_QUITARCONTRATO:
        return responseRepomQuitarContrato(resp)
    elif codEMonitorAcao == ACAO_REPOM_CANCELARCONTRATO:
        return responseRepomCancelarContrato(resp)
    elif codEMonitorAcao == ACAO_REPOM_INTERROMPERCONTRATO:
        return responseRepomInterromperContrato(resp)
    elif codEMonitorAcao == ACAO_REPOM_CONSULTARCONTRATO:
        return responseRepomConsultarContrato(resp)
    elif codEMonitorAcao == ACAO_REPOM_CONCILIACAO_CONTABIL_DATA:
        return responseRepomConciliacaoContabilData(resp)
    elif codEMonitorAcao == ACAO_REPOM_EMITE_FINANCEIRO_2:
        return responseRepomEmiteFinanceiro(resp)
    elif codEMonitorAcao == ACAO_REPOM_ADICIONARMOVIMENTO:
        return responseRepomAdicionarMovimento(resp)
    elif codEMonitorAcao == ACAO_REPOM_EMITIRCONTRATOGRATUITO:
        return responseRepomEmitirContratoGratuito(resp, cert, url, headers, req)
    elif codEMonitorAcao == ACAO_REPOM_ATUALIZARPROPRIETARIO:
        return responseRepomAtualizaProp(resp)
    elif codEMonitorAcao == ACAO_REPOM_ATUALIZARMOTORISTA:
        return responseRepomAtualizaMot(resp)
    # Repom por meio da ActionProcessor
    elif repom.is_recognized_action(codEMonitorAcao, None, ['url']):
        return repom.parse_response(context_resp, codEMonitorAcao)
    # -------------------------------------------------------
    # acoes target
    # -------------------------------------------------------
    # -------------------------------------------------------
    # acoes pagbem
    elif codEMonitorAcao == ACAO_PAGBEM_CADASTRAR_CONTRATANTE:
        return responsePagBemCadastrarProprietario(resp)
    elif codEMonitorAcao == ACAO_PAGBEM_RELATORIO_FINANCEIRO_DATA:
        return responsePagBemRelatorioFinanceiroData(resp, req)
    elif codEMonitorAcao == ACAO_PAGBEM_CONCILIACAO_FINANCEIRA_DATA:
        return responsePagBemConciliacaoFinanceiraData(resp, req)
    elif codEMonitorAcao == ACAO_PAGBEM_CONSULTAR_ABASTECIMENTOS:
        return responsePagBemConsultarAbastecimento(resp)
    elif codEMonitorAcao == ACAO_PAGBEM_ENVIAR_RECALCULO_IMPOSTOS:
        return responsePagBemEnviarRecalculoImpostos(resp)
    elif codEMonitorAcao == ACAO_PAGBEM_BAIXAR_RECIBO_VALE_PEDAGIO:
        return response_pag_bem_baixar_recibo_vale_pedagio(resp)
    # ----------------------------------------------------------
    # acoes EXTRATTA
    # ----------------------------------------------------------
    elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARPROPRIETARIO:
        return responseExtrattaCadastrarProprietario(resp)
    elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARVEICULO or \
            codEMonitorAcao == ACAO_EXTRATTA_CADASTRARCARRETA1 or \
            codEMonitorAcao == ACAO_EXTRATTA_CADASTRARCARRETA2 or \
            codEMonitorAcao == ACAO_EXTRATTA_CADASTRARCARRETA3:
        return responseExtrattaCadastrarVeiculo(resp, codEMonitorAcao)
    elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARMOTORISTA:
        return responseExtrattaCadastrarMotorista(resp)
    elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARCLIENTE or \
            codEMonitorAcao == ACAO_EXTRATTA_CADASTRARREMETENTE or \
            codEMonitorAcao == ACAO_EXTRATTA_CADASTRARDESTINATARIO:
        return responseExtrattaCadastrarCliente(resp)
    elif codEMonitorAcao == ACAO_EXTRATTA_VINCULARCARTAOPROP:
        return responseExtrattaVincularCartaoProp(resp)
    elif codEMonitorAcao == ACAO_EXTRATTA_VINCULARCARTAOMOT:
        return responseExtrattaVincularCartaoMot(resp)
    elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARVIAGEM:
        return responseExtrattaCadastrarViagem(resp)
    elif codEMonitorAcao == ACAO_EXTRATTA_AJUSTEFINANCEIRO:
        return responseExtrattaAjusteFinanceiro(resp)
    elif codEMonitorAcao == ACAO_EXTRATTA_BAIXARVIAGEM:
        return responseExtrattaBaixarViagem(resp)
    elif codEMonitorAcao == ACAO_EXTRATTA_CANCELARVIAGEM:
        return responseExtrattaCancelarViagem(resp)
    elif codEMonitorAcao == ACAO_EXTRATTA_CONSULTAPEDAGIO:
        return responseExtrattaConsultaPedagio(resp)

    # -------------------------------------------------------
    #  Rodobank
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_RODOBANK_CADASTRARPROPRIETARIO or \
            codEMonitorAcao == ACAO_RODOBANK_CADASTRARMOTORISTA or \
            codEMonitorAcao == ACAO_RODOBANK_CADASTRARVEICULO or \
            codEMonitorAcao == ACAO_RODOBANK_CADASTRARCARRETA1 or \
            codEMonitorAcao == ACAO_RODOBANK_CADASTRARCARRETA2 or \
            codEMonitorAcao == ACAO_RODOBANK_CADASTRARCARRETA3 or \
            codEMonitorAcao == ACAO_RODOBANK_CANCELAR_CONTRATO:
        return responseRondobankCadastros(ret, codEMonitorAcao)
    elif codEMonitorAcao == ACAO_RODOBANK_INSERIR_ROTA or \
            codEMonitorAcao == ACAO_RODOBANK_CONSULTAR_ROTA:
        return responseRodobankInserirRota(ret)
    elif codEMonitorAcao == ACAO_RODOBANK_OBTERCUSTO_ROTA:
        return responseRodobankObterCustoRota(ret)
    elif codEMonitorAcao == ACAO_RODOBANK_EMITE_CONTRATO:
        return responseRodobankNewContract(ret)

    ########################################################
    # GERENCIADORAS DE RISCO
    ########################################################
    # -------------------------------------------------------
    # acoes rondon
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_RONDON_CADASTRARPROPRIETARIO:
        return responseRondonCadastrarProprietario(resp)
    elif codEMonitorAcao == ACAO_RONDON_CADASTRARMOTORISTA:
        return responseRondonCadastrarMotorista(resp)
    elif codEMonitorAcao == ACAO_RONDON_CADASTRARVEICULO or \
            codEMonitorAcao == ACAO_RONDON_CADASTRARCARRETA1 or \
            codEMonitorAcao == ACAO_RONDON_CADASTRARCARRETA2 or \
            codEMonitorAcao == ACAO_RONDON_CADASTRARCARRETA3:
        return responseRondonCadastrarVeiculo(resp)
    elif codEMonitorAcao == ACAO_RONDON_MOTORISTA_FOTO or \
            codEMonitorAcao == ACAO_RONDON_MOTORISTA_FOTOCNH:
        return responseRondonMotoristaFoto(resp)
    # elif codEMonitorAcao == ACAO_RONDON_MOTORISTA_FOTOCNH:
    #     return responseRondonMotoristaCnh(resp)
    # elif codEMonitorAcao == ACAO_RONDON_CADASTRARCONHECIMENTO:
    #    return responseRondonCadastrarConhecimento(resp)
    # -------------------------------------------------------
    # acoes grlog
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_GRLOG_CADASTRARMOTORISTA:
        return responseGrLogCadastrarMotorista(ret)
    elif codEMonitorAcao == ACAO_GRLOG_CADASTRARVEICULO:
        return responseGrLogCadastrarVeiculo(ret)
    elif codEMonitorAcao == ACAO_GRLOG_CONSULTARAPIDA:
        return responseGrLogConsultaRapida(ret)
    elif codEMonitorAcao == ACAO_GRLOG_PESQUISACONJUNTO:
        return responseGrLogPesquisaConjunto(ret)
    elif codEMonitorAcao == ACAO_GRLOG_CONSULTACONJUNTO:
        return responseGrLogConsultaConjunto(ret)
    elif codEMonitorAcao == ACAO_GRLOG_CADASTRARCARRETA or \
            codEMonitorAcao == ACAO_GRLOG_CADASTRARCARRETA2 or \
            codEMonitorAcao == ACAO_GRLOG_CADASTRARCARRETA3:
        return responseGrLogCadastrarCarreta(ret, codEMonitorAcao)
    elif codEMonitorAcao == ACAO_GRLOG_GET_TIPO_CARROCERIA:
        return responseGrLogGetTipoCarroceria(ret)
    # -------------------------------------------------------
    # acoes raster
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_RASTER_SETCONJUNTO:
        return response_raster_set_conjunto(resp)
    elif codEMonitorAcao == ACAO_RASTER_SETSOLICITACAOPESQUISACONSULTA:
        return response_raster_set_solicitacao_pesquisa_consulta(resp)
    elif codEMonitorAcao == ACAO_RASTER_GETRESULTADOPESQUISACONSULTA:
        return response_raster_get_resultado_pesquisa_consulta(resp)
    elif codEMonitorAcao == ACAO_RASTER_GETDOCUMENTOPESQUISACONSULTA:
        return response_raster_get_documento_pesquisa_consulta(resp)
    elif codEMonitorAcao == ACAO_RASTER_SETSOLICITACAOPESQUISACONSULTACONJUNTO:
        return response_raster_set_solicitacao_pesquisa_consulta_conjunto(resp)
    elif codEMonitorAcao == ACAO_RASTER_GETRESULTADOPESQUISACONSULTACONJUNTO:
        return response_raster_get_resultado_pesquisa_consulta_conjunto(resp)
    elif raster.is_recognized_action(codEMonitorAcao):
        return raster.parse_response(context_resp, codEMonitorAcao)
    # -------------------------------------------------------
    # acoes EPTASGA
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_EPTASGA_OBTERABASTECIMENTOS:
        return responseEptaSgaObterAbastecimentos(resp)
    # -------------------------------------------------------
    # acoes serasa
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_SERASA_CONSULTARPF or codEMonitorAcao == ACAO_SERASA_CONSULTARPJ:
        return responseSerasaConsultarPessoa(resp, codEMonitorAcao)
    # -------------------------------------------------------
    # ACOES RODOBENS
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_RODOBENS_CADASTRARVEICULO:
        return responseRodobensSalvaVeiculo(ret)
    elif (codEMonitorAcao == ACAO_RODOBENS_CADASTRARPROPRIETARIO or
          codEMonitorAcao == ACAO_RODOBENS_CADASTRARMOTORISTA):
        return responseRodobensCadastrarPessoa(ret, codEMonitorAcao, reqAux)
    elif codEMonitorAcao == ACAO_RODOBENS_SOLICITARMONITORAMENTO:
        return responseRodobensSalvaSM(ret)

    # -------------------------------------------------------
    # ACOES M3RISK
    # -------------------------------------------------------
    # elif codEMonitorAcao == ACAO_M3RISK_ADD_SM:
    #   return responseM3riskAddSM(resp)

    # -------------------------------------------------------
    # ACOES TRIZY
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_TRIZY_GET_PROPMOTVEIC:
        return resposeTrizyGetCredenciamento(ret)
    elif codEMonitorAcao == ACAO_TRIZY_GET_MOT_IMGS:
        return resposeTrizyGetMotImgs(ret)
    elif codEMonitorAcao == ACAO_TRIZY_GET_COMPROVANTES:
        return responseGetComprovante(resp)
    elif codEMonitorAcao == ACAO_TRIZY_GET_VIAGEMFINALIZADA:
        return responseGetViagemFinalizada(resp)
    elif ACAO_TRIZY_ADDPEDIDO <= codEMonitorAcao <= ACAO_TRIZY_FIM:
        return responseTrizy(resp, ret)
    # -------------------------------------------------------
    # ACOES SIGA
    # -------------------------------------------------------
    elif codEMonitorAcao == ACAO_SIGA_GERARTICKET:
        return responseSigaGerarTicket(resp)
    elif codEMonitorAcao == ACAO_SIGA_UPLOAD:
        return responseSigaUpload(resp)
    elif codEMonitorAcao == ACAO_SIGA_SOLICITARCONSULTA:
        return responseSigaSolicitarConsulta(resp)
    elif codEMonitorAcao == ACAO_SIGA_OBTERCONSULTA:
        return responseSigaObterConsulta(resp)
    # ---------------------------------------------------------
    # ACOES CARGOBANK
    # ---------------------------------------------------------

    elif codEMonitorAcao == ACAO_CARGOBANK_EMITE_CIOT:
        return responseCargobank_GerarCiot(resp)
    elif codEMonitorAcao == ACAO_CARGOBANK_CANCELAR_CIOT:
        return responseCargobank_CancelarCiot(resp)
    elif codEMonitorAcao == ACAO_CARGOBANK_FINALIZAR_CIOT:
        return responseCargobank_FinalizarCiot(resp)
    elif codEMonitorAcao == ACAO_CARGOBANK_QUITAR_CIOT:
        return responseCargobank_QuitarCiot(resp)
    elif codEMonitorAcao == ACAO_CARGOBANK_PEDAGIO_CRIARROTA:
        return responseCargobank_CriarRota(resp)
    elif codEMonitorAcao == ACAO_CARGOBANK_PEDAGIO_CONSULTARVALORROTA:
        return responseCargobank_ConsultaValorPedagio(resp)
    elif codEMonitorAcao == ACAO_CARGOBANK_PEDAGIO_EMITIRPEDAGIO:
        return responseCargobank_EmitirPedagio(resp)
    elif codEMonitorAcao == ACAO_CARGOBANK_PEDAGIO_CANCELARPEDAGIO:
        return responseCargobank_CancelarPedagio(resp)

    # Carguero
    elif carguero.is_recognized_action(codEMonitorAcao):
        return carguero.parse_response(context_resp, codEMonitorAcao)

    # CiotPag
    elif ciot_pag.is_recognized_action(codEMonitorAcao):
        return ciot_pag.parse_response(context_resp, codEMonitorAcao)

    # EmProtege
    elif emprotege.is_recognized_action(codEMonitorAcao):
        return emprotege.parse_response(context_resp, codEMonitorAcao)

    # FreteBras
    elif fretebras.is_recognized_action(codEMonitorAcao):
        return fretebras.parse_response(context_resp, codEMonitorAcao)

    # M3Risk
    elif m3risk.is_recognized_action(codEMonitorAcao):
        return m3risk.parse_response(context_resp, codEMonitorAcao)

    # MaxBot
    elif maxbot.is_recognized_action(codEMonitorAcao):
        return maxbot.parse_response(context_resp, codEMonitorAcao)

    # MyTracking
    elif mytracking.is_recognized_action(codEMonitorAcao):
        return mytracking.parse_response(context_resp, codEMonitorAcao)

    # NddCargo
    elif nddcargo.is_recognized_action(codEMonitorAcao):
        return nddcargo.parse_response(context_resp, codEMonitorAcao)

    # FFDigital
    elif ffdigital.is_recognized_action(codEMonitorAcao):
        return ffdigital.parse_response(context_resp, codEMonitorAcao)

    # Polisoftware
    elif polisoftware.is_recognized_action(codEMonitorAcao):
        return polisoftware.parse_response(context_resp, codEMonitorAcao)

    # Rondonline
    elif rondonline.is_recognized_action(codEMonitorAcao):
        return rondonline.parse_response(context_resp, codEMonitorAcao)

    # SigaSr
    elif sigagr.is_recognized_action(codEMonitorAcao):
        return sigagr.parse_response(context_resp, codEMonitorAcao)

    # Tracker
    elif tracker.is_recognized_action(codEMonitorAcao):
        return tracker.parse_response(context_resp, codEMonitorAcao)

    # Trafegus
    elif trafegus.is_recognized_action(codEMonitorAcao):
        return trafegus.parse_response(context_resp, codEMonitorAcao)

    # TipFrete
    elif tipfrete.is_recognized_action(codEMonitorAcao):
        return tipfrete.parse_response(context_resp, codEMonitorAcao)

    # X7Bank
    elif x7bank.is_recognized_action(codEMonitorAcao):
        return x7bank.parse_response(context_resp, codEMonitorAcao)

    # CTASmart
    elif ctasmart.is_recognized_action(codEMonitorAcao):
        return ctasmart.parse_response(context_resp, codEMonitorAcao)

    # TruckPag
    elif truckpag.is_recognized_action(codEMonitorAcao):
        return truckpag.parse_response(context_resp, codEMonitorAcao)

    # Krona
    elif krona.is_recognized_action(codEMonitorAcao):
        return krona.parse_response(context_resp, codEMonitorAcao)

    # ProFrota
    elif profrota.is_recognized_action(codEMonitorAcao):
        return profrota.parse_response(context_resp, codEMonitorAcao)

    # FFGr
    elif ffgr.is_recognized_action(codEMonitorAcao):
        return ffgr.parse_response(context_resp, codEMonitorAcao)

    # Sisger
    elif sisger.is_recognized_action(codEMonitorAcao):
        return sisger.parse_response(context_resp, codEMonitorAcao)

    # UberLog
    elif uberlog.is_recognized_action(codEMonitorAcao):
        return uberlog.parse_response(context_resp, codEMonitorAcao)

    # SmartLoad
    elif smartload.is_recognized_action(codEMonitorAcao):
        return smartload.parse_response(context_resp, codEMonitorAcao)

    # Senig
    elif senig.is_recognized_action(codEMonitorAcao):
        return senig.parse_response(context_resp, codEMonitorAcao)

    # AllTank
    elif alltank.is_recognized_action(codEMonitorAcao):
        return alltank.parse_response(context_resp, codEMonitorAcao)

    # AlgelLira
    elif angellira.is_recognized_action(codEMonitorAcao):
        return angellira.parse_response(context_resp, codEMonitorAcao)

    # Porto Seguro
    elif porto_seguro.is_recognized_action(codEMonitorAcao):
        return porto_seguro.parse_response(context_resp, codEMonitorAcao)

    # FFCred
    elif ffcred.is_recognized_action(codEMonitorAcao):
        return ffcred.parse_response(context_resp, codEMonitorAcao)

    # Leadsfy
    elif leadsfy.is_recognized_action(codEMonitorAcao):
        return leadsfy.parse_response(context_resp, codEMonitorAcao)

    # Pozi Digital
    elif pozidigital.is_recognized_action(codEMonitorAcao):
        return pozidigital.parse_response(context_resp, codEMonitorAcao)

    #FreteBras Trucker
    elif fretebrastrucker.is_recognized_action(codEMonitorAcao):
        return fretebrastrucker.parse_response(context_resp, codEMonitorAcao)

    # Efrete Vale Pedagio
    elif _efretehub.is_recognized_action(codEMonitorAcao):
        return _efretehub.parse_response(context_resp, codEMonitorAcao)

    return '', 'AÇÃO NÃO ENCONTRADA AO TRATAR RETORNO'


# metodo abaixo chamado via SOR para executar um processo do emonitor.jar
# e aguardar usando socket uma resposta
# baseado no emonitorws.emWSD.java (metodo remoteWS)
def call_remote_ws(request):
    usuario = request.args.get('u', type=str)
    senha = request.args.get('s', type=str)
    #
    msgRet = geral.check_user_password(usuario, senha)
    if msgRet is not None:
        erro = 't'
    else:
        codInstalacao = request.args.get('inst', type=int)
        codEmpresa = request.args.get('emp', type=int)
        codEMonitorAcao = request.args.get('emac', type=int)
        if codInstalacao <= 0 or codEmpresa <= 0 or codEMonitorAcao <= 0:
            erro = 't'
            msgRet = 'PARAMETROS INVALIDOS (inst,emp,emac)'
        else:
            try:
                requestJSON = request.json
                url = requestJSON['url']
                req = requestJSON['request']
                action = requestJSON['action']
                actionBig = requestJSON['actionBig']
                requestMethod = requestJSON['requestMethod']
                requestProperties = requestJSON['requestProperties']
                # criar socket servidor para aguardar resposta do emonitor.jar
                gs = geralsockets.Socket()
                if not gs.create_server():
                    erro = 't'
                    msgRet = 'Erro em opcartao.call_remote_ws.create_server: ' + \
                             str(codInstalacao) + ' / ' + str(codEmpresa) + ' / ' + str(codEMonitorAcao)
                else:
                    port = gs.getServerPort()
                    #
                    timestampSpool = geral.timems()
                    #
                    if codEMonitorAcao == ACAO_OPERADORASEMCHAVEPUB_ENVIODIRETOTEXTXML:
                        acao = 'enviooperadorasemdireto'
                    else:
                        acao = 'enviooperadoracomdireto'
                    # criar comando para executar o emonitor.jar
                    cmd = '/sistemas/emonitor/emonitor_proc.sh ' + acao + ' 100010 1 ' + str(codInstalacao) + ' ' + str(
                        codEmpresa) + ' ' + str(timestampSpool)
                    strProperties = 'portEMWS=' + str(port) + '\n'
                    strProperties += 'codEMonitorAcao=' + str(codEMonitorAcao) + '\n'
                    strProperties += 'url=' + url + '\n'
                    strProperties += 'request=' + geral.getstrnotempty(req).replace('\r', '').replace('\n', '') + '\n'
                    strProperties += 'action=' + geral.getstrnotempty(action) + '\n'
                    strProperties += 'actionBig=' + geral.getstrnotempty(actionBig) + '\n'
                    strProperties += 'requestMethod=' + geral.getstrnotempty(requestMethod) + '\n'
                    strProperties += 'requestProperties=' + geral.getstrnotempty(requestProperties) + '\n'
                    nomeArqProperties = '/sistemas/emonitor/tmpremoteWS/' + str(codInstalacao) + '_' + str(
                        codEmpresa) + '_' + str(timestampSpool) + '.properties'
                    geral.strtofile(nomeArqProperties, strProperties)
                    printdh('call_remote_ws: ' + cmd)
                    system(cmd)
                    # aguardar resposta no socket servidor do emonitor.jar
                    response = gs.receive()
                    if response is not None:
                        if response.startswith('ERRO:'):
                            erro = 't'
                        else:
                            erro = 'f'
                        msgRet = response
                    else:
                        erro = 't'
                        msgRet = 'ERRO AO TENTAR OBTER RESPOSTA DO WEBSERVICE REMOTO!'
                    #
            except Exception as e:
                erro = 't'
                msgRet = 'Erro em opcartao.call_remote_ws: ' + str(codInstalacao) + ' / ' + str(
                    codEmpresa) + ' / ' + str(codEMonitorAcao)
                print(msgRet)
                print(e)
    #
    responseJSON = {}
    responseJSON['erro'] = erro
    responseJSON['msgRet'] = msgRet
    return jsonify(responseJSON)
