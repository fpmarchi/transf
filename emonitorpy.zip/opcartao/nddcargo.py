import re
import time
from datetime import datetime
from functools import wraps
from typing import Tuple, Optional

import requests
import xmltodict
from requests import Response

from dispacher import ActionProcessor
from dispacher.decorators import handle_exception_factory
from geral import conditional_key, deep_get, set_context, safe_cast, static_vars, remove_accents
from geralxml import xml_from_dict, AssinaturaA1, mount_xml_response


class NddException(Exception):
    pass


class NddCargo(ActionProcessor):
    # HOST = 'http://localhost:5000/test'
    # TEST_HOST = 'http://localhost:5000/test'
    HOST = 'https://wsagent.nddcargo.com.br'
    TEST_HOST = 'https://homologa.nddcargo.com.br'
    BASE_PATH = '/wsagente/ExchangeMessage.asmx'

    # Actions
    REQUEST_OT_SEND = 1600
    CONSULT_OT_SEND = 1601

    REQUEST_OT_CANCELLATION = 1602
    CONSULT_OT_CANCELLATION = 1603

    REQUEST_OT_CHANGE = 1604
    CONSULT_OT_CHANGE = 1606

    REQUEST_OT_CLOSING = 1605
    CONSULT_OT_CLOSING = 1607

    REQUEST_OT_BREAK_MERC = 1608
    CONSULT_OT_BREAK_MERC = 1609

    REQUEST_OT_IMMEDIATE_PAYMENT = 1610

    SEARCH_OT_PAYMENT_MADE = 1611

    # Internal actions
    GET_GUID = 1

    def __init__(self):
        super().__init__()

        self.add_callable_records('url', {
            self.DEFAULT_FUNCTION: self.make_url_assembler()
        })

        self.add_callable_records('request', {
            self.CONSULT_OT_SEND: (_out_consul_operation, {'process_code': 1000}),
            self.CONSULT_OT_CANCELLATION: (_out_consul_operation, {'process_code': 1001}),
            self.CONSULT_OT_CHANGE: (_out_consul_operation, {'process_code': 1002}),
            self.CONSULT_OT_CLOSING: (_out_consul_operation, {'process_code': 1005}),
            self.CONSULT_OT_BREAK_MERC: (_out_consul_operation, {'process_code': 1002}),
        })


#
#   Códigos independentes de instancia
#

# Tratamento de exceções
def _nddcargo_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a NddCargo:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    NddException,
    _nddcargo_exception_callback,
    any_exception_callback
)


#
# Decorators
#
def _require_guid(func: callable):
    @wraps(func)
    def wrapper(*args, **kwargs):
        req = _nddcargo.context.get('req', {})
        props = _nddcargo.context.get('props', {})

        if req.get('guid'):
            props['guid'] = req.get('guid')
        else:
            message = _cross_talk(1004, props.get('cnpj'))

            url = _nddcargo.dispatch(NddCargo.DEFAULT_FUNCTION, _nddcargo.context, 'url')[0]
            headers = {'content-type': 'text/xml'}
            req = _soap_envelop(message)
            resp = requests.post(url, data=req, headers=headers)

            guid = deep_get(
                _extract_soap_response(resp.text, 'SendResponse.SendResult'),
                'CrossTalk_Message.CrossTalk_Header.GUID'
            )

            props['guid'] = guid

        return func(*args, **kwargs)

    return wrapper


@_handle_exception
@_require_guid
def _out_consul_operation(req: dict, props: dict, process_code: int):
    delay = req.get('delay', 8)

    # Delay padrão de 8 segundos para dar tempo de processar a requisição
    if not delay:
        delay = 8

    time.sleep(delay)
    message = _cross_talk(process_code, props.get('cnpj'), props['guid'], 8)

    return _soap_envelop(message, None), ''


#
#   Instancia limpa e sem configuração
#
_nddcargo = NddCargo()

#
#   Códigos dependentes de instancia
#

# Decorators da instancia
_link_to_request = _nddcargo.link_to_factory('request')
_link_to_response = _nddcargo.link_to_factory('response')


def _source_document(cte: bool, nfse: bool, nfe: bool):
    if cte:
        return 'CT-e'
    elif nfse:
        return 'NFS-e'
    elif nfe:
        return 'NF-e'
    else:
        return 'Viagem'


def _cargo_owner(sender: bool, recipient: bool, consignee: bool):
    if sender:
        return 1
    elif recipient:
        return 2
    elif consignee:
        return 3
    else:
        return 4


@_link_to_request(NddCargo.REQUEST_OT_SEND)
@_handle_exception
@_require_guid
def _out_lote_ot(req: dict, props: dict, pfx_path: str, pfx_password: str):
    ctx: dict = {}

    rntrc_category = deep_get(req, 'proprietario.categoria_rntrc')
    vehicle_ownership = deep_get(req, 'proprietario.categoria_rntrc')
    is_tac_agregado = rntrc_category == 0 and vehicle_ownership in ['A', 'M']

    def get_zip_code(coleta, entrega):
        if entrega and coleta == entrega:
            entrega = str(safe_cast(entrega, int, 0) + 1)

        return entrega

    rg = deep_get(req, 'motorista.rg')
    if rg == '':
        raise NddException("Identidade do motorista não pode ser vazia!")

    soap_req: dict = {
        'loteOT_envio': {
            '@xmlns:xsi': 'http://www.w3.org/2003/05/soap-envelope',
            '@xmlns:xsd': 'http://tempuri.org/',
            '@xmlns': 'http://www.nddigital.com.br/nddcargo',
            '@versao': '4.2.11.0',
            '@token': 'intersite_42110_20221101',
            'operacoes.OT.infOT': {
                '@Id': props['guid'],
                '@gerPgtoFin': deep_get(req, 'ndd_cargo.movimentacao_financeira'),
                '@impAuto': 2,  # Aguarde tarefas para uma possivel dinamização
                '@gerPgtoPedagio': 2,  # Aguarde tarefas para uma possivel dinamização
                'ide': {
                    'cnpj': props['cnpj'],
                    'numero': req.get('codigo'),
                    'serie': deep_get(req, 'documento.serie'),
                    'ptEmissor': deep_get(req, 'ndd_cargo.pt_emissor', ''),
                    # Não enviar em TAC Agregado
                    **conditional_key('dtInicio', req.get('data_inicio', '').split('T')[0], not is_tac_agregado),
                    **conditional_key(
                        'dtFim',
                        req.get('data_prev_fim', '').split('T')[0] if req.get('data_prev_fim') else None
                    )
                },
                'carga': {
                    **conditional_key('padrao', {
                        'codigoSH': deep_get(req, 'mercadoria.ncm')[0:4],
                        'quantidade':
                            safe_cast(deep_get(req, 'mercadoria.quantidade'), float)
                            if safe_cast(deep_get(req, 'mercadoria.quantidade'), float)
                            else safe_cast(deep_get(req, 'mercadoria.peso_saida'), float),
                        set_context('remetente', ctx, req.get('remetente')): {
                            'cnpj' if len(ctx.get('cnpj_cpf', '')) > 11 else 'cpf': ctx.get('cnpj_cpf'),
                            'nome': ctx.get('nome', '').strip(),
                            set_context('endereco', ctx, ctx.get('endereco')): {
                                'UF': ctx.get('uf'),
                                'codigoMunicipio': ctx.get('codibge_cidade'),
                                'bairro': ctx.get('bairro', '').strip(),
                                'logradouro': ctx.get('logradouro', '').strip(),
                                'numero': safe_cast(ctx.get('numero', '0'), int, '0'),
                                'CEP': ctx.get('cep'),
                                **conditional_key('complemento', ctx.get('complemento', '').strip())
                            }
                        },
                        set_context('destinatario', ctx, req.get('destinatario')): {
                            'cnpj'
                            if len(ctx.get('cnpj_cpf', '')) > 11
                            else 'cpf':
                                ctx.get('cnpj_cpf'),
                            'nome': ctx.get('nome'),
                            set_context('endereco', ctx, ctx.get('endereco')): {
                                'UF': ctx.get('uf'),
                                'codigoMunicipio': ctx.get('codibge_cidade'),
                                'bairro': ctx.get('bairro', '').strip(),
                                'logradouro': ctx.get('logradouro', '').strip(),
                                'numero': safe_cast(ctx.get('numero', '0'), int, '0'),
                                'CEP': ctx.get('cep'),
                                **conditional_key('complemento', ctx.get('complemento', '').strip())
                            }
                        }
                    }, not is_tac_agregado),
                    **conditional_key('TACagregado', {
                        set_context('remetente', ctx, req.get('remetente')): {
                            'cnpj'
                            if len(ctx.get('cnpj_cpf', '')) > 11
                            else 'cpf':
                                ctx.get('cnpj_cpf'),
                            'nome': ctx.get('nome', '').strip(),
                            set_context('endereco', ctx, ctx.get('endereco')): {
                                'UF': ctx.get('uf'),
                                'codigoMunicipio': ctx.get('codibge_cidade'),
                                'bairro': ctx.get('bairro', '').strip(),
                                'logradouro': ctx.get('logradouro', '').strip(),
                                'numero': safe_cast(ctx.get('numero', '0'), int, '0'),
                                'CEP': ctx.get('cep'),
                                **conditional_key('complemento', ctx.get('complemento', '').strip())
                            }
                        }
                    }, is_tac_agregado),
                    **conditional_key(set_context('consignatario', ctx, req.get('consignatario')), {
                        'cnpj' if len(ctx.get('cnpj_cpf', '')) > 11 else 'cpf': ctx.get('cnpj_cpf'),
                        'nome': ctx.get('nome'),
                        set_context('endereco', ctx, ctx.get('endereco')): {
                            'UF': ctx.get('uf'),
                            'codigoMunicipio': ctx.get('codibge_cidade'),
                            'bairro': ctx.get('bairro', '').strip(),
                            'logradouro': ctx.get('logradouro', '').strip(),
                            'numero': safe_cast(ctx.get('numero', '0'), int, '0'),
                            'CEP': ctx.get('cep'),
                            **conditional_key('complemento', ctx.get('complemento', '').strip())
                        }
                    }, not not req.get('ndd_con_cnpjcpf')),
                    'proprietarioCarga': _cargo_owner(
                        deep_get(req, 'cliente.cnpj_cpf', '').strip() == req.get('remetente.cnpj_cpf', '').strip(),
                        req.get('cliente.cnpj_cpf', '').strip() == req.get('destinatario.cnpj_cpf', '').strip(),
                        req.get('consignatario.cnpj_cpf', '').strip() != ''
                    ),
                    set_context('documentosOriginarios.documentoOriginario', ctx, req.get('documento')): {
                        'tipo': _source_document(
                            ctx.get('tipo') == 'CT',
                            ctx.get('tipo') == 'NFS',
                            ctx.get('tipo') == 'NF'
                        ),
                        'numero': ctx.get('identificador')
                    },
                },
                'contatos.contato': {
                    'nome': deep_get(req, 'motorista.nome', '').strip(),
                    'contato': deep_get(req, 'motorista.celular')
                },
                'transp': {
                    'rntrc': deep_get(req, 'proprietario.rntrc').rjust(9, '0'),
                    'cnpjTransportador'
                    if len(deep_get(req, 'proprietario.cnpj_cpf', '')) > 11
                    else 'cpfTransportador':
                        deep_get(req, 'proprietario.cnpj_cpf'),

                    **conditional_key('infTransportador', {
                        set_context('ide.tac', ctx, deep_get(req, 'proprietario.dados_fisica')): {
                            'nomeCompleto': deep_get(req, 'proprietario.nome', '').strip(),
                            'nomeMae':
                                ctx.get('nome_mae', '').strip()
                                if ctx.get('nome_mae', '').strip()
                                else 'NAO INFORMADO',
                            'nomePai':
                                ctx.get('nome_pai', '').strip()
                                if ctx.get('nome_pai', '').strip()
                                else 'NAO INFORMADO',
                            'dataNascimento': ctx.get('data_nascimento'),
                            'identidade': ctx.get('identidade', '').strip()
                        },
                        set_context('endereco', ctx, deep_get(req, 'proprietario.endereco')): {
                            'UF': ctx.get('uf'),
                            'cidade': ctx.get('cidade', '').strip(),
                            'bairro': ctx.get('bairro', '').strip(),
                            'logradouro': ctx.get('logradouro', '').strip(),
                            'numero': safe_cast(ctx.get('numero', '0'), int, '0'),
                            'CEP': ctx.get('cep'),
                            **conditional_key('complemento', ctx.get('complemento', '').strip())
                        },
                        'telefone': deep_get(req, 'proprietario.celular'),
                        'email':
                            deep_get(req, 'proprietario.email', '').strip()
                            if deep_get(req, 'proprietario.email', '').strip()
                            else 'NAOINFORMADO@NI.COM',
                    }, ((safe_cast(deep_get(req, 'proprietario.categoria_rntrc'), int, -1) == 0) or
                        (
                                safe_cast(deep_get(req, 'proprietario.categoria_rntrc'), int, -1) == 3 and
                                len(deep_get(req, 'proprietario.cnpj_cpf')) == 11
                        ))),
                    **conditional_key('infTransportador', {
                        set_context('ide.etc', ctx, deep_get(req, 'proprietario')): {
                            'razaoSocial': ctx.get('nome', '').strip(),
                            'nomeFantasia': ctx.get('nome', '').split(" ")[0],
                            'inscEstadual': ctx.get('inscricao_estadual'),
                            'atividadePrincipal': '49',
                            'formaConstituicao':
                                deep_get(req, 'ndd_cargo.formacao_constituicao', '').strip()
                                if deep_get(req, 'ndd_cargo.formacao_constituicao', '').strip() not in ['', '0']
                                else '206-2',
                            'dataConstituicao': _date_ddmmyy(deep_get(req, 'ndd_cargo.data_constituicao')) if deep_get(
                                req, 'ndd_cargo.data_constituicao') == '' else '2022-01-01',
                            set_context('socio', ctx, deep_get(req, 'proprietario')): {
                                'nomeCompleto':
                                    ctx.get('nome_titular', '').strip()
                                    if ctx.get('nome_titular', '').strip()
                                    else 'NAO INFORMADO',
                                'nomeMae':
                                    deep_get(ctx, 'dados_fisica.nome_mae', '').strip()
                                    if deep_get(ctx, 'dados_fisica.nome_mae', '').strip()
                                    else 'NAO INFORMADO',
                                'nomePai':
                                    deep_get(ctx, 'dados_fisica.nome_pai', '').strip()
                                    if deep_get(ctx, 'dados_fisica.nome_pai', '').strip()
                                    else 'NAO INFORMADO',
                                'dataNascimento':
                                    deep_get(ctx, 'dados_fisica.data_nascimento', '').strip()
                                    if deep_get(ctx, 'dados_fisica.data_nascimento', '').strip()
                                    else '1999-01-01',
                                'cpf':
                                    ctx.get('cpf_titular', '').strip()
                                    if ctx.get('cpf_titular') and len(ctx.get('cpf_titular')) < 14
                                    else '00000000000',
                                'identidade':
                                    deep_get(ctx, 'dados_fisica.identidade', '').strip()
                                    if deep_get(ctx, 'dados_fisica.identidade', '').strip()
                                    else '0000000',
                                set_context('endereco', ctx, deep_get(req, 'proprietario.endereco')):
                                    {
                                        'UF': ctx.get('uf'),
                                        'cidade': ctx.get('cidade', '').strip(),
                                        'bairro': ctx.get('bairro', '').strip(),
                                        'logradouro': ctx.get('logradouro', '').strip(),
                                        'numero': safe_cast(ctx.get('numero', '0'), int, '0'),
                                        'CEP': ctx.get('cep'),
                                        **conditional_key('complemento', ctx.get('complemento', '').strip())
                                    },
                                'telefone':
                                    deep_get(req, 'proprietario.celular', '').strip()
                                    if deep_get(req, 'proprietario.celular', '').strip()
                                    else '19999999999',
                                'email':
                                    deep_get(req, 'proprietario.email', '').strip()
                                    if deep_get(req, 'proprietario.email', '').strip()
                                    else 'NAOINFORMADO@NI.COM',
                            }
                        },
                        set_context('endereco', ctx, deep_get(req, 'proprietario.endereco')): {
                            'UF': ctx.get('uf'),
                            'cidade': ctx.get('cidade', '').strip(),
                            'bairro': ctx.get('bairro', '').strip(),
                            'logradouro': ctx.get('logradouro', '').strip(),
                            'numero': safe_cast(ctx.get('numero', '0'), int, '0'),
                            'CEP': ctx.get('cep'),
                            **conditional_key('complemento', ctx.get('complemento', '').strip())
                        },
                        'telefone': deep_get(req, 'proprietario.celular'),
                        **conditional_key(
                            'cartaoId',
                            1,
                            deep_get(req, 'ndd_cargo.movimentacao_financeira') == 1
                        ),
                    }, (safe_cast(deep_get(req, 'proprietario.categoria_rntrc'), int, -1) == 1)
                                      or (safe_cast(deep_get(req, 'proprietario.categoria_rntrc'), int,
                                                    -1) == 3 and len(deep_get(req, 'proprietario.cnpj_cpf')) == 14)),

                    **conditional_key('infTransportador', {
                        set_context('ide.ctc', ctx, deep_get(req, 'proprietario.dados_fisica')): {
                            'razaoSocial': deep_get(req, 'proprietario.nome', '').strip(),
                            'nomeFantasia': deep_get(req, 'proprietario.nome', '').split(" ")[0],
                            'inscEstadual': deep_get(req, 'proprietario.inscricao_estadual'),
                            'atividadePrincipal': '49',
                            'formaConstituicao':
                                deep_get(req, 'ndd_cargo.formacao_constituicao', '').strip()
                                if deep_get(req, 'ndd_cargo.formacao_constituicao', '').strip() not in ['', '0']
                                else '206-2',
                            'dataConstituicao':
                                _date_ddmmyy(deep_get(req, 'ndd_cargo.data_constituicao'))
                                if deep_get(req, 'ndd_cargo.data_constituicao', '').strip()
                                else '2022-01-01',
                            set_context('socio', ctx, deep_get(req, 'proprietario')): {
                                'nomeCompleto':
                                    ctx.get('nome_titular', '').strip()
                                    if ctx.get('nome_titular', '').strip()
                                    else 'NAO INFORMADO',
                                'nomeMae':
                                    deep_get(ctx, 'dados_fisica.nome_mae', '').strip()
                                    if deep_get(ctx, 'dados_fisica.nome_mae', '').strip()
                                    else 'NAO INFORMADO',
                                'nomePai':
                                    deep_get(ctx, 'dados_fisica.nome_pai', '').strip()
                                    if deep_get(ctx, 'dados_fisica.nome_pai', '').strip()
                                    else 'NAO INFORMADO',
                                'dataNascimento':
                                    deep_get(ctx, 'dados_fisica.data_nascimento', '').strip()
                                    if deep_get(ctx, 'dados_fisica.data_nascimento', '').strip()
                                    else '1999-01-01',
                                'cpf':
                                    deep_get(ctx, 'cpf_titular', '').strip()
                                    if deep_get(ctx, 'cpf_titular', '').strip()
                                    else '00000000000',
                                'identidade':
                                    deep_get(ctx, 'dados_fisica.identidade', '').strip()
                                    if deep_get(ctx, 'dados_fisica.identidade', '').strip()
                                    else '0000000',
                                set_context('endereco', ctx, deep_get(req, 'proprietario.endereco')):
                                    {
                                        'UF': ctx.get('uf'),
                                        'cidade': ctx.get('cidade', '').strip(),
                                        'bairro': ctx.get('bairro', '').strip(),
                                        'logradouro': ctx.get('logradouro', '').strip(),
                                        'numero': safe_cast(ctx.get('numero', '0'), int, '0'),
                                        'CEP': ctx.get('cep'),
                                        **conditional_key('complemento', ctx.get('complemento', '').strip())
                                    },
                                'telefone':
                                    deep_get(req, 'proprietario.celular', '').strip()
                                    if deep_get(req, 'proprietario.celular', '').strip()
                                    else '19999999999',
                                'email':
                                    deep_get(req, 'proprietario.email', '').strip()
                                    if deep_get(req, 'proprietario.email', '').strip()
                                    else 'NAOINFORMADO@NI.COM',
                            }
                        },
                        set_context('endereco', ctx, deep_get(req, 'proprietario.endereco')): {
                            'UF': ctx.get('uf', '').strip(),
                            'cidade': ctx.get('cidade', '').strip(),
                            'bairro': ctx.get('bairro', '').strip(),
                            'logradouro': ctx.get('logradouro', '').strip(),
                            'numero': safe_cast(ctx.get('numero', '0'), int, '0'),
                            'CEP': ctx.get('cep'),
                            **conditional_key('complemento', ctx.get('complemento', '').strip())
                        },
                        'telefone': deep_get(req, 'proprietario.celular'),
                    }, safe_cast(deep_get(req, 'proprietario.categoria_rntrc'), int, -1) == 2),

                    **conditional_key('gestoraCartao', '001', deep_get(req, 'ndd_cargo.movimentacao_financeira') == 1),
                    'rota': {
                        'rotaERP': (
                            f"{deep_get(req, 'origem.nome', '').strip()} / "
                            f"{deep_get(req, 'destino.nome', '').strip()}"[:30].strip()
                        ),
                        'informacoes': {
                            'nome': (
                                f"{deep_get(req, 'origem.nome', '').strip()} / "
                                f"{deep_get(req, 'destino.nome', '').strip()}"[:30].strip()
                            ),
                            'pontosParada>pontoParada': [
                                {
                                    'cep':
                                        deep_get(req, 'coleta.endereco.cep')
                                        if deep_get(req, 'coleta.endereco.cep', '').strip()
                                        else deep_get(req, 'remetente.endereco.cep'),
                                },
                                {
                                    'cep':
                                        get_zip_code(
                                            deep_get(req, 'coleta.endereco.cep'),
                                            deep_get(req, 'entrega.endereco.cep')
                                        )
                                        if deep_get(req, 'entrega.endereco.cep', '').strip()
                                        else get_zip_code(
                                            deep_get(req, 'remetente.endereco.cep'),
                                            deep_get(req, 'destinatario.endereco.cep')
                                        ),
                                }
                            ]
                        }
                    },
                    set_context('condutores.condutor', ctx, req.get('motorista')): {
                        'cpf': ctx.get('cpf', ''),
                        'informacoes': {
                            'nomeCompleto': ctx.get('nome', '').strip(),
                            'nomeMae':
                                ctx.get('nome_mae', '').strip()
                                if ctx.get('nome_mae', '').strip()
                                else 'NAO INFORMADO',
                            'dataNascimento': ctx.get('data_nascimento', '').strip()
                            if ctx.get('data_nascimento', '').strip()
                            else '1999-01-01',

                            'identidade': ctx.get('rg', ''),
                            'RNTRCTransportador': deep_get(req, 'proprietario.rntrc', '').rjust(9, '0'),
                            'cnpjTransportador' if len(deep_get(req, 'proprietario.cnpj_cpf', '')) > 11
                            else 'cpfTransportador': deep_get(req, 'proprietario.cnpj_cpf'),
                            set_context('endereco', ctx, ctx.get('endereco')): {
                                'UF': ctx.get('uf'),
                                'cidade': ctx.get('cidade', '').strip(),
                                'bairro': ctx.get('bairro', '').strip(),
                                'logradouro': ctx.get('logradouro', '').strip(),
                                'numero': safe_cast(ctx.get('numero', '0'), int, '0'),
                                'CEP': ctx.get('cep'),
                                **conditional_key('complemento', ctx.get('complemento', '').strip())
                            },
                            'telefone':
                                deep_get(req, 'motorista.telefone', '').strip()
                                if deep_get(req, 'motorista.telefone', '').strip()
                                else deep_get(req, 'motorista.celular'),
                            **conditional_key('cartaoId', 1, deep_get(req, 'ndd_cargo.movimentacao_financeira') == 1),
                        }

                    },
                    set_context('veiculos>veiculo', ctx, req.get('veiculo')):
                        [
                            {
                                'placa': ctx.get('placa'),
                                'informacoes': {
                                    'modelo': ctx.get('modelo'),
                                    'tipo': 1,
                                    'RNTRCTransportador': deep_get(ctx, 'proprietario.rntrc', '').rjust(9, '0')
                                }
                            }
                        ] + [
                            {
                                'placa': c.get('placa'),
                                'informacoes': {
                                    'modelo': c.get('modelo'),
                                    'tipo': 1,
                                    'RNTRCTransportador': deep_get(c, 'proprietario.rntrc', '').rjust(9, '0')
                                }
                            } for c in (
                                ctx.get('carretas', [])
                                if deep_get(req, 'ndd_cargo.enviar_carretas') is True
                                else []
                            )
                        ],

                    set_context('valores', ctx, req.get('valores')): {
                        'vlrFrete': ctx.get('frete'),

                        **conditional_key(
                            'parcelamento.informacoes.parcelas>parcela', list(
                                filter(
                                    lambda x: not not safe_cast(x.get('valorAplicado'), float),
                                    [
                                        {
                                            'nome': 'ADIANTAMENTO',

                                            **conditional_key(
                                                'tipoPgto.imediato',
                                                2,
                                                deep_get(req, 'ndd_cargo.pagar_adiantamento')
                                            ),
                                            **conditional_key(
                                                'tipoPgto.manual.dataPrevisao',
                                                datetime.today().isoformat()[0:10],
                                                not deep_get(req, 'ndd_cargo.pagar_adiantamento')
                                            ),
                                            'valorAplicado': ctx.get('mot_adiantamento'),
                                        },
                                        {
                                            'nome': 'ADIANTAMENTO 2',
                                            # **conditional_key(
                                            #     'cartaoId',
                                            #     1,
                                            #     deep_get(req, 'ndd_cargo.movimentacao_financeira') == 1
                                            # ),

                                            **conditional_key(
                                                'tipoPgto.imediato',
                                                2,
                                                deep_get(req, 'ndd_cargo.pagar_adiantamento')
                                            ),
                                            **conditional_key(
                                                'tipoPgto.manual.dataPrevisao',
                                                datetime.today().isoformat()[0:10],
                                                not deep_get(req, 'ndd_cargo.pagar_adiantamento')
                                            ),
                                            'valorAplicado': ctx.get('mot_adiantamento2'),
                                        },
                                        {
                                            'nome': 'SALDO',
                                            'tipoPgto.manual': {
                                                'dataPrevisao': datetime.today().isoformat()[0:10],
                                            },
                                            'valorAplicado': float(ctx.get('frete')) - float(
                                                ctx.get('mot_adiantamento')) - float(ctx.get('mot_adiantamento2')),

                                            'valorReal': ctx.get('saldo_motorista'),  # se cnpj

                                            **conditional_key('descontos>desconto', list(
                                                filter(
                                                    lambda x: not not safe_cast(x.get('vlrDesc'), float),
                                                    [
                                                        {
                                                            'nmDesc': 'QUEBRA',
                                                            'vlrDesc': ctx.get('valor_quebra'),
                                                            'dsDesc': 'QUEBRA DE MERCADORIA',
                                                        },
                                                        {
                                                            'nmDesc': 'OUTROS DESCONTOS',
                                                            'vlrDesc': ctx.get('mot_outros_descontos'),
                                                            'dsDesc': 'OUTROS DESCONTOS',
                                                        },
                                                        {
                                                            'nmDesc': 'OUTROS DESCONTOS 2',
                                                            'vlrDesc': ctx.get('mot_outros_descontos2'),
                                                            'dsDesc': 'OUTROS DESCONTOS 2',
                                                        },
                                                        {
                                                            'nmDesc': 'SEGURO',
                                                            'vlrDesc': ctx.get('seguro'),
                                                            'dsDesc': 'SEGURO',
                                                        },
                                                    ] + [
                                                        {
                                                            'nmDesc': 'DESCONTOS ADICIONAIS',
                                                            'vlrDesc': expense.get('valor_base'),
                                                            'dsDesc': expense.get('descricao_desp') if expense.get(
                                                                'descricao_desp') else 'DESCONTOS ADICIONAIS'
                                                        }
                                                        for expense in req.get('despesas', '')
                                                    ]
                                                )
                                            )),
                                        }
                                    ]
                                )

                            ), deep_get(req, 'ndd_cargo.parcelamento') is True),

                        'retencoes': {
                            'irrf': ctx.get('irrf', 0),
                            'inss': ctx.get('inss', 0),
                            'sestsenat': ctx.get('sest_senat', 0),
                        },

                        'tipoRateio': 2,

                        **conditional_key('vlrPedagio', ctx.get('pedagio'),
                                          deep_get(req, 'ndd_cargo.incluir_pegagio') is True),
                        'tarifas': {
                            'quantidadeTotal': '1',
                            'valorTotal': 0.00,  # ctx.get('mot_frete')
                        },
                        **conditional_key(
                            set_context('dadosBancarios', ctx, deep_get(req, 'ndd_cargo.dados_bancarios')),
                            {
                                'codigoInstituicaoFinanceira': ctx.get('codigo_instituicao') if ctx.get('codigo_instituicao') else '0',
                                'numeroAgencia': ctx.get('agencia') if ctx.get('agencia') else '0',
                                'numeroConta': ctx.get('conta') if ctx.get('conta') else '0',
                                #'digitoConta': (ctx.get('conta', '') + '-0').split('-')[1]

                                **conditional_key('chavePix', ctx.get('chave_pix', '').strip(), not not ctx.get('chave_pix')),
                                **conditional_key('tipoChave', ctx.get('tipo_chave', ''), not not ctx.get('tipo_chave')),
                                **conditional_key('tipoPagamento', ctx.get('tipo_pagamento', ''), not not ctx.get('tipo_pagamento')),
                            },
                            deep_get(req, 'ndd_cargo.movimentacao_financeira') == 2
                            # and (not deep_get(req, 'ndd_cargo.tipo_pagamento'))
                        ),
                    },
                    'categoriaPedagio': _get_toll_category(deep_get(req, 'veiculo.eixos_conjunto'))
                },
            }
        }
    }

    xml = remove_accents(xml_from_dict(soap_req))

    message = _cross_talk(1000, props.get('cnpj'), props['guid'], 7)

    assinatura = AssinaturaA1(certificado=pfx_path, senha=pfx_password)
    xml = assinatura.assinar_elemento(xml, 'infOT', prolog=True)

    return _soap_envelop(message, xml), ''


@_link_to_request(NddCargo.REQUEST_OT_CHANGE)
@_handle_exception
@_require_guid
def _out_change_ot(req: dict, props: dict, pfx_path: str, pfx_password: str):
    ctx: dict = {}

    rntrc_category = deep_get(req, 'proprietario.categoria_rntrc')
    vehicle_ownership = deep_get(req, 'proprietario.categoria_rntrc')
    is_tac_agregado = rntrc_category == 0 and vehicle_ownership in ['A', 'M']

    ctx.update(req.get('veiculo'))
    veiculos = [
                   {
                       'placa': ctx.get('placa'),
                       'informacoes': {
                           'modelo': ctx.get('modelo'),
                           'tipo': 1,
                           'RNTRCTransportador': deep_get(ctx, 'proprietario.rntrc', '').rjust(9, '0')
                       }
                   }
               ] + [
                   {
                       'placa': c.get('placa'),
                       'informacoes': {
                           'modelo': c.get('modelo'),
                           'tipo': 1,
                           'RNTRCTransportador': deep_get(ctx, 'proprietario.rntrc', '').rjust(9, '0')
                       }
                   } for c in (ctx.get('carretas', []) if deep_get(req, 'ndd_cargo.enviar_carretas') is True else [])
               ]

    soap_req: dict = {
        'alterarOT_envio': {
            '@xmlns:xsi': 'http://www.w3.org/2003/05/soap-envelope',
            '@xmlns:xsd': 'http://tempuri.org/',
            '@xmlns': 'http://www.nddigital.com.br/nddcargo',
            '@versao': '4.2.11.0',
            '@token': 'intersite_42110_20221101',
            'OT.infOT': {
                '@Id': props['guid'],
                'cnpj': props['cnpj'],
                set_context('autorizacao.ciot', ctx, req.get('ndd_cargo')): {
                    'numero': ctx.get('ciot'),
                    'ciotCodVerificador': ctx.get('cod_verificador')
                },
                'alteracoes.alteracao.ANTT': {
                    **conditional_key('padrao.ate24hrs', {
                        'validade': {
                            'dtInicio': req.get('data_inicio', '').split('T')[0],
                            **conditional_key(
                                'dtFim',
                                req.get('data_prev_fim', '').split('T')[0] if req.get('data_prev_fim') else None
                            )
                        },
                        'carga': {
                            'codigoSH': deep_get(req, 'mercadoria.ncm')[0:4],
                            'quantidade': safe_cast(deep_get(req, 'mercadoria.quantidade'), float) if safe_cast(
                                deep_get(req, 'mercadoria.quantidade'), float) else safe_cast(
                                deep_get(req, 'mercadoria.peso_saida'), float),
                        },
                        'veiculos>veiculo': veiculos,
                        'categoriaPedagio': _get_toll_category(deep_get(req, 'veiculo.eixos_conjunto')),
                        'tarifas': {
                            'quantidadeTotal': 1
                        }
                    }, not is_tac_agregado),
                    **conditional_key('TACagregado', {
                        'veiculos>veiculo': veiculos,
                        'categoriaPedagio': _get_toll_category(deep_get(req, 'veiculo.eixos_conjunto')),
                        'tarifas': {
                            'quantidadeTotal': 1
                        }
                    }, is_tac_agregado),
                },
                'motivo': deep_get(ctx, 'ndd_cargo.motivo_auteracao', 'Auteracao de dados da OT')
            }
        }
    }

    message = _cross_talk(1001, props.get('cnpj'), props['guid'], 7)

    assinatura = AssinaturaA1(certificado=pfx_path, senha=pfx_password)
    xml = assinatura.assinar_elemento(xml_from_dict(soap_req), 'infOT', prolog=True)

    return _soap_envelop(message, xml), ''


@_link_to_request(NddCargo.REQUEST_OT_CANCELLATION)
@_handle_exception
@_require_guid
def _out_cancel_ot(req: dict, props: dict, pfx_path: str, pfx_password: str):
    soap_req: dict = {
        'cancelarOT_envio': {
            '@xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance',
            '@xmlns:xsd': 'http://www.w3.org/2001/XMLSchema',
            '@xmlns': 'http://www.nddigital.com.br/nddcargo',
            '@versao': '4.2.11.0',
            '@token': 'intersite_42110_20221101',
            'infCancOT': {
                '@Id': props['guid'],
                'cnpj': props['cnpj'],
                'autorizacao.ciot': {
                    'numero': req.get('ciot'),
                    'ciotCodVerificador': req.get('cod_verificador')
                },
                'motivo': req.get('motivo')
            }
        }
    }

    message = _cross_talk(1002, props.get('cnpj'), props['guid'], 7)

    assinatura = AssinaturaA1(certificado=pfx_path, senha=pfx_password)
    xml = assinatura.assinar_elemento(xml_from_dict(soap_req), 'infCancOT', prolog=True)

    return _soap_envelop(message, xml), ''


@_link_to_request(NddCargo.REQUEST_OT_CLOSING)
@_handle_exception
@_require_guid
def _out_close_ot(req: dict, props: dict, pfx_path: str, pfx_password: str):
    rntrc_category = deep_get(req, 'proprietario.categoria_rntrc')
    vehicle_ownership = deep_get(req, 'proprietario.categoria_rntrc')
    is_tac_agregado = rntrc_category == 0 and vehicle_ownership in ['A', 'M']

    soap_req: dict = {
        'encerrarOT_envio': {
            '@xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance',
            '@xmlns:xsd': 'http://www.w3.org/2001/XMLSchema',
            '@xmlns': 'http://www.nddigital.com.br/nddcargo',
            '@versao': '4.2.11.0',
            '@token': 'intersite_42110_20221101',
            'infEnceOT': {
                '@Id': props['guid'],
                'cnpj': props['cnpj'],
                'autorizacao.ciot': {
                    'numero': req.get('ciot'),
                    'ciotCodVerificador': req.get('cod_verificador')
                },
                'encerramento': {
                    **conditional_key('padrao', {
                        'qtdeCarga': safe_cast(deep_get(req, 'mercadoria.peso_chegada'), float)
                    }, not is_tac_agregado),
                    **conditional_key('TACagregado.viagens>viagem', [
                        {
                            'rota': {
                                'rotaERP': f"{deep_get(req, 'origem.nome', '').strip()} / "
                                           f"{deep_get(req, 'destino.nome', '').strip()}"[:30].strip(),
                            },
                            'codigoSH': deep_get(req, 'mercadoria.ncm')[0:4],
                            'qtdeCarga': safe_cast(deep_get(req, 'mercadoria.peso_chegada'), int),
                            'qtdeViagens': 1
                        }
                    ], is_tac_agregado),
                }
            }
        }
    }

    message = _cross_talk(1005, props.get('cnpj'), props['guid'], 7)

    assinatura = AssinaturaA1(certificado=pfx_path, senha=pfx_password)
    xml = assinatura.assinar_elemento(xml_from_dict(soap_req), 'infEnceOT', prolog=True)

    return _soap_envelop(message, xml), ''


@_link_to_request(NddCargo.REQUEST_OT_BREAK_MERC)
@_handle_exception
@_require_guid
def _out_change_ot(req: dict, props: dict, pfx_path: str, pfx_password: str):
    ctx: dict = {}

    soap_req: dict = {
        'alterarOT_envio': {
            '@xmlns:xsi': 'http://www.w3.org/2003/05/soap-envelope',
            '@xmlns:xsd': 'http://tempuri.org/',
            '@xmlns': 'http://www.nddigital.com.br/nddcargo',
            '@versao': '4.2.11.0',
            '@token': 'intersite_42110_20221101',
            'OT.infOT': {
                '@Id': props['guid'],
                'cnpj': props['cnpj'],
                set_context('autorizacao.ciot', ctx, req.get('ndd_cargo')): {
                    'numero': ctx.get('ciot')[0:12],
                    'ciotCodVerificador': ctx.get('cod_verificador')
                },
                'alteracoes.alteracao.financeiro': {
                    'ajustaParc': {
                        'nome': 'SALDO',
                        'altValores': {
                            'desconto': {
                                'nmDesc': 'Desconto de quebra',
                                'vlrDesc': (safe_cast(deep_get(req, 'valores.mot_frete_saida'), float, 0) - safe_cast(
                                    deep_get(req, 'valores.mot_frete'), float, 0)) + safe_cast(
                                    deep_get(req, 'valores.valor_quebra'), float, 0),
                                'dsDesc': 'Informacao adicional',
                                'rubrica': '1'
                            },
                        },
                    },
                    # 'ajustaParc': {
                    #     'carga': {
                    #         'quantidade': safe_cast(deep_get(req, 'mercadoria.peso_chegada'), float),
                    #     }
                    # }
                },
                'motivo': deep_get(req, 'ndd_cargo.motivo_alteracao', 'Alteração de dados da OT')
            }
        }
    }

    message = _cross_talk(1001, props.get('cnpj'), props['guid'], 7)

    assinatura = AssinaturaA1(certificado=pfx_path, senha=pfx_password)
    xml = assinatura.assinar_elemento(xml_from_dict(soap_req), 'infOT', prolog=True)

    return _soap_envelop(message, xml), ''


@_link_to_request(NddCargo.REQUEST_OT_IMMEDIATE_PAYMENT)
@_handle_exception
@_require_guid
def _out_request_ot_immediate_payment(req: dict, props: dict, pfx_path: str, pfx_password: str):
    ctx: dict = {}

    soap_req: dict = {
        'pagamentoImediatoOT_envio': {
            '@xmlns:xsi': 'http://www.w3.org/2003/05/soap-envelope',
            '@xmlns:xsd': 'http://tempuri.org/',
            '@xmlns': 'http://www.nddigital.com.br/nddcargo',
            '@versao': '4.2.11.0',
            '@token': 'intersite_42110_20221101',
            'infPgtoOT': {
                '@Id': props['guid'],
                'cnpj': props['cnpj'],
                set_context('autorizacao.ciot', ctx, req.get('ndd_cargo')): {
                    'numero': ctx.get('ciot')[0:12],
                    'ciotCodVerificador': ctx.get('cod_verificador')
                },
                **conditional_key('nomeParcela', 'ADIANTAMENTO',
                                  deep_get(req, 'ndd_cargo.tipo_pagamento_realizar', '') == 'AD'),
                **conditional_key('nomeParcela', 'ADIANTAMENTO 2',
                                  deep_get(req, 'ndd_cargo.tipo_pagamento_realizar', '') == 'AD2'),
                **conditional_key('nomeParcela', 'SALDO',
                                  deep_get(req, 'ndd_cargo.tipo_pagamento_realizar', '') == 'SD'),

                'motivo': deep_get(req, 'ndd_cargo.motivo_liberacao', 'Pagamento de adiantamento')

            }
        }
    }

    message = _cross_talk(2005, props.get('cnpj'), props['guid'], 1)

    assinatura = AssinaturaA1(certificado=pfx_path, senha=pfx_password)
    xml = assinatura.assinar_elemento(xml_from_dict(soap_req), 'infPgtoOT', prolog=True)

    return _soap_envelop(message, xml), ''


@_link_to_request(NddCargo.SEARCH_OT_PAYMENT_MADE)
@_handle_exception
@_require_guid
def _out_search_ot_payment_made(req: dict, props: dict, pfx_path: str, pfx_password: str):
    ctx: dict = {}

    soap_req: dict = {
        'pagamentoOT_envio': {
            '@xmlns:xsi': 'http://www.w3.org/2003/05/soap-envelope',
            '@xmlns:xsd': 'http://tempuri.org/',
            '@xmlns': 'http://www.nddigital.com.br/nddcargo',
            '@versao': '4.2.11.0',
            '@token': 'intersite_42110_20221101',
            'infConsultaPgtos': {
                '@Id': props['guid'],
                'cnpjContratante': props['cnpj'],
                # 'cnpjEmitente': props['cnpj'],
                'periodo': {
                    'dataInicial': deep_get(req,'ndd_cargo.data_inicial'),
                    'dataFinal': deep_get(req,'ndd_cargo.data_final'),
                }
                #'GUID': deep_get(req,'ndd_cargo.id_viagem'),

            }
        }
    }

    message = _cross_talk(1003, props.get('cnpj'), props['guid'], 1)

    assinatura = AssinaturaA1(certificado=pfx_path, senha=pfx_password)
    xml = assinatura.assinar_elemento(xml_from_dict(soap_req), 'infConsultaPgtos', prolog=True)

    return _soap_envelop(message, xml), ''


#
# Funções para tratamento de retornos
#
@_link_to_response(NddCargo.DEFAULT_FUNCTION)
@_handle_exception
@static_vars(
    regexp=re.compile(r"'(.*?)'")
)
def _in_default(resp: Response, callable_key: int):
    regexp = _in_default.regexp
    cross_message = _extract_soap_response(resp.text, 'SendResponse.SendResult').get('CrossTalk_Message', {})

    header = cross_message.get('CrossTalk_Header')
    body = cross_message.get('CrossTalk_Body')

    success = header.get('ResponseCode') in ['202', '200']
    em_resp = {
        'sucesso': success
    }

    if success:
        conteudo = {
            'guid': header.get('GUID')
        }
        em_resp['conteudo'] = conteudo

        if header.get('ResponseCode') == '202':
            return mount_xml_response(em_resp), ''

        if callable_key == NddCargo.CONSULT_OT_SEND:
            data = deep_get(body, 'retornoConsultaLoteOT.operacoes.OT.infOT')

            conteudo['ciot'] = {
                'numero': deep_get(data, 'autorizacao.ciot.numero'),
                'cod_verificador': deep_get(data, 'autorizacao.ciot.ciotCodVerificador'),
                'valor': safe_cast(deep_get(data, 'valores.vlrFrete'), float, 0)
            }
        elif callable_key == NddCargo.SEARCH_OT_PAYMENT_MADE:
            if deep_get(body, 'retornoConsultaPgtos.pgtos.pgto'):
                conteudo['retorno'] = deep_get(body, 'retornoConsultaPgtos.pgtos.pgto')
            else:
                data = deep_get(body, 'retornoConsultaPgtos.mensagens.mensagem')
                conteudo['mensagem'] = deep_get(data, 'mensagem')

    else:
        if callable_key == NddCargo.CONSULT_OT_SEND:
            messages = deep_get(body, 'retornoConsultaLoteOT.operacoes.OT.infOT.mensagens.mensagem', [])
        elif callable_key == NddCargo.CONSULT_OT_CHANGE or callable_key == NddCargo.CONSULT_OT_BREAK_MERC:
            messages = deep_get(body, 'retornoConsulta.mensagens.mensagem', [])
        elif callable_key == NddCargo.CONSULT_OT_CANCELLATION:
            messages = deep_get(body, 'retornoConsultaCancelamento.mensagens.mensagem', [])
        elif callable_key == NddCargo.CONSULT_OT_CLOSING:
            messages = deep_get(body, 'retornoConsultaEncerramento.mensagens.mensagem', [])
        elif callable_key == NddCargo.REQUEST_OT_IMMEDIATE_PAYMENT and not deep_get(body, 'Body.mensagens.mensagem', []):
            messages = deep_get(body, 'retornoPagamentoImediato.mensagens.mensagem', [])
        else:
            messages = deep_get(body, 'Body.mensagens.mensagem', [])

        if type(messages) is not list:
            messages = [messages]

        em_resp['erros'] = []
        for message in messages:
            matches = [m.groups()[0] for m in regexp.finditer(message.get('observacao', '').rsplit(' - ', 1)[0])]

            field = matches[0].rsplit(':', 1)[-1] \
                if len(matches) == 3 \
                else ' - '
            desc = message.get('observacao', '').rsplit(' - ', 1)[-1] \
                if len(matches) == 3 \
                else message.get('observacao', '')

            em_resp['erros'].append(
                {
                    'campo': field,
                    'descricao': desc
                }
            )

    return mount_xml_response(em_resp), ''


#
# Funções utilitárias
#
@static_vars(category={
    2: 7,
    3: 8,
    4: 9,
    5: 10,
    6: 11,
    7: 12,
    8: 13,
    9: 14,
    10: 15,
    '>10': 16
})
def _get_toll_category(number_of_axles: int):
    category: dict = _get_toll_category.category

    if number_of_axles and number_of_axles > 10:
        return category.get('>10')

    return category.get(number_of_axles)


@_handle_exception
def _cross_talk(process_code: int, cnpj: str, guid: str = None, exg_pattern: int = 1):
    soap_req: dict = {
        'CrossTalk_Message': {
            '@xmlns:xsd': 'http://www.w3.org/2001/XMLSchema',
            '@xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance',
            '@xmlns': 'http://www.nddigital.com.br/nddcargo',
            'CrossTalk_Header': {
                'ProcessCode': process_code,
                'MessageType': 100,
                'ExchangePattern': exg_pattern,
                **conditional_key('GUID', guid),
                'DateTime': datetime.today().isoformat(),
                'EnterpriseId': cnpj,
                'Token': '123456789123456'
            },
            'CrossTalk_Body': {
                'CrossTalk_Version_Body': {
                    '@versao': '4.2.11.0'
                }
            }
        }
    }

    return xml_from_dict(soap_req, prolog=True)


@_handle_exception
def _soap_envelop(message: str = None, data: str = None):
    soap_req: dict = {
        ('Envelope', 'soap'): {
            '@xmlns:soap': 'http://www.w3.org/2003/05/soap-envelope',
            '@xmlns:tem': 'http://tempuri.org/',
            'Header': None,
            'Body': {
                ('Send', 'tem'): {
                    'message': bytes(message, 'utf-8') if message is not None else message,
                    'rawData': bytes(data, 'utf-8') if data is not None else data,
                }
            }
        }
    }

    return xml_from_dict(soap_req, prolog=True)


@_handle_exception
def _extract_soap_response(resp: str, extra_path: str = '') -> Optional[dict]:
    try:
        return xmltodict.parse(
            deep_get(
                xmltodict.parse(resp),
                'soap:Envelope.soap:Body' + ('.' + extra_path if extra_path else '')
            )
        )
    except (Exception,):
        return None


def _date_ddmmyy(s: str) -> str:
    try:
        return datetime.strptime(s, "%d/%m/%Y").strftime("%Y-%m-%d")
    except (Exception,):
        return ''
