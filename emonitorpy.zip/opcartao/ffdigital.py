import json
from datetime import datetime
from typing import Tuple

import xmltodict
from requests import Response, post

from dispacher import ActionProcessor
from dispacher.action_processor import HttpMethod
from dispacher.decorators import handle_exception_factory
from geral import wsstrtoDDMMAAAA, conditional_keys, conditional_key, deep_get, safe_cast, round_by_abnt
from geralxml import mount_xml_response


class FFException(Exception):
    pass


# ESSA FFDIGITAL SERÁ DESCONTINUADA FUTURAMENTE, DESSA FORMA OS NOVOS MÉTODOS SERÃO FEITOS NA FFCRED
# Classe base
class FFDigital(ActionProcessor):
    # CIOT
    GENERATE_CIOT = 1650
    CANCEL_CIOT = 1651
    FINISH_CIOT = 1652

    CONSULT_DOCUMENTS = 1660
    DOWNLOAD_DOCUMENT = 1661

    # Contas
    VERIFY_ACCOUNT = 1654
    CREATE_ACCOUNT = 1655

    # Pagamentos
    LIST_ACREDITED = 1656
    TRANSFER_PAYMENT = 1657
    REGISTER_CIOT_DISCHARGE = 1653
    FINALIZE_CIOT_DISCHARGE = 1658
    CONSULT_PAYMENTS = 1659
    GENERATE_INVOICES = 1662

    HOST = {
        'account': 'https://contasdigitais.tech4log.com',
        'ciot': 'https://ciot.tech4log.com',
        'payment': 'https://pagamentos.tech4log.com'
    }
    TEST_HOST = {
        'account': ('https://contasdigitais.ffcredscd.com.br', '/api'),
        'ciot': 'https://ciot-dev.ffcredscd.com.br',
        'payment': 'https://pagamentos-dev.ffcredscd.com.br'
    }

    def __init__(self):
        self.BASE_PATH = '/api'
        self.TEST_BASE_PATH = '/rls/api'

        self.add_callable_records('url', {
            # self.GENERATE_CIOT: self.make_url_assembler('/test'),
            self.GENERATE_CIOT: self.make_url_assembler('/v2/operacao/gerar', host_slug='ciot'),

            # self.CANCEL_CIOT: self.make_url_assembler('/test'),
            self.CANCEL_CIOT: self.make_url_assembler('/v2/operacao/cancelar', host_slug='ciot'),

            # self.FINISH_CIOT: self.make_url_assembler('/test'),
            self.FINISH_CIOT: self.make_url_assembler('/v2/operacao/finalizar', host_slug='ciot'),

            # self.REGISTER_CIOT_DISCHARGE: self.make_url_assembler('/test'),
            self.REGISTER_CIOT_DISCHARGE: self.make_url_assembler('/v2/quitacao/registrar', host_slug='ciot'),

            # self.CONSULT_DOCUMENTS: self.make_url_assembler('/test'),
            self.CONSULT_DOCUMENTS: self.make_url_assembler('/v2/arquivo/listaConferidos', host_slug='ciot',
                                                            method=HttpMethod.GET),

            # self.REGISTER_CIOT_DISCHARGE: self.make_url_assembler('/test'),
            self.DOWNLOAD_DOCUMENT: self.make_url_assembler('/v2/arquivo/download', host_slug='ciot'),

            # self.VERIFY_ACCOUNT: self.make_url_assembler('/test'),
            self.VERIFY_ACCOUNT: self.make_url_assembler(
                '/conta/verificar/$cnpjcpf',
                host_slug='account',
                method=HttpMethod.GET,
                use_template=True
            ),

            # self.CREATE_ACCOUNT: self.make_url_assembler('/test'),
            self.CREATE_ACCOUNT: self.make_url_assembler('/conta', host_slug='account'),

            self.LIST_ACREDITED: self.make_url_assembler('/v2/operacao/listar', host_slug='ciot'),

            # self.TRANSFER_PAYMENT: self.make_url_assembler('/test'),
            self.TRANSFER_PAYMENT: self.make_url_assembler('/v1/transferir', host_slug='payment'),

            # self.FINALIZE_CIOT_DISCHARGE: self.make_url_assembler('/test'),
            self.FINALIZE_CIOT_DISCHARGE: self.make_url_assembler('/v1/quitacao/finalizar', host_slug='payment'),

            self.CONSULT_PAYMENTS: self.make_url_assembler(
                '/v1/pagamentos2',
                method=HttpMethod.GET,
                host_slug='payment'
            ),

            self.GENERATE_INVOICES: self.make_url_assembler('/v1/faturas-emitidas', host_slug='payment',
                                                            method=HttpMethod.GET),
        })

        super().__init__()


#
#   Códigos independentes de instancia
#

# Tratamento de exceções
def _ff_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a F&F:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    FFException,
    _ff_exception_callback,
    any_exception_callback
)

#
#   Códigos dependentes de instancia
#

# Instancia limpa e sem configuração (singleton)
_ffdigital = FFDigital()

# Decorators da instancia
_link_to_request = _ffdigital.link_to_factory('request')
_link_to_response = _ffdigital.link_to_factory('response')


@_link_to_request(FFDigital.GENERATE_CIOT)
@_handle_exception
def _out_generate_ciot(req: dict, props: dict) -> Tuple[str, str]:
    tipo_viagem = 1
    if req.get('conh_prop_tipoantt') == 3 and req.get('conh_veic_propriedade') in ['A', 'M', 'G']:
        tipo_viagem = 3

    type_break = _get_type_break(req.get('conh_tipodesc'), req.get('conh_tipotoler'))

    min_break = _get_min_break(type_break, req.get('conh_pesosaida'), req.get('conh_valortoler'))

    max_break = _get_max_break(type_break, req.get('conh_pesosaida'), req.get('conh_valortoler'))

    value_outros = (
            (safe_cast(req.get('conh_valorseguro'), float, 0) if req.get('conh_descsegurosaldomot') == 'S' else 0)
            + (safe_cast(req.get('conh_valorseguro2'), float, 0) if req.get('conh_descseguro2saldomot') == 'S' else 0)
            + safe_cast(req.get('conh_outrosdescontosmot'), float, 0)
            + safe_cast(req.get('conh_outrosdescontosmot2'), float, 0)
    )

    req_data = {
        'Token': props['token'],  # Transportadora
        'CpfCnpjContratado': req.get('conh_prop_cnpjcpf', ''),
        'RNTRCContratado': req.get('conh_prop_rntrc', ''),

        'Veiculos': list(filter(lambda x: not not x.get('Placa'), [
            {
                'Placa': req.get('conh_veic_placa', ''),
                'RNTRC': req.get('conh_prop_rntrc', '')
            },
            {
                'Placa': req.get('conh_veic_placacarreta1', ''),
                'RNTRC': req.get('conh_car1_prop_rntrc') if req.get(
                    'conh_car1_prop_rntrc') else req.get('conh_prop_rntrc', '')
            },
            {
                'Placa': req.get('conh_veic_placacarreta2', ''),
                'RNTRC': req.get('conh_car2_prop_rntrc') if req.get(
                    'conh_car2_prop_rntrc') else req.get('conh_prop_rntrc', '')
            },
            {
                'Placa': req.get('conh_veic_placacarreta3', ''),
                'RNTRC': req.get('conh_car3_prop_rntrc') if req.get(
                    'conh_car3_prop_rntrc') else req.get('conh_prop_rntrc', '')
            }
        ])),

        'CpfCnpjContratante': req.get('cnpj_empresa', '') if req.get('cnpj_empresa', '') else req.get(
            'conh_filial_cnpjcpf', ''),
        'CpfCnpjDestinatario': req.get('conh_mot_cpf', ''),  # !!!!!
        'CodigoMunicipioOrigem': req.get('conh_codibgeorig', ''),
        'CodigoMunicipioDestino': req.get('conh_codibgedest', ''),
        'CpfCnpjMotorista': req.get('conh_mot_cpf', ''),
        'CodigoNaturezaCarga': req.get('conh_ncm')[:4] if req.get('conh_ncm', '') else '0001',
        'PesoCarga': req.get('conh_pesosaida'),
        'DataInicioViagem': wsstrtoDDMMAAAA(req.get('conh_datafimcarregamento')),
        **conditional_key(
            'DataFimViagem', wsstrtoDDMMAAAA(req.get('conh_dataprevisaodescarga')),
            not not req.get('conh_dataprevisaodescarga')
        ),
        # 1 — Padrão 3 — TAC Agregado
        'TipoViagem': tipo_viagem,
        **conditional_key('RNTRCContratante', req.get('conh_filial_rntrc'), tipo_viagem == 3),
        'QuantidadeTarifas': 0, 'ValorTarifas': 0,
        'ValorFreteTotal': req.get('conh_valorviagem'),
        **conditional_key(
            'CriterioAceite', req.get('ff_criterios', '').split(','),
            not not req.get('ff_criterios', '').strip()
        ),
        'taxa_quebra': round(float(req.get('conh_valormerc')) / float(req.get('conh_pesosaida')), 5),
        # mercadoria total/ peso carga saida

        'taxa_recalculo': safe_cast(req.get('conh_precotonempresa').replace(',', '.', 1), float) / 1000 if type(
            req.get('conh_precotonempresa')) is str else req.get('conh_precotonempresa') / 1000,  # ppt empresa
        'TipoDeQuebra': type_break,
        'LimiteMinQuebra': min_break,
        'LimiteMaxQuebra': max_break,
        'CodigoInterno': req.get('conh_numero'),
        'cte': req.get('conh_numconhec'),
        'ValorMercadoriaTotal': req.get('conh_valormerc'),
        'ValorFretePorUnidade': 0,
        'IRRF': req.get('conh_impirrf'),
        'INSS': req.get('conh_impinss'),
        'SEST_SENAT': req.get('conh_impsestsenat'),
        'Outros': value_outros,
        # 'cte': req.get('conh_ctechave'),
        'PagarMotorista': 'sim' if req.get('ff_favorecido') == 'M' else 'nao',

        **conditional_keys(req.get('conh_tipodesc') in 'XFHPIN', {
            **conditional_key('DiferencaFrete', 'saida', req.get('conh_tipodesc') == 'P'),
            **conditional_key('DiferencaFrete', 'saida', req.get('conh_tipodesc') == 'I'),
            **conditional_key('DiferencaFrete', 'saida', req.get('conh_tipodesc') == 'N'),
            **conditional_key('DiferencaFrete', 'chegada-menor-saida', req.get('conh_tipodesc') == 'X'),
            **conditional_key('DiferencaFrete', 'chegada-com-tolerancia', req.get('conh_tipodesc') == 'F'),
            **conditional_key('DiferencaFrete', 'chegada-menor-saida', req.get('conh_tipodesc') == 'H'),
            # **conditional_key('DiferencaFrete', 'chegada-com-tolerancia-desconto-integral', req.get('conh_tipodesc') == 'H'),
            # 'DiferencaFrete': 'chegada-menor-saida',
            'DiferencaFreteTolerancia': round_by_abnt(
                float(req.get('conh_pesosaida')) * float(req.get('conh_valortoler')) / 100
            ),
            # fazer em km
            **conditional_keys(
                req.get('conh_meiopagamento') == 'CD',
                {
                    'PagtoContaDigital': 1
                },
                {
                    'PagtoContaDigital': 0,
                    'CartaFrete': req.get('conh_cartafrete')
                }
            ),
        }),

        **conditional_keys(req.get('conh_programa_pgto') == 'S', {
            'DiferencaFrete': 'saida',
            'DiferencaFreteTolerancia': float(req.get('conh_pesosaida')) * float(req.get('conh_valortoler')) / 100,
            # fazer em km
            **conditional_keys(
                req.get('conh_meiopagamento') == 'CD',
                {
                    'PagtoContaDigital': 1
                },
                {
                    'PagtoContaDigital': 0,
                    'CartaFrete': req.get('conh_cartafrete')
                }
            ),
        }),

        'NomeMotorista': req.get('conh_mot_nome', ''),
        'NomeContratado': req.get('conh_prop_nome', ''),

        'Parcelas': [
            dict_.update({'NumeroParcela': index + 1}) or dict_
            for (index, dict_) in enumerate(
                filter(lambda x: not not x.get('Valor'), [
                    {
                        'CodigoInterno': req.get('ff_codparcela_adto'),  # Adiantamento (Orientado pelo Leonardo da F&F)
                        'DataVencimento': wsstrtoDDMMAAAA(req.get('ff_venc_faturas')),
                        'Valor': safe_cast(req.get('conh_valoradiant'), float, 0),
                        'CategoriaPagamento': 'Adiantamento',
                    },
                    {
                        'CodigoInterno': '10',  # Adiantamento (Orientado pelo Leonardo da F&F)
                        'DataVencimento': wsstrtoDDMMAAAA(req.get('ff_venc_faturas')),
                        # M.01: Não enviado a pedido do Leonarda da F & F
                        'Valor': 0,  # safe_cast(req.get('conh_valoradiant2'), float, 0),
                        'CategoriaPagamento': 'Adiantamento',
                    },
                    {
                        'CodigoInterno': req.get('ff_codparcela_saldo'),  # Saldo (Orientado pelo Leonardo da F&F)
                        'DataVencimento': wsstrtoDDMMAAAA(req.get('ff_venc_faturas')),
                        'Valor': safe_cast(req.get('conh_valorsaldo'), float, 0),
                        'CategoriaPagamento': 'Saldo',
                    }
                ])
            )
        ]
    }

    return json.dumps(req_data), ''


@_link_to_request(FFDigital.CANCEL_CIOT)
@_handle_exception
def _out_cancel_ciot(req: dict, props: dict) -> Tuple[str, str]:
    req_data = {
        'Token': props['token'],  # Transportadora
        'Ciot': req.get('ciot'),
        'Motivo': req.get('motivo_cancelamento')
    }

    return json.dumps(req_data), ''


@_link_to_request(FFDigital.REGISTER_CIOT_DISCHARGE)
@_handle_exception
def _out_register_ciot_discharge(req: dict, props: dict) -> Tuple[str, str]:
    now = datetime.now()
    if req.get('data_fim').strip():
        end_date = datetime.strptime(req.get('data_fim'), '%Y-%m-%dT%H:%M:%S')
    else:
        end_date = now

    req_data = {
        'Token': props['token'],  # Transportadora
        'Ciot': req.get('ciot'),
        'CnpjQuitador': req.get('quitador'),
        'PesoCargaEntregue': req.get('peso_chegada').replace(',', '.'),
        'DataEntrega': end_date.strftime("%m/%d/%Y"),
        'DataQuitacao': now.strftime("%m/%d/%Y"),
        'Arquivos': []
    }

    return json.dumps(req_data), ''


@_link_to_request(FFDigital.FINALIZE_CIOT_DISCHARGE)
@_handle_exception
def _out_finalize_ciot_discharge(req: dict, props: dict) -> Tuple[str, str]:
    json_resp = _get_list_acredited_data()
    # PagarMotorista = False
    # destination_document = ''
    if json_resp.get('sucesso'):
        data = deep_get(json_resp, 'conteudo.dados_ciot')

        if data.get('PagarMotorista') == 'sim':
            destination_document = data.get('CpfCnpjMotorista')
        else:
            destination_document = data.get('CpfCnpjContratado')
    else:
        raise FFException('Não foi possível obter a situação atual do CIOT informado')

    digital_payment = req.get('ff_pagto_digital') is True
    req_data = {
        'Token': props['token'],  # Pagador
        'NumeroDocumento': req.get('ciot'),
        'CpfOuCnpjDestino': destination_document,
        'IdQuitadoFilial': '0' if digital_payment else '1',
        'IdProcessoLocal': req.get('ff_id_parcela'),
        'cheque': not digital_payment
    }

    return json.dumps(req_data), ''


@_link_to_request(FFDigital.FINISH_CIOT)
@_handle_exception
def _out_finish_ciot(req: dict, props: dict) -> Tuple[str, str]:
    req_data = {
        'Token': props['token'],  # Transportadora
        'Ciot': req.get('ciot')
    }

    return json.dumps(req_data), ''


@_link_to_request(FFDigital.CREATE_ACCOUNT)
@_handle_exception
def _out_create_account(req: dict, props: dict) -> Tuple[str, str]:
    req_data = {
        'Token': props['token'],  # Transportadora
        'cpf_cnpj': req.get('cnpjcpf'),
        'nome': req.get('nome'),
        'data_nascimento': req.get('datanasc'),
        'telefone': req.get('celularnumero', '').lstrip('0'),
        'email': req.get('email'),
        'cep': req.get('cep'),
        'logradouro': req.get('endereco'),
        'numero': req.get('numero'),
        'bairro': req.get('bairro'),
        'cidade': req.get('cidade'),
        'uf': req.get('uf'),
        'senha': req.get('senha'),
        'numero_cartao': req.get('cartao')
    }

    return json.dumps(req_data), ''


@_link_to_request(FFDigital.LIST_ACREDITED)
@_handle_exception
def _out_list_acredited(req: dict, props: dict) -> Tuple[str, str]:
    req_data = {
        'Token': props['token'],  # Posto
        "ColunaFiltro": "Protocolo",
        "ColunaConsulta": req.get('ciot')
    }

    return json.dumps(req_data), ''


@_link_to_request(FFDigital.TRANSFER_PAYMENT)
@_handle_exception
def _out_transfer_payment(req: dict, props: dict) -> Tuple[str, str]:
    json_resp = _get_list_acredited_data()

    # PagarMotorista = False
    # destination_document = ''
    if json_resp.get('sucesso'):
        data = deep_get(json_resp, 'conteudo.dados_ciot')

        if data.get('PagarMotorista') == 'sim':
            destination_document = data.get('CpfCnpjMotorista')
        else:
            destination_document = data.get('CpfCnpjContratado')
    else:
        raise FFException('Não foi possível obter a situação atual do CIOT informado')

    digital_payment = req.get('ff_pagto_digital') is True
    req_data = {
        'Token': props['token'],  # Pagador
        'TipoDocumento': 'ciot',
        'NumeroDocumento': req.get('ciot'),
        'ContaDestino': '',
        'CpfOuCnpjDestino': destination_document,
        'Valor': req.get('valor'),
        'CategoriaPagamento': 'adiantamento',
        'IdQuitadoFilial': '0' if digital_payment else '1',
        'IdProcessoLocal': req.get('ff_id_parcela'),
        'cheque': not digital_payment
    }

    return json.dumps(req_data), ''


@_link_to_request(FFDigital.CONSULT_PAYMENTS)
@_handle_exception
def _out_transfer_payment(req: dict, props: dict) -> Tuple[str, str]:
    req_data = {
        'Token': props['token'],  # Pagador
        'DataInicial': datetime.strptime(req.get('data_ini'), '%Y-%m-%dT%H:%M:%S').strftime("%d/%m/%Y"),
        'DataFinal': datetime.strptime(req.get('data_fim'), '%Y-%m-%dT%H:%M:%S').strftime("%d/%m/%Y")
    }

    return json.dumps(req_data), ''


@_link_to_request(FFDigital.CONSULT_DOCUMENTS)
@_handle_exception
def _out_consult_documents(req: dict, props: dict) -> Tuple[str, str]:
    req_data = {
        'Token': props['token'],
        'PeriodoInicio': datetime.strptime(req.get('data_ini'), '%d/%m/%Y').strftime("%Y-%m-%d"),
        'PeriodoFim': datetime.strptime(req.get('data_fim'), '%d/%m/%Y').strftime("%Y-%m-%d")
    }

    return json.dumps(req_data), ''


@_link_to_request(FFDigital.DOWNLOAD_DOCUMENT)
@_handle_exception
def _out_download_document(req: dict, props: dict) -> Tuple[str, str]:
    req_data = {
        'Token': props['token'],  # Pagador
        'CodigoArquivo': req.get('CodigoArquivo', '')
    }

    return json.dumps(req_data), ''


@_link_to_request(FFDigital.GENERATE_INVOICES)
@_handle_exception
def _out_generate_invoices(req: dict, props: dict) -> Tuple[str, str]:
    req_data = {
        'Token': props['token'],
        'data': req.get('data_search').split('T')[0],
    }

    return json.dumps(req_data), ''


@_link_to_request(FFDigital.DEFAULT_FUNCTION)
@_handle_exception
def _out_default() -> Tuple[None, str]:
    return None, ''


#
# Tratamento de retornos
#
@_link_to_response(FFDigital.VERIFY_ACCOUNT)
@_handle_exception
def _in_verify_account(resp: Response) -> Tuple[str, str]:
    ret = resp.json()
    status = resp.status_code

    if status == 200:
        resp_data = {
            'sucesso': True,
            'conteudo': {
                'existe': ret.get('Sucesso'),
                'msg': ret.get('Mensagem')
            }
        }
    else:
        resp_data = {
            'sucesso': False,
            'msg_erro': ret.get('Mensagem')
        }

    return mount_xml_response(resp_data), ''


@_link_to_response(FFDigital.CREATE_ACCOUNT)
@_handle_exception
def _in_create_account(resp: Response) -> Tuple[str, str]:
    # Remover quando a integração estiver estável
    # ret = json.loads('''
    #     {
    #         "Sucesso": true,
    #         "Mensagem": "Operação realizada com Sucesso",
    #         "Conta": {
    #             "cpf_cnpj": "55682513045",
    #             "nome": "MARIO GARCIA MONTEIRO E SILVA",
    #             "data_nascimento": "1984-01-08",
    #             "telefone": "063984623651",
    #             "email": "guilherme.lucas.dacunha@uniube.br",
    #             "cep": "77500000",
    #             "logradouro": "RUA SAO FRANCISCO",
    #             "numero": "SN",
    #             "bairro": "SAO FRANCISCO",
    #             "cidade": "PORTO NACIONAL",
    #             "uf": "TO",
    #             "uuid": "cJp8n0IJOkj0k2qcfVy-w"
    #         }
    #     }
    # ''')

    ret = resp.json()
    sucesso = ret.get('Sucesso', False)

    resp_data = {
        'sucesso': sucesso,
    }

    if sucesso:
        resp_data = {
            'sucesso': True,
            'conteudo': {
                'uuid': deep_get(ret, 'Conta.uuid'),
                'msg': ret.get('Mensagem')
            }
        }
    else:
        if 'Campos' in ret and ret.get:
            resp_data['erros'] = [
                {
                    'campo': k or ' - ',
                    'descricao': '\n'.join(v) or ''
                }
                for k, v in ret.get('Campos', {}).items()
            ]
        elif 'Mensagem' in ret and ret.get:
            resp_data['erros'] = [
                {
                    'campo': 'CPF',
                    'descricao': deep_get(ret, 'Mensagem'),
                }]

    return mount_xml_response(resp_data), ''


@_link_to_response(FFDigital.CONSULT_DOCUMENTS)
@_handle_exception
def _in_consult_documents(resp: Response) -> Tuple[str, str]:
    ret = resp.json()
    sucesso = ret.get('Sucesso', False)

    if sucesso:
        resp_data = {
            'sucesso': True,
            'conteudo': {
                'Mensagem': deep_get(ret, 'Mensagem'),
                'Documentos': deep_get(ret, 'Documentos'),
            }
        }
    else:
        resp_data = {
            'sucesso': False,
            'conteudo': '',
        }
    return mount_xml_response(resp_data), ''


@_link_to_response(FFDigital.DOWNLOAD_DOCUMENT)
@_handle_exception
def _in_download_document(resp: Response) -> Tuple[str, str]:
    ret = resp.json()
    sucesso = ret.get('Sucesso', False)

    if sucesso:
        resp_data = {
            'sucesso': True,
            'conteudo': {
                'Mensagem': deep_get(ret, 'DescricaoArquivo'),
                'Extensao': deep_get(ret, 'Extensao'),
                'Documentos': deep_get(ret, 'Arquivo'),
            }
        }
    else:
        resp_data = {
            'sucesso': False,
            'msg_erro': '',
        }
    return mount_xml_response(resp_data), ''


@_link_to_response(FFDigital.GENERATE_INVOICES)
@_handle_exception
def _in_generate_invoices(resp: Response) -> Tuple[str, str]:
    ret = resp.json()
    sucesso = ret.get('Sucesso', False)

    if sucesso:
        resp_data = {
            'sucesso': True,
            'conteudo': {
                'msg': ret.get('Mensagem'),
                'dados': ret.get('dados')
            }
        }
    else:
        resp_data = {
            'sucesso': False,
            'msg_erro': ret.get('Mensagem'),
        }
    return mount_xml_response(resp_data), ''


@_link_to_response(FFDigital.DEFAULT_FUNCTION)
@_handle_exception
def _in_default(resp: Response) -> Tuple[str, str]:
    # Remover quando a integração estiver estável
    # retornos = {
    #     FFDigital.TRANSFER_PAYMENT: '{"Sucesso": true,"Mensagem": "Operação realizada com Sucesso","CodigoOperacao": "4_O-IZhHNdi4SNSUwFZB3"}',
    #     FFDigital.REGISTER_CIOT_DISCHARGE: '{"Sucesso": true,"Mensagem": "Operação realizada com Sucesso"}',
    #     FFDigital.FINALIZE_CIOT_DISCHARGE: '{"Sucesso": true,"Mensagem": "Operação realizada com Sucesso","CodigoOperacao": "5m7Fv4a0_pVQucy1HEFv8","IdProcessoLocal": "11"}',
    #     FFDigital.GENERATE_CIOT: '{"Sucesso":true,"CIOT":"3720002001535631","Mensagem":"Dados inseridos com sucesso!","Erro":null}',
    #     FFDigital.CANCEL_CIOT: '{"Sucesso": true, "ProtocoloCancelamento": "3408434870395326130", "Mensagem": "Operação realizada com sucesso", "Erro": null}'
    # }

    # if retornos.get(callable_key) is not None:
    #     ret = json.loads(retornos.get(callable_key))
    # else:
    ret = resp.json()

    success = ret.get('Sucesso') if 'Sucesso' in ret else ret.get('success', False)
    if not success:
        resp_data = {
            'sucesso': success,
            # 'msg_erro': ret.get('Mensagem')
        }
        if 'Campos' in ret and ret.get:
            resp_data['erros'] = [
                {
                    'campo': k or ' - ',
                    'descricao': '\n'.join(v) or ''
                }
                for k, v in ret.get('Campos', {}).items()
            ]
        elif 'Mensagem' in ret:
            resp_data['msg_erro'] = ret.get('Mensagem').replace('Suporte', 'Suporte da FFCred') + (
                '\n' + ret.get('Erro')
                .replace('","', '\n')
                .replace('["', '\n')
                .replace('"]', '\n')
                if ret.get('Erro')
                else ''
            )
        elif 'error' in ret:
            resp_data['msg_erro'] = ret.get('error')

        return mount_xml_response(resp_data), ''

    resp_content = {
        'msg': ret.get('Mensagem')
    }

    resp_data = {
        'sucesso': success,
        'conteudo': resp_content
    }

    if 'CIOT' in ret:
        resp_content['ciot'] = ret.get('CIOT')
    elif 'ProtocoloCancelamento' in ret:
        resp_content['protocolo'] = ret.get('ProtocoloCancelamento')
    elif 'Ciots' in ret:
        resp_content['dados_ciot'] = ret.get('Ciots', [{}])[0]
    elif 'Data' in ret:
        resp_content['pagamentos'] = ret.get('Data', [])

    return mount_xml_response(resp_data), ''


#
# Funções utilitárias
#
def _get_list_acredited_data():
    req_str = _ffdigital.build_request(_ffdigital.context, FFDigital.LIST_ACREDITED)[0]
    url = _ffdigital.dispatch(FFDigital.LIST_ACREDITED, _ffdigital.context, 'url')[0]
    resp = post(url, json=json.loads(req_str))

    resp = _ffdigital.parse_response(
        {**{'resp': resp}, **_ffdigital.context},
        FFDigital.LIST_ACREDITED
    )[0]

    return json.loads(deep_get(xmltodict.parse(resp), 'resp.json', '{}'))


def _get_type_break(type_break: str, type_discont: str):
    if type_break in 'PFX' and type_discont == '1':
        type_break = 'desconto-percentual-ultrapassado'
    elif type_break in 'PF' and type_discont == '2':
        type_break = 'desconto-peso-ultrapassado'
    elif type_break in 'N':
        type_break = 'nenhum-desconto'
    elif type_break in 'IH':
        type_break = 'desconto-total-diferenca-tolerancia'
    # elif type_break in 'F':
    #   type_break = 'desconto-total-diferenca-tolerancia'
    return type_break


def _get_min_break(type_break: str, merc_weight: float, taxa_break: float):
    min_break = 0.0

    if type_break == 'desconto-percentual-ultrapassado':
        min_break = round_by_abnt(float(taxa_break))
    elif type_break == 'desconto-peso-ultrapassado':
        min_break = round_by_abnt((float(taxa_break) * float(merc_weight)) / 100)
    elif type_break == 'desconto-total-diferenca-tolerancia':
        min_break = round_by_abnt((float(taxa_break) * float(merc_weight)) / 100)
    return min_break


def _get_max_break(type_break: str, merc_weight: float, taxa_break: float):
    max_break = 0.0

    if type_break == 'desconto-percentual-ultrapassado':
        max_break = 100.0
    elif type_break == 'desconto-peso-ultrapassado':
        max_break = round_by_abnt(merc_weight)
    elif type_break == 'desconto-total-diferenca-tolerancia':
        max_break = round_by_abnt((float(taxa_break) * float(merc_weight)) / 100)
    return max_break
