import json
from typing import Tuple
from urllib.parse import urlparse

from future.backports.urllib.parse import urlunparse
from requests import Response, post

from dispacher import ActionProcessor
from dispacher.action_processor import HttpMethod
from dispacher.decorators import handle_exception_factory, parse_props
from geral import conditional_keys, conditional_key, deep_get, safe_cast, round_by_abnt
from geralxml import mount_xml_response


class FFCredException(Exception):
    pass


# ESSA FFCRED É NOVA, TODOS OS MÉTODOS DEVERAM SER DESENVOLVIDOS NESSE ARQUIVO
# Classe base
class FFCred(ActionProcessor):
    GENERATE_TOKEN = 1665
    GENERATE_CIOT = 1666
    CHECK_REQUESTS = 1667
    CONSULT_CIOT = 1668
    CANCEL_CIOT = 1669
    CLOSE_CIOT = 1670
    PAYMENT_PIX = 1671
    PAYMENT_TRC = 1672

    HOST = 'https://gatewaytms.tech4log.com'
    TEST_HOST = 'http://gatewaytms-homolog.tech4log.com'

    def __init__(self):
        self.BASE_PATH = '/api'

        self.add_callable_records('url', {
            self.GENERATE_TOKEN: self.make_url_assembler('/auth/login'),
            self.GENERATE_CIOT: self.make_url_assembler('/v1/ciots', ),
            self.CHECK_REQUESTS: self.make_url_assembler('/v1/ciots/check-requests', HttpMethod.GET),
            self.CONSULT_CIOT: self.make_url_assembler('/v1/ciots/$ciot', HttpMethod.GET, use_template=True),
            self.CANCEL_CIOT: self.make_url_assembler('/v1/ciots/$ciot/cancel', use_template=True),
            self.CLOSE_CIOT: self.make_url_assembler('/v1/ciots/$ciot/close', use_template=True),
            self.PAYMENT_PIX: self.make_url_assembler('/transactions/pix', ),
            self.PAYMENT_TRC: self.make_url_assembler('/transactions/trc'),
        })

        super().__init__()

    __token_cache: dict = {}

    @parse_props
    def get_headers(self, context_req: dict) -> Tuple[dict, str]:
        props = context_req.get('props', {})
        user = props.get('usuario', '')
        password = props.get('senha', '')

        if not user or not password:
            return {}, 'O usuario ou senha não foram informados!'

        try:
            auth_request = {
                'cpf_cnpj': user,
                'password': password
            }

            uri = self.context.get('url')
            parsed_uri = list(urlparse(uri))
            parsed_uri[2] = ''

            local_ctx = {
                'url': urlunparse(parsed_uri),
                'props': props
            }
            uri = self.dispatch(self.GENERATE_TOKEN, local_ctx, 'url')[0]
            resp = post(uri, data=auth_request)
        except Exception as e:
            return {}, 'O uErro ao buscar token de autorização na FFCred!\n' + str(e)

        resp_json = resp.json()

        if resp_json.get('success'):

            token = deep_get(resp_json, 'data.token', '')

            return {
                'Authorization': 'Bearer ' + token,
                'Content-Type': 'application/json'
            }, ''
        else:
            return {}, 'Por favor verifique as credenciais de acesso para FFCred!'


#
#   Códigos independentes de instancia
#

# Tratamento de exceções
def _ffcred_exception_callback(data: dict) -> Tuple[str, str]:
    return '', data.get('ex_message', 'Não foi possível recuperar a mensagem de erro ;(')


def any_exception_callback(data: dict) -> Tuple[str, str]:
    return '', 'Ocorreu um erro desconhecido ao comunicar com a F&FCred:\n' + data['ex_message']


_handle_exception = handle_exception_factory(
    FFCredException,
    _ffcred_exception_callback,
    any_exception_callback
)

#
#   Códigos dependentes de instancia
#

# Instancia limpa e sem configuração (singleton)
_ffcred = FFCred()

# Decorators da instancia
_link_to_request = _ffcred.link_to_factory('request')
_link_to_response = _ffcred.link_to_factory('response')


# Login paragerar o token Bearer para realizar as autenticações
@_link_to_request(_ffcred.GENERATE_TOKEN)
@_handle_exception
def _out_authenticate_user(props: dict):
    data = {
        "cpf_cnpj": props.get('usuario'),
        "password": props.get('senha')
    }

    return data, ''


@_link_to_request(FFCred.GENERATE_CIOT)
@_handle_exception
def _out_generate_ciot(req: dict) -> Tuple[str, str]:
    if req.get('conh_prop_tipoantt') == 3 and req.get('conh_veic_propriedade') in ['A', 'M', 'G']:
        tipo_viagem = 3
    else:
        tipo_viagem = 1

    type_break = _get_type_break(req.get('conh_tipodesc'), req.get('conh_tipotoler'))

    min_break = _get_min_break(type_break, req.get('conh_pesosaida'), req.get('conh_valortoler'))

    max_break = _get_max_break(type_break, req.get('conh_pesosaida'), req.get('conh_valortoler'))

    value_outros = (
            (safe_cast(req.get('conh_valorseguro'), float, 0) if req.get('conh_descsegurosaldomot') == 'S' else 0)
            + (safe_cast(req.get('conh_valorseguro2'), float, 0) if req.get('conh_descseguro2saldomot') == 'S' else 0)
            + safe_cast(req.get('conh_outrosdescontosmot'), float, 0)
            + safe_cast(req.get('conh_outrosdescontosmot2'), float, 0)
    )

    req_data = {
        'CpfCnpjContratado': req.get('conh_prop_cnpjcpf', ''),
        'NomeContratado': req.get('conh_prop_nome', ''),
        'RNTRCContratado': req.get('conh_prop_rntrc', ''),

        'Veiculos': list(filter(lambda x: not not x.get('Placa'), [
            {
                'RNTRC': req.get('conh_prop_rntrc', ''),
                'Placa': req.get('conh_veic_placa', '')
            },
            {
                'RNTRC': req.get('conh_car1_prop_rntrc') if req.get(
                    'conh_car1_prop_rntrc') else req.get('conh_prop_rntrc', ''),
                'Placa': req.get('conh_veic_placacarreta1', '')
            },
            {
                'RNTRC': req.get('conh_car2_prop_rntrc') if req.get(
                    'conh_car2_prop_rntrc') else req.get('conh_prop_rntrc', ''),
                'Placa': req.get('conh_veic_placacarreta2', '')
            },
            {
                'RNTRC': req.get('conh_car3_prop_rntrc') if req.get(
                    'conh_car3_prop_rntrc') else req.get('conh_prop_rntrc', ''),
                'Placa': req.get('conh_veic_placacarreta3', '')
            }
        ])),

        'CpfCnpjContratante': req.get('cnpj_empresa', '') if req.get('cnpj_empresa', '') else req.get(
            'conh_filial_cnpjcpf', ''),
        'CpfCnpjDestinatario': req.get('conh_mot_cpf', ''),  # !!!!!
        'CodigoMunicipioOrigem': req.get('conh_codibgeorig', ''),
        'CodigoMunicipioDestino': req.get('conh_codibgedest', ''),
        'CodigoNaturezaCarga': req.get('conh_ncm')[:4] if req.get('conh_ncm', '') else '0001',
        'PesoCarga': req.get('conh_pesosaida'),
        'DataInicioViagem': req.get('conh_datafimcarregamento')[0:10],
        **conditional_key(
            'DataFimViagem', req.get('conh_dataprevisaodescarga')[0:10],
            not not req.get('conh_dataprevisaodescarga')[0:10]
        ),
        # 1 — Padrão 3 — TAC Agregado
        'TipoViagem': tipo_viagem,
        **conditional_key('RNTRCContratante', req.get('conh_filial_rntrc'), tipo_viagem == 3),
        'QuantidadeTarifas': 0,
        'ValorTarifas': 0,
        'ValorFreteTotal': req.get('conh_valorviagem'),
        'cte': req.get('conh_numconhec'),
        'IRRF': req.get('conh_impirrf'),
        'INSS': req.get('conh_impinss'),
        'SEST_SENAT': req.get('conh_impsestsenat'),
        'Outros': value_outros,
        **conditional_key(
            'CriterioAceite', req.get('ff_criterios', '').split(','),  ##Comprovantes
            not not req.get('ff_criterios', '').strip()
        ),
        'TipoDeQuebra': type_break,
        'LimiteMinQuebra': min_break,
        'LimiteMaxQuebra': max_break,
        'CodigoInterno': req.get('conh_numero'),
        'ValorMercadoriaTotal': req.get('conh_valormerc'),
        'Pedagio': req.get('conh_valorpedagio'),

        **conditional_keys(req.get('conh_tipodesc') in 'XFHPIN', {
            **conditional_key('DiferencaFrete', 'saida', req.get('conh_tipodesc') == 'P'),
            **conditional_key('DiferencaFrete', 'saida', req.get('conh_tipodesc') == 'I'),
            **conditional_key('DiferencaFrete', 'saida', req.get('conh_tipodesc') == 'N'),
            **conditional_key('DiferencaFrete', 'chegada-menor-saida', req.get('conh_tipodesc') == 'X'),
            **conditional_key('DiferencaFrete', 'chegada-com-tolerancia', req.get('conh_tipodesc') == 'F'),
            **conditional_key('DiferencaFrete', 'chegada-menor-saida', req.get('conh_tipodesc') == 'H'),
            # **conditional_key('DiferencaFrete', 'chegada-com-tolerancia-desconto-integral', req.get('conh_tipodesc') == 'H'),
            # 'DiferencaFrete': 'chegada-menor-saida',
            'DiferencaFreteTolerancia': round_by_abnt(
                float(req.get('conh_pesosaida')) * float(req.get('conh_valortoler')) / 100
            ),
        }),

        'PagarMotorista': 'sim' if req.get('ff_favorecido') == 'M' else 'nao',
        'CpfCnpjMotorista': req.get('conh_mot_cpf', ''),
        'DescricaoFilial': '',
        'PagtoContaDigital': 0,
        'NomeMotorista': req.get('conh_mot_nome', ''),
        'Parcelas': [
            dict_.update({'NumeroParcela': index + 1}) or dict_
            for (index, dict_) in enumerate(
                filter(lambda x: not not x.get('Valor'), [
                    {
                        'CodigoInterno': req.get('ff_codparcela_adto'),  # Adiantamento (Orientado pelo Leonardo da F&F)
                        'DataVencimento': req.get('ff_venc_faturas')[0:10],
                        'Valor': safe_cast(req.get('conh_valoradiant'), float, 0),
                        'CategoriaPagamento': 'Adiantamento',
                    },
                    {
                        'CodigoInterno': req.get('ff_codparcela_saldo'),  # Saldo (Orientado pelo Leonardo da F&F)
                        'DataVencimento': req.get('ff_venc_faturas')[0:10],
                        'Valor': safe_cast(req.get('conh_valorsaldo'), float, 0),
                        'CategoriaPagamento': 'Saldo',
                    }
                ])
            )
        ]
    }

    # 'taxa_quebra': round(float(req.get('conh_valormerc')) / float(req.get('conh_pesosaida')), 5),
    #
    # 'taxa_recalculo': safe_cast(req.get('conh_precotonempresa').replace(',', '.', 1), float) / 1000 if type(
    #     req.get('conh_precotonempresa')) is str else req.get('conh_precotonempresa') / 1000,  # ppt empresa

    return json.dumps(req_data), ''


@_link_to_request(FFCred.CHECK_REQUESTS)
@_handle_exception
def _out_check_request_ciot(req: dict) -> Tuple[str, str]:
    req_data = {
        'ids': [
            req.get('ids_check_request')
        ]
    }

    return json.dumps(req_data), ''


@_link_to_request(FFCred.CANCEL_CIOT)
@_handle_exception
def _out_cancel_ciot(req: dict) -> Tuple[str, str]:
    req_data = {
        'Motivo': req.get('motivo_cancelamento')
    }

    return json.dumps(req_data), ''


@_link_to_request(FFCred.PAYMENT_PIX, FFCred.PAYMENT_TRC)
@_handle_exception
def _out_payment_ciot(req: dict) -> Tuple[str, str]:
    req_data = {
        'protocol': req.get('ciot'),
        'to_driver': req.get('pagamento_favorecido'),
        'parcel_number': req.get('numero_parcela'),
        'bank_account': {
            'bank_number': req.get('numero_banco'),
            'branch': req.get('agencia'),
            'account_number': req.get('numero_conta'),
            'account_digit': req.get('digito_conta'),
            'account_type': req.get('tipo_conta')
        },

        **conditional_keys(
            req.get('tipo_pagamento') == 'S',
            {
                'end_weight': safe_cast(req.get('peso_chegada', 0), float, 0),
                'delivery_date': req.get('data_entrega', '')[0:10]
            },
        ),
    }

    return json.dumps(req_data), ''


@_link_to_request(FFCred.DEFAULT_FUNCTION)
@_handle_exception
def _out_default() -> Tuple[None, str]:
    return None, ''


#
# Tratamento de retornos
@_link_to_response(FFCred.DEFAULT_FUNCTION)
@_handle_exception
def _in_default(resp: Response) -> Tuple[str, str]:
    ret = resp.json()

    try:
        sucess = ret.get('success')

        if not sucess:
            resp_data = {
                'sucesso': sucess,
            }
            if 'code' in ret and type(ret.get('error')) != dict:

                resp_data = {
                    'sucesso': False,
                    'msg_erro': ret.get('error')
                }

            elif 'error' in ret and ret.get:
                resp_data['erros'] = [
                    {
                        'campo': k or ' - ',
                        'descricao': '\n'.join(v) or ''
                    }
                    for k, v in ret.get('error', {}).items()
                ]
        else:
            resp_data = {
                'sucesso': sucess,
                'conteudo': ret.get('data', '')
            }
    except Exception as e:
        resp_data = {
            'sucesso': False,
            'msg_erro': 'Ocorreu um erro desconhecido ao tentar retornar as informações do EmonitorPy:\n' + str(e)
        }

    return mount_xml_response(resp_data), ''


#
# Funções utilitárias
#

def _get_type_break(type_break: str, type_discont: str):
    if type_break in 'PFX' and type_discont == '1':
        type_break = 'desconto-percentual-ultrapassado'
    elif type_break in 'PF' and type_discont == '2':
        type_break = 'desconto-peso-ultrapassado'
    elif type_break in 'N':
        type_break = 'nenhum-desconto'
    elif type_break in 'IH':
        type_break = 'desconto-total-diferenca-tolerancia'
    # elif type_break in 'F':
    #   type_break = 'desconto-total-diferenca-tolerancia'
    return type_break


def _get_min_break(type_break: str, merc_weight: float, taxa_break: float):
    min_break = 0.0

    if type_break == 'desconto-percentual-ultrapassado':
        min_break = round_by_abnt(float(taxa_break))
    elif type_break == 'desconto-peso-ultrapassado':
        min_break = round_by_abnt((float(taxa_break) * float(merc_weight)) / 100)
    elif type_break == 'desconto-total-diferenca-tolerancia':
        min_break = round_by_abnt((float(taxa_break) * float(merc_weight)) / 100)
    return min_break


def _get_max_break(type_break: str, merc_weight: float, taxa_break: float):
    max_break = 0.0

    if type_break == 'desconto-percentual-ultrapassado':
        max_break = 100.0
    elif type_break == 'desconto-peso-ultrapassado':
        max_break = round_by_abnt(merc_weight)
    elif type_break == 'desconto-total-diferenca-tolerancia':
        max_break = round_by_abnt((float(taxa_break) * float(merc_weight)) / 100)
    return max_break
