import json
import time
from datetime import date
from typing import Tuple

from ActionProcessor import handle_exception_factory
from geraljson import *
from geralxml import dict_to_xml

ACAO_EXTRATTA_INICIO = 1300
ACAO_EXTRATTA_CADASTRARPROPRIETARIO = 1301
ACAO_EXTRATTA_CADASTRARVEICULO = 1302
ACAO_EXTRATTA_CADASTRARCARRETA1 = 1303
ACAO_EXTRATTA_CADASTRARCARRETA2 = 1304
ACAO_EXTRATTA_CADASTRARCARRETA3 = 1305
ACAO_EXTRATTA_CADASTRARMOTORISTA = 1306
ACAO_EXTRATTA_CADASTRARCLIENTE = 1307
ACAO_EXTRATTA_VINCULARCARTAOPROP = 1308
ACAO_EXTRATTA_VINCULARCARTAOMOT = 1309
ACAO_EXTRATTA_CADASTRARVIAGEM = 1310
ACAO_EXTRATTA_AJUSTEFINANCEIRO = 1311
ACAO_EXTRATTA_BAIXARVIAGEM = 1312
ACAO_EXTRATTA_CANCELARVIAGEM = 1313
ACAO_EXTRATTA_CONSULTAPEDAGIO = 1314
ACAO_EXTRATTA_CADASTRARDESTINATARIO = 1316
ACAO_EXTRATTA_CADASTRARREMETENTE = 1317

ACAO_EXTRATTA_FIM = 1349


def requestExtrattaCadastrarProprietario(reqJSON, properties):
    try:
        req = {}
        isPf = len(getJSON(reqJSON, 'prop_cnpjcpf')) == 11
        req['CNPJAplicacao'] = properties['CNPJAplicacao']
        req['Token'] = properties['Token']
        req['CNPJEmpresa'] = properties['CNPJAplicacao']
        req['CnpjCpf'] = getJSON(reqJSON, 'prop_cnpjcpf')
        req['RazaoSocial'] = getJSON(reqJSON, 'prop_nome')
        req['NomeFantasia'] = getJSON(reqJSON, 'prop_nome')
        if isPf:
            req['RG'] = getJSON(reqJSON, 'prop_rg')
            req['RGOrgaoExpedidor'] = getJSON(reqJSON, 'prop_orgaorg')
        else:
            req['IE'] = getJSON(reqJSON, 'prop_ie')
        req['RNTRC'] = getJSON(reqJSON, 'prop_rntrc')
        req['TipoContrato'] = getTipoContrato(getJSON(reqJSON, 'prop_agregado'))
        dataNasc = getJSON(reqJSON, 'prop_datanasc')
        if dataNasc != '':
            req['DataNascimento'] = dataNasc
        inss = getJSON(reqJSON, 'prop_cei')
        if inss != '':
            req['INSS'] = inss
        # req['Referencia1'] = '' nao é obrigatorio
        # req['Referencia2'] = '' nao é obrigatorio
        arrayContato = []
        contato = {}
        email = getJSON(reqJSON, 'prop_email')
        if email != '':
            contato['Email'] = email
        telefoneFixo = getJSON(reqJSON, 'prop_foneddd') + getJSON(reqJSON, 'prop_fonenumero')
        celular = getJSON(reqJSON, 'prop_celularddd') + getJSON(reqJSON, 'prop_celularnumero')
        if telefoneFixo != '' and celular != '':
            contato['Telefone'] = telefoneFixo
            contato['Celular'] = celular
        elif (telefoneFixo == '') and celular != '':
            contato['Telefone'] = celular
        elif telefoneFixo != '':
            contato['Telefone'] = telefoneFixo
        arrayContato.append(contato)
        req['Contatos'] = arrayContato
        arrayEndereco = []
        endereco = {}
        endereco['CEP'] = getJSON(reqJSON, 'prop_cep')
        endereco['Endereco'] = getJSON(reqJSON, 'prop_endereco')
        complemento = getJSON(reqJSON, 'prop_complemento')
        if complemento != '':
            endereco['Complemento'] = complemento
        numero = getJSON(reqJSON, 'prop_numero')
        if numero != '' and numero != 'SN' and numero != 'S/N':
            endereco['Numero'] = numero
        endereco['Bairro'] = getJSON(reqJSON, 'prop_bairro')
        ibge = getJSON(reqJSON, 'prop_codibge')
        ibgeEstado = ibge[:2]
        endereco['IBGECidade'] = int(ibge)
        endereco['IBGEEstado'] = int(ibgeEstado)
        endereco['BACENPais'] = 1058
        if isPf:
            endereco['NomeMae'] = getJSON(reqJSON, 'prop_nomemae')
            nomePai = getJSON(reqJSON, 'prop_nomepai')
            if nomePai != '':
                endereco['NomePai'] = nomePai
            else:
                endereco['NomePai'] = 'NÃO INFORMADO'

        arrayEndereco.append(endereco)
        req['Enderecos'] = arrayEndereco
        return json.dumps(req), ''
    except Exception as e:
        print('Erro em responsePagBemConsultarAbastecimento')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseRasterCadastrarGeral(resp, msgSucesso):
    try:
        ret = resp.content.decode('utf-8')
        root = json.loads(ret)
        sucesso = getJSON(root, 'Sucesso')
        if sucesso:
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msgSucesso + '!</msg></resp>', ''
        else:
            mensagem = getJSON(root, 'Mensagem')
            mensagem = mensagem.replace('<br/>', '').replace('</br>', '')
            # if acao == ACAO_EXTRATTA_CADASTRARDESTINATARIO:
            #     mensagem = 'Destinatário: ' + mensagem
            # elif acao == ACAO_EXTRATTA_CADASTRARREMETENTE:
            #     mensagem = 'Remetente: ' + mensagem
            # elif acao == ACAO_EXTRATTA_CADASTRARCLIENTE:
            #     mensagem = 'Cliente: ' + mensagem

            return '', mensagem
    except Exception as e:
        print('Erro em responseRasterCadastrarGeral')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO'


def responseExtrattaCadastrarProprietario(resp):
    try:
        return responseRasterCadastrarGeral(resp, 'Proprietario cadastrado com sucesso!')
    except Exception as e:
        print('Erro em responseExtrattaCadastrarProprietario')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO'


def requestExtrattaCadastrarVeiculo(reqJSON, properties, codEMonitorAcao):
    try:
        prefixTag = ''
        if codEMonitorAcao == ACAO_EXTRATTA_CADASTRARVEICULO:
            prefixTag = 'veic_'
        elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARCARRETA1:
            prefixTag = 'car1_'
        elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARCARRETA2:
            prefixTag = 'car2_'
        elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARCARRETA3:
            prefixTag = 'car3_'
        req = {}
        req['CNPJAplicacao'] = properties['CNPJAplicacao']
        req['Token'] = properties['Token']
        req['CPFCNPJProprietario'] = getJSON(reqJSON, 'prop_cnpjcpf')
        # req['CPFMotorista'] = '' nao é obrigatório
        req['CNPJEmpresa'] = properties['CNPJAplicacao']
        req['Placa'] = getJSON(reqJSON, prefixTag + 'placa')
        req['Chassi'] = getJSON(reqJSON, prefixTag + 'chassi')
        if getJSON(reqJSON, prefixTag + 'renavam') != '':
            req['Renavam'] = int(getJSON(reqJSON, prefixTag + 'renavam'))
        if getJSON(reqJSON, prefixTag + 'anofab') != '':
            req['AnoFabricacao'] = int(getJSON(reqJSON, prefixTag + 'anofab'))
        if getJSON(reqJSON, prefixTag + 'anomod') != '':
            req['AnoModelo'] = int(getJSON(reqJSON, prefixTag + 'anomod'))
        req['Marca'] = getJSON(reqJSON, prefixTag + 'marca')
        req['Modelo'] = getJSON(reqJSON, prefixTag + 'modelo')
        if codEMonitorAcao == ACAO_EXTRATTA_CADASTRARVEICULO:
            req['ComTracao'] = True
        else:
            req['ComTracao'] = False
        # req['IdTipoCarreta'] = '' nao obrig
        propriedade = getJSON(reqJSON, prefixTag + 'propriedade')
        req['TipoContrato'] = getTipoContratoVeic(propriedade)
        if getJSON(reqJSON, prefixTag + 'quanteixos') != '':
            req['QuantidadeEixos'] = int(getJSON(reqJSON, prefixTag + 'quanteixos'))
        # req['IdTipoCavalo'] = '' nao obrig
        # req['TecnologiaRastreamento'] = '' nao obrig
        # req['NumeroFrota'] = '' nao obrig
        # req['CodigoDaOperacao'] = '' nao obrig
        # req['Município'] = '' nao obrig
        # req['CNPJFilial'] = '' nao obrig
        # req['IdTecnologia'] = '' nao obrig
        if getJSON(reqJSON, prefixTag + 'codibge') != '':
            req['IBGECidade'] = int(getJSON(reqJSON, prefixTag + 'codibge'))
        return json.dumps(req), ''
    except Exception as e:
        print('Erro em requestExtrattaCadastrarVeiculo')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseExtrattaCadastrarVeiculo(resp, codEMonitorAcao):
    entidade = ''
    if codEMonitorAcao == ACAO_EXTRATTA_CADASTRARVEICULO:
        entidade = 'Veículo cadastrado com sucesso!'
    elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARCARRETA1:
        entidade = 'Carreta1 cadastrada com sucesso!'
    elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARCARRETA2:
        entidade = 'Carreta2 cadastrada com sucesso!'
    elif codEMonitorAcao == ACAO_EXTRATTA_CADASTRARCARRETA3:
        entidade = 'Carreta3 cadastrada com sucesso!'
    try:
        return responseRasterCadastrarGeral(resp, entidade)
    except Exception as e:
        print('Erro em responseExtrattaCadastrarVeiculo')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO'


def requestExtrattaCadastrarMotorista(reqJSON, properties):
    try:
        req = {}
        req['CNPJAplicacao'] = properties['CNPJAplicacao']
        req['Token'] = properties['Token']
        req['CPFCNPJUsuario'] = getJSON(reqJSON, 'mot_cnh')
        req['CNPJEmpresa'] = properties['CNPJAplicacao']
        req['Nome'] = getJSON(reqJSON, 'mot_nome')
        req['RG'] = getJSON(reqJSON, 'mot_rg')
        req['RGOrgaoExpedidor'] = getJSON(reqJSON, 'mot_orgaorg')
        req['CPF'] = getJSON(reqJSON, 'mot_cpf')
        req['Sexo'] = getJSON(reqJSON, 'mot_sexo')
        req['CNH'] = getJSON(reqJSON, 'mot_cnh')
        req['CNHCategoria'] = getJSON(reqJSON, 'mot_catcnh')
        req['ValidadeCNH'] = getJSON(reqJSON, 'mot_datavalidcnh')
        celular = getJSON(reqJSON, 'mot_celularddd') + getJSON(reqJSON, 'mot_celularnumero')
        if celular != '':
            req['Celular'] = celular
        if getJSON(reqJSON, 'mot_funcionario') == 'S':
            req['TipoContrato'] = 1
        else:
            req['TipoContrato'] = 3
        req['Email'] = getJSON(reqJSON, 'mot_email')
        # req['Foto'] = ''
        req['CEP'] = getJSON(reqJSON, 'mot_cep')
        req['Endereco'] = getJSON(reqJSON, 'mot_endereco')
        complemento = getJSON(reqJSON, 'mot_complemento')
        if complemento != '':
            req['Complemento'] = complemento
        numero = getJSON(reqJSON, 'mot_numero')
        if numero != '' and numero != 'SN' and numero != 'S/N':
            req['Numero'] = numero
        req['Bairro'] = getJSON(reqJSON, 'mot_bairro')
        ibge = getJSON(reqJSON, 'mot_codibge')
        ibgeEstado = ibge[:2]
        req['IBGECidade'] = ibge
        req['IBGEEstado'] = ibgeEstado
        req['BACENPais'] = 1058
        req['NomeMae'] = getJSON(reqJSON, 'mot_nomemae')
        nomePai = getJSON(reqJSON, 'mot_nomepai')
        if nomePai != '':
            req['NomePai'] = nomePai
        else:
            req['NomePai'] = 'NÃO INFORMADO'
        req['DataNascimento'] = getJSON(reqJSON, 'mot_datanasc')
        return json.dumps(req), ''
    except Exception as e:
        print('Erro em requestExtrattaCadastrarMotorista')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseExtrattaCadastrarMotorista(resp):
    try:
        return responseRasterCadastrarGeral(resp, 'Motorista cadastrado com sucesso!')
    except Exception as e:
        print('Erro em responseExtrattaCadastrarMotorista')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO'


def requestExtrattaCadastrarCliente(reqJSON, properties):
    try:
        req = {}
        isPf = len(getJSON(reqJSON, 'cliente_cnpjcpf')) == 11
        if isPf:
            tipoPessoa = 1
        else:
            tipoPessoa = 2
        ibge = getJSON(reqJSON, 'cliente_codibge')
        ibgeEstado = ibge[:2]
        nome = getJSON(reqJSON, 'cliente_nome')
        nomefantasia = getJSON(reqJSON, 'cliente_nomefantasia')
        celular = getJSON(reqJSON, 'cliente_celularddd') + getJSON(reqJSON, 'cliente_celularnumero')
        if nomefantasia == '':
            nomefantasia = nome
        email = getJSON(reqJSON, 'cliente_email')
        complemento = getJSON(reqJSON, 'cliente_complemento')
        numero = getJSON(reqJSON, 'cliente_numero')
        lat = getJSON(reqJSON, 'cliente_lat')
        lon = getJSON(reqJSON, 'cliente_lon')
        raio = getJSON(reqJSON, 'cliente_raio')
        req['CNPJAplicacao'] = properties['CNPJAplicacao']
        req['Token'] = properties['Token']
        req['CNPJEmpresa'] = properties['CNPJAplicacao']
        # req['IdCliente'] = '' # nao vou vandar :(
        req['BACENPais'] = 1058  # depois eu vejo
        req['IBGEEstado'] = int(ibgeEstado)
        req['IBGECidade'] = int(ibge)
        req['RazaoSocial'] = nome
        req['NomeFantasia'] = nomefantasia
        req['TipoPessoa'] = tipoPessoa
        req['CNPJCPF'] = getJSON(reqJSON, 'cliente_cnpjcpf')
        if isPf:
            req['RG'] = getJSON(reqJSON, 'cliente_rg')
            # req['OrgaoExpedidorRG'] = ''#nao tem no bd
        else:
            req['IE'] = getJSON(reqJSON, 'cliente_ie')
        if celular != '':
            req['Celular'] = celular
        if email != '':
            req['Email'] = email
        req['CEP'] = getJSON(reqJSON, 'cliente_cep')
        req['Endereco'] = getJSON(reqJSON, 'cliente_endereco')
        if complemento != '':
            req['Complemento'] = complemento
        if numero != '' and numero != 'SN' and numero != 'S/N':
            req['Numero'] = numero
        req['Bairro'] = getJSON(reqJSON, 'cliente_bairro')
        if lat != '':
            req['Latitude'] = getJSON(reqJSON, 'cliente_lat')
        if lon != '':
            req['Longitude'] = getJSON(reqJSON, 'cliente_lon')
        if raio != '':
            req['RaioLocalizacao'] = getJSON(reqJSON, 'cliente_raio')
        # req['ObrigarCPFReceber'] = ''
        # req['PermitirAlterarData'] = ''
        # req['EnviarSMSConfirmacao'] = ''
        # req['EnviarEmailConfirmacao'] = ''
        # req['AutenticarCodigoBarraNF'] = ''
        # req['ModeloImpressao'] = ''
        return json.dumps(req), ''
    except Exception as e:
        print('Erro em requestExtrattaCadastrarCliente')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseExtrattaCadastrarCliente(resp):
    try:
        return responseRasterCadastrarGeral(resp, ' cadastrado com sucesso!')
    except Exception as e:
        print('Erro em responseExtrattaCadastrarCliente')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO'


def requestExtrattaVincularCartaoProp(reqJSON, properties):
    try:
        req = {}
        req['CNPJAplicacao'] = properties['CNPJAplicacao']
        req['Token'] = properties['Token']
        req['CNPJEmpresa'] = properties['CNPJAplicacao']
        req['NumeroCartao'] = getJSON(reqJSON, 'prop_numerocartao')
        req['Documento'] = getJSON(reqJSON, 'prop_cnpjcpf')
        return json.dumps(req), ''
    except Exception as e:
        print('Erro em requestExtrattaVincularCartaoProp')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseExtrattaVincularCartaoProp(resp):
    try:
        return responseRasterCadastrarGeral(resp, 'Cartão vinculado ao Proprietário com sucesso!')
    except Exception as e:
        print('Erro em responseExtrattaVincularCartaoProp')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO'


def requestExtrattaVincularCartaoMot(reqJSON, properties):
    try:
        req = {}
        req['CNPJAplicacao'] = properties['CNPJAplicacao']
        req['Token'] = properties['Token']
        req['CNPJEmpresa'] = properties['CNPJAplicacao']
        req['NumeroCartao'] = getJSON(reqJSON, 'mot_numerocartao')
        req['Documento'] = getJSON(reqJSON, 'mot_cpf')
        return json.dumps(req), ''
    except Exception as e:
        print('Erro em requestExtrattaVincularCartaoMot')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseExtrattaVincularCartaoMot(resp):
    try:
        return responseRasterCadastrarGeral(resp, 'Cartão vinculado ao Motorista com sucesso!')
    except Exception as e:
        print('Erro em responseExtrattaVincularCartaoMot')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO'


@handle_exception_factory()
def requestExtrattaCadastrarViagem(reqJSON, properties):
    req = {}
    req['IdViagem'] = getJSON(reqJSON, 'conh_id')
    req['CNPJAplicacao'] = properties['CNPJAplicacao']
    req['CNPJEmpresa'] = properties['CNPJAplicacao']
    req['Token'] = properties['Token']
    req['CPFCNPJClienteDestino'] = getJSON(reqJSON, 'conh_dest_cnpjcpf')
    req['CPFCNPJClienteOrigem'] = getJSON(reqJSON, 'conh_rem_cnpjcpf')
    # req['CPFCNPJClienteTomador'] = getJSON(reqJSON, 'conh_rem_cnpjcpf') #nao obrig
    req['CPFCNPJProprietario'] = getJSON(reqJSON, 'conh_prop_cnpjcpf')  # nao obrig
    # req['NomeProprietario'] = getJSON(reqJSON, 'conh_rem_cnpjcpf') #nao obrig
    req['RNTRC'] = getJSON(reqJSON, 'conh_prop_rntrc')
    req['CNPJFilial'] = getJSON(reqJSON, 'conh_filial_cnpjcpf')
    req['RazaoSocialFilial'] = getJSON(reqJSON, 'conh_filial_nome')
    req['CPFMotorista'] = getJSON(reqJSON, 'conh_mot_cpf')
    # req['IdCarga'] = ''
    req['Placa'] = getJSON(reqJSON, 'conh_veic_placa')
    req['DataColeta'] = getJSON(reqJSON, 'conh_dataemissao')
    req['DataPrevisaoEntrega'] = getJSON(reqJSON, 'conh_dataprevisaodescarga')
    req['StatusViagem'] = 1
    req['StatusIntegracao'] = 1
    req['ForcarCiotNaoEquiparado'] = reqJSON.get('extratta_ciotnaoequiparado', False)
    arrayCarretas = []
    if getJSON(reqJSON, 'conh_veic_placacarreta1') != '':
        arrayCarretas.append(getJSON(reqJSON, 'conh_veic_placacarreta1'))
    if getJSON(reqJSON, 'conh_veic_placacarreta2') != '':
        arrayCarretas.append(getJSON(reqJSON, 'conh_veic_placacarreta2'))
    if getJSON(reqJSON, 'conh_veic_placacarreta3') != '':
        arrayCarretas.append(getJSON(reqJSON, 'conh_veic_placacarreta3'))
    if len(arrayCarretas) > 0:
        req['Carretas'] = arrayCarretas
    req['DocumentoCliente'] = getJSON(reqJSON, 'conh_numero')
    req['PesoSaida'] = float(getJSON(reqJSON, 'conh_pesosaida'))
    if getJSON(reqJSON, 'conh_enviarpedagio') == 'S':
        req['ValorPedagio'] = float(getJSON(reqJSON, 'conh_valorpedagio'))
    req['ValorMercadoria'] = float(getJSON(reqJSON, 'conh_valormerc'))
    if float(getJSON(reqJSON, 'conh_impirrf')) > 0:
        req['IRRPF'] = float(getJSON(reqJSON, 'conh_impirrf'))
    if float(getJSON(reqJSON, 'conh_impinss')) > 0:
        req['INSS'] = float(getJSON(reqJSON, 'conh_impinss'))
    if float(getJSON(reqJSON, 'conh_impsestsenat')):
        req['SESTSENAT'] = float(getJSON(reqJSON, 'conh_impsestsenat'))
    req['NumeroDocumento'] = getJSON(reqJSON, 'conh_numconhec')
    req['DataEmissao'] = getJSON(reqJSON, 'conh_dataemissao')
    req['Produto'] = getJSON(reqJSON, 'conh_descmerc')
    req['Unidade'] = 0
    req['Quantidade'] = float(getJSON(reqJSON, 'conh_quantmerc'))
    req['Coleta'] = getJSON(reqJSON, 'conh_rem_endereco') + ', ' + getJSON(reqJSON, 'conh_rem_numero')
    req['Entrega'] = getJSON(reqJSON, 'conh_dest_endereco') + ', ' + getJSON(reqJSON, 'conh_dest_numero')
    req['NumeroCartao'] = getJSON(reqJSON, 'conh_numerocartao')
    req['HabilitarDeclaracaoCiot'] = True
    if getJSON(reqJSON, 'conh_ncm') != '':
        req['NaturezaCarga'] = int(getJSON(reqJSON, 'conh_ncm'))
    req['NumeroControle'] = getJSON(reqJSON, 'conh_numero') + '_' + str(time.time())
    if getJSON(reqJSON, 'conh_tpambop') == '0':
        req['CEPOrigem'] = getJSON(reqJSON, 'conh_ceporig')
        req['CEPDestino'] = getJSON(reqJSON, 'conh_cepdest')
        if getJSON(reqJSON, 'conh_tipocarga') != '':
            req['CodigoTipoCarga'] = int(getJSON(reqJSON, 'conh_tipocarga'))
        else:
            req['CodigoTipoCarga'] = 0
        if getJSON(reqJSON, 'conh_kmrodado') != '':
            req['DistanciaViagem'] = int(getJSON(reqJSON, 'conh_kmrodado'))
        else:
            req['DistanciaViagem'] = 0
    dadosPagamento = {}
    if getJSON(reqJSON, 'conh_formapagtoopcartao') == 'R':
        dadosPagamento['FormaPagamento'] = 1
    elif getJSON(reqJSON, 'conh_formapagtoopcartao') == 'T':
        if getJSON(reqJSON, 'conh_tipoconta') == '1':  # conta corrente
            dadosPagamento['FormaPagamento'] = 2
        elif getJSON(reqJSON, 'conh_tipoconta') == '2':  # conta poupanca
            dadosPagamento['FormaPagamento'] = 3
        elif getJSON(reqJSON, 'conh_tipoconta') == '3':  # conta pagamentos
            dadosPagamento['FormaPagamento'] = 4
        dadosPagamento['CodigoBacen'] = getJSON(reqJSON, 'conh_codbanco')
        dadosPagamento['Agencia'] = getJSON(reqJSON, 'conh_agencia')
        dadosPagamento['Conta'] = getJSON(reqJSON, 'conh_conta')
    else:
        dadosPagamento['FormaPagamento'] = 5
    req['DadosPagamento'] = dadosPagamento
    dadosAntt = {}
    if getJSON(reqJSON, 'conh_tpambop') == '0':
        if getJSON(reqJSON, 'conh_altodesemp') == 'true':
            dadosAntt['AltoDesempenho'] = True
        else:
            dadosAntt['AltoDesempenho'] = False
        dadosAntt['DestinacaoComercial'] = True
        dadosAntt['FreteRetorno'] = False
    req['DadosAntt'] = dadosAntt
    arrayViagemRegra = []
    viagemRegra = {}
    viagemRegra['TaxaAntecipacao'] = 0
    viagemRegra['ToleranciaPeso'] = float(getJSON(reqJSON, 'conh_valortoler'))
    valorMerc = float(getJSON(reqJSON, 'conh_valormerc'))
    pesoSaida = float(getJSON(reqJSON, 'conh_pesosaida'))
    valorTonMerc = valorMerc / pesoSaida * 1000
    viagemRegra['TarifaTonelada'] = valorTonMerc
    viagemRegra['TipoQuebraMercadoria'] = getTipoQuebraMercadoria(getJSON(reqJSON, 'conh_tipodesc'))
    arrayViagemRegra.append(viagemRegra)
    req['ViagemRegra'] = arrayViagemRegra
    req['ViagemEstabelecimentos'] = []
    arrayViagemEventos = []
    if float(getJSON(reqJSON, 'conh_valoradiant')) > 0:
        eventoAdto = {}
        # eventoAdto['IdViagemEvento'] = ''
        eventoAdto['TipoEvento'] = 0
        eventoAdto['ValorPagamento'] = float(getJSON(reqJSON, 'conh_valoradiant'))
        eventoAdto['Status'] = 0
        # eventoAdto['DataValidade'] = 0
        # eventoAdto['IRRPF'] = 0
        # eventoAdto['INSS'] = 0
        # eventoAdto['SESTSENAT'] = 0
        # eventoAdto['Instrucao'] = 0
        # eventoAdto['ValorBruto'] = 0
        # eventoAdto['IdMotivo'] = 0
        eventoAdto['HabilitarPagamentoCartao'] = getJSON(reqJSON, 'conh_formapagtoopcartao') != 'O'
        # eventoAdto['NumeroControle'] = True
        arrayViagemEventos.append(eventoAdto)
    eventoSaldo = {}
    eventoSaldo['TipoEvento'] = 1
    eventoSaldo['ValorPagamento'] = float(getJSON(reqJSON, 'conh_valorsaldo'))
    eventoSaldo['Status'] = 0
    # eventoSaldo['DataValidade'] = 0
    # eventoSaldo['IRRPF'] = 0
    # eventoSaldo['INSS'] = 0
    # eventoSaldo['SESTSENAT'] = 0
    # eventoSaldo['Instrucao'] = 0
    # eventoSaldo['ValorBruto'] = 0
    # eventoSaldo['IdMotivo'] = 0
    eventoSaldo['HabilitarPagamentoCartao'] = getJSON(reqJSON, 'conh_formapagtoopcartao') != 'O'
    # eventoAdto['NumeroControle'] = True
    arrayViagemEventos.append(eventoSaldo)
    req['ViagemEventos'] = arrayViagemEventos
    req['ViagemDocumentos'] = []
    req['ViagemOutrosDescontos'] = []
    if (getJSON(reqJSON, 'conh_enviarpedagio') == 'S'):
        objPedagio = {}
        if getJSON(reqJSON, 'conh_fornecedorpedagio') != '':
            objPedagio['Fornecedor'] = int(getJSON(reqJSON, 'conh_fornecedorpedagio'))
        objPedagio['IdentificadorHistorico'] = getJSON(reqJSON, 'conh_tokenpedagio')
    else:
        objPedagio = {}
        objPedagio['Fornecedor'] = 0
        objPedagio['IdentificadorHistorico'] = ''
    req['Pedagio'] = objPedagio
    arrayDocumentosFiscais = []
    objCte = {}
    # objCte['IdViagemDocumentoFiscal'] = ''
    if getJSON(reqJSON, 'conh_numconhec') != '':
        objCte['NumeroDocumento'] = int(getJSON(reqJSON, 'conh_numconhec'))
    objCte['Serie'] = getJSON(reqJSON, 'conh_serie')
    objCte['PesoSaida'] = float(getJSON(reqJSON, 'conh_pesosaida'))
    # objCte['Valor'] = getJSON(reqJSON, '') # valor do frete fiscal
    objCte['TipoDocumento'] = 1
    arrayDocumentosFiscais.append(objCte)
    qtdeNfs = int(getJSON(reqJSON, 'conh_ctnfs'))
    for i in range(1, qtdeNfs + 1, 1):
        objNf = {}
        objNf['NumeroDocumento'] = int(getJSON(reqJSON, 'conh_numnf' + str(i)))
        objNf['Serie'] = getJSON(reqJSON, 'conh_serienf' + str(i))
        objNf['PesoSaida'] = float(getJSON(reqJSON, 'conh_quantnf' + str(i)))
        objNf['Valor'] = float(getJSON(reqJSON, 'conh_valornf' + str(i)))
        objNf['TipoDocumento'] = 4
        arrayDocumentosFiscais.append(objNf)
    req['DocumentosFiscais'] = arrayDocumentosFiscais
    return json.dumps(req), ''


@handle_exception_factory()
def responseExtrattaCadastrarViagem(resp) -> Tuple[str, str]:
    # Foi feito este tratamento, pois a extrata devolve este erro com a contra barra.
    # A viagem cadastrou na Extrata porem nao gerou ciot, é necessario salvar o idViagem
    # no SOR para posteiormente reenviar
    res = str(resp.content)
    if res.find("Falha ao declarar CIOT:") > 0:
        posIni = res.find("[\"")
        posFim = res.find("\"]") + 2
        msg = "Erro ao declarar CIOT:" + res[posIni:posFim]

        idViagemExtratta = ''
        rejeicao = ''

        if resp.text.find("Rejeição") > 0:
            posIni = resp.text.find(":") + 16
            posFim = resp.text.find("\"]") + 2
            rejeicao = resp.text[posIni:posFim]
        if res.find("IdViagem") > 0:
            posIni = res.find("IdViagem\":") + 10
            posFim = res.find("IdViagem\":") + 16
            idViagemExtratta = res[posIni:posFim]

        return dict_to_xml({
            'resp': {
                'erro': 'f',
                'msg': msg,
                'numviagopcartao': idViagemExtratta,
                'rejeicao': rejeicao
            }
        }, prolog=True), ''
    else:
        ret = resp.content.decode('utf-8')
        root = json.loads(ret)
        sucesso = getJSON(root, 'Sucesso')

        msgSucesso = ''
        if sucesso:
            if getJSON(root, 'Mensagem') != '':
                msgSucesso = getJSON(root, 'Mensagem')
            objeto = getJSON(root, 'Objeto')
            idViagemExtratta = getJSON(objeto, 'IdViagem')
            objCiot = getJSON(objeto, 'CIOT')
            dadosCiot = getJSON(objCiot, 'Dados')
            gerouCiot = getJSON(objCiot, 'Declarado')
            if gerouCiot:
                if msgSucesso != '':
                    msgSucesso += '\nContrato Extratta Gerado com sucesso!'
                else:
                    msgSucesso = 'Contrato Extratta Gerado com sucesso!'
                ciot = getJSON(dadosCiot, 'Ciot') + getJSON(dadosCiot, 'Verificador')
            else:
                return dict_to_xml({
                    'resp': {
                        'erro': 't',
                        'msg': 'O CIOT não foi gerado: ' + getJSON(objCiot, 'Mensagem')
                    }
                }, prolog=True), ''

            Eventos = getJSON(objeto, 'Eventos')
            obsEvento = ''
            for evento in Eventos:
                idViagemEvento = getJSON(evento, 'IdViagemEvento')
                tipoEventoViagem = getJSON(evento, 'TipoEventoViagem')

                if tipoEventoViagem == 0 and idViagemEvento > 0:
                    obsEvento += '\nEvento de Adiantamento ID: ' + str(idViagemEvento)
                elif tipoEventoViagem == 1 and idViagemEvento > 0:
                    obsEvento += '\nEvento de Saldo ID: ' + str(idViagemEvento)

            objPedagio = getJSON(objeto, 'Pedagio')
            status = getJSON(objPedagio, 'Status')
            valorPed = 0
            protocoloPed = 0
            if status == 0:
                valorPed = getJSON(objPedagio, 'Valor')
                protocoloPed = getJSON(objPedagio, 'ProtocoloValePedagio')
            elif status == 1:
                msgSucesso = msgSucesso + '\n ' + 'ValePedágio: ' + getJSON(objPedagio, 'Mensagem')
            elif status == 2:
                msgSucesso = msgSucesso + '\n Recurso de ValePedágio desativado na integração'

            return dict_to_xml({
                'resp': {
                    'erro': 'f',
                    'msg': msgSucesso + '!',
                    'numviagopcartao': idViagemExtratta,
                    'ciot': ciot,
                    'eventosviagem': obsEvento,
                    'valorpedagio': valorPed,
                    'protocolovalepedagio': protocoloPed
                }
            }, prolog=True), ''
        else:
            mensagem = getJSON(root, 'Mensagem')
            mensagem = mensagem.replace('<br/>', '')
            return '', mensagem


def requestExtrattaAjusteFinanceiro(reqJSON, properties):
    try:
        req = {}
        req['IdViagem'] = getJSON(reqJSON, 'conh_id')
        req['CNPJAplicacao'] = properties['CNPJAplicacao']
        req['Token'] = properties['Token']
        req['CNPJEmpresa'] = properties['CNPJAplicacao']
        viagemEventos = []
        ObjEvento = {}
        if getJSON(reqJSON, 'conh_idviagemevento') != '':
            ObjEvento['IdViagemEvento'] = int(getJSON(reqJSON, 'conh_idviagemevento'))
        ObjEvento['Status'] = 0  # -Aberto
        if getJSON(reqJSON, 'conh_valorajuste') != '':
            ObjEvento['ValorPagamento'] = float(getJSON(reqJSON, 'conh_valorajuste'))
        ObjEvento['HabilitarPagamentoCartao'] = getJSON(reqJSON, 'conh_formapagtoopcartao') != 'O'
        viagemEventos.append(ObjEvento)
        req['viagemEventos'] = viagemEventos

        return json.dumps(req), ''
    except Exception as e:
        print('Erro em requestExtrattaAjusteFinanceiro')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseExtrattaAjusteFinanceiro(resp):
    try:
        ret = resp.content.decode('utf-8')
        root = json.loads(ret)
        sucesso = getJSON(root, 'Sucesso')
        if sucesso:
            msgSucesso = 'Ajuste Financeiro Gerado com sucesso!'
            # objeto = getJSON(root, 'Objeto')
            # idViagemExtratta = getJSON(objeto, 'IdViagem')
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msgSucesso + '!</msg></resp>', ''
        else:
            mensagem = getJSON(root, 'Mensagem')
            mensagem = mensagem.replace('<br/>', '')
            return '', mensagem
    except Exception as e:
        print('Erro em responseExtrattaAjusteFinanceiro')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO'


def requestExtrattaBaixarViagem(reqJSON, properties):
    try:
        req = {}

        req['CNPJAplicacao'] = properties['CNPJAplicacao']
        req['Token'] = properties['Token']
        req['CNPJEmpresa'] = properties['CNPJAplicacao']
        today = date.today()
        req['DataEvento'] = today.strftime("%d-%m-%Y")
        req['CodigoViagem'] = getJSON(reqJSON, 'conh_id')

        return json.dumps(req), ''
    except Exception as e:
        print('Erro em requestExtrattaBaixarViagem')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseExtrattaBaixarViagem(resp):
    try:
        ret = resp.content.decode('utf-8')
        root = json.loads(ret)
        sucesso = getJSON(root, 'Sucesso')
        if sucesso:
            msgSucesso = 'Viagem baixada com sucesso !'
            # objeto = getJSON(root, 'Objeto')
            # idViagemExtratta = getJSON(objeto, 'IdViagem')
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msgSucesso + '!</msg></resp>', ''
        else:
            mensagem = getJSON(root, 'Mensagem')
            mensagem = mensagem.replace('<br/>', '')
            return '', mensagem
    except Exception as e:
        print('Erro em responseExtrattaBaixarViagem')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO'


def requestExtrattaCancelarViagem(reqJSON, properties):
    try:
        req = {}

        req['CNPJAplicacao'] = properties['CNPJAplicacao']
        req['Token'] = properties['Token']
        req['CNPJEmpresa'] = properties['CNPJAplicacao']
        today = date.today()
        req['DataEvento'] = today.strftime("%d-%m-%Y")
        req['CodigoViagem'] = getJSON(reqJSON, 'conh_id')

        return json.dumps(req), ''
    except Exception as e:
        print('Erro em requestExtrattaCancelarViagem')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseExtrattaCancelarViagem(resp):
    try:
        ret = resp.content.decode('utf-8')
        root = json.loads(ret)
        sucesso = getJSON(root, 'Sucesso')
        if sucesso:
            msgSucesso = 'Viagem cancelada com sucesso !'
            # objeto = getJSON(root, 'Objeto')
            # idViagemExtratta = getJSON(objeto, 'IdViagem')
            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><msg>' + msgSucesso + '!</msg></resp>', ''
        else:
            mensagem = getJSON(root, 'Mensagem')
            mensagem = mensagem.replace('<br/>', '')
            return '', mensagem
    except Exception as e:
        print('Erro em responseExtrattaCancelarViagem')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO'


def requestExtrattaConsultaPedagio(reqJSON, properties):
    try:
        req = {}

        req['CNPJAplicacao'] = properties['CNPJAplicacao']
        req['Token'] = properties['Token']
        req['CNPJEmpresa'] = properties['CNPJAplicacao']
        req["TipoVeiculo"] = 'Caminhao'
        req['QtdEixos'] = getJSON(reqJSON, 'rot_quanteixos')
        req['ExibirDetalhes'] = "false"
        localizacoes = []
        ibge = {}

        ibge['IbgeCidade'] = getJSON(reqJSON, 'rot_codibgeorig')
        localizacoes.append(ibge)
        qtdeIbge = int(getJSON(reqJSON, 'rot_quantibge'))
        for i in range(1, qtdeIbge + 1, 1):
            ibge = {}
            ibge['IbgeCidade'] = getJSON(reqJSON, 'rot_ibge' + str(i))
            localizacoes.append(ibge)
        ibge = {}
        ibge['IbgeCidade'] = getJSON(reqJSON, 'rot_codibgedest')
        localizacoes.append(ibge)

        req['localizacoes'] = localizacoes

        return json.dumps(req), ''
    except Exception as e:
        print('Erro em requestExtrattaConsultarPedagio')
        print(e)
        return '', 'ERRO NO PROCESSAMENTO DA RESPOSTA DA OPERADORA DE CARTÃO'


def responseExtrattaConsultaPedagio(resp):
    try:
        ret = resp.content.decode('utf-8')
        root = json.loads(ret)
        status = int(getJSON(root, 'Status'))
        if status == 1:
            custoTotal = getJSON(root, 'CustoTotal')
            IdentificadorHistorico = getJSON(root, 'IdentificadorHistorico')

            return '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro><valorpedagio>' + str(
                custoTotal) + '</valorpedagio> <identificadorPedagio>' + str(
                IdentificadorHistorico) + '</identificadorPedagio> </resp>', ''

        else:
            mensagem = getJSON(root, 'Mensagem')
            mensagem = mensagem.replace('<br/>', '')
            return '', mensagem
    except Exception as e:
        print('Erro em responseExtrattaCancelarViagem')
        print(e)
        return '', 'ERRO NA CHAMADA DA OPERADORA DE CARTÃO'


#
def dict_to_obj(our_dict):
    """
    Function that takes in a dict and returns a custom object associated with the dict.
    This function makes use of the "__module__" and "__class__" metadata in the dictionary
    to know which object type to create.
    """
    if "__class__" in our_dict:
        # Pop ensures we remove metadata from the dict to leave only the instance arguments
        class_name = our_dict.pop("__class__")

        # Get the module name from the dict and import it
        module_name = our_dict.pop("__module__")

        # We use the built in __import__ function since the module name is not yet known at runtime
        module = __import__(module_name)

        # Get the class from the module
        class_ = getattr(module, class_name)

        # Use dictionary unpacking to initialize the object
        obj = class_(**our_dict)
    else:
        obj = our_dict
    return obj


def getTipoContrato(agregado):
    # Agregado - S
    # Agregado Misto - M
    # Terceiro - N
    # Próprio - P
    # Agreg.(Ger.Como Terc.)-G
    # Tipo de contrato do proprietário a ser integrado
    # Frota = 1, Cooperado = 2, Agregado = 3 e Terceiro = 4
    switcher = {
        "P": 1,
        "S": 3,
        "M": 3,
        "G": 3,
        "N": 3,
    }
    return switcher.get(agregado)


def getTipoContratoVeic(propriedade):
    # Próprio Produtivo - S
    # Próprio Apoio Frota - F
    # Próprio Apoio Frete - R
    # Próprio Oficina(Comércio) - O
    # Terceiros - N
    # Agregado - A
    # Agregado Misto - M
    # Agregado(ger.como terceiro)-G
    # Tipo de contrato do proprietário a ser integrado
    # Frota = 1, Cooperado = 2, Agregado = 3 e Terceiro = 4
    switcher = {
        "S": 1,
        "F": 1,
        "R": 1,
        "O": 1,
        "N": 3,
        "A": 3,
        "M": 3,
        "G": 3,
    }
    return switcher.get(propriedade)


def getTipoQuebraMercadoria(tipoDesconto):
    # P - Parcial
    # I - Integral
    # N - Não desconta
    # F - Parcial + Dif.de Frete
    # H - Integral + Dif.de Frete
    switcher = {
        "P": 0,
        "I": 1,
        "N": 0,
        "F": 0,
        "H": 1,
    }
    return switcher.get(tipoDesconto)
