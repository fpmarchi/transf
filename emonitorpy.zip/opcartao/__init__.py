from ffcred import FFCred
from ffdigital import FFDigital
from nddcargo import NddCargo
from pozidigital import PoziDigital
from repom import Repom
from tipfrete import TipFrete

tipfrete = TipFrete.get_instance(min_action=1550, max_action=1599)
nddcargo = NddCargo.get_instance(min_action=1600, max_action=1649)
#QUANDO PEDIR PARA EXCLUIR, ADICIONAR O INTERVALO PARA FFCRED
ffdigital = FFDigital.get_instance(min_action=1650, max_action=1664)
ffcred = FFCred.get_instance(min_action=1665, max_action=1699)
repom = Repom.get_instance(min_action=1150, max_action=1199)
pozidigital = PoziDigital.get_instance(min_action=1750, max_action=1799)
