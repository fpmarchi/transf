import requests
from flask import Flask, request, jsonify, Response
from urllib.parse import urlparse

import bimdfe
import dao
import eminstall
import emj
import emws
import geralsis
import geralss
import mail
import processqueries
import whatsapp
from createLinks import createLinks
from edi import edi
from efrete import ACAO_EFRETE_GERARMODCOMPCIOT
from geral import datetimeactualtostr, printdh, filetostr
from geralsis import getCertProperties, prop, saveProperty
from geralxml import AssinaturaA1
from metadata import getEnginePGLightInterno, getEnginePG, getConnPG, engineEMonitor, engineSitesat
from opcartao.opcartao import call_envio_opcartao, call_envio_opcartao_mod_comp_ciot, call_remote_ws
from repom import ACAO_REPOM_GERARMODCOMPCIOT
from sefaz.sefaz_spooler import callSefaz, processBiMdfeDist
from sftp import process_commands
from ss import callSS

##########################################################################
app = Flask("emonitorpy")
# por enqto dashboard apenas nos EMs EM1/EM2/EMP, com BD PG dashboard... nao tem no SAT1/SAT3
# createdb dashboard -U postgres -w
# https://flask-monitoringdashboard.readthedocs.io/en/latest/configuration.html
# DESATIVADO POR ENQTO POIS ACALMOU O USO, E EXCLUIDO O BD
# dashboardCfg = '/sistemas/emonitorpy/cfg/dashboard.cfg'
# if fileexists(dashboardCfg):
#     dashboard.config.init_from(file=dashboardCfg)
#     dashboard.bind(app)


##########################################################################
@app.route("/test", methods=['GET'])
def test():
    # with getConnPG(engineEMonitor) as connPG:
    #     connPG.execute('select count(*) from emonitoruf')
    #     print(geral.dateactualtostr())
    return geralsis.VERSAO + ' em operação em ' + datetimeactualtostr()


##########################################################################
@app.route("/opcartao", methods=['POST'])
def opcartao():
    # parametros passados na URL
    codInstalacao = request.args.get('inst', type=int)
    codEmpresa = request.args.get('emp', type=int)
    codEMonitorAcao = request.args.get('emac', type=int, default=605)  # opcartao.ACAO_OPERADORASEMCHAVEPUB_ENVIODIRETO
    apenasGerarArq = request.args.get('gerarq', type=str, default='f')
    printdh('Processando Op.Cartao - Acao ' + str(codEMonitorAcao) + ' - Inst.' + str(codInstalacao) + '/' + str(codEmpresa) + ' - Gerar Arq.=' + apenasGerarArq)
    # processar JSON do POST
    requestJSON = request.json
    url = requestJSON['url']
    req = requestJSON['request']
    action = requestJSON['action']
    requestMethod = requestJSON['requestMethod']
    requestProperties = requestJSON['requestProperties']
    # informacoes do certificado
    with getConnPG(engineEMonitor) as connPG:
        pfx_path, pfx_password = getCertProperties(connPG, codInstalacao, codEmpresa, 0)
    if pfx_path == '' or pfx_password == '':
        erro = 't'
        resp = '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><msg>ERRO AO TENTAR OBTER DADOS DO CERTIFICADO DO SERVIDOR DO EMONITOR (PROPERTIES/BD)</msg></resp>'
    else:
        # chamar a operadora
        if isModCompCiot(codEMonitorAcao):
            resp, erros, arqreq, arqresp = call_envio_opcartao_mod_comp_ciot(pfx_path, pfx_password, codInstalacao, codEmpresa, codEMonitorAcao, apenasGerarArq, url, req, action, requestMethod, requestProperties)
        else:
            resp, erros, arqreq, arqresp = call_envio_opcartao(pfx_path, pfx_password, codInstalacao, codEmpresa, codEMonitorAcao, apenasGerarArq, url, req, action, requestMethod, requestProperties)
        erro = 'f'
        if arqreq != '':
            arqreq = '<arqreq><![CDATA[' + filetostr(arqreq) + ']]></arqreq>'
        if arqresp != '':
            arqresp = '<arqresp><![CDATA[' + filetostr(arqresp) + ']]></arqresp>'
        if erros != '':
            erro = 't'
            resp = '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><msg>' + erros + '</msg>' + arqreq + arqresp + '</resp>'
        elif resp == '':
            erro = 't'
            resp = '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><msg>ERRO AO TENTAR OBTER RESPOSTA DO WEBSERVICE REMOTO</msg>' + arqreq + arqresp + '</resp>'
        elif resp.endswith('</resp>'):
            resp = resp.replace('</resp>', arqreq + arqresp + '</resp>')
    responseJSON = {'erro': erro, 'msgRet': resp}
    return jsonify(responseJSON)


def isModCompCiot(codEMonitorAcao):
    return codEMonitorAcao == ACAO_EFRETE_GERARMODCOMPCIOT or codEMonitorAcao == ACAO_REPOM_GERARMODCOMPCIOT


##########################################################################
@app.route("/remoteWS", methods=['POST'])
def remoteWS():
    return call_remote_ws(request)


##########################################################################
@app.route("/sefaz", methods=['POST'])
def sefaz():
    # parametros passados na URL
    codInstalacao = request.args.get('inst', type=int)
    codEmpresa = request.args.get('emp', type=int)
    codEMonitorAcao = request.args.get('emac', type=int)
    codUF = request.args.get('coduf')
    numUF = request.args.get('numuf')
    tpAmb = request.args.get('tpamb')
    versao = request.args.get('versao')
    printdh(f'Processando SEFAZ - Acao {codEMonitorAcao} - Inst.{codInstalacao}/{codEmpresa} - UF: {codUF}/{numUF} - Amb.: {tpAmb} - Versao:{versao}')
    # processar JSON do POST
    requestJSON = request.json
    req = requestJSON['request']
    # informacoes do certificado
    with getConnPG(engineEMonitor) as connPG:
        pfx_path, pfx_password = getCertProperties(connPG, codInstalacao, codEmpresa, 0)
    if pfx_path == '' or pfx_password == '':
        erro = 't'
        resp = '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><msg>ERRO AO TENTAR OBTER DADOS DO CERTIFICADO DO SERVIDOR DO EMONITOR (PROPERTIES/BD)</msg></resp>'
    else:
        # chamar a operadora
        resp, erros, arqreq, arqresp = callSefaz(pfx_path, pfx_password, codInstalacao, codEmpresa, codEMonitorAcao, codUF, numUF, tpAmb, versao, req)
        erro = 'f'
        if arqreq != '':
            arqreq = '<arqreq><![CDATA[' + filetostr(arqreq) + ']]></arqreq>'
        if arqresp != '':
            arqresp = '<arqresp><![CDATA[' + filetostr(arqresp) + ']]></arqresp>'
        if erros != '':
            erro = 't'
            if '<msgRet>' not in erros:  # pois existem msgs de erro geradas em msgRet apos analisar retorno da SEFAZ
                erros = '<msgRet>' + erros + '</msgRet>'
            resp = '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><msg>' + erros + '</msg>' + arqreq + arqresp + '</resp>'
        elif resp == '':
            erro = 't'
            resp = '<?xml version="1.0" encoding="utf-8"?><resp><erro>t</erro><msg>ERRO AO TENTAR OBTER RESPOSTA DO WEBSERVICE REMOTO</msg>' + arqreq + arqresp + '</resp>'
        elif resp.endswith('</resp>'):
            resp = resp.replace('</resp>', arqreq + arqresp + '</resp>')
    responseJSON = {'erro': erro, 'msgRet': resp}
    return jsonify(responseJSON)


##########################################################################
@app.route("/getStrSign", methods=['GET'])
def getStrSign():
    # parametros passados na URL
    codInstalacao = request.args.get('inst', type=int)
    codEmpresa = request.args.get('emp', type=int)
    strSign = request.args.get('str', type=str)
    # informacoes do certificado
    with getConnPG(engineEMonitor) as connPG:
        pfx_path, pfx_password = getCertProperties(connPG, codInstalacao, codEmpresa, 0)
    if pfx_path == '' or pfx_password == '':
        erro = 't'
        resp = 'ERRO AO TENTAR OBTER DADOS DO CERTIFICADO DO SERVIDOR DO EMONITOR (PROPERTIES/BD)'
    else:
        try:
            assinatura = AssinaturaA1(certificado=pfx_path, senha=pfx_password)
            resp = assinatura.assinarStr(strSign)
            erro = 'f'
        except Exception as e:
            erro = 't'
            resp = 'ERRO INTERNO AO ASSINAR STRING - ' + str(e)
    responseJSON = {'erro': erro, 'msgRet': resp}
    return jsonify(responseJSON)


##########################################################################
# http://localhost:5000/checkFilialDist?inst=2072&emp=1&cnpjcpf=09597734000174&numuf=51&tipo=nfe
@app.route("/checkFilialDist", methods=['GET'])
def checkFilialDist():
    # parametros passados na URL
    inst = request.args.get('inst', type=int)
    emp = request.args.get('emp', type=int)
    cnpjcpf = request.args.get('cnpjcpf', type=str)
    numuf = request.args.get('numuf', type=str)
    tipo = request.args.get('tipo', type=str)
    #
    if tipo is None or tipo == '':
        erro = 't'
        resp = 'ERRO DE PARAMETRO tipo NAO INFORMADO NA URL'
    else:
        with getConnPG(engineEMonitor) as connPG:
            # checar se tem nomeArqCertifCliente
            pfx_path, pfx_password = getCertProperties(connPG, inst, emp, 0)
            if pfx_path == '' or pfx_password == '':
                erro = 't'
                resp = 'ERRO AO TENTAR OBTER DADOS DO CERTIFICADO DO SERVIDOR DO EMONITOR (PROPERTIES/BD)'
            else:
                if tipo == 'nfe':
                    proptipo = 'NFe'
                elif tipo == 'cte':
                    proptipo = 'CTe'
                elif tipo == 'mdfe':
                    proptipo = 'MDFe'
                proptipo = proptipo + 'DistInstalacoes'
                # checar se tem xxxDistInstalacoes no BD instempfil inst/emp/cnpjcpf/numuf
                if dao.hasInstEmpFil(connPG, inst, emp, cnpjcpf, numuf):
                    # achou, checar se em xxxDistInstalacoes o campo xxxDist = S
                    if not dao.hasInstEmpFil(connPG, inst, emp, cnpjcpf, numuf, tipo):
                        # fazer UPDATE para setar o campo xxxDist = S
                        if dao.updInstEmpFil(connPG, inst, emp, cnpjcpf, numuf, tipo+'dist', 'S'):
                            erro = 'f'
                            resp = 'FILIAL ATUALIZADA COM SUCESSO NO SERVIDOR DO EMONITOR (PROPERTIES/BD)'
                            saveProperty(proptipo, str(inst) + '_' + str(emp) + '_' + str(cnpjcpf) + '_' + str(numuf), ',', False)
                        else:
                            erro = 't'
                            resp = 'ERRO AO TENTAR ATUALIZAR FILIAL NO SERVIDOR DO EMONITOR (PROPERTIES/BD)'
                    else:
                        erro = 'f'
                        resp = 'FILIAL JA CADASTRADA NO SERVIDOR DO EMONITOR (PROPERTIES/BD)'
                else:
                    # nao achou, fazer INSERT
                    if dao.insInstEmpFil(connPG, inst, emp, cnpjcpf, numuf, tipo+'dist', 'S'):
                        erro = 'f'
                        resp = 'FILIAL INSERIDA COM SUCESSO NO SERVIDOR DO EMONITOR (PROPERTIES/BD)'
                        saveProperty(proptipo, f'{inst}_{emp}_{cnpjcpf}_{numuf}', ',', False)
                    else:
                        erro = 't'
                        resp = 'ERRO AO TENTAR INSERIR FILIAL NO SERVIDOR DO EMONITOR (PROPERTIES/BD)'
    #
    responseJSON = {'erro': erro, 'msgRet': resp}
    return jsonify(responseJSON)


##########################################################################
# http://localhost:5000/installCert?inst=2072&emp=1&email=ed@ed.br&senha=1234&checkexp=S
@app.route("/installCert", methods=['POST'])
def installCert():
    response = eminstall.installCert(request, engineEMonitor)
    return jsonify(response)


##########################################################################
# http://localhost:5000/updateCert?inst=2072&emp=1&email=ed@ed.br&senha=1234&checkexp=S
@app.route("/updateCert", methods=['POST'])
def updateCert():
    response = eminstall.updateCert(request, engineEMonitor)
    return jsonify(response)


# json de resposta genérico em caso de erro no empy
error_response = {"erro": True, "msgRet": "Erro no EMPY"}


@app.route("/sendXmlsIS", methods=['POST'])
def sendXmlsIS():
    try:
        body = request.json
        response = eminstall.sendXmlsIS(engineEMonitor, **body)
        return jsonify(response)
    except Exception as e:
        print(e)  # temporário, definir error handler
        return jsonify(error_response)


@app.route("/sendCertIS", methods=['POST'])
def sendCertIS():
    try:
        body = request.json
        response = eminstall.sendCertIS(engineEMonitor, **body)
        return jsonify(response)
    except Exception as e:
        print(e)  # temporário, definir error handler
        return jsonify(error_response)


@app.route("/sendEmailIS", methods=['POST'])
def sendEmailIS():
    try:
        body = request.json
        response = eminstall.sendEmailIS(engineEMonitor, **body)
        return jsonify(response)
    except Exception as e:
        print(e)  # temporário, definir error handler
        return jsonify(error_response)


##########################################################################
# http://localhost:5000/getSizeCert?inst=2072&emp=1
@app.route("/getSizeCert", methods=['GET'])
def getSizeCert():
    response = eminstall.getSizeCert(request, engineEMonitor)
    return Response(response, mimetype='text/plain')


##########################################################################
# Servicos abaixo de consulta da tabela BIMDFE de diversas formas
# em uso tambem pelos SORs como pela FreteBras
##########################################################################
# http://localhost:5000/getBiMdfePropVeic?u=8*-%3C.%29&s=%22.%3C%3B*%3D%24*6&p=28788202000169&v=JHX0143&di=01-01-1900
@app.route("/getBiMdfePropVeic", methods=['GET'])
def getBiMdfePropVeic():
    return Response(bimdfe.getBiMdfePropVeic(engineEMonitor, request), mimetype='application/xml')


# http://localhost:5000/getBiMdfePropVeicComp?u=8*-%3C.%29&s=%22.%3C%3B*%3D%24*6&p=28788202000169&v=JHX0143&di=01-01-1900
@app.route("/getBiMdfePropVeicComp", methods=['GET'])
def getBiMdfePropVeicComp():
    return Response(bimdfe.getBiMdfePropVeicComp(engineEMonitor, request), mimetype='application/xml')


# http://localhost:5000/getBiMdfeMotComp?u=8*-%3C.%29&s=%22.%3C%3B*%3D%24*6&m=73692654120&di=01-01-1900
@app.route("/getBiMdfeMotComp", methods=['GET'])
def getBiMdfeMotComp():
    return Response(bimdfe.getBiMdfeMotComp(engineEMonitor, request), mimetype='application/xml')


# http://localhost:5000/getBiMdfePerComp?u=8*-%3C.%29&s=%22.%3C%3B*%3D%24*6&di=01-07-2022&df=02-07-2022
@app.route("/getBiMdfePerComp", methods=['GET'])
def getBiMdfePerComp():
    return Response(bimdfe.getBiMdfePerComp(engineEMonitor, request), mimetype='application/xml')


'''
Enviar no body do request em base64, separados por ENTER do LINUX #10:
sqlFields=chave,msgRet,arqXMLResp
sqlWhere=where codinstalacao = 3 and codempresa = 1 and cnpjinut = '02910203000140' and codemonitoracao = 11 and status = 4 and chave > '000000000020000' and (anoinut = '50' or anoinut = '50  ')
sqlOrder=order by chave,msgRet
c3FsRmllbGRzPWNoYXZlLG1zZ1JldCxhcnFYTUxSZXNwCnNxbFdoZXJlPXdoZXJlIGNvZGluc3RhbGFjYW8gPSAzIGFuZCBjb2RlbXByZXNhID0gMSBhbmQgY25wamludXQgPSAnMDI5MTAyMDMwMDAxNDAnIGFuZCBjb2RlbW9uaXRvcmFjYW8gPSAxMSBhbmQgc3RhdHVzID0gNCBhbmQgY2hhdmUgPiAnMDAwMDAwMDAwMDIwMDAwJyBhbmQgKGFub2ludXQgPSAnNTAnIG9yIGFub2ludXQgPSAnNTAgICcpCnNxbE9yZGVyPW9yZGVyIGJ5IGNoYXZlLG1zZ1JldAo=

delete from emonitorspool where datains >= '2021-10-21';commit;
PG:
select codemonitorspool,datains,chave,status,msgret,substring(arqxmlresp,1,100) from emonitorspool where codinstalacao = 2029 and codempresa = 1 and cnpjinut = '09535606000104' and codemonitoracao = 11 and status = 4 and chave > '000000000020000' and (anoinut = '52' or anoinut = '52  ');
PG/SquirrelSQL
select codemonitorspool,datains,chave,status,msgret,arqxmlresp from emonitorspool where codinstalacao = 2029 and codempresa = 1 and cnpjinut = '09535606000104' and codemonitoracao = 11 and status = 4 and chave > '000000000020000' and (anoinut = '52' or anoinut = '52  ');
FB:
commit;select codemonitorspool,datains,chave,status,msgret,arqxmlresp from emonitorspool where codinstalacao = 2029 and codempresa = 1 and cnpjinut = '09535606000104' and codemonitoracao = 11 and status = 4 and chave > '000000000020000' and (anoinut = '52' or anoinut = '52  ');

'''


# https://www.base64encode.org/
# http://localhost:5000/execSqlComp
@app.route("/execSqlComp", methods=['POST'])
def execSqlComp():
    return Response(emws.execSqlComp(engineEMonitor, request), mimetype='text/xml')


# http://localhost:5000/execSqlGeral
@app.route("/execSqlGeral", methods=['POST'])
def execSqlGeral():
    return Response(emws.execSqlGeral(engineEMonitor, request), mimetype='text/xml')


# http://localhost:5000/execSqlIns
@app.route("/execSqlIns", methods=['POST'])
def execSqlIns():
    return Response(emws.execSqlIns(engineEMonitor, request), mimetype='text/xml')


##########################################################################
# INICIO: criados outros metodos, semelhante aos existentes acima, mas que serao usados na interacao com o emj

# http://localhost:5000/emAtivo?u=8*-%3C.%29&s=%22.%3C%3B*%3D%24*6
@app.route("/emAtivo", methods=['GET'])
def emAtivo():
    return emj.ativo(engineEMonitor, request)


# http://localhost:5000/emIns?u=8*-%3C.%29&s=%22.%3C%3B*%3D%24*6
# sql e arqxml dentro de um JSON no body
@app.route("/emIns", methods=['POST'])
def emIns():
    return emj.insertEMonitorSpool(engineEMonitor, request)


# http://localhost:5000/emIns?u=8*-%3C.%29&s=%22.%3C%3B*%3D%24*6
# sql dentro de um JSON no body
@app.route("/emUpd",methods=['POST'])
def emUpd():
    return emj.updateEMonitorSpool(engineEMonitor,request)


# COMENTADO POIS SERA USADO APENAS emSel/selectEMonitorSpool
# http://localhost:5000/emSelByCod?u=8*-%3C.%29&s=%22.%3C%3B*%3D%24*6
# codemonitorspool dentro de um JSON no body
# @app.route("/emSelByCod",methods=['POST'])
# def emSelByCod():
#     return emj.selectEMonitorSpoolByCod(engineEMonitor,request)


# http://localhost:5000/emSel?u=8*-%3C.%29&s=%22.%3C%3B*%3D%24*6
# sqlWhere e sqlOrder dentro de um JSON no body
@app.route("/emSel",methods=['POST'])
def emSel():
    return emj.selectEMonitorSpool(engineEMonitor,request)


# http://localhost:5000/emSelGeral?u=8*-%3C.%29&s=%22.%3C%3B*%3D%24*6
# sqlWhere e sqlOrder dentro de um JSON no body
@app.route("/emSelGeral",methods=['POST'])
def emSelGeral():
    return emj.selectGeral(engineEMonitor,request)


# FIM: criados outros metodos, semelhante aos existentes acima, mas que serao usados na interacao com o emj
##########################################################################

##########################################################################
# Servico abaixo chamado via EMI
# http://localhost:5000/getWSDist?inst=3&emp=1&cnpjinut=&codEMonitorSpool=&dataIni=2021-09-01&dataFim=2021-11-30&chave=&tipo=N
@app.route("/getWSDist", methods=['GET'])
def getWSDist():
    return Response(emws.getWSDist(engineEMonitor, request), mimetype='text/xml')


@app.route("/getXMLsWSDist", methods=['GET'])
def getXMLsWSDist():
    return Response(emws.getXMLsWSDist(engineEMonitor, request), mimetype='text/xml')


##########################################################################
# http://localhost:5000/createLinksEM?s=sat1&nr=c2509&ativo=
@app.route("/createLinksEM", methods=['POST'])
def createLinksEM():
    # parametros passados na URL
    servidor = request.args.get('s')
    nomeReduz = request.args.get('nr')
    ativo = request.args.get('ativo')
    dirss = '/sistemas/sitesat2-is/'
    strIndex = filetostr('/sistemas/emonitorpy/sitesat/timers/index.html')
    try:
        createLinks(servidor, nomeReduz, ativo, dirss, strIndex)
        return Response('OK', mimetype='text/plain')
    except Exception as e:
        print('Erro em createLinksEM')
        print(e)
        return Response('ERRO', mimetype='text/plain')


##########################################################################
# Servicos abaixo usados para integracao com EDI / VIAGENS TERCEIROS / EMP
##########################################################################
@app.route("/insertViagemEdi", methods=['POST'])
def insertViagemEdi():
    return Response(edi.insertViagem(engineEdi, request), mimetype='text/xml')


@app.route("/cancelViagemEdi", methods=['POST'])
def cancelViagemEdi():
    return Response(edi.cancelViagem(engineEdi, request), mimetype='text/xml')


# metodo abaixo chamado pelo SOR para obter viagens para o painel de viagens terceiros
@app.route("/getViagemEdi", methods=['GET'])
def getViagemEdi():
    return Response(edi.getViagem(engineEdi, engineEMonitor, request), mimetype='text/xml')


@app.route("/insertPessoaLogEdi", methods=['POST'])
def insertPessoaLogEdi():
    return jsonify(edi.insertPessoaLogEdi(engineEdi, request))


@app.route("/getPessoaLogEdi", methods=['POST'])
def getPessoaLogEdi():
    return jsonify(edi.getPessoaLogEdi(engineEdi, request))


##########################################################################
# Servicos abaixo usados para integracao com EDI / VIAGENS GERRISCO / EMP
##########################################################################
@app.route("/insertViagemGerRisco", methods=['POST'])
def insertViagemGerRisco():
    return Response(edi.insertViagemGerRisco(engineEdi, request), mimetype='text/xml')


# metodo abaixo de consulta via WEBSAF das viagens com dados de opcars
# criado o metodo abaixo para que nao haja perguntas de porque esta chamando GerRisco se sao dados de OpCar
# mas nos SORs a tabela é a mesma
@app.route("/getViagemOpCar", methods=['GET'])
def getViagemOpCar():
    return getViagemGerRisco()


# http://localhost:5000/getViagemOpCar?di=01/01/2022&df=31/01/2022&cnpjgr=01648418000172,12815827000132&cnpjgrp=&insts=1594,2029&tf=T&tap=T
@app.route("/getViagemGerRisco", methods=['GET'])
def getViagemGerRisco():
    return Response(edi.getViagemGerRisco(engineEdi, request, False), mimetype='text/xml')


# metodo abaixo de consulta via WEBSAF das viagens com dados de opcars de forma resumida
# criado o metodo abaixo para que nao haja perguntas de porque esta chamando GerRisco se sao dados de OpCar
# mas nos SORs a tabela é a mesma
@app.route("/getViagemOpCarRes", methods=['GET'])
def getViagemOpCarRes():
    return getViagemGerRiscoRes()


# http://localhost:5000/getViagemOpCarRes?di=01/01/2022&df=31/01/2022&cnpjgr=01648418000172,12815827000132&cnpjgrp=&insts=1594,2029&tf=T&tap=T
@app.route("/getViagemGerRiscoRes", methods=['GET'])
def getViagemGerRiscoRes():
    return Response(edi.getViagemGerRisco(engineEdi, request, True), mimetype='text/xml')


##########################################################################
# Servicos abaixo usados para integracao com WEBSAF
##########################################################################

##########################################################################
# http://localhost:5000/contarVarias?insts=3,2029&dataIni=2020-04-01&dataFim=2020-04-08
# http://emonitor.intersite.com.br:5000/contarVarias?insts=2029&dataIni=2022-01-01&dataFim=2022-01-31
# http://emonitor2.intersite.com.br:5000/contarVarias?insts=2029&dataIni=2022-01-01&dataFim=2022-01-31
@app.route("/contarVarias", methods=['POST'])
def contarVarias():
    return Response(emws.contarVarias(engineEMonitor, request), mimetype='text/xml')


@app.route("/contarVariosSistemaExt", methods=['POST'])
def contarVariosSistemaExt():
    return Response(emws.contarVariosSistemaExt(engineEMonitor, request), mimetype='text/xml')


# webservice abaixo que obtem dados tabela BIMDFE do servidor EMP, principalmente relativos a infRespTec (sistemas de concorrentes)
# http://localhost:5000/getBiMdfeDistRespTec?di=01/07/2022&df=31/07/2022
# http://emonitorp.intersite.com.br:5000/getBiMdfeDistRespTec?di=01/01/2022&df=31/01/2022
@app.route("/getBiMdfeDistRespTec", methods=['GET'])
def getBiMdfeDistRespTec():
    return Response(processBiMdfeDist(engineEMonitor, request), mimetype='text/xml')


##########################################################################
# Servicos abaixo usados pelo SITESAT
##########################################################################

# http://localhost:5000/getQuery?t=1234567890&db=machado
# Execucao de SQL especifico via parceria com a empresa Novel/Flex
# SQL vai no body
@app.route("/getQuery", methods=['POST'])
def getQuery():
    return Response(processqueries.getQuery(engineSitesat, request), mimetype='application/json')


# http://localhost:5000/getQueryBI?t=1234567890&db=machado
# Execucao de SQL especifico via parceria com a empresa Novel/BI
# SQL vai no body
@app.route("/getQueryBI", methods=['POST'])
def getQueryBI():
    return Response(processqueries.getQueryBI(engineSitesatBI, request), mimetype='application/json')


# http://ss0.intersite.com.br:5000/getSSUsuariosAtivosBySchema?db=c2594
@app.route("/getSSUsuariosAtivosBySchema", methods=['GET'])
def getSSUsuariosAtivosBySchema():
    engineSitesat = getEnginePGLightInterno(geralsis.prop, 'Sitesat')
    return geralss.getSSUsuariosAtivosBySchema(engineSitesat, request)


@app.route("/listNomeReduz", methods=['GET'])
def listNomeReduz():
    return geralss.listNomeReduz()


##########################################################################
@app.route("/ss", methods=['POST'])
def ss():
    # parametros passados na URL
    nomeReduzEmpresa = request.args.get('nomeReduzEmpresa', type=str)
    codEMonitorAcao = request.args.get('emac', type=int)
    printdh('Processando SITESAT - Acao ' + str(codEMonitorAcao) + ' - Empresa ' + nomeReduzEmpresa)
    # processar JSON do POST
    requestJSON = request.json
    requestMethod = requestJSON['requestMethod']
    resp, erros = callSS(nomeReduzEmpresa, codEMonitorAcao, requestJSON, requestMethod)
    erro = 'f'
    if erros != '':
        erro = 't'
        resp = erros
    elif resp == '':
        erro = 't'
        resp = 'ERRO AO TENTAR OBTER RESPOSTA DO WEBSERVICE REMOTO'
    responseJSON = {'erro': erro, 'msgRet': resp}
    return jsonify(responseJSON)


##########################################################################
@app.route("/sftp", methods=['POST'])
def sftp():
    cl = request.content_length
    if cl is not None and cl > 30 * 1024 * 1924:
        return {
            'sucess': False,
            'msg_error': 'O conteúdo de envio não pode exceder os 30 MB'
        }
    try:
        ret = process_commands(request.json)
        return ret
    except Exception as e:
        print('Erro em sftp')
        print(e)
        return {
            'sucess': False,
            'msg_error': 'Erro ao processar o JSON recebido'
        }


##########################################################################
@app.route("/getfilesimap", methods=['POST'])
def getfilesimap():
    return mail.get_files_attached(request)


@app.route("/delfilesimap", methods=['POST'])
def delfilesimap():
    return mail.del_files_attached(request)


##########################################################################
@app.route("/callwhatsapp", methods=['POST'])
def callwhatsapp():
    return whatsapp.call_whatsapp(request, engineEMonitor)

@app.route('/middleware', methods=['POST'])
def middleware():
    data = request.json

    headers = dict(request.headers)

    if 'X-Data-Content-Type' in headers:
        headers['Content-Type'] = headers.get('X-Data-Content-Type')
        del headers['X-Data-Content-Type']

    headers['Host'] = urlparse(data.get('url')).hostname

    r = requests.request(
        data.get('method'),
        headers=headers,
        url=data.get('url'),
        data=data.get('data')
    )

    return Response(
        r.text,
        status=r.status_code,
        content_type=r.headers['content-type'],
    )


##########################################################################
isDebug = False
engineEMonitor = getEnginePG(prop, 'EMonitor') # EM1/EM2/EMP => 25..250
engineEdi = getEnginePG(prop, 'Edi') # somente no EMP => 10..100
engineSitesat = getEnginePG(prop, 'Sitesat') # SSs/FLEX/NOVEL => 5..100
engineSitesatBI = getEnginePG(prop, 'SitesatBI') # SSs/BI/NOVEL => 5..100
if __name__ == "__main__":
    # print(secrets.token_urlsafe(16))
    app.secret_key = 'Ef6xvkV7lkih7iALd7vIsQ'
    if isDebug:  # o Flask é disparado via Gunicorn WSGI Server quando isDebug = False
        app.run(host='0.0.0.0', debug=isDebug, use_reloader=isDebug)
