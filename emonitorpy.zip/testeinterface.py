# https://www.devmedia.com.br/tkinter-interfaces-graficas-em-python/33956
# https://www.delftstack.com/pt/tutorial/tkinter-tutorial/tkinter-message-box/
# https://www.geeksforgeeks.org/graph-plotting-in-python-set-1/
# https://matplotlib.org/2.0.2/users/pyplot_tutorial.html

from tkinter import *
from tkinter import messagebox


class Application:
    def __init__(self, master=None):
        #
        self.fontePadrao = ("Arial", "10")
        #
        self.frame1 = Frame(master)
        self.frame1["padx"] = 10
        self.frame1["pady"] = 10
        self.frame1.pack()
        #
        self.labelNome = Label(self.frame1, text="Nome:")
        self.labelNome["font"] = ("Verdana", "10", "italic", "bold")
        self.labelNome.pack(side=LEFT)
        #
        self.fieldNome = Entry(self.frame1)
        self.fieldNome["width"] = 30
        self.fieldNome["font"] = self.fontePadrao
        self.fieldNome.pack(side=LEFT)
        #
        self.botao = Button(self.frame1)
        self.botao["text"] = "Imprimir Nome"
        self.botao["font"] = ("Calibri", "10")
        self.botao["width"] = 15
        #self.botao.bind('<Button-1>', self.imprimirNome)
        self.botao["command"] = self.imprimirNome
        self.botao.pack()
        #
        self.frame2 = Frame(master)
        self.frame2["pady"] = 20
        self.frame2.pack()
        #
        self.sair = Button(self.frame2)
        self.sair["text"] = "Sair"
        self.sair["font"] = ("Calibri", "10")
        self.sair["width"] = 15
        self.sair["command"] = self.frame2.quit
        self.sair.pack()


    #def imprimirNome(self, event):
    def imprimirNome(self):
        messagebox.showinfo("Mensagem", 'Nice to meet you... ' + self.fieldNome.get())


root = Tk()
Application(root)
root.mainloop()
