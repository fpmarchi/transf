import os
import base64
import requests
import zipfile
from datetime import datetime as dt

from metadata import getConnPG
from geral import (
    pfx_expiration_date,
    datetimeactualtostr,
    pfx_cert_info,
    pfx_cnpjcpf,
    fileexists,
    strempty,
)
from sefaz import dao
import geralsis as gs
import mail


def installCert(request, engineEMonitor):
    inst = request.args.get("inst", type=int)
    emp = request.args.get("emp", type=int)
    email = request.args.get("email", type=str)
    senha = request.args.get("senha", type=str)
    checkexp = request.args.get("checkexp", type=str)
    usuarioWEBSAF = request.args.get("usuarioWEBSAF", type=str)
    tpAmb = request.args.get("tpAmb", type=str)
    servidorEmonitor = request.args.get("servidorEmonitor", type=int)
    moduloPuro = request.args.get("moduloPuro", type=str)

    erro = "f"
    with getConnPG(engineEMonitor) as connPG:
        pfx_path, pfx_password = gs.getCertProperties(connPG, inst, emp, -1)
        if pfx_path != "":
            erro = "t"
            resp = f"JA EXISTE A INSTALACAO {inst}_{emp} NO EMONITOR"
        else:
            dircertdest = f"{gs.inst_path}{inst}/{emp}/cert/"
            os.makedirs(dircertdest, mode=0o775)

            instemp = f"{inst}_{emp}"
            nomecertorig = f"{gs.certs_path}cert_{instemp}.pfx"
            nomecertdest = f"{dircertdest}cert.pfx"
            arqcertif = request.data.decode()
            arqcertif = base64.decodebytes(arqcertif.encode())

            with open(nomecertorig, "wb") as nomecertorig_salvar:
                nomecertorig_salvar.write(arqcertif)
            os.system(f"cp {nomecertorig} {nomecertdest}")

            if dao.insInstEmp(connPG, inst, emp, email, nomecertdest, senha, checkexp):
                resp = "INST/EMP INSERIDA COM SUCESSO NO SERVIDOR DO EMONITOR (PROPERTIES/BD)"
            else:
                erro = "t"
                resp = "ERRO AO TENTAR INSERIR INST/EMP NO SERVIDOR DO EMONITOR (PROPERTIES/BD)"

            if erro == "f":
                isBackup = gs.getProperty("isBackup") == "N"
                if isBackup:
                    mail.send(
                        dest_mail="servidor@intersite.com.br",
                        title=f"Instalacao de Certificado da Instalacao {instemp} na InterSite",
                        message=f"Processamento realizado com sucesso pelo usuario "
                                f"{usuarioWEBSAF} em {datetimeactualtostr()}",
                    )

                dao.insEMonitorSpoolRelerArqProperties(connPG, "376", "1")

                if isBackup:
                    # url_servidor = "http://localhost:8080/"
                    url_servidor = "http://websaf.intersite.com.br:8082/"
                    url = (
                        f"{url_servidor}"
                        f"emonitorws/webresources/install/"
                        f"insInstalacaoEmp/{inst}/{emp}/"
                        f"{moduloPuro}/{tpAmb}/"
                        f"{servidorEmonitor}/"
                        f"{usuarioWEBSAF}"
                    )
                    requests.get(url).json()
                connPG.close()

                pfx_exp_date = pfx_expiration_date(nomecertdest, senha)
                resp = f"Certificado expira em {pfx_exp_date}"
    responseJSON = {"erro": erro, "msgRet": resp}
    return responseJSON


def updateCert(request, engineEMonitor):
    inst = request.args.get("inst", type=int)
    emp = request.args.get("emp", type=int)
    email = request.args.get("email", type=str)
    senha = request.args.get("senha", type=str)
    checkexp = request.args.get("checkexp", type=str)
    usuarioWEBSAF = request.args.get("usuarioWEBSAF", type=str)

    erro = "f"
    with getConnPG(engineEMonitor) as connPG:
        pfx_path, pfx_password = gs.getCertProperties(connPG, inst, emp, 0)
        if pfx_path == "":
            erro = "t"
            resp = f"NAO EXISTE A INSTALACAO {inst}_{emp} NO EMONITOR"
        else:
            dircertdest = f"{gs.inst_path}{inst}/{emp}/cert/"
            instemp = f"{inst}_{emp}"
            nomecertorig = f"{gs.certs_path}cert_{instemp}.pfx"
            arqcertif = request.data.decode()
            arqcertif = base64.decodebytes(arqcertif.encode())

            with open(nomecertorig, "wb") as nomecertorig_salvar:
                nomecertorig_salvar.write(arqcertif)

            nomecertdest = f"{dircertdest}cert.pfx"
            nomecertdestold = f"{dircertdest}certold.pfx"
            cnpjcpforig = pfx_cnpjcpf(nomecertorig, senha)
            cnpjcpfdest = pfx_cnpjcpf(nomecertdest, pfx_password)

            if (
                not strempty(cnpjcpforig)
                and not strempty(cnpjcpfdest)
                and cnpjcpforig[0:8] != cnpjcpfdest[0:8]
            ):
                erro = "t"
                resp = f"CNPJ DO NOVO CERTIFICADO {cnpjcpforig} DIFERENTE DO ATUAL {cnpjcpfdest}"
            else:
                os.system(f"cp {nomecertdest} {nomecertdestold}")
                os.system(f"cp {nomecertorig} {nomecertdest}")

                if dao.updInstEmp(connPG, inst, emp, email, nomecertdest, senha, checkexp):
                    resp = "INST/EMP ATUALIZADA COM SUCESSO NO SERVIDOR DO EMONITOR (PROPERTIES/BD)"
                else:
                    erro = "t"
                    resp = "ERRO AO TENTAR ALTERAR INST/EMP NO SERVIDOR DO EMONITOR (PROPERTIES/BD)"

                if erro == "f":
                    isBackup = gs.getProperty("isBackup") == "N"
                    if isBackup:
                        mail.send(
                            dest_mail="servidor@intersite.com.br",
                            title=f"Atualização de Certificado da Instalacao {instemp} na InterSite",
                            message=f"Processamento realizado com sucesso pelo usuario "
                                    f"{usuarioWEBSAF} em {datetimeactualtostr()}\n"
                                    f"Por seguranca, abaixo seguem a senha e o certificado antigos "
                                    f"caso os novos dados tenham algum problema...\n"
                                    f"Senha Antiga = {pfx_password}",
                            attachments=[nomecertdestold],
                            attname="certold.pfx",
                        )

                    dao.insEMonitorSpoolRelerArqProperties(connPG, "376", "1")

                    if isBackup:
                        # url_servidor = "http://localhost:8080/"
                        url_servidor = "http://websaf.intersite.com.br:8082/"
                        url = (
                            f"{url_servidor}"
                            f"emonitorws/webresources/install/"
                            f"updInstalacaoEmp/{inst}/{emp}/"
                            f"{usuarioWEBSAF}"
                        )
                        requests.get(url).json()

                    pfx_exp_date = pfx_expiration_date(nomecertdest, senha)
                    resp = f"Certificado expira em {pfx_exp_date}"
    responseJSON = {"erro": erro, "msgRet": resp}
    return responseJSON


def sendXmlsIS(
    engineEMonitor,
    codInstalacao,
    codEmpresa,
    dataIni,
    dataFim,
    tipoDoc,
    servidor,
    emailDest,
    usuarioWEBSAF,
):
    try:
        data_inicio_limpa = str(dataIni).replace("/", "_")
        data_fim_limpa = str(dataFim).replace("/", "_")
        nome_zip = f"{codInstalacao}_{codEmpresa}_{data_inicio_limpa}_{data_fim_limpa}.zip"
        path_zip = f"tmp/{nome_zip}"

        xml_dir = "/sistemas/emonitor/instalacoes/100010/1/xml/"
        lista_xmls = [f for f in os.listdir(xml_dir) if os.path.isfile(os.path.join(xml_dir, f))]
        lista_xmls_ass = [xml for xml in lista_xmls if str(xml).endswith(".ass.xml")]

        connPG = getConnPG(engineEMonitor)
        response = dao.getXmlsEMonitorSpool(connPG, codInstalacao, codEmpresa, tipoDoc, dataIni, dataFim)

        erro_xmls = "Chaves com XML nao localizado, nem no BD nem na pasta xml do mExec 100010:\n"
        if not response:
            erro = True
            msgRet = "ERRO NO EMPY: nenhum XML encontrado no BD do EMONITOR!"
        else:
            lista_nome_xmls = []
            for xml in response:
                xml_ass = xml[0]
                cod_emsp = int(xml[1])
                chave = xml[2]
                nome = f"{codInstalacao}_{codEmpresa}_{cod_emsp}.xml"
                if len(str(xml_ass)) > 100:
                    with open(nome, "w") as f:
                        for line in xml_ass:
                            f.write(line)
                    lista_nome_xmls.append(nome)
                else:
                    nome_orig = f"{xml_dir}{cod_emsp}.ass.xml"
                    if nome_orig in lista_xmls_ass:
                        with open(nome_orig, "r") as n1:
                            with open(nome, "w") as n2:
                                for line in n1:
                                    n2.write(line)
                        lista_nome_xmls.append(nome)
                    else:
                        erro_xmls += f"{chave}\n"
            with zipfile.ZipFile(path_zip, "w") as zip_output:
                for xml in lista_nome_xmls:
                    zip_output.write(xml, compress_type=zipfile.ZIP_DEFLATED)
                    os.remove(xml)
            erro = False
            msgRet = "Arquivos encontrados"

        if erro is False:
            title = f"Envio de XMLs da instalacao {codInstalacao} / {codEmpresa} - {servidor}"
            message_l1 = f"Processamento realizado com sucesso pelo usuario {usuarioWEBSAF} em {dt.now()}"
            message_l2 = f"Arquivo .zip com XMLs anexado no e-mail"
            message_l3 = f"{erro_xmls}"
            message = f"{message_l1}\n{message_l2}\n{message_l3}\n"

            mail.send(
                dest_mail=emailDest,
                title=title,
                message=message,
                attachments=[path_zip],
                attname=nome_zip,
            )
            msgRet = "Link do Arquivo compactado enviado por e-mail com sucesso!"

        responseJSON = {"erro": erro, "msgRet": msgRet}
        return responseJSON
    except Exception as e:
        raise Exception(e)


def sendCertIS(engineEMonitor, codInstalacao, codEmpresa, emailDest, usuarioWEBSAF):
    try:
        with getConnPG(engineEMonitor) as connPG:
            pfx_path, pfx_password = gs.getCertProperties(connPG, codInstalacao, codEmpresa, 0)
            email_cliente = dao.getEndDestEmailSair(connPG, codInstalacao, codEmpresa)
        datetime_now = dt.now()
        exp_date = pfx_expiration_date(pfx_path, pfx_password) - datetime_now
        exp_date_days = exp_date.days
        info_interna = ""
        for info in pfx_cert_info(pfx_path, pfx_password):
            info_interna += info + "  "

        m_email = f"Email do Cliente: {email_cliente}"
        m_senha = f"Senha do Certificado: {pfx_password}"
        m_info = f"Informação interna do certificado: {info_interna}"
        m_cert_exp = f"Dias para expirar certificado: {exp_date_days}"
        m_processamento = f"Processamento realizado com sucesso pelo usuário {usuarioWEBSAF} em {datetime_now}"

        title = f"Envio de certificado e senha da instalacao {codInstalacao} / {codEmpresa} do servidor da InterSite"
        message = f"{m_email}\n{m_senha}\n{m_info}\n{m_cert_exp}\n{m_processamento}\n"
        attachment = [pfx_path]

        mail.send(
            dest_mail=emailDest,
            title=title,
            message=message,
            attachments=attachment,
            attname="cert.pfx",
        )

        msgRet = "Certificado enviado para o e-mail informado."
        responseJSON = {"erro": False, "msgRet": msgRet}
        return responseJSON
    except Exception as e:
        raise Exception(e)


def sendEmailIS(engine, titulo, texto):
    try:
        for email in mail.get_emails_em(engine):
            mail.send(dest_mail=email, title=titulo, message=texto)

        msgRet = "Emails enviados com sucesso."
        responseJSON = {"erro": False, "msgRet": msgRet}
        return responseJSON
    except Exception as e:
        raise Exception(e)


def getSizeCert(request, engineEMonitor):
    inst = request.args.get("inst", type=int)
    emp = request.args.get("emp", type=int)

    arqCert = f"{gs.inst_path}{inst}/{emp}/cert/cert.pfx"

    if fileexists(arqCert):
        sizeCert = os.path.getsize(arqCert)
        try:
            with getConnPG(engineEMonitor) as connPG:
                pfx_path, pfx_password = gs.getCertProperties(connPG, inst, emp, 0)
            expirationCert = pfx_expiration_date(pfx_path, pfx_password)
        except Exception as e:
            print(e)
            expirationCert = "-1"
        sizeCert = f"{sizeCert},{expirationCert}"
    else:
        sizeCert = "-1,-1"
    return sizeCert
