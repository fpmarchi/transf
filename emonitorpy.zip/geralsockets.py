import socket

class Socket:
    DEFAULTHOST = '127.0.0.1'
    DEFAULTTIMEOUT = 60000 # 60s

    def __init__(self):
        self.s: socket = None

    def create_server(self, host = DEFAULTHOST, port = 0, timeout = DEFAULTTIMEOUT):
        try:
            self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.s.settimeout(timeout)
            self.bind(host, port)
            return True
        except Exception as e:
            print('Erro em geralsockets.create_server' + host + ' / ' + str(port))
            print(e)
            return False


    def create_client(self, port):
        self.create_client2(host=self.DEFAULTHOST, port=port, timeout=self.DEFAULTTIMEOUT)


    def create_client2(self, host, port, timeout):
        try:
            self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.s.settimeout(timeout)
            self.connect(host, port)
            return True
        except Exception as e:
            print('Erro em geralsockets.create_client' + host + ' / ' + str(port))
            print(e)
            return False


    def bind(self, host = DEFAULTHOST, port = 0):
        try:
            self.s.bind((host, port))
            self.s.listen()
            return True
        except Exception as e:
            print('Erro em geralsockets.bind' + host + ' / ' + str(port))
            print(e)
            return False


    def connect(self, host = DEFAULTHOST, port = 0):
        try:
            self.s.connect((host, port))
            return True
        except Exception as e:
            print('Erro em geralsockets.connect' + host + ' / ' + str(port))
            print(e)
            return False


    def getServerPort(self):
        return self.s.getsockname()[1]


    def accept(self):
        return self.s.accept() # retorna conn,addr


    def receive(self):
        try:
            conn, addr = self.accept()
            with conn:
                ret = []
                while True:
                    data = conn.recv(4096)
                    if not data:
                        break
                    ret.append(data.decode())
                return ''.join(ret)
        except Exception as e:
            print('Erro em geralsockets.receive')
            print(e)
            return None


    def send(self, msg: str, port: int, create = True):
        self.send2(msg=msg, host=self.DEFAULTHOST, port=port, timeout=self.DEFAULTTIMEOUT, create=create)


    def send2(self, msg, host, port, timeout, create = True):
        if create:
            if not self.create_client2(host, port, timeout):
                return False
        #
        self.s.sendall(msg.encode())
        return True

