import json
from collections import Callable
from json import dumps
from re import search
from typing import Tuple, Any
from functools import wraps

from requests import Response, post

from ActionProcessor import ActionProcessor, Callable_cfg


class MaxBot(ActionProcessor):
    MIN_ACTION = 4000
    MAX_ACTION = 4049
    PUT_CONTACT = 4000  # ACAO_MAXBOT_CADASTRAR_CONTATO
    SEND_TEXT = 4001  # ACAO_MAXBOT_ENVIAR_TEXTO

    DEFAULT_URL = 'https://mbr.maxbot.com.br/api/v1.php'

    def __init__(self):
        default_values: dict = {'url': self.DEFAULT_URL}
        request_builders: Callable_cfg = {
            self.PUT_CONTACT: (_put_contact_out, default_values),
            self.SEND_TEXT: (_send_text_out, default_values)
        }

        response_parsers: Callable_cfg = {
            self.SEND_TEXT: (_send_text_in, default_values),
            self.DEFAULT_FUNCTION: (_default_in, default_values)
        }

        super().__init__(request_builders, response_parsers)

    def get_url(self) -> str:
        return self.DEFAULT_URL


# Define o tipo de exceção local
class MaxBotException(Exception):
    pass


# Decorators (Devem ser declarados antes do uso)
def _handle_exception(func) -> Callable:
    @wraps(func)
    def wrapper(*args, **kwargs) -> Any:
        try:
            return func(*args, **kwargs)
        except MaxBotException as e:
            return '', str(e)
        except Exception as e:
            msg = 'Ocorreu um erro inesperado ao comunicar com a MaxBot:\n', str(e)
            print(msg)
            return '', msg

    return wrapper


# Funções para criação do JSON
@_handle_exception
def _put_contact_out(req: dict) -> Tuple[str, str]:
    if not req.get('token'):
        raise MaxBotException('O token de autorização não foi informado!')

    requerid_errors = check_required_values(req, ['nome', 'celular'])
    if requerid_errors:
        raise MaxBotException('Valores não encontrados: \n' + requerid_errors)

    if not ('sobrenome' in req):
        name_pats: list = req.get('nome', '').split(' ')
        req['name'] = name_pats[0]
        req['sobrenome'] = name_pats[-1]

    json_str = {
        'token': req.get('token', ''),
        'cmd': 'put_contact',
        'segmentation': 'LGPD',
        'tag': 'VIP',
        'name': req.get('nome', ''),
        'surname': req.get('sobrenome', ''),
        'whatsapp': whats_number(req.get('celular', '')),
        'mobile_phone': '55' + req.get('celular', '')[1:]
    }

    return dumps(json_str), ''


@_handle_exception
def _send_text_out(req: dict) -> Tuple[str, str]:
    json_dict = {
        'token': req.get('token', ''),
        'cmd': 'send_text',
        'ct_whatsapp': whats_number(req.get('celular', '')),
        'msg': req.get('mensagem', '')
    }

    return dumps(json_dict), ''


# Funções para tratamento de retorno
@_handle_exception
def _default_in(resp: Response) -> Tuple[str, str]:
    res = resp.json()

    resumido = {}
    json_dict = {
        'resumido': resumido,
        'completo': res
    }

    if res.get('status') != 1:
        raise MaxBotException('Erro retornado pela MaxBot:\n' + res.get('msg', ''))

    resumido['msg'] = res.get('msg', '')

    if 'contact_id' in res:
        resumido['id_contato'] = res['contact_id']

    return mount_xml_response(json_dict), ''


@_handle_exception
def _send_text_in(url: str, req_in: str, req: str, resp: Response) -> Tuple[str, str]:
    if 'Contact not found' in resp.json().get('msg'):
        json_to_send, err = _put_contact_out(json.loads(req_in))
        if err:
            return '', err

        resp = post(url, json=json.loads(json_to_send))
        if resp.json().get('status') == 1:
            resp = post(url, json=json.loads(req))

    return _default_in(resp)


# Funções utilitárias
def whats_number(cell: str) -> str:
    """
        Remove o 9 adicional de um celular. Como o x em 99x99999999
        e coloca o prefixo 55 nesse número.

        :param cell: str

        :return Exemplo: 67911111111 -> 556711111111
    """

    cell = cell.lstrip('0')
    groups = search(r'(^\d{2})(\d?)(\d{8})', cell).groups()

    return '55{0}{2}'.format(*groups)


def check_required_values(data: dict, requerid_keys: list) -> str:
    """
        Verifica se os valores keys informadas na lista de de keys requeridas
        foram definidos. Caso não sejam irá preencher a mensagem de retorno

        :param data: dict
        :param requerid_keys: list

        :return Mensagens com os campos obrigatórios. Ex.: O valor para example é obrigatório!
    """

    return ''.join(
        f'O valor para {k} é obrigatório!\n'
        for k in data.keys()
        if (k in requerid_keys) and (not data.get(k))
    )


def mount_xml_response(data: dict) -> str:
    """
        Retorna o XML de retorno contendo o JSON carregado a partir do
        dicionario informado no parâmetro data

        :param data: dict
        :return: XML String with JSON from data input
    """
    return '<?xml version="1.0" encoding="utf-8"?>' \
           '<resp>' \
           '<erro>f</erro>' \
           '<json>' + dumps(data) + '</json>' \
           '</resp>'
