# instancia o objeto base a ser importado
from leadsfy import Leadsfy
from mensageria.maxbot import MaxBot

maxbot = MaxBot()
leadsfy = Leadsfy.get_instance(min_action=1700, max_action=1749)
