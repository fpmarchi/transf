'''
Lista de links de documentacoes:
- http://www.abrasf.org.br/pagina_publica.php
- CENTI:
  - https://sites.google.com/a/centi.com.br/nfse/documentacao-nfs-e
  - https://api.centi.com.br/swagger/index.html
  - Cidades usadas:
    Rio Verde/GO: http://servicos.rioverde.go.gov.br/
- ABACO:
  - Cidades usadas:
    Varzea Grande/MT: https://www.e-nfs.com.br/varzeagrande/servlet/hwlistamanuaisportal
           Validador: https://www.e-nfs.com.br/varzeagrande/validador.html
- COPLAN:
  - Cidades usadas:
    Rondonopolis/MT: https://www.gp.srv.br/tributario_homologacao/servlet/anfse_web_service?wsdl http://intranet.rondonopolis.mt.gov.br/tributario_rondonopolis/servlet/anfse_web_service?wsdl

set schema 'serradies';
update conhecimentoadic set nfserps = 101 where numero = 15;
update conhecimentoadic set nfseemonitorstatus = null, nfsestatus = null where numero = 15;
select nfsemsgret,nfserps,nfseserie,nfsenumero,nfseprot,numformsegcte from conhecimentoadic where numero = 15;

select status,msgret,cast(arqxmlresp as varchar(10000)) from emonitorspool where codemonitorspool = 460063;

'''

import xml.etree.ElementTree as tree
import requests
#import certifi_icpbr
import json
import xml.dom.minidom as mdom

from geralxml import *
from geraljson import *
from geral import *
from geralsis import prop
import sefaz_spooler
from notacontrol import process_response_notacontrol, process_request_notacontrol
from sefaz import dao

from centi import *
from abaco import *
from coplan import *
from betha import process_request_betha, process_response_betha
from agili import process_request_agili
from fiorilli import process_response_fiorilli, process_request_fiorilli

# Lista de Codigos de IBGE de Cidades implementadas
# IMPORTANTE: COLOCAR CIDADES ORDENADAS POR ESTADO
# GO
CODIBGE_GO_RIOVERDE = '5218805'


# MT
CODIBGE_MT_VARZEAGRANDE = '5108402'
CODIBGE_MT_RONDONOPOLIS = '5107602'
CODIBGE_MT_CANARANA = '5102702'
CODIBGE_MT_LUCASDORIOVERDE = '5105259'
CODIBGE_MT_SORRISO = '5107925'
CODIBGE_MT_CUIABA = '5103403'


# PA
CODIBGE_PA_ITAITUBA = '1503606'


# Acoes do MDF-e 3
ACAO_NFSE_RECEPCAO = 501
ACAO_NFSE_CANCELAMENTO = 503
ACAO_NFSE_CONSULTA_NFSE_POR_RPS = 504  # usado nas comunicacoes assincronas de autorizacao
ACAO_NFSE_CONSULTA_NFSE = 505
ACAO_NFSE_CONSULTA_LOTE_RPS = 506
ACAO_NFSE_CONSULTA_SITLOTE_RPS = 507
ACAO_NFSE_IMPRIME_NFSE = 508


def callNFSe(conn, pfx_path, pfx_password, codInstalacao, codEmpresa, codEMonitorAcao, codIBGE, tpAmb, versao, req):
    try:
        req = req.replace('\\"', '"')
        reqJSON = ''
        if req:
            reqJSON = json.loads(req)
    except Exception as e:
        print('Erro em callNFSe ao ler JSON')
        print(e)
        return '', 'Erro em callNFSe ao ler JSON => ' + str(e), '', ''
    # gerar request (XML ou JSON), assinar, checar com XSD (se for XML), pegar parametros da comunicacao (URL, metodo, tipo, acao)
    dataHoraEnvioLote = datetime.now()

    # Permite a criação de assinaturas de XML válidas
    if codIBGE == CODIBGE_PA_ITAITUBA:
        assinatura = AssinaturaA1(certificado=pfx_path, senha=pfx_password, raw_cert=True)
    else:
        assinatura = AssinaturaA1(certificado=pfx_path, senha=pfx_password)

    req, erros = processRequest(codEMonitorAcao, codIBGE, reqJSON, assinatura, tpAmb)
    if erros != '':
        return '', erros, '', ''
    reqOrig = req # pois req pode sofrer alteracoes no metodo abaixo getParamsCom
    codUF, versao, url, requestMethod, contentType, extensionType, action, req = getParamsCom(codEMonitorAcao, codIBGE, tpAmb, versao, reqJSON, req)
    if url == '':
        return '', 'Codigo de IBGE do Municipio ' + codIBGE + ' sem URL', '', ''
    contentType = contentType + ';charset=utf-8'
    # enviar requisicao e aguardar resposta usando o certificado do cliente
    with pfx_to_pem(pfx_path, pfx_password) as cert:
        try:
            headers = {}
            headers['Content-type'] = contentType
            if action != '':
                headers['SOAPAction'] = action
            # if requestProperties != '':
            #     # PENDENTE requestProperties nao pode ter = e & como conteudo valido, pois sao separadores de campos
            #     if hasPreProcessRequestProperties(codEMonitorAcao):
            #         headers, erros = preProcessRequestProperties(cert, codEMonitorAcao, url, requestProperties, headers)
            #         if erros != '':
            #             return '', erros, '', ''
            #     else:
            #         if processRequestProperties(codEMonitorAcao):
            #             listProperties = list(requestProperties.split('&'))
            #             for property in listProperties:
            #                 entry = property.split('=')
            #                 headers[entry[0]] = entry[1]
            # url, requestMethod = preProcessURLRequestMethod(cert, codEMonitorAcao, url, requestMethod, headers, req, reqAux)
            # if url == '':
            #     return '', requestMethod, '', '' # se der erro ao tentar preprocessar, url retorna vazia e requestMethod retorna o erro
            #
            if requestMethod and requestMethod.upper() == 'GET':
                resp = requests.get(url, cert=cert, data=req, headers=headers)
            elif requestMethod and requestMethod.upper() == 'PATCH':
                resp = requests.patch(url, cert=cert, data=req, headers=headers)
            elif requestMethod and requestMethod.upper() == 'PUT':
                resp = requests.put(url, cert=cert, data=req, headers=headers)
            else:
                resp = requests.post(url, cert=cert, data=req, headers=headers, verify=False) # nao verifica a veracidade de nenhuma chave publica de prefeitura
            retcode = resp.status_code # https://pt.wikipedia.org/wiki/Lista_de_códigos_de_estado_HTTP
            ret = resp.content.decode('utf-8')
            #
            arqreq = '/sistemas/emonitorpy/tmp/req' + str(codInstalacao) + '_' + str(codEmpresa) + '_' + str(codEMonitorAcao) + extensionType
            arqresp = '/sistemas/emonitorpy/tmp/resp' + str(codInstalacao) + '_' + str(codEmpresa) + '_' + str(codEMonitorAcao) + extensionType
            strtofile(arqreq, req)
            if ret is None:
                ret = ''
            strtofile(arqresp, ret)
            #
            resp2 = ''
            numeroNFSe = '' # vai gravar o numero da NFSe e nao algum protocolo retornado pela PM no EMonitorSpool.nProt
            msgRet = getMsgRetByRetCode(retcode,url)

            if codIBGE in [CODIBGE_MT_CUIABA]:
                msgRet = ''

            if msgRet == '':
                resp2, msgRet, numeroNFSe = processResponse(codEMonitorAcao, codIBGE, ret)
            #
            if msgRet != '':
                codEMonitorSpool = dao.insEMonitorSpool(False, conn, codInstalacao, codEmpresa, codEMonitorAcao, codUF, codIBGE, tpAmb,
                                     getJSON(reqJSON, 'conh_rps'), '', versao, dataHoraEnvioLote, msgRet,
                                     reqOrig, req, ret, sefaz_spooler.EMONITORSPOOL_ERROPROCESSAMENTO)
                print('Spool com erro = ' + str(codEMonitorSpool) + ' - ' + msgRet)
                if codIBGE in [CODIBGE_MT_CANARANA, CODIBGE_MT_LUCASDORIOVERDE, CODIBGE_MT_CUIABA]:
                    reqOrig = escape(reqOrig)
                    ret = escape(ret)
                    strtofile(arqreq, escape(req))
                    strtofile(arqresp, ret)
                msgRet = createtag('msgRet', msgRet) + createtag('codEMonitorSpool', str(codEMonitorSpool)) + createtag('arqXMLAss', reqOrig) + createtag('arqXMLResp', ret)
                return '', msgRet, arqreq, arqresp
            else:
                isAssinc, codEMonitorAcaoAssinc = isAcaoAssinc(codEMonitorAcao, codIBGE)
                if isAssinc:
                    return callNFSeAssinc(conn, pfx_path, pfx_password, codInstalacao, codEmpresa, codEMonitorAcaoAssinc, codIBGE, tpAmb, versao, req, reqJSON, assinatura, arqreq, arqresp)
                #
                codEMonitorSpool = dao.insEMonitorSpool(False, conn, codInstalacao, codEmpresa, codEMonitorAcao, codUF, codIBGE, tpAmb,
                                     getJSON(reqJSON, 'conh_rps'), numeroNFSe, versao, dataHoraEnvioLote, 'Autorizado o uso da NFS-e',
                                     reqOrig, req, ret, sefaz_spooler.EMONITORSPOOL_PROCESSADO)
                print('Spool processado = ' + str(codEMonitorSpool))
                if codIBGE in [CODIBGE_MT_CANARANA, CODIBGE_MT_LUCASDORIOVERDE, CODIBGE_MT_VARZEAGRANDE, CODIBGE_MT_RONDONOPOLIS, CODIBGE_MT_CUIABA]:
                    reqOrig = escape(reqOrig)
                    ret = escape(ret)
                    strtofile(arqreq, escape(req))
                    strtofile(arqresp, ret)
                resp2 = '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro>' + resp2 + createtag('codEMonitorSpool', str(codEMonitorSpool)) + createtag('arqXMLAss', reqOrig) + createtag('arqXMLResp', ret) + '</resp>'
                return resp2, '', arqreq, arqresp
        except Exception as e:
            print('Erro Interno em callNFSe')
            print(e)
            msgRet = 'ERRO INTERNO NA CHAMADA DO SERVICO NFSE'
            codEMonitorSpool = dao.insEMonitorSpool(False, conn, codInstalacao, codEmpresa, codEMonitorAcao, codUF, codIBGE, tpAmb,
                                 getJSON(reqJSON, 'conh_rps'), '', versao, dataHoraEnvioLote, msgRet,
                                 reqOrig, req, '', sefaz_spooler.EMONITORSPOOL_ERROPROCESSAMENTO)
            print('Spool com erro interno = ' + str(codEMonitorSpool))
            msgRet = createtag('msgRet', msgRet) + createtag('codEMonitorSpool', str(codEMonitorSpool))
            return '', msgRet, '', ''


def isAcaoAssinc(codEMonitorAcao, codIBGE):
  #  if (codIBGE == CODIBGE_MT_RONDONOPOLIS) and codEMonitorAcao == ACAO_NFSE_RECEPCAO:
  #       return True, ACAO_NFSE_CONSULTA_NFSE_POR_RPS
  #   else:
        return False, codEMonitorAcao


def getMsgRetByRetCode(retcode,url):
    if retcode == 401:
        return 'ACESSO NEGADO (PROVAVELMENTE DEVIDO A CREDENCIAIS INVÁLIDAS) À PREFEITURA (401)'
    elif retcode == 403:
        return 'ACESSO NEGADO (PROVAVELMENTE DEVIDO A ERRO DE CERTIFICADO) À PREFEITURA (403)'
    elif retcode == 404:
        return 'INFORMAÇÃO NÃO ENCONTRADA NO ENDEREÇO ' + url + ' (404) '
    elif retcode == 500:
        return 'ERRO INTERNO DO SERVIDOR DA PREFEITURA (500). URL:' + url
    else:
        return ''


def callNFSeAssinc(conn, pfx_path, pfx_password, codInstalacao, codEmpresa, codEMonitorAcao, codIBGE, tpAmb, versao, req, reqJSON, assinatura, arqreq, arqresp):
    # ficar em loop dormindo SleepTimeSpoolerAsyncThread e tentando numAttempts
    # para processar ate que tenha retorno de autorizado ou de erro definitivo
    dataHoraEnvioLote = datetime.now()
    reqAssinc, erros = processRequest(codEMonitorAcao, codIBGE, reqJSON, assinatura, tpAmb)
    if erros != '':
        return '', erros, '', ''
    reqOrigAssinc = reqAssinc # pois req pode sofrer alteracoes no metodo abaixo getParamsCom
    codUF, versao, url, requestMethod, contentType, extensionType, action, req = getParamsCom(codEMonitorAcao, codIBGE, tpAmb, versao, reqJSON, req)
    if url == '':
        return '', 'Codigo de IBGE do Municipio ' + codIBGE + ' sem URL', '', ''
    contentType = contentType + '; charset=utf-8'
    # enviar requisicao e aguardar resposta usando o certificado do cliente
    with pfx_to_pem(pfx_path, pfx_password) as cert:
        try:
            headers = {}
            headers['Content-type'] = contentType
            if action != '':
                headers['SOAPAction'] = action
            sleepAssinc = int(prop['SleepTimeSpoolerAsyncThread'].data) / 1000
            numAttempts = int(prop['numAttempts'].data)
            ctAttempts = 0
            while ctAttempts < numAttempts:
                if requestMethod and requestMethod.upper() == 'GET':
                    resp = requests.get(url, cert=cert, data=reqAssinc, headers=headers)
                elif requestMethod and requestMethod.upper() == 'PATCH':
                    resp = requests.patch(url, cert=cert, data=reqAssinc, headers=headers)
                elif requestMethod and requestMethod.upper() == 'PUT':
                    resp = requests.put(url, cert=cert, data=reqAssinc, headers=headers)
                else:
                    resp = requests.post(url, cert=cert, data=reqAssinc, headers=headers, verify=False)  # nao verifica a veracidade de nenhuma chave publica de prefeitura
                retcode = resp.status_code  # https://pt.wikipedia.org/wiki/Lista_de_códigos_de_estado_HTTP
                retAssinc = resp.content.decode('utf-8')
                #
                arqreqAssinc = '/sistemas/emonitorpy/tmp/req' + str(codInstalacao) + '_' + str(codEmpresa) + '_' + str(codEMonitorAcao) + extensionType
                arqrespAssinc = '/sistemas/emonitorpy/tmp/resp' + str(codInstalacao) + '_' + str(codEmpresa) + '_' + str(codEMonitorAcao) + extensionType
                strtofile(arqreqAssinc, reqAssinc)
                if retAssinc is None:
                    retAssinc = ''
                strtofile(arqrespAssinc, retAssinc)
                #
                resp2 = ''
                numeroNFSe = ''  # vai gravar o numero da NFSe e nao algum protocolo retornado pela PM no EMonitorSpool.nProt
                msgRet = getMsgRetByRetCode(retcode,url)
                if msgRet == '':
                    resp2, msgRet, numeroNFSe = processResponse(codEMonitorAcao, codIBGE, retAssinc)
                #
                if msgRet != '':
                    codEMonitorSpool = dao.insEMonitorSpool(False, conn, codInstalacao, codEmpresa, codEMonitorAcao, codUF, codIBGE, tpAmb,
                                         getJSON(reqJSON, 'conh_rps'), '', versao, dataHoraEnvioLote, msgRet,
                                         reqOrigAssinc, req, retAssinc, sefaz_spooler.EMONITORSPOOL_ERROPROCESSAMENTO)
                    print('Spool com erro = ' + str(codEMonitorSpool) + ' - ' + msgRet)
                    msgRet = createtag('msgRet', msgRet) + createtag('codEMonitorSpool', str(codEMonitorSpool)) + createtag('arqXMLAss', reqOrigAssinc) + createtag('arqXMLResp', retAssinc)
                    return '', msgRet, arqreqAssinc, arqrespAssinc
                else:
                    codEMonitorSpool = dao.insEMonitorSpool(False, conn, codInstalacao, codEmpresa, codEMonitorAcao, codUF, codIBGE, tpAmb,
                                         getJSON(reqJSON, 'conh_rps'), numeroNFSe, versao, dataHoraEnvioLote, 'Autorizado o uso da NFS-e',
                                         reqOrigAssinc, req, retAssinc, sefaz_spooler.EMONITORSPOOL_PROCESSADO)
                    print('Spool processado = ' + str(codEMonitorSpool))
                    if codIBGE in [CODIBGE_MT_CANARANA, CODIBGE_MT_LUCASDORIOVERDE, CODIBGE_MT_VARZEAGRANDE]:
                        reqOrigAssinc = escape(reqOrigAssinc)
                        retAssinc = escape(retAssinc)
                        strtofile(arqreq, escape(reqAssinc))
                        strtofile(arqresp, retAssinc)
                    resp2 = '<?xml version="1.0" encoding="utf-8"?><resp><erro>f</erro>' + resp2 + createtag('codEMonitorSpool', str(codEMonitorSpool)) + createtag('arqXMLAss', reqOrigAssinc) + createtag('arqXMLResp', retAssinc) + '</resp>'
                    #print(resp2)
                    return resp2, '', arqreq, arqresp
                #
                ctAttempts = ctAttempts + 1
                sleep(sleepAssinc)
        except Exception as e:
            print('Erro Interno em callNFSeAssinc')
            print(e)
            msgRet = 'ERRO INTERNO NA CHAMADA DO SERVICO NFSE ASSINCRONO'
            codEMonitorSpool = dao.insEMonitorSpool(False, conn, codInstalacao, codEmpresa, codEMonitorAcao, codUF, codIBGE, tpAmb,
                                 getJSON(reqJSON, 'conh_rps'), '', versao, dataHoraEnvioLote, msgRet,
                                 reqOrig, req, '', sefaz_spooler.EMONITORSPOOL_ERROPROCESSAMENTO)
            print('Spool com erro interno (assincrono) = ' + str(codEMonitorSpool))
            msgRet = createtag('msgRet', msgRet) + createtag('codEMonitorSpool', str(codEMonitorSpool))
            return '', msgRet, '', ''


def getParamsCom(codEMonitorAcao, codIBGE, tpAmb, versao, reqJSON, req):
    # returns codUF, versao, url, requestMethod, contentType, extensionType, action, req (que pode ser processado para incluir outras infos)
    url = ''
    #-------------------------------------------------------
    # acoes CODIBGE_GO_RIOVERDE
    #-------------------------------------------------------
    if codIBGE == CODIBGE_GO_RIOVERDE:
        if tpAmb == '1':
            url = 'https://api.centi.com.br/nfe/<#ACAO>/go/rioverde'
        else:
            url = 'https://api.centi.com.br/nfe/<#ACAO>/homologacao/go/rioverde'
        if codEMonitorAcao == ACAO_NFSE_RECEPCAO or codEMonitorAcao == ACAO_NFSE_CONSULTA_NFSE or codEMonitorAcao == ACAO_NFSE_CANCELAMENTO:
            if codEMonitorAcao == ACAO_NFSE_RECEPCAO:
                url = url.replace('<#ACAO>','gerar')
            elif codEMonitorAcao == ACAO_NFSE_CONSULTA_NFSE:
                if tpAmb == '1':
                    url = url.replace('<#ACAO>', 'consultar/rps')
                else:
                    url = url.replace('<#ACAO>', 'consultar')
                    url = url.replace('homologacao', 'homologacao/rps')
            elif codEMonitorAcao == ACAO_NFSE_CANCELAMENTO:
                url = url.replace('<#ACAO>', 'cancelar')
            us = getJSON(reqJSON, 'us')
            pw = getJSON(reqJSON, 'pw')
            reqJSON = {}
            reqJSON['xml'] = req
            reqJSON['usuario'] = us
            reqJSON['senha'] = pw
            req = json.dumps(reqJSON)
            return 'GO', versao, url, 'POST', 'application/json', '.json', '', req
        else:
            return '', '', '', '', '', '', '', ''
    #-------------------------------------------------------
    # acoes ODIBGE_MT_SORRISO
    #-------------------------------------------------------
    if codIBGE == CODIBGE_MT_SORRISO:
        if tpAmb == '1':
            url = 'https://agilibluedemonstracao.agilicloud.com.br/api<#ACAO>'
        else:
            url = 'https://agilibluedemonstracao.agilicloud.com.br/api/<#ACAO>'
        if codEMonitorAcao == ACAO_NFSE_RECEPCAO or codEMonitorAcao == ACAO_NFSE_CONSULTA_NFSE or codEMonitorAcao == ACAO_NFSE_CANCELAMENTO:
            if codEMonitorAcao == ACAO_NFSE_RECEPCAO:
                url = url.replace('<#ACAO>','GerarNfse')
            elif codEMonitorAcao == ACAO_NFSE_CONSULTA_NFSE:
                url = url.replace('<#ACAO>', 'ConsultarNfseFaixa')
                if tpAmb == '1':
                    print('no error')#url = url.replace('<#ACAO>', 'consultar')
                else:
                    print('no error')#url = url.replace('<#ACAO>', 'consultar')
                    print('no error')#url = url.replace('homologacao', 'homologacao/rps')
            elif codEMonitorAcao == ACAO_NFSE_CANCELAMENTO:
                url = url.replace('<#ACAO>', 'CancelarNfse')


            return 'MT', versao, url, 'POST', 'application/xml', '.xml', '', req
        else:
            return '', '', '', '', '', '', '', ''
    #-------------------------------------------------------
    # acoes CODIBGE_MT_VARZEAGRANDE
    #-------------------------------------------------------
    elif codIBGE == CODIBGE_MT_VARZEAGRANDE:
        if tpAmb == '1':
            url = 'https://www.e-nfs.com.br/varzeagrande/servlet/<#ACAO>?wsdl' #'https://e-nfs.com.br/varzeagrande/servlet/<#ACAO>?wsdl'
        else:
            url = 'https://enfs-hom.abaco.com.br/varzeagrande/servlet/<#ACAO>?wsdl'
        if codEMonitorAcao == ACAO_NFSE_RECEPCAO or \
                codEMonitorAcao == ACAO_NFSE_CONSULTA_NFSE_POR_RPS or \
                codEMonitorAcao == ACAO_NFSE_CONSULTA_NFSE or \
                codEMonitorAcao == ACAO_NFSE_CONSULTA_LOTE_RPS or \
                codEMonitorAcao == ACAO_NFSE_CONSULTA_SITLOTE_RPS or \
                codEMonitorAcao == ACAO_NFSE_CANCELAMENTO:
            if codEMonitorAcao == ACAO_NFSE_RECEPCAO:
                url = url.replace('<#ACAO>','arecepcionarloterps')
            elif codEMonitorAcao == ACAO_NFSE_CONSULTA_NFSE_POR_RPS:
                url = url.replace('<#ACAO>', 'aconsultarnfseporrps')
            elif codEMonitorAcao == ACAO_NFSE_CONSULTA_NFSE:
                url = url.replace('<#ACAO>', 'aconsultarnfse')
            elif codEMonitorAcao == ACAO_NFSE_CONSULTA_LOTE_RPS:#ACAO_NFSE_CONSULTA_LOTE_RPS:
                url = url.replace('<#ACAO>', 'aconsultarloterps')
            elif codEMonitorAcao == ACAO_NFSE_CONSULTA_SITLOTE_RPS:
                url = url.replace('<#ACAO>', 'aconsultarsituacaoloterps')
            elif codEMonitorAcao == ACAO_NFSE_CANCELAMENTO:
                url = url.replace('<#ACAO>', 'acancelarnfse')
            return 'MT', versao, url, 'POST', 'application/xml', '.xml', '', req
        else:
            return '', '', '', '', '', '', '', ''
    #-------------------------------------------------------
    # acoes CODIBGE_MT_RONDONOPOLIS
    #-------------------------------------------------------
    elif codIBGE == CODIBGE_MT_RONDONOPOLIS:
        if tpAmb == '1':
            url = 'http://intranet.rondonopolis.mt.gov.br/tributario_rondonopolis/servlet/anfse_web_service?wsdl'
        else:
            url = 'https://www.gp.srv.br/tributario/homologacao/anfse_web_service?wsdl'
        return 'MT', versao, url, 'POST', 'text/xml', '.xml', '', req

    # -------------------------------------------------------
    # acoes CODIBGE_MT_CANARANA
    # -------------------------------------------------------
    elif codIBGE in [CODIBGE_MT_CANARANA, CODIBGE_MT_LUCASDORIOVERDE]:
        if tpAmb == '1':
            url = 'http://e-gov.betha.com.br/e-nota-contribuinte-ws/nfseWS?wsdl'
        else:
            url = 'http://e-gov.betha.com.br/e-nota-contribuinte-test-ws/nfseWS?wsdl'
        return 'MT', versao, url, 'POST', 'text/xml', '.xml', '', req

    # -------------------------------------------------------
    # acoes CODIBGE_PA_ITAITUBA
    # -------------------------------------------------------
    elif codIBGE == CODIBGE_PA_ITAITUBA:
        if tpAmb == '1':
            url = 'http://fi1.fiorilli.com.br:5663/IssWeb-ejb/IssWebWS/IssWebWS?wsdl'
        else:
            url = 'http://fi1.fiorilli.com.br:5663/IssWeb-ejb/IssWebWS/IssWebWS?wsdl'
        if codEMonitorAcao == ACAO_NFSE_RECEPCAO or \
                codEMonitorAcao == ACAO_NFSE_CONSULTA_NFSE_POR_RPS or \
                codEMonitorAcao == ACAO_NFSE_CONSULTA_NFSE or \
                codEMonitorAcao == ACAO_NFSE_CONSULTA_LOTE_RPS or \
                codEMonitorAcao == ACAO_NFSE_CONSULTA_SITLOTE_RPS or \
                codEMonitorAcao == ACAO_NFSE_CANCELAMENTO:
            if codEMonitorAcao == ACAO_NFSE_RECEPCAO:
                url = url.replace('<#ACAO>','recepcionarLoteRpsSincrono')
            elif codEMonitorAcao == ACAO_NFSE_CONSULTA_LOTE_RPS:#ACAO_NFSE_CONSULTA_LOTE_RPS:
                url = url.replace('<#ACAO>', 'consultarLoteRps')
            elif codEMonitorAcao == ACAO_NFSE_CANCELAMENTO:
                url = url.replace('<#ACAO>', 'cancelarNfse')
            return 'PA', versao, url, 'POST', 'application/xml', '.xml', '', req
        else:
            return '', '', '', '', '', '', '', ''
    elif codIBGE == CODIBGE_MT_CUIABA:
        if tpAmb == '1':
            url = 'https://wscuiaba.issnetonline.com.br/webservicenfse204/nfse.asmx'
        else:
            url = 'https://www.issnetonline.com.br/homologaabrasf/webservicenfse204/nfse.asmx'

        return 'MT', versao, url, 'POST', 'application/xml', '.xml', '', req
        # else:
        #     return '', '', '', '', '', '', '', ''
    # -------------------------------------------------------
    # Implementacao nao encontrada
    # -------------------------------------------------------
    else:
        return '', '', '', '', '', '', '', ''


def processRequest(codEMonitorAcao, codIBGE, reqJSON, assinatura, tpAmb):
    # returns request, erros
    if codIBGE == CODIBGE_GO_RIOVERDE:
        return processRequestCenti(codEMonitorAcao, codIBGE, reqJSON, assinatura)
    elif codIBGE == CODIBGE_MT_VARZEAGRANDE:
        return process_request_abaco(codEMonitorAcao, codIBGE, reqJSON, assinatura)
    elif codIBGE == CODIBGE_MT_SORRISO:
        return process_request_agili(codEMonitorAcao, codIBGE, reqJSON, assinatura)
    elif codIBGE == CODIBGE_MT_RONDONOPOLIS:
        return process_request_coplan(codEMonitorAcao, codIBGE, reqJSON, assinatura)
    elif codIBGE in [CODIBGE_MT_CANARANA, CODIBGE_MT_LUCASDORIOVERDE]:
        return process_request_betha(codEMonitorAcao, codIBGE, reqJSON, assinatura)
    elif codIBGE == CODIBGE_PA_ITAITUBA:
        return process_request_fiorilli(codEMonitorAcao, codIBGE, reqJSON, assinatura)
    elif codIBGE == CODIBGE_MT_CUIABA:
        return process_request_notacontrol(codEMonitorAcao, codIBGE, reqJSON, assinatura, tpAmb)
    else:
        return '', 'Codigo de IBGE do Municipio ' + codIBGE + ' sem Implementacao'


def processResponse(codEMonitorAcao, codIBGE, ret):
    # returns response, erros, nProt(numero da NFSe)
    if codIBGE == CODIBGE_GO_RIOVERDE:
        return processResponseCenti(codEMonitorAcao, codIBGE, ret)
    elif codIBGE == CODIBGE_MT_VARZEAGRANDE:
        return process_response_abaco(codEMonitorAcao, codIBGE, ret)
    elif codIBGE == CODIBGE_MT_SORRISO:
        return process_response_abaco(codEMonitorAcao, codIBGE, ret)
    elif codIBGE == CODIBGE_MT_RONDONOPOLIS:
        return process_response_coplan(codEMonitorAcao, ret)
    elif codIBGE in [CODIBGE_MT_CANARANA, CODIBGE_MT_LUCASDORIOVERDE]:
        return process_response_betha(codEMonitorAcao, codIBGE, ret)
    elif codIBGE == CODIBGE_PA_ITAITUBA:
        return process_response_fiorilli(codEMonitorAcao, codIBGE, ret)
    elif codIBGE == CODIBGE_MT_CUIABA:
        return process_response_notacontrol(codEMonitorAcao, codIBGE, ret)
    else:
        return '', 'Codigo de IBGE do Municipio ' + codIBGE + ' sem Implementacao', ''


