import json
from typing import Tuple

import xmltodict

import nfse_spooler
from ActionProcessor import handle_exception_factory
from geral import *
from geralxml import *


class FiorilliException(Exception):
    pass


def process_request_fiorilli(cod_acao_emonitor: int, cod_ibge: int,
                             req: dict, assinatura: AssinaturaA1) -> Tuple[str, str]:
    if cod_acao_emonitor == nfse_spooler.ACAO_NFSE_RECEPCAO:
        xml, erro = request_fiorilli_recepcao(cod_ibge, req, assinatura)
    # if cod_acao_emonitor == nfse_spooler.ACAO_NFSE_RECEPCAO:
    #     xml, erro = recepcionar_loterps_sincrono(cod_ibge, req, assinatura)
    elif cod_acao_emonitor == nfse_spooler.ACAO_NFSE_CONSULTA_LOTE_RPS:
        xml, erro = consultar_lote_rps(req, cod_ibge)
    elif cod_acao_emonitor == nfse_spooler.ACAO_NFSE_CANCELAMENTO:
        xml, erro = cancelar_nfse(req, cod_ibge, assinatura)
    else:
        return '', 'Acao ' + str(cod_acao_emonitor) + ' sem Implementação'

    return xml, erro


def envelop(service1: str, service2: str, data: Union[str, dict]):
    if not data:
        return data

    soap_env: dict = {
        'soapenv:Envelope': {
            '@xmlns:soapenv': 'http://schemas.xmlsoap.org/soap/envelope/',
            '@xmlns:ws': 'http://ws.issweb.fiorilli.com.br/',
            '@xmlns:xd': 'http://www.w3.org/2000/09/xmldsig#',
            '@xmlns:nfse': 'http://www.abrasf.org.br/nfse.xsd',
            'soapenv:Header': '',
            'soapenv:Body': {
                'ws:' + service1: {
                    service2: data,  # (data, {'cdata': True})
                    'username': '01001001000113',
                    'password': '123456'
                },
            }
        }
    }

    lote_str = xml_from_dict(soap_env, indent=True, indent_with_space=True)
    return lote_str


def request_fiorilli_recepcao(cod_ibge: int, req: dict, assinatura: AssinaturaA1) -> Tuple[str, str]:
    rps, erros = process_xml_request_fiorilli_recepcao(req, assinatura)

    lote: dict = {
        'LoteRps': {
            '@Id': 'lote' + req.get('conh_rps', ''),
            '@versao': '2.02',
            '#ns': 'nfse',
            'NumeroLote': req.get('conh_nreclote', ''),
            'CpfCnpj': {
                'Cnpj': req.get('conh_filial_cnpjcpf', '')
            },
            'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
            'QuantidadeRps': 1,
            'ListaRps': rps
        }
    }

    envelop_str = envelop('recepcionarLoteRpsSincrono', 'nfse:EnviarLoteRpsSincronoEnvio', lote)
    envelop_str = assinatura.assinar_elementos(envelop_str, 'InfDeclaracaoPrestacaoServico')
    envelop_str = assinatura.assinar_elementos(envelop_str, 'LoteRps')

    return envelop_str, ''


def process_xml_request_fiorilli_recepcao(req: dict, assinatura):
    rps: dict = {
        'Rps.InfDeclaracaoPrestacaoServico': {
            '@Id': 'rps' + req.get('conh_rps' + '1', ''),
            'Rps': {
                'IdentificacaoRps': {
                    'Numero': req.get('conh_rps', ''),
                    'Serie': req.get('conh_serie', ''),
                    'Tipo': 1,
                },
                'DataEmissao': req.get('conh_datahoraemissao'),
                'Status': '1',
            },
            'Competencia': '2013-05-13',  # req.get('NaturezaOperacao', '1'),
            'Servico': {
                'Valores': {
                    'ValorServicos': req.get('conh_freteempresa', ''),
                    'ValorDeducoes': 0.00,
                    'ValorPis': req.get('conh_valorpis', ''),
                    'ValorCofins': req.get('conh_valorcofins', ''),
                    'ValorInss': req.get('conh_valoriss', ''),
                    'ValorIr': req.get('conh_valorirrf', ''),
                    'ValorCsll': req.get('conh_valorcsll', ''),
                    'OutrasRetencoes': 0.00,
                    'ValorIss': req.get('conh_taxaiss', ''),
                    'Aliquota': 0.02,  # str(float(req.get('conh_freteempresa', '')) *0.03),
                    # 'DescontoIncondicionado': 0.00,
                    # 'DescontoCondicionado': 0.00,
                },
                'IssRetido': req.get('conh_pagaiss', ''),
                'ResponsavelRetencao': req.get('conh_pagaiss', ''),
                'ItemListaServico': req.get('conh_codservico', ''),
                # 'CodigoCnae': req.get('conh_cnae', ''),
                # 'CodigoTributacaoMunicipio': req.get('conh_codtributacao', ''),
                'Discriminacao': req.get('conh_descservico', ''),
                'CodigoMunicipio': '5108402',
                'CodigoPais': '1058',  # 'CodigoPais',
                'ExigibilidadeISS': '1',  # 'CodigoPais',
                # 'MunicipioIncidencia': '',  # 'CodigoPais',
                # 'NumeroProcesso': '',  # 'CodigoPais',

            },
            'Prestador': {
                'CpfCnpj': {
                    'Cnpj' if len(req.get('conh_cliente_cnpjcpf', '')) > 11 else
                    'Cpf': req.get('conh_cliente_cnpjcpf', '')
                },
                'InscricaoMunicipal': req.get('conh_filial_inscmun', '')
            },
            'Tomador': {
                'IdentificacaoTomador': {
                    'CpfCnpj': {
                        'Cnpj' if len(req.get('conh_cliente_cnpjcpf', '')) > 11 else
                        'Cpf': req.get('conh_cliente_cnpjcpf', '')
                    },
                    # 'InscricaoMunicipal': '',
                },
                'RazaoSocial': req.get('conh_cliente_nome', ''),
                'Endereco': {
                    'Endereco': req.get('conh_cliente_endereco', ''),
                    'Numero': req.get('conh_cliente_numero', ''),
                    'Complemento': req.get('conh_cliente_complemento', ''),
                    'Bairro': req.get('conh_cliente_bairro', ''),
                    'CodigoMunicipio': req.get('conh_cliente_cidade_codibge', ''),  # '5108402',  # 5107040
                    'Uf': req.get('conh_cliente_cidade_uf', ''),
                    'CodigoPais': '1058',
                    'Cep': req.get('conh_cliente_cep', ''),
                },
                'Contato': {
                    'Telefone': req.get('conh_cliente_fone', ''),
                    'Email': req.get('conh_cliente_email', ''),
                }
            },
            # 'RegimeEspecialTributacao': req.get('conh_cliente_cep', ''),
            'OptanteSimplesNacional': '2',
            'IncentivoFiscal': '2',
        }
    }

    return rps, ''


def consultar_lote_rps(req: dict, cod_ibge: int):
    query: dict = {
        'ConsultarLoteRpsEnvio': {
            '@xmlns': 'http://www.abrasf.org.br/nfse.xsd',
            'Prestador': {
                'CpfCnpj': {
                    'Cnpj' if len(req.get('conh_filial_cnpjcpf', '')) > 11 else
                    'Cpf': req.get('conh_filial_cnpjcpf', '')
                },
                'InscricaoMunicipal': req.get('conh_filial_inscmun', '')
            },
            'Protocolo': req.get('conh_nprot', ''),
        }
    }
    return envelop('ws:consultarLoteRps', xml_from_dict(query)), ''


def cancelar_nfse(req: dict, cod_ibge: int, assinatura: AssinaturaA1):
    query: dict = {
        'CancelarNfseEnvio': {
            '@xmlns': 'http://www.abrasf.org.br/nfse.xsd',
            'Pedido.InfPedidoCancelamento': {
                '@Id': 'Cancelamento_' + '01001001000113',
                'IdentificacaoNfse': {
                    'Numero': req.get('conh_rps', ''),
                    'CpfCnpj': {
                        'Cnpj' if len(req.get('conh_filial_cnpjcpf', '')) > 11 else
                        'Cpf': req.get('conh_filial_cnpjcpf', '')
                    },
                    'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
                    'CodigoMunicipio': '1503606'
                },
                'CodigoCancelamento': '2',
            }
        }
    }

    rps_str = xml_from_dict(query)
    rps_str = assinatura.assinar_elemento(rps_str, 'InfPedidoCancelamento')
    return envelop('ws:cancelarNfse', rps_str), ''

    # return envelop('ws:cancelarNfse', xml_from_dict(query)), ''


def consulta_nfse(req: dict, cod_ibge: int, ):
    query: dict = {
        'ConsultarNfsEnvio': {
            'Prestador': {
                'Cnpj': req.get('conh_filial_cnpjcpf', ''),
                'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
            },
            'NumeroNfse': req.get('conh_rps', ''),
            'PeriodoEmissao': {
                'DataInicial': req.get('data_inicio', ''),
                'DataFinal': req.get('data_fim', ''),
            },
            'Tomador': {
                'CpfCnpj': {
                    'Cnpj': '',  # if len(req.get('conh_cliente_cnpjcpf', '')) > 11 else
                    'Cpf': ''  # req.get('conh_cliente_cnpjcpf', '')
                },
                'InscricaoMunicipal': '',  # req.get('conh_filial_inscmun', ''),
            },
            'IntermediarioServico': {
                'RazaoSocial': '',  # req.get('conh_cliente_nome', ''),
                'CpfCnpj': {
                    'Cnpj': '',  # if len(req.get('conh_cliente_cnpjcpf', '')) > 11 else
                    'Cpf': '',  # req.get('conh_cliente_cnpjcpf', '')
                },
                'InscricaoMunicipal': req.get('conh_filial_inscmun', '')
            }
        }
    }
    return envelop('ConsultarNfsEnvio', xml_from_dict(query)), ''


@handle_exception_factory()
def process_response_fiorilli(acao: int, cod_ibge: int, ret: str):
    resp: dict = deep_get(xmltodict.parse(ret), 'SOAP-ENV:Envelope.SOAP-ENV:Body')

    def set_resp_if_exists(name: str):
        nonlocal resp
        value: dict = deep_get(resp, name + '\\.ExecuteResponse.Outputxml')
        if value:
            resp = xmltodict.parse(value.get('#text'))
            return True
        return False

    def process_response_list_element(data_: Tuple[dict, list]) -> list:
        if not data_:
            return []

        data_ = data_ if type(data_) is list else [data_]

        try:
            result_list = []
            msg: dict
            for msg in data_:
                msg = msg.get('MensagemRetorno', {})
                result_list.append({
                    'codigo': msg.get('Codigo', ''),
                    'mensagem': msg.get('Mensagem', ''),
                    'sugestao': msg.get('Correcao', '')
                })

            return result_list
        except (Exception,):
            return []

    result = {}
    numero_nfe = ''

    if set_resp_if_exists('RecepcionarLoteRPS'):
        data: dict = deep_get(resp, 'EnviarLoteRpsResposta')

        if 'Protocolo' in data:
            result['sucesso'] = True
            result['numerolote'] = data.get('NumeroLote', '')
            result['data_recebimento'] = data.get('DataRecebimento', '')
            result['protocolo'] = data.get('Protocolo', '')
        else:
            result['sucesso'] = False
            result['erros'] = process_response_list_element(data.get('ListaMensagemRetorno'))

    elif set_resp_if_exists('ConsultarSituacaoLoteRps'):
        data: dict = resp.get('ConsultarSituacaoLoteRpsResposta')

        if 'ListaMensagemRetorno' not in data:
            result['sucesso'] = True
            result['notas'] = []

            # result['status'] = data.get('Situacao', '')

            result['notas'].append({
                'status': '1',
                'numero': data.get('NumeroLote', ''),
                'pdf': ''  # target.get('OutrasInformacoes', '')
            })
        else:
            result['sucesso'] = False
            result['erros'] = process_response_list_element(data.get('ListaMensagemRetorno'))

    elif set_resp_if_exists('ConsultarNfsePorRps'):
        data: dict = resp.get('ConsultarNfseRpsResposta')

        if 'CompNfse' in data:
            data: dict = deep_get(data, 'CompNfse.Nfse.InfNfse')
            result = {
                'sucesso': True,
                'status': 1,
                'numero': data.get('Numero', ''),
                'codigo_verificacao': data.get('CodigoVerificacao', ''),
                'data_emissao': data.get('DataEmissao', ''), 'pdf': ''  # data.get('OutrasInformacoes', '')
            }
        else:
            result['sucesso'] = False
            result['erros'] = process_response_list_element(data.get('ListaMensagemRetorno'))

    elif set_resp_if_exists('ConsultarLoteRps'):
        data: dict = resp.get('ConsultarLoteRpsResposta')

        if 'ListaNfse' in data:
            result['sucesso'] = True
            result['notas'] = []
            data: dict = deep_get(data, 'ListaNfse')
            data = data if type(data) is list else [data]

            for target in data:
                target: dict = deep_get(target, 'CompNfse.Nfse.InfNfse')
                result['notas'].append({
                    'status': 1,
                    'numero': int(target.get('Numero', '')),
                    'codigo_verificacao': target.get('CodigoVerificacao', ''),
                    'data_emissao': target.get('DataEmissao', ''),
                    'pdf': ''  # target.get('OutrasInformacoes', '')
                })

        else:
            result['sucesso'] = False
            result['erros'] = process_response_list_element(data.get('ListaMensagemRetorno'))

    elif set_resp_if_exists('ConsultarNfse'):
        data: dict = resp.get('ConsultarNfseResposta')

        if 'ListaNfse' in data:
            result['sucesso'] = True
            result['notas'] = []
            data: dict = deep_get(data, 'ListaNfse.CompNfse')
            data = data if type(data) is list else [data]

            for target in data:
                target: dict = deep_get(target, 'Nfse.InfNfse')
                result['notas'].append({
                    'status': 1,
                    'numero': int(target.get('Numero', '')),
                    'codigo_verificacao': target.get('CodigoVerificacao', ''),
                    'data_emissao': target.get('DataEmissao', ''),
                    'pdf': ''  # target.get('OutrasInformacoes', '')
                })
        else:
            result['sucesso'] = False
            result['erros'] = process_response_list_element(data.get('ListaMensagemRetorno'))

    elif set_resp_if_exists('CancelarNfse'):
        data: dict = resp.get('CancelarNfseResposta')

        if 'RetCancelamento' in data:
            data = deep_get(data, 'RetCancelamento.NfseCancelamento.Confirmacao', {})
            result['sucesso'] = True
            result['data_confirmacao'] = data.get('DataHora', '')
            result['codigo_cancelamento'] = deep_get(data, 'Pedido.InfPedidoCancelamento.CodigoCancelamento', '')

            result['motivo_cancelamento'] = {
                '1': 'Erro na emissão',
                '2': 'Serviço não prestado',
                '3': 'Erro de assinatura',
                '4': 'Duplicidade da nota',
                '5': 'Erro de processamento'
            }.get(result['codigo_cancelamento'], '')

        else:
            result['sucesso'] = False
            result['erros'] = process_response_list_element(data.get('ListaMensagemRetorno'))
    else:
        return '', 'EMPY: Um retorno desconhecido foi recebido da Abaco.', ''

    return '<json><![CDATA[' + json.dumps(result) + ']]></json>', '', numero_nfe
