import xml.etree.ElementTree as tree
from datetime import datetime, timedelta

import sefaz_spooler
from geralxml import *
from geral import removeAccents

# Acoes diversas NF-e
ACAO_NFE_DOWNLOADNF2 = 29;

# Acoes do NF-e 4
ACAO_NFE_AUTORIZACAO4 = 41
ACAO_NFE_RETAUTORIZACAO4 = 42
ACAO_NFE_INUTILIZACAO4 = 44
ACAO_NFE_CONSULTA4 = 45
ACAO_NFE_STATUSSERVICO4 = 46
ACAO_NFE_CONSULTACADASTRO4 = 47
ACAO_NFE_RECEPCAOEVENTO4 = 48
#
ACAO_NFE_CONSULTANFDIST = 10;
ACAO_NFE_CONSULTANFDISTAUTO = 11;

RET_ENVLOTEEVENTO_NOERRO = "128";
RET_ENVLOTEEVENTOPROC_NOERRO = "135";
RET_CONSNFE_NOERROAUTOR = "100"
RET_CONSULTANFDIST_NOERRO2 = "138"

TPEVENTO_MANIFDESTNFE_CONFIRM = "210200"
TPEVENTO_MANIFDESTNFE_CIENCIA = "210210"
TPEVENTO_MANIFDESTNFE_DESCONH = "210220"
TPEVENTO_MANIFDESTNFE_OPNAOREAL = "210240"


def callNFe(pfx_path, pfx_password, codEMonitorAcao, codUF, numUF, req, rsEMonitorUFAcao, spool):
    #
    if codEMonitorAcao == ACAO_NFE_CONSULTANFDISTAUTO:
        request = requestConsultaNFDistAuto(rsEMonitorUFAcao, req)
    elif codEMonitorAcao == ACAO_NFE_RECEPCAOEVENTO4:
        request, erros = requestRecepcaoEvento(pfx_path, pfx_password, rsEMonitorUFAcao, spool)
        if erros != '':
            return '', '', '', erros
    elif codEMonitorAcao == ACAO_NFE_DOWNLOADNF2:
        request, erros = requestDownloadNF(rsEMonitorUFAcao, spool)
        if erros != '':
            return '', '', '', erros
    elif codEMonitorAcao == ACAO_NFE_CONSULTA4:
        request, erros = requestConsultaNF(rsEMonitorUFAcao, spool)
        if erros != '':
            return '', '', '', erros
    #
    request = requestHeader(rsEMonitorUFAcao, numUF) + request + requestFooter()
    #print(request)
    #
    url = rsEMonitorUFAcao['urlprinc']
    action = rsEMonitorUFAcao['urlacao']
    #
    ret, erros = sefaz_spooler.processRequestSefaz(pfx_path, pfx_password, codEMonitorAcao, codUF, numUF, request, url, action)
    if erros != '':
        return request, ret, '', erros
    else:
        resp, erros = processResponse(codEMonitorAcao, ret)
        if erros != '':
            return request, ret, '', erros
        else:
            return request, ret, resp, '' # ret = XML normal de resposta, resp = apenas xMotivo (distauto) ou um dicionario dos valores uteis no emws.py


def requestHeader(rsEMonitorUFAcao, numUF):
    header = list()
    header.append('<?xml version="1.0" encoding="utf-8" ?>')
    header.append('<env:Envelope xmlns:env="http://www.w3.org/2003/05/soap-envelope" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">')
    header.append('<env:Header/>')
    return ''.join(header)


def requestFooter():
    return '</env:Envelope>'


def requestConsultaNFDistAuto(rsEMonitorUFAcao, request):
    listCampos = list(request.split('_'))
    req = list()
    req.append('<env:Body>')
    req.append('<nfeDistDFeInteresse xmlns="' + rsEMonitorUFAcao['urldadosmsg'] + '">')
    req.append('<nfeDadosMsg>')
    req.append('<distDFeInt xmlns="' + rsEMonitorUFAcao['urldadosmsgelement'] + '" versao="' + rsEMonitorUFAcao['versaodados'] + '">')
    req.append(createtag('tpAmb', rsEMonitorUFAcao['tpamb']))
    req.append(createtag('cUFAutor', listCampos[1].strip()))
    if len(listCampos[0]) == 14:
        req.append(createtag('CNPJ', listCampos[0].strip()))
    else:
        req.append(createtag('CPF', listCampos[0].strip()))
    req.append('<distNSU>')
    req.append(createtag('ultNSU', listCampos[2]))
    req.append('</distNSU>')
    req.append('</distDFeInt>')
    req.append('</nfeDadosMsg>')
    req.append('</nfeDistDFeInteresse>')
    req.append('</env:Body>')
    return ''.join(req)


def requestDownloadNF(rsEMonitorUFAcao, spool):
    req = list()
    req.append('<env:Body>')
    req.append('<nfeDistDFeInteresse xmlns="' + rsEMonitorUFAcao['urldadosmsg'] + '">')
    req.append('<nfeDadosMsg>')
    req.append('<distDFeInt xmlns="' + rsEMonitorUFAcao['urldadosmsgelement'] + '" versao="1.01">') # por enqto fixo versao
    req.append(createtag('tpAmb', rsEMonitorUFAcao['tpamb']))
    req.append(createtag('cUFAutor', spool['anoinut'].strip()))
    if len(spool['cnpjinut']) == 14:
        req.append(createtag('CNPJ', spool['cnpjinut'].strip()))
    else:
        req.append(createtag('CPF', spool['cnpjinut'].strip()))
    req.append('<consChNFe>')
    req.append(createtag('chNFe', spool['chave']))
    req.append('</consChNFe>')
    req.append('</distDFeInt>')
    req.append('</nfeDadosMsg>')
    req.append('</nfeDistDFeInteresse>')
    req.append('</env:Body>')
    return ''.join(req), ''


def requestRecepcaoEvento(pfx_path, pfx_password, rsEMonitorUFAcao, spool):
    strArqXMLAss, erros = createEventoXML(pfx_path, pfx_password, rsEMonitorUFAcao, spool)
    if erros != '':
        return '', erros
    #
    req = list()
    try:
        req.append('<env:Body>')
        req.append('<nfeDadosMsg xmlns="' + rsEMonitorUFAcao['urldadosmsg'] + '">')
        req.append('<envEvento xmlns="' + rsEMonitorUFAcao['urldadosmsgelement'] + '" versao="' + rsEMonitorUFAcao['versaodados'] + '">')
        req.append(createtag('idLote', str(int(spool['codemonitorspool']))))
        req.append(strArqXMLAss)
        req.append('</envEvento>')
        req.append('</nfeDadosMsg>')
        req.append('</env:Body>')
        return ''.join(req), ''
    except Exception as e:
        print('Erro em requestRecepcaoEvento')
        print(e)
        return '', 'Erro em requestRecepcaoEvento ao montar Arquivo XML => ' + str(e)


def createEventoXML(pfx_path, pfx_password, rsEMonitorUFAcao, spool):
    try:
        tpEvento = spool['tpevento']
        chaveId = tpEvento + spool['chave'] + '01' # fixo por enqto padlzero(str(spool['nseqevento']),2)
        fusoHorario = spool['serienfinut']
        dhEvento = str(datetime.now() - timedelta(minutes=5)).replace(' ','T',1)[0:19] # ritual para sincronizar com relogio da SEFAZ
        #
        req = list()
        # req.append('<?xml version="1.0" encoding="UTF-8"?>')
        req.append('<evento xmlns="http://www.portalfiscal.inf.br/nfe" versao="' + rsEMonitorUFAcao['versaodados'] + '">')
        req.append('<infEvento Id="ID' + chaveId + '">')
        req.append('<cOrgao>91</cOrgao>') # fixo
        req.append('<tpAmb>' + rsEMonitorUFAcao['tpamb'] + '</tpAmb>')
        req.append('<CNPJ>' + spool['cnpjinut'] + '</CNPJ>')
        req.append('<chNFe>' + spool['chave'] + '</chNFe>')
        req.append('<dhEvento>' + dhEvento + '-' + fusoHorario + '</dhEvento>')
        req.append('<tpEvento>' + tpEvento + '</tpEvento>')
        req.append('<nSeqEvento>1</nSeqEvento>') # fixo por enqto
        req.append('<verEvento>' + rsEMonitorUFAcao['versaodados'] + '</verEvento>')
        req.append('<detEvento versao="' + rsEMonitorUFAcao['versaodados'] + '">')
        if tpEvento == TPEVENTO_MANIFDESTNFE_CIENCIA:
            req.append('<descEvento>Ciencia da Operacao</descEvento>')
        elif tpEvento == TPEVENTO_MANIFDESTNFE_DESCONH:
            req.append('<descEvento>Desconhecimento da Operacao</descEvento>')
        elif tpEvento == TPEVENTO_MANIFDESTNFE_OPNAOREAL:
            req.append('<descEvento>Operacao nao Realizada</descEvento>')
            if spool['justcanc'] is not None and spool['justcanc'] != '':
                req.append('<xJust>' + spool['justcanc'] + '</xJust>')
        elif tpEvento == TPEVENTO_MANIFDESTNFE_CONFIRM:
            req.append('<descEvento>Confirmacao da Operacao</descEvento>')
        req.append('</detEvento>')
        req.append('</infEvento>')
        req.append('</evento>')
    except Exception as e:
        print('Erro em createEventoXML/NFe')
        print(e)
        return '', 'Erro em createEventoXML/NFe ao montar sub-Arquivo XML => ' + str(e)
    #
    try:
        strXML = ''.join(req)
        strXML = assinarXML(chaveId, strXML, pfx_path, pfx_password)
        return strXML, ''
    except Exception as e:
        print('Erro em createEventoXML/NFe/assinatura')
        print(e)
        return '', 'Erro em createEventoXML/NFe ao assinar sub-Arquivo XML => ' + str(e)


def requestConsultaNF(rsEMonitorUFAcao, spool):
    req = list()
    req.append('<env:Body>')
    req.append('<nfeDadosMsg xmlns="' + rsEMonitorUFAcao['urldadosmsg'] + '">')
    req.append('<consSitNFe xmlns="' + rsEMonitorUFAcao['urldadosmsgelement'] + '" versao="' + rsEMonitorUFAcao['versaodados'] + '">')
    req.append(createtag('tpAmb', str(spool['tpamb'])))
    req.append(createtag('xServ', 'CONSULTAR'))
    if spool['chave'].startswith('DEST'):
        chave = spool['chave'][4:]  # tirar DEST do inicio
    else:
        chave = spool['chave']
    req.append(createtag('chNFe', chave))
    req.append('</consSitNFe>')
    req.append('</nfeDadosMsg>')
    req.append('</env:Body>')
    return ''.join(req), ''


def processResponse(codEMonitorAcao, ret):
    #
    try:
        # Teste CienciaOp
        # ret = '<?xml version="1.0" encoding="UTF-8"?><soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"><soap:Header><WSCorIDSOAPHeader CorID="CC41A22FA9FE680C0283B9E6724E9E12,1:1,0,0,,,AgAAALNIQgAAAAFGAAAAAQAAABFqYXZhLnV0aWwuSGFzaE1hcAAAAAJIQgAAAAJGAAAAAgAAABBqYXZhLmxhbmcuU3RyaW5nAA9DYWxsZXJUaW1lc3RhbXBIQgAAAANFAAAAAgANMTYzNTUxNDQyNTkwM0hCAAAABEUAAAACAApUeG5UcmFjZUlkSEIAAAAFRQAAAAIAIUNDNDFBMjFGQTlGRTY4MEMwMjgzQjlFNjJFRDZGMkM3MA==" xmlns="http://www.ca.com/apm" /></soap:Header><soap:Body><nfeRecepcaoEventoNFResult xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeRecepcaoEvento4"><retEnvEvento xmlns="http://www.portalfiscal.inf.br/nfe" versao="1.00"><idLote>6676640</idLote><tpAmb>1</tpAmb><verAplic>AN_1.2.4</verAplic><cOrgao>91</cOrgao><cStat>128</cStat><xMotivo>Lote de evento processado</xMotivo><retEvento versao="1.00"><infEvento Id="ID891215084819097"><tpAmb>1</tpAmb><verAplic>AN_1.2.4</verAplic><cOrgao>91</cOrgao><cStat>135</cStat><xMotivo>Evento registrado e vinculado a NF-e</xMotivo><chNFe>35211000610862000136550010002197101000852264</chNFe><tpEvento>210210</tpEvento><xEvento>Ciencia da Operacao</xEvento><nSeqEvento>1</nSeqEvento><CNPJDest>29566192000180</CNPJDest><dhRegEvento>2021-10-28T16:25:17-03:00</dhRegEvento><nProt>891215084819097</nProt></infEvento></retEvento></retEnvEvento></nfeRecepcaoEventoNFResult></soap:Body></soap:Envelope>'
        root = tree.fromstring(ret)
    except tree.ParseError:
        return '','Nao foi possivel processar XML de retorno de NFe'
    if len(root) > 1:
        body = root[1] # agora tem soap:Header como root[0]
    else:
        body = root[0] # sem soap:Header como root[0]
    result = body[0]
    ret = result[0]
    if codEMonitorAcao == ACAO_NFE_CONSULTANFDISTAUTO or \
        codEMonitorAcao == ACAO_NFE_DOWNLOADNF2:
        listCampos = list(ret[0])
        if codEMonitorAcao == ACAO_NFE_DOWNLOADNF2:
            resp = {}
            resp['msgret'] = ''
            resp['nprot'] = ''
            resp['datahorareclote'] = ''
            resp['nprotinut'] = '' # nao usado
    elif codEMonitorAcao == ACAO_NFE_RECEPCAOEVENTO4:
        listCampos = list(ret)
        resp = {}
        resp['msgret'] = ''
        resp['nprot'] = ''
        resp['datahorareclote'] = ''
        resp['nprotinut'] = '' # nao usado
    elif codEMonitorAcao == ACAO_NFE_CONSULTA4:
        # POR ENQTO NAO TRATADO CASO DE CONSULTA DEVOLVER COMO NFE CANCELADA, APENAS AUTORIZADA, PARA PAINEL DE NFEDEST/NFEDIST
        listCampos = list(ret)
        resp = {}
        resp['msgret'] = ''
        resp['nprot'] = ''
        resp['datahorareclote'] = ''
        resp['nprotinut'] = '' # digval
    #
    temErro = False
    temDownloadNF = True
    msgRet = ''
    for campo in listCampos:
        tag = campo.tag
        value = campo.text
        if tag.endswith('cStat'):
            if codEMonitorAcao == ACAO_NFE_DOWNLOADNF2 and value != RET_CONSULTANFDIST_NOERRO2:
                temErro = True
                resp['msgret'] += '(' + value + ') '
            if codEMonitorAcao == ACAO_NFE_RECEPCAOEVENTO4 or \
                codEMonitorAcao == ACAO_NFE_CONSULTA4:
                if (codEMonitorAcao == ACAO_NFE_RECEPCAOEVENTO4 and value != RET_ENVLOTEEVENTO_NOERRO) or \
                    (codEMonitorAcao == ACAO_NFE_CONSULTA4 and value != RET_CONSNFE_NOERROAUTOR):
                    temErro = True
                    resp['msgret'] += '(' + value + ') '
                else:
                    for campo2 in listCampos:
                        tagCampo = campo2.tag
                        if (codEMonitorAcao == ACAO_NFE_RECEPCAOEVENTO4 and tagCampo.endswith('retEvento')) or \
                            (codEMonitorAcao == ACAO_NFE_CONSULTA4 and tagCampo.endswith('protNFe')):
                            infEvento = campo2[0]
                            listCamposInfEvento = list(infEvento)
                            for campoInfEvento in listCamposInfEvento:
                                tagInfEvento = campoInfEvento.tag
                                valueInfEvento = campoInfEvento.text
                                if tagInfEvento.endswith('cStat'):
                                    if (codEMonitorAcao == ACAO_NFE_RECEPCAOEVENTO4 and valueInfEvento != RET_ENVLOTEEVENTOPROC_NOERRO) or \
                                        (codEMonitorAcao == ACAO_NFE_CONSULTA4 and valueInfEvento != RET_CONSNFE_NOERROAUTOR):
                                        temErro = True
                                        resp['msgret'] += '(' + valueInfEvento + ') '
                                elif tagInfEvento.endswith('xMotivo'):
                                    resp['msgret'] += valueInfEvento
                                elif tagInfEvento.endswith('dhRegEvento') or \
                                    tagInfEvento.endswith('dhRecbto'):
                                    resp['datahorareclote'] = valueInfEvento.replace('T',' ')
                                elif tagInfEvento.endswith('nProt'):
                                    resp['nprot'] = valueInfEvento
                                elif tagInfEvento.endswith('digVal'):
                                    resp['nprotinut'] = valueInfEvento
                    break
        elif tag.endswith('xMotivo'):
            msgRet = value
            if codEMonitorAcao == ACAO_NFE_DOWNLOADNF2 or \
                codEMonitorAcao == ACAO_NFE_RECEPCAOEVENTO4 or \
                codEMonitorAcao == ACAO_NFE_CONSULTA4:
                resp['msgret'] += value
        elif tag.endswith('dhRegEvento') or \
            tag.endswith('dhRecbto') or \
            tag.endswith('dhResp'):
            if codEMonitorAcao == ACAO_NFE_DOWNLOADNF2:
                resp['datahorareclote'] = value.replace('T',' ')
        elif codEMonitorAcao == ACAO_NFE_DOWNLOADNF2 and tag.endswith('loteDistDFeInt'):
            temDownloadNF = True
    # por enqto nao ha erros a serem tratados no retorno
    if codEMonitorAcao == ACAO_NFE_CONSULTANFDISTAUTO:
        return removeAccents(msgRet), ''
    else:
        # ACAO_NFE_DOWNLOADNF2 ou ACAO_NFE_RECEPCAOEVENTO4 ou ACAO_NFE_CONSULTA4
        if codEMonitorAcao == ACAO_NFE_DOWNLOADNF2 and not temDownloadNF:
            temErro = True
        if temErro:
            return resp, resp['msgret']
        else:
            return resp, ''

