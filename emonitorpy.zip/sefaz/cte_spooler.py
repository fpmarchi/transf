import xml.etree.ElementTree as tree
from datetime import datetime, timedelta

import sefaz_spooler
from geralxml import *
from geral import removeAccents

# Acoes do CT-e 3
ACAO_CTE_RECEPCAO3 = 131
ACAO_CTE_RETRECEPCAO3 = 132
ACAO_CTE_INUTILIZACAO3 = 134
ACAO_CTE_CONSULTA3 = 135
ACAO_CTE_STATUSSERVICO3 = 136
ACAO_CTE_CONSULTACADASTRO3 = 137
ACAO_CTE_RECEPCAOEVENTO3 = 138
ACAO_CTE_DOWNLOADCT3 = 139
# Acoes do CT-e 3
ACAO_CTE_RECEPCAOSINC4 = 143
ACAO_CTE_CONSULTA4 = 145
ACAO_CTE_STATUSSERVICO4 = 146
ACAO_CTE_RECEPCAOEVENTO4 = 148
#
ACAO_CTE_CONSULTACTDIST = 110
ACAO_CTE_CONSULTACTDISTAUTO = 111

RET_ENVLOTEEVENTO_NOERRO = "135"

TPEVENTO_DESTCTE_DESACORDO = "610110"


def callCTe(pfx_path, pfx_password, codEMonitorAcao, codUF, numUF, req, rsEMonitorUFAcao, spool):
    #
    if codEMonitorAcao == ACAO_CTE_CONSULTACTDISTAUTO:
        request = requestConsultaCTDistAuto(rsEMonitorUFAcao, req)
    elif codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO3 or codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO4:
        request, erros = requestRecepcaoEvento(pfx_path, pfx_password, rsEMonitorUFAcao, spool)
        if erros != '':
            return '', '', '', erros
    #
    request = requestHeader(rsEMonitorUFAcao, numUF) + request + requestFooter()
    #print(request)
    #
    url = rsEMonitorUFAcao['urlprinc']
    action = rsEMonitorUFAcao['urlacao']
    #
    ret, erros = sefaz_spooler.processRequestSefaz(pfx_path, pfx_password, codEMonitorAcao, codUF, numUF, request, url, action)
    if erros != '':
        return request, ret, '', erros
    else:
        resp, erros = processResponse(codEMonitorAcao, ret)
        if erros != '':
            return request, ret, '', erros
        else:
            return request, ret, resp, '' # ret = XML normal de resposta, resp = apenas xMotivo (distauto) ou POR ENQTO SEM USO


def requestHeader(rsEMonitorUFAcao, numUF):
    header = list()
    header.append('<?xml version="1.0" encoding="utf-8" ?>')
    header.append('<env:Envelope xmlns:env="http://www.w3.org/2003/05/soap-envelope" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">')
    if rsEMonitorUFAcao['codemonitoracao'] == ACAO_CTE_RECEPCAOEVENTO3 or  rsEMonitorUFAcao['codemonitoracao'] == ACAO_CTE_RECEPCAOEVENTO4:
        header.append('<env:Header>')
        header.append('<cteCabecMsg xmlns="' + rsEMonitorUFAcao['urlcabecmsg'] + '">')
        header.append(createtag('versaoDados', rsEMonitorUFAcao['versaodados']))
        header.append(createtag('cUF', str(numUF)))
        header.append('</cteCabecMsg>')
        header.append('</env:Header>')
    else:
        header.append('<env:Header/>')
    return ''.join(header)


def requestFooter():
    return '</env:Envelope>'


def requestConsultaCTDistAuto(rsEMonitorUFAcao, request):
    listCampos = list(request.split('_'))
    req = list()
    req.append('<env:Body>')
    req.append('<cteDistDFeInteresse xmlns="' + rsEMonitorUFAcao['urldadosmsg'] + '">')
    req.append('<cteDadosMsg>')
    req.append('<distDFeInt xmlns="' + rsEMonitorUFAcao['urldadosmsgelement'] + '" versao="' + rsEMonitorUFAcao['versaodados'] + '">')
    req.append(createtag('tpAmb', rsEMonitorUFAcao['tpamb']))
    req.append(createtag('cUFAutor', listCampos[1].strip()))
    if len(listCampos[0]) == 14:
        req.append(createtag('CNPJ', listCampos[0].strip()))
    else:
        req.append(createtag('CPF', listCampos[0].strip()))
    req.append('<distNSU>')
    req.append(createtag('ultNSU', listCampos[2]))
    req.append('</distNSU>')
    req.append('</distDFeInt>')
    req.append('</cteDadosMsg>')
    req.append('</cteDistDFeInteresse>')
    req.append('</env:Body>')
    return ''.join(req)


def requestRecepcaoEvento(pfx_path, pfx_password, rsEMonitorUFAcao, spool):
    strArqXMLAss, erros = createEventoXML(pfx_path, pfx_password, rsEMonitorUFAcao, spool)
    if erros != '':
        return '', erros
    #
    req = list()
    try:
        req.append('<env:Body>')
        req.append('<cteDadosMsg xmlns="' + rsEMonitorUFAcao['urldadosmsg'] + '">')
        req.append(strArqXMLAss)
        req.append('</cteDadosMsg>')
        req.append('</env:Body>')
        return ''.join(req), ''
    except Exception as e:
        print('Erro em requestRecepcaoEvento')
        print(e)
        return '', 'Erro em requestRecepcaoEvento ao montar Arquivo XML => ' + str(e)


def createEventoXML(pfx_path, pfx_password, rsEMonitorUFAcao, spool):
    try:
        tpEvento = spool['tpevento']

        # fixo por enqto padlzero(str(spool['nseqevento']),2)
        if rsEMonitorUFAcao['versaodados'] == '4.00':
            chaveId = tpEvento + spool['chave'] + '001'
        else:
            chaveId = tpEvento + spool['chave'] + '01'

        fusoHorario = spool['serienfinut']
        dhEvento = str(datetime.now() - timedelta(minutes=5)).replace(' ','T',1)[0:19] # ritual para sincronizar com relogio da SEFAZ
        #
        req = list()
        # req.append('<?xml version="1.0" encoding="UTF-8"?>')
        req.append('<eventoCTe xmlns="' + rsEMonitorUFAcao['urldadosmsgelement'] + '" versao="' + rsEMonitorUFAcao['versaodados'] + '">')
        req.append('<infEvento xmlns="' + rsEMonitorUFAcao['urldadosmsgelement'] + '" Id="ID' + chaveId + '">')
        req.append('<cOrgao>' + str(spool['numuf']) + '</cOrgao>')
        req.append('<tpAmb>' + str(spool['tpamb']) + '</tpAmb>')
        req.append('<CNPJ>' + spool['cnpjinut'] + '</CNPJ>')
        req.append('<chCTe>' + spool['chave'] + '</chCTe>')
        req.append('<dhEvento>' + dhEvento + '-' + fusoHorario + '</dhEvento>')
        req.append('<tpEvento>' + tpEvento + '</tpEvento>')
        req.append('<nSeqEvento>1</nSeqEvento>') # fixo por enqto
        req.append('<detEvento xmlns="' + rsEMonitorUFAcao['urldadosmsgelement'] + '" versaoEvento="' + rsEMonitorUFAcao['versaodados'] + '">')
        req.append('<evPrestDesacordo>')
        if tpEvento == TPEVENTO_DESTCTE_DESACORDO:
            req.append('<descEvento xmlns="' + rsEMonitorUFAcao['urldadosmsgelement'] + '" >Prestacao do Servico em Desacordo</descEvento>')
            req.append('<indDesacordoOper xmlns="' + rsEMonitorUFAcao['urldadosmsgelement'] + '" >1</indDesacordoOper>')
            req.append('<xObs xmlns="' + rsEMonitorUFAcao['urldadosmsgelement'] + '" >' + spool['justcanc'] + '</xObs>')
        req.append('</evPrestDesacordo>')
        req.append('</detEvento>')
        req.append('</infEvento>')
        req.append('</eventoCTe>')
    except Exception as e:
        print('Erro em createEventoXML/CTe')
        print(e)
        return '', 'Erro em createEventoXML/CTe ao montar sub-Arquivo XML => ' + str(e)
    #
    try:
        strXML = ''.join(req)
        strXML = assinarXML(chaveId, strXML, pfx_path, pfx_password)
        return strXML, ''
    except Exception as e:
        print('Erro em createEventoXML/CTe/assinatura')
        print(e)
        return '', 'Erro em createEventoXML/CTe ao assinar sub-Arquivo XML => ' + str(e)


def processResponse(codEMonitorAcao, ret):
    #
    try:
        root = tree.fromstring(ret)
    except tree.ParseError:
        return '','Nao foi possivel processar XML de retorno de CTe'
    if codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO3 or codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO4:
        try:
            body = root[1]
        except:
            body = root[0]
    else:
        body = root[0]
    result = body[0]
    ret = result[0]
    listCampos = list(ret[0])
    if codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO3 or codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO4:
        resp = {}
        resp['msgret'] = ''
        resp['nprot'] = ''
        resp['datahorareclote'] = ''
        resp['nprotinut'] = '' # nao usado
    #
    temErro = False
    msgRet = ''
    for campo in listCampos:
        tag = campo.tag
        value = campo.text
        if tag.endswith('cStat'):
            if codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO3 or codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO4:
                if ((codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO3 or codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO4) and value != RET_ENVLOTEEVENTO_NOERRO):
                    temErro = True
                    resp['msgret'] += '(' + value + ') '
        elif tag.endswith('xMotivo'):
            msgRet = value
            if codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO3 or codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO4:
                resp['msgret'] += value
        elif tag.endswith('dhRegEvento') or \
            tag.endswith('dhRecbto'):
            if codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO3 or codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO4:
                resp['datahorareclote'] = value.replace('T',' ')
        elif tag.endswith('nProt'):
            if codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO3 or codEMonitorAcao == ACAO_CTE_RECEPCAOEVENTO4:
                resp['nprot'] = value
    #
    if codEMonitorAcao == ACAO_CTE_CONSULTACTDISTAUTO:
        return removeAccents(msgRet), ''
    else:
        # ACAO_CTE_RECEPCAOEVENTO3 ou ACAO_CTE_RECEPCAOEVENTO4
        if temErro:
            return resp, resp['msgret']
        else:
            return resp, ''



