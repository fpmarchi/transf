import json
from typing import Tuple

import xmltodict

import nfse_spooler
from ActionProcessor import handle_exception_factory
from geral import *
from geralxml import *


class AbacoException(Exception):
    pass


def process_request_abaco(cod_acao_emonitor: int, cod_ibge: int,
                          req: dict, assinatura: AssinaturaA1) -> Tuple[str, str]:
    if cod_acao_emonitor == nfse_spooler.ACAO_NFSE_RECEPCAO:
        xml, erro = request_abaco_recepcao(cod_ibge, req, assinatura)
    elif cod_acao_emonitor == nfse_spooler.ACAO_NFSE_CONSULTA_SITLOTE_RPS:
        xml, erro = consulta_nfse_situacao_lote_rps(req, cod_ibge)
    elif cod_acao_emonitor == nfse_spooler.ACAO_NFSE_CONSULTA_NFSE_POR_RPS:
        xml, erro = consulta_nfse_por_rps(req, cod_ibge)
    elif cod_acao_emonitor == nfse_spooler.ACAO_NFSE_CONSULTA_SITLOTE_RPS:
        xml, erro = consulta_lote_rps_envio(req, cod_ibge)
    elif cod_acao_emonitor == nfse_spooler.ACAO_NFSE_CONSULTA_NFSE:#ACAO_NFSE_CONSULTA_NFSE:
        xml, erro = consulta_nfse(req, cod_ibge)
    elif cod_acao_emonitor == nfse_spooler.ACAO_NFSE_CANCELAMENTO:
        xml, erro = cancelar_nfse_envio(req, cod_ibge)
    else:
        return '', 'Acao ' + str(cod_acao_emonitor) + ' sem Implementação'

    return xml, erro


def envelop(service: str, data: str):
    if not data:
        return data

    header = {
        'cabecalho': (
            {
                'versaoDados': 'V2010'
            },
            {
                'attr': {
                    'versao': '201001'
                }
            }
        )
    }

    soap_env: dict = {
        'soapenv:Envelope': (
            {
                'soapenv:Header': None,
                'soapenv:Body': {
                    f'e:{service}.Execute': {
                        'e:Nfsecabecmsg': escape(dict_to_xml(header)),
                        'e:Nfsedadosmsg': escape(data)
                    }
                }
            },
            {
                'attr': {
                    'xmlns:soapenv': 'http://schemas.xmlsoap.org/soap/envelope/',
                    'xmlns:e': 'http://www.e-nfs.com.br'
                }
            }
        )
    }

    return dict_to_xml(soap_env, indent=True, prolog=True)


def request_abaco_recepcao(cod_ibge: int, req: dict, assinatura: AssinaturaA1) -> Tuple[str, str]:
    rps, erros = xml_request_abaco_recepcao(req, cod_ibge)

    lote: dict = {
        'EnviarLoteRpsEnvio': (
            {
                'LoteRps': (
                    {
                        'NumeroLote': req.get('conh_rps', ''),
                        'Cnpj': req.get('conh_filial_cnpjcpf', ''),
                        'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
                        'QuantidadeRps': 1,
                        'ListaRps': {
                            'Rps': rps
                        }
                    },
                    {
                        'attr': {
                            'id': 'lote' + req.get('conh_rps', '')
                        }
                    },
                )
            },
            {
                'attr': {
                    'xmlns': 'http://www.e-nfs.com.br'
                }
            }
        )
    }

    lote_str = dict_to_xml(lote)
    sign_str = assinatura.assinar(lote_str, True, 'id', certificado_rpslote=True)
    lote_str = lote_str.replace('</Rps></ListaRps>', sign_str + '</Rps></ListaRps>')
    lote_str = assinatura.assinar(lote_str, True, 'id', True)

    return envelop('RecepcionarLoteRps', lote_str), ''


def xml_request_abaco_recepcao(req: dict, cod_ibge: int):
    rps: dict = {
        'InfRps': (
            {
                'IdentificacaoRps': {
                    'Numero': req.get('conh_rps', ''),
                    'Serie': req.get('conh_serie', ''),
                    'Tipo': 1,
                },
                'DataEmissao': req.get('conh_datahoraemissao'),
                'NaturezaOperacao': req.get('NaturezaOperacao', '1'),
                'RegimeEspecialTributacao': 1,
                'OptanteSimplesNacional': 2,
                'IncentivadorCultural': 2,
                'Status': '1',
                'Servico': {
                    'Valores': {
                        'ValorServicos': req.get('conh_freteempresa', ''),
                        'ValorDeducoes': 0.00,
                        'ValorPis': req.get('conh_valorpis', ''),
                        'ValorCofins': req.get('conh_valorcofins', ''),
                        'ValorInss': req.get('conh_valoriss', ''),
                        'ValorIr': req.get('conh_valorirrf', ''),
                        'ValorCsll': req.get('conh_valorcsll', ''),
                        'IssRetido': req.get('conh_pagaiss', ''),
                        'ValorIss': req.get('conh_taxaiss', ''),
                        'ValorIssRetido': req.get('conh_valoriss', ''),
                        'OutrasRetencoes': 0.00,
                        'BaseCalculo': req.get('conh_freteempresa', ''),
                        'Aliquota': 0.02,  # str(float(req.get('conh_freteempresa', '')) *0.03),
                        'ValorLiquidoNfse': str(
                            float(req.get('conh_freteempresa', '')) - float(req.get('conh_valoriss', ''))),
                        'DescontoIncondicionado': 0.00,
                        'DescontoCondicionado': 0.00
                    },
                    'ItemListaServico': req.get('conh_codservico', ''),
                    'CodigoCnae': req.get('conh_cnae', ''),
                    'CodigoTributacaoMunicipio': req.get('conh_codtributacao', ''),
                    'Discriminacao': req.get('conh_descservico', ''),
                    'CodigoMunicipio': '5108402'
                },
                'Prestador': {
                    'Cnpj': req.get('conh_filial_cnpjcpf', ''),
                    'InscricaoMunicipal': req.get('conh_filial_inscmun', '')
                },
                'Tomador': {
                    'IdentificacaoTomador': {
                        'CpfCnpj': {
                            'Cnpj' if len(req.get('conh_cliente_cnpjcpf', '')) > 11 else
                            'Cpf': req.get('conh_cliente_cnpjcpf', '')
                        },
                        # 'InscricaoMunicipal': '',
                    },
                    'RazaoSocial': req.get('conh_cliente_nome', ''),
                    'Endereco': {
                        'Endereco': req.get('conh_cliente_endereco', ''),
                        'Numero': req.get('conh_cliente_numero', ''),
                        'Complemento': req.get('conh_cliente_complemento', ''),
                        'Bairro': req.get('conh_cliente_bairro', ''),
                        'CodigoMunicipio': req.get('conh_cliente_cidade_codibge', ''),  # '5108402',  # 5107040
                        'Uf': req.get('conh_cliente_cidade_uf', ''),
                        'Cep': req.get('conh_cliente_cep', ''),
                    },
                    'Contato': {
                        'Telefone': req.get('conh_cliente_fone', ''),
                        'Email': req.get('conh_cliente_email', ''),
                    }
                },
            },
            {
                'attr': {
                    'id': req.get('conh_rps', '')
                }
            }
        )
    }

    return dict_to_xml(rps, indent=True), ''


def consulta_nfse_situacao_lote_rps(req: dict, cod_ibge: int):
    query: dict = {
        'ConsultarSituacaoLoteRpsEnvio': {
            'Prestador': {
                'Cnpj': req.get('conh_filial_cnpjcpf', ''),
                'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
            },
            'Protocolo': req.get('conh_nprot', ''),
        }
    }
    return envelop('ConsultarSituacaoLoteRpsEnvio', dict_to_xml(query)), ''


def consulta_nfse_por_rps(req: dict, cod_ibge: int):
    query: dict = {
        'ConsultarNfseRpsEnvio': {
            'IdentificacaoRps': {
                'Numero': req.get('conh_rps', ''),
                'Serie': req.get('conh_serie', ''),
                'Tipo': 1
            },
            'Prestador': {
                'Cnpj': req.get('conh_filial_cnpjcpf', ''),
                'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
            }
        }
    }
    return envelop('ConsultarNfseRpsEnvio', dict_to_xml(query)), ''


def consulta_lote_rps_envio(req: dict, cod_ibge: int):
    query: dict = {
        'ConsultarLoteRpsEnvio': {
            'Prestador': {
                'Cnpj': req.get('conh_filial_cnpjcpf', ''),
                'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
            },
            'Protocolo': req.get('conh_nprot', ''),
        }
    }
    return envelop('ConsultarLoteRpsEnvio', dict_to_xml(query)), ''


def consulta_nfse(req: dict, cod_ibge: int):
    query: dict = {
        'ConsultarNfsEnvio': {
            'Prestador': {
                'Cnpj': req.get('conh_filial_cnpjcpf', ''),
                'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
            },
            'NumeroNfse': req.get('conh_rps', ''),
            'PeriodoEmissao': {
                'DataInicial': req.get('data_inicio', ''),
                'DataFinal': req.get('data_fim', ''),
            },
            'Tomador': {
                'CpfCnpj': {
                    'Cnpj': '', #if len(req.get('conh_cliente_cnpjcpf', '')) > 11 else
                    'Cpf': '' # req.get('conh_cliente_cnpjcpf', '')
                },
                'InscricaoMunicipal': '',# req.get('conh_filial_inscmun', ''),
            },
            'IntermediarioServico': {
                'RazaoSocial':'', #req.get('conh_cliente_nome', ''),
                'CpfCnpj': {
                    'Cnpj':'',#  if len(req.get('conh_cliente_cnpjcpf', '')) > 11 else
                    'Cpf':'', # req.get('conh_cliente_cnpjcpf', '')
                },
                'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
            }
        }
    }
    return envelop('ConsultarNfsEnvio', dict_to_xml(query)), ''


def cancelar_nfse_envio(req: dict, cod_ibge: int):
    query: dict = {
        'CancelarNfseEnvio': {
            'Pedido': {
                'InfPedidoCancelamento': (
                    {
                        'IdentificacaoNfse': {
                            'Numero': req.get('conh_rps', ''),
                            'Cnpj': req.get('conh_filial_cnpjcpf', ''),
                            'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
                            'CodigoMunicipio': '5108402'
                        },
                        'CodigoCancelamento': req.get('conh_rps', ''),
                    },

                    {
                        'attr': {
                            'id': req.get('conh_rps', ''),
                        }
                    }
                ),
            },

        }
    }
    return envelop('CancelarNfseEnvio', dict_to_xml(query)), ''


@handle_exception_factory()
def process_response_abaco(acao: int, cod_ibge: int, ret: str):
    resp: dict = deep_get(xmltodict.parse(ret), 'SOAP-ENV:Envelope.SOAP-ENV:Body')

    def set_resp_if_exists(name: str):
        nonlocal resp
        value: dict = deep_get(resp, name + '\\.ExecuteResponse.Outputxml')
        if value:
            resp = xmltodict.parse(value.get('#text'))
            return True
        return False

    def process_response_list_element(data_: Tuple[dict, list]) -> list:
        if not data_:
            return []

        data_ = data_ if type(data_) is list else [data_]

        try:
            result_list = []
            msg: dict
            for msg in data_:
                msg = msg.get('MensagemRetorno', {})
                result_list.append({
                    'codigo': msg.get('Codigo', ''),
                    'mensagem': msg.get('Mensagem', ''),
                    'sugestao': msg.get('Correcao', '')
                })

            return result_list
        except (Exception,):
            return []

    result = {}
    numero_nfe = ''

    if set_resp_if_exists('RecepcionarLoteRPS'):
        data: dict = deep_get(resp, 'EnviarLoteRpsResposta')

        if 'Protocolo' in data:
            result['sucesso'] = True
            result['numerolote'] = data.get('NumeroLote', '')
            result['data_recebimento'] = data.get('DataRecebimento', '')
            result['protocolo'] = data.get('Protocolo', '')
        else:
            result['sucesso'] = False
            result['erros'] = process_response_list_element(data.get('ListaMensagemRetorno'))

    elif set_resp_if_exists('ConsultarSituacaoLoteRps'):
        data: dict = resp.get('ConsultarSituacaoLoteRpsResposta')

        if 'ListaMensagemRetorno' not in data:
            result['sucesso'] = True
            result['notas'] = []

            #result['status'] = data.get('Situacao', '')

            result['notas'].append({
                'status': '1',
                'numero': data.get('NumeroLote', ''),
                'pdf': ''  # target.get('OutrasInformacoes', '')
            })
        else:
            result['sucesso'] = False
            result['erros'] = process_response_list_element(data.get('ListaMensagemRetorno'))

    elif set_resp_if_exists('ConsultarNfsePorRps'):
        data: dict = resp.get('ConsultarNfseRpsResposta')

        if 'CompNfse' in data:
            data: dict = deep_get(data, 'CompNfse.Nfse.InfNfse')
            result = {
                'sucesso': True,
                'status': 1,
                'numero': data.get('Numero', ''),
                'codigo_verificacao': data.get('CodigoVerificacao', ''),
                'data_emissao': data.get('DataEmissao', ''), 'pdf': '' # data.get('OutrasInformacoes', '')
            }
        else:
            result['sucesso'] = False
            result['erros'] = process_response_list_element(data.get('ListaMensagemRetorno'))

    elif set_resp_if_exists('ConsultarLoteRps'):
        data: dict = resp.get('ConsultarLoteRpsResposta')

        if 'ListaNfse' in data:
            result['sucesso'] = True
            result['notas'] = []
            data: dict = deep_get(data, 'ListaNfse')
            data = data if type(data) is list else [data]

            for target in data:
                target: dict = deep_get(target, 'CompNfse.Nfse.InfNfse')
                result['notas'].append({
                    'status': 1,
                    'numero': int(target.get('Numero', '')),
                    'codigo_verificacao': target.get('CodigoVerificacao', ''),
                    'data_emissao': target.get('DataEmissao', ''),
                    'pdf': ''#target.get('OutrasInformacoes', '')
                })

        else:
            result['sucesso'] = False
            result['erros'] = process_response_list_element(data.get('ListaMensagemRetorno'))

    elif set_resp_if_exists('ConsultarNfse'):
        data: dict = resp.get('ConsultarNfseResposta')

        if 'ListaNfse' in data:
            result['sucesso'] = True
            result['notas'] = []
            data: dict = deep_get(data, 'ListaNfse.CompNfse')
            data = data if type(data) is list else [data]

            for target in data:
                target: dict = deep_get(target, 'Nfse.InfNfse')
                result['notas'].append({
                    'status': 1,
                    'numero': int(target.get('Numero', '')),
                    'codigo_verificacao': target.get('CodigoVerificacao', ''),
                    'data_emissao': target.get('DataEmissao', ''),
                    'pdf': '' #target.get('OutrasInformacoes', '')
                })
        else:
            result['sucesso'] = False
            result['erros'] = process_response_list_element(data.get('ListaMensagemRetorno'))

    elif set_resp_if_exists('CancelarNfse'):
        data: dict = resp.get('CancelarNfseResposta')

        if 'RetCancelamento' in data:
            data = deep_get(data, 'RetCancelamento.NfseCancelamento.Confirmacao', {})
            result['sucesso'] = True
            result['data_confirmacao'] = data.get('DataHora', '')
            result['codigo_cancelamento'] = deep_get(data, 'Pedido.InfPedidoCancelamento.CodigoCancelamento', '')

            result['motivo_cancelamento'] = {
                '1': 'Erro na emissão',
                '2': 'Serviço não prestado',
                '3': 'Erro de assinatura',
                '4': 'Duplicidade da nota',
                '5': 'Erro de processamento'
            }.get(result['codigo_cancelamento'], '')

        else:
            result['sucesso'] = False
            result['erros'] = process_response_list_element(data.get('ListaMensagemRetorno'))
    else:
        return '', 'EMPY: Um retorno desconhecido foi recebido da Abaco.', ''

    return '<json><![CDATA[' + json.dumps(result) + ']]></json>', '', numero_nfe
