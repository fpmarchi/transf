import json
import sys
from collections import Callable
from functools import wraps
from typing import Tuple

import xmltodict

import nfse_spooler
from geral import conditional_key, deep_get
from geralxml import *


# Define o tipo de exceção localValorIss
class BethaException(Exception):
    pass


# Decorators (Devem ser declarados antes do uso)
def _handle_exception(func: Callable) -> Callable:
    @wraps(func)
    def wrapper(*args, **kwargs) -> Tuple[str, str]:
        try:
            return func(*args, **kwargs)
        except BethaException as e:
            return '', str(e)
        except Exception as e:
            _, _, exc_tb = sys.exc_info()
            filename = exc_tb.tb_frame.f_code.co_filename
            debug = f'Erro inesperado em: {func.__name__} => {filename}:{exc_tb.tb_lineno}. Detalhes:\n{str(e)}'

            print(debug, file=sys.stderr)
            return '', 'Ocorreu um erro inesperado elaborar os XML de envio para a Betha.'

    return wrapper


def process_request_betha(cod_acao_emonitor: int, cod_ibge: int,
                          req: dict, assinatura: AssinaturaA1) -> Tuple[str, str]:
    if cod_acao_emonitor == nfse_spooler.ACAO_NFSE_RECEPCAO:
        xml, erro = request_betha_recepcao(cod_ibge, req, assinatura)
    elif cod_acao_emonitor == nfse_spooler.ACAO_NFSE_CONSULTA_SITLOTE_RPS:
        xml, erro = request_betha_consulta_lote(req)
    elif cod_acao_emonitor == nfse_spooler.ACAO_NFSE_CONSULTA_NFSE_POR_RPS:
        xml, erro = request_betha_consulta_nfse(req)
    elif cod_acao_emonitor == nfse_spooler.ACAO_NFSE_CANCELAMENTO:
        xml, erro = request_betha_cancelamento(req, cod_ibge, assinatura)
    elif cod_acao_emonitor == nfse_spooler.ACAO_NFSE_CONSULTA_NFSE:
        xml, erro = request_betha_busca_nfse(req)
    else:
        return '', 'Acao ' + str(cod_acao_emonitor) + ' sem Implementação'

    return xml, erro


def envelop(service: str, data: str, version: int = 2.02):
    if not data:
        return data

    header = {
        'cabecalho': {
            '@xmlns': 'http://www.betha.com.br/e-nota-contribuinte-ws',
            '@versao': version,
            'versaoDados': version
        }
    }

    soap_env: dict = {
        'soapenv:Envelope': {
            '@xmlns:soapenv': 'http://schemas.xmlsoap.org/soap/envelope/',
            '@xmlns:e': 'http://www.betha.com.br/e-nota-contribuinte-ws',
            'soapenv:Header': None,
            'soapenv:Body': {
                f'e:{service}': {
                    'nfseCabecMsg': bytes(xml_from_dict(header), 'utf-8'),
                    'nfseDadosMsg': bytes(data, 'utf-8')
                }
            }
        }
    }

    return xml_from_dict(soap_env, indent=True, indent_with_space=True, prolog=True)


def request_betha_recepcao(cod_ibge: int, req: dict, signer: AssinaturaA1) -> Tuple[str, str]:
    rps, errors = xml_request_betha_recepcao(req, cod_ibge)

    batch: dict = {
        'EnviarLoteRpsEnvio': {
            '@xmlns': 'http://www.betha.com.br/e-nota-contribuinte-ws',
            'LoteRps': {
                '@Id': 'lote' + req.get('conh_rps', ''),
                '@versao': '2.02',
                'NumeroLote': req.get('conh_nreclote', ''),
                'CpfCnpj': {
                    'Cnpj': req.get('conh_filial_cnpjcpf', '')
                },
                'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
                'QuantidadeRps': 1,
                'ListaRps': {
                    'Rps': rps
                }
            }
        }
    }

    batch_str = signer.assinar_elementos(xml_from_dict(batch), 'InfDeclaracaoPrestacaoServico', apply_sign_ns=False)
    batch_str = signer.assinar_elementos(batch_str, 'LoteRps', apply_sign_ns=False)

    return envelop('RecepcionarLoteRps', batch_str), ''


def xml_request_betha_recepcao(req: dict, cod_ibge: int):
    rps: dict = {
        'InfDeclaracaoPrestacaoServico  ': {
            '@Id': 'rps' + req.get('conh_rps', ''),
            'Rps': {
                'IdentificacaoRps': {
                    'Numero': req.get('conh_rps', ''),
                    'Serie': req.get('conh_serie', ''),
                    'Tipo': 1
                },
                'DataEmissao': req.get('conh_datahoraemissao', '').split('T')[0],
                'Status': '1',
            },
            'Competencia': req.get('conh_datahoraemissao', '').split('T')[0],
            'Servico': {
                'Valores': {
                    'ValorServicos': req.get('conh_freteempresa', 0),
                    'ValorDeducoes': 0,
                    'ValorPis': 0,
                    'ValorCofins': 0,
                    'ValorIr': 0,
                    'ValorCsll': 0,
                    'OutrasRetencoes': 0,
                    **conditional_key(
                        'ValorIss', (0 if req.get('conh_pagaiss') != '2' else req.get('conh_valoriss')),
                        (req.get('conh_cliente_cidade_codibge') != '5105259'),
                        # cod_ibge != '5105259' or req.get('conh_natureza') != '1',
                    ),  # safe_cast(req.get('conh_valoriss'), 0),
                    **conditional_key('Aliquota', req.get('conh_taxaiss', 0), (
                            req.get('conh_cliente_cidade_codibge', '') != '5105259' and req.get(
                        'conh_pagaiss') == '2')),
                    # 'Aliquota': req.get('conh_taxaiss', 0),
                    'DescontoIncondicionado': 0,
                    'DescontoCondicionado': 0
                },
                'IssRetido': (1 if req.get('conh_pagaiss') == '2' else 2),
                **conditional_key('ResponsavelRetencao', '1', req.get('conh_pagaiss') == '2'),
                'ItemListaServico': req.get('conh_codservico', ''),
                # **conditional_key('CodigoCnae', req.get('conh_cnae', ''), cod_ibge != '5105259'),
                'CodigoTributacaoMunicipio': req.get('conh_codtributacao', ''),
                'Discriminacao': req.get('conh_descservico'),
                'CodigoMunicipio': req.get('conh_cliente_cidade_codibge') if req.get(
                    'conh_pagaiss') == '2' else cod_ibge,
                # cod_ibge, #**conditional_key('CodigoPais', 1058, cod_ibge != '5105259'), Conforme tarefa 101277, foi retirado o país pois exigibilidadeISS está setado como 1
                'ExigibilidadeISS': 1,
                'MunicipioIncidencia': cod_ibge if req.get('conh_cliente_cidade_codibge') == cod_ibge else req.get(
                    'conh_cliente_cidade_codibge', '')
            },
            'Prestador': {
                'CpfCnpj': {
                    'Cnpj': req.get('conh_filial_cnpjcpf', '')
                },
                'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
            },
            'Tomador': {
                'IdentificacaoTomador': {
                    'CpfCnpj': {
                        'Cnpj' if len(req.get('conh_cliente_cnpjcpf', '')) > 11 else
                        'Cpf': req.get('conh_cliente_cnpjcpf', '')
                    }
                },
                'RazaoSocial': req.get('conh_cliente_nome', ''),
                'Endereco': {
                    'Endereco': req.get('conh_cliente_endereco', ''),
                    'Numero': req.get('conh_cliente_numero', ''),
                    **conditional_key('Complemento', req.get('conh_cliente_complemento', '')),
                    'Bairro': req.get('conh_cliente_bairro', ''),
                    'CodigoMunicipio': req.get('conh_cliente_cidade_codibge', ''),
                    'Uf': req.get('conh_cliente_cidade_uf', ''),
                    'Cep': req.get('conh_cliente_cep', '')
                },
                'Contato': {
                    'Telefone': req.get('conh_cliente_fone', ''),
                    **conditional_key('Email', req.get('conh_cliente_email', ''))
                }
            },
            'OptanteSimplesNacional': '2',
            'IncentivoFiscal': '2',
        }
    }

    return xml_from_dict(rps), ''


def request_betha_consulta_lote(req: dict):
    query = {
        'ConsultarLoteRpsEnvio': {
            '@xmlns': 'http://www.betha.com.br/e-nota-contribuinte-ws',
            'Prestador': {
                'CpfCnpj': {
                    'Cnpj' if len(req.get('conh_filial_cnpjcpf', '')) > 11 else
                    'Cpf': req.get('conh_filial_cnpjcpf', '')
                },
            },
            'Protocolo': req.get('conh_nprot', '')
        }
    }

    return envelop('ConsultarLoteRps', xml_from_dict(query)), ''


def request_betha_consulta_nfse(req: dict):
    query = {
        'ConsultarNfseRpsEnvio': {
            '@xmlns': 'http://www.betha.com.br/e-nota-contribuinte-ws',
            'IdentificacaoRps': {
                'Numero': req.get('conh_rps', ''),
                'Serie': req.get('conh_serie', ''),
                'Tipo': 1
            },
            'Prestador': {
                'CpfCnpj': {
                    'Cnpj' if len(req.get('conh_filial_cnpjcpf', '')) > 11 else
                    'Cpf': req.get('conh_filial_cnpjcpf', '')
                },
            }
        }
    }

    return envelop('ConsultarNfsePorRps', xml_from_dict(query)), ''


def request_betha_busca_nfse(req: dict):
    query = {
        'ConsultarNfseServicoPrestadoEnvio': {
            '@xmlns': 'http://www.betha.com.br/e-nota-contribuinte-ws',
            'Prestador': {
                'CpfCnpj': {
                    'Cnpj' if len(req.get('conh_filial_cnpjcpf', '')) > 11 else
                    'Cpf': req.get('conh_filial_cnpjcpf', '')
                }
            },
            **conditional_key('NumeroNfse', req.get('conh_numeronfse')),
            'PeriodoEmissao': {
                'DataInicial': (req.get('data_inicio', '') + 'T').split('T')[0],
                'DataFinal': (req.get('data_fim', '') + 'T').split('T')[0]
            },
            'Pagina': 1
        }
    }

    return envelop('ConsultarNfseServicoPrestado', xml_from_dict(query)), ''


def request_betha_cancelamento(req: dict, cod_ibge: int, signer: AssinaturaA1):
    cancel = {
        'CancelarNfseEnvio': {
            '@xmlns': 'http://www.betha.com.br/e-nota-contribuinte-ws',
            'Pedido': {
                'InfPedidoCancelamento': {
                    '@Id': 'nfse' + req.get('conh_numeronfse', ''),
                    'IdentificacaoNfse': {
                        'Numero': req.get('conh_numeronfse', ''),
                        'CpfCnpj': {
                            'Cnpj' if len(req.get('conh_filial_cnpjcpf', '')) > 11 else
                            'Cpf': req.get('conh_filial_cnpjcpf', '')
                        },
                        'InscricaoMunicipal': req.get('conh_filial_inscmun', ''),
                        'CodigoMunicipio': cod_ibge,
                    },
                    'CodigoCancelamento': 1
                }
            }
        }
    }

    batch_str = signer.assinar_elementos(xml_from_dict(cancel), 'InfPedidoCancelamento', apply_sign_ns=False)

    return envelop('CancelarNfse', batch_str), ''


def process_response_betha(acao: int, cod_ibge: int, ret: str):
    resp: dict = deep_get(xmltodict.parse(ret), 'env:Envelope.env:Body')

    def set_resp_if_exists(name: str):
        nonlocal resp
        value = deep_get(resp, name + '.return')
        if value:
            resp = xmltodict.parse(value)
            return True
        return False

    def process_response_list_element(data_: Tuple[dict, list]) -> list:
        if not data_:
            return []

        data_ = data_ if type(data_) is list else [data_]

        try:
            result_list = []
            msg: dict
            for msg in data_:
                msg = msg.get('MensagemRetorno', {})
                result_list.append({
                    'codigo': msg.get('Codigo', ''),
                    'mensagem': msg.get('Mensagem', ''),
                    'sugestao': msg.get('Correcao', '')
                })

            return result_list
        except (Exception,):
            return []

    try:
        result = {}
        numero_nfe = ''

        if set_resp_if_exists('ns2:RecepcionarLoteRpsResponse'):
            data: dict = deep_get(resp, 'EnviarLoteRpsResposta')

            if 'Protocolo' in data:
                result = {
                    'sucesso': True,
                    'lote': data.get('NumeroLote', ''),
                    'data_recebimento': data.get('DataRecebimento', ''),
                    'protocolo': data.get('Protocolo', ''),
                }
            else:
                result['sucesso'] = False
                result['erros'] = process_response_list_element(data.get('ListaMensagemRetorno'))

        elif set_resp_if_exists('ns2:ConsultarLoteRpsResponse'):
            data: dict = resp.get('ConsultarLoteRpsResposta')

            if 'ListaMensagemRetorno' not in data:
                result['sucesso'] = True
                result['situacao'] = data.get('Situacao', '')
                result['notas'] = []
                data: dict = data.get('ListaNfse')
                data = data if type(data) is list else [data]

                for target in data:
                    target: dict = deep_get(target, 'CompNfse.Nfse.InfNfse')
                    result['notas'].append({
                        'status': deep_get(target, 'DeclaracaoPrestacaoServico'
                                                   '.InfDeclaracaoPrestacaoServico'
                                                   '.Rps.Status', 0),
                        'numero': target.get('Numero', ''),
                        'codigo_verificacao': target.get('CodigoVerificacao', ''),
                        'data_emissao': target.get('DataEmissao', ''),
                        'pdf': target.get('OutrasInformacoes', '')
                    })
            else:
                result['sucesso'] = False
                result['erros'] = process_response_list_element(data.get('ListaMensagemRetorno'))

        elif set_resp_if_exists('ns2:ConsultarNfsePorRpsResponse'):
            data: dict = resp.get('ConsultarNfseRpsResposta')

            if 'CompNfse' in data:
                data: dict = deep_get(data, 'CompNfse.Nfse.InfNfse')
                result = {
                    'sucesso': True,
                    'status': deep_get(data, 'DeclaracaoPrestacaoServico'
                                             '.InfDeclaracaoPrestacaoServico'
                                             '.Rps.Status', 0),
                    'numero': data.get('Numero', ''),
                    'codigo_verificacao': data.get('CodigoVerificacao', ''),
                    'data_emissao': data.get('DataEmissao', ''), 'pdf': data.get('OutrasInformacoes', '')
                }
            else:
                result['sucesso'] = False
                result['erros'] = process_response_list_element(data.get('ListaMensagemRetorno'))

        elif set_resp_if_exists('ns2:ConsultarNfseServicoPrestadoResponse'):
            data: dict = resp.get('ConsultarNfseServicoPrestadoResposta')

            if 'ListaNfse' in data:
                result['sucesso'] = True
                result['notas'] = []
                data: dict = deep_get(data, 'ListaNfse.CompNfse')
                data = data if type(data) is list else [data]

                for target in data:
                    target: dict = deep_get(target, 'Nfse.InfNfse')
                    result['notas'].append({
                        'status': deep_get(target, 'DeclaracaoPrestacaoServico'
                                                   '.InfDeclaracaoPrestacaoServico'
                                                   '.Rps.Status', 0),
                        'numero': target.get('Numero', ''),
                        'codigo_verificacao': target.get('CodigoVerificacao', ''),
                        'data_emissao': target.get('DataEmissao', ''),
                        'pdf': target.get('OutrasInformacoes', '')
                    })
            else:
                result['sucesso'] = False
                result['erros'] = process_response_list_element(data.get('ListaMensagemRetorno'))

        elif set_resp_if_exists('ns2:CancelarNfseResponse'):
            data: dict = resp.get('CancelarNfseResposta')

            if 'RetCancelamento' in data:
                data = deep_get(data, 'RetCancelamento.NfseCancelamento.Confirmacao', {})
                result['sucesso'] = True
                result['data_confirmacao'] = data.get('DataHora', '')
                result['codigo_cancelamento'] = deep_get(data, 'Pedido.InfPedidoCancelamento.CodigoCancelamento', '')

                result['motivo_cancelamento'] = {
                    '1': 'Erro na emissão',
                    '2': 'Serviço não prestado',
                    '3': 'Erro de assinatura',
                    '4': 'Duplicidade da nota',
                    '5': 'Erro de processamento'
                }.get(result['codigo_cancelamento'], '')

            else:
                result['sucesso'] = False
                result['erros'] = process_response_list_element(data.get('ListaMensagemRetorno'))
        else:
            return '', 'EMPY: Um retorno desconhecido foi recebido da Betha.', ''

        return '<json><![CDATA[' + json.dumps(result) + ']]></json>', '', numero_nfe

    except Exception as e:
        return '', 'EMPY: Erro ao tratar retorno da Betha: ' + str(e), ''
