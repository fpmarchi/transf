import geral
from metadata import getConnPG
import dao
import base64
import gzip


def getBiMdfePropVeic(engine,request):
    usuario = request.args.get('u',type=str)
    senha = request.args.get('s',type=str)
    propCnpjCpf = request.args.get('p',type=str)
    veiculoPlaca = request.args.get('v',type=str)
    dataIni = request.args.get('di',type=str)
    #
    msgRet = geral.check_user_password(usuario, senha)
    if msgRet is not None:
        erro = 'true'
    else:
        if geral.strempty(propCnpjCpf) or geral.strempty(veiculoPlaca) or geral.strempty(dataIni):
            erro = 'true'
            msgRet = 'PARAMETROS INVALIDOS (p,v,di)'
        else:
            try:
                with getConnPG(engine) as connPG:
                    msgRet = dao.getBiMdfePropVeic(connPG, propCnpjCpf, veiculoPlaca, dataIni)
                    if geral.strempty(msgRet):
                        erro = 'true'
                        msgRet = 'NENHUM MDFe ENCONTRADO'
                    else:
                        erro = 'false'
            except Exception as e:
                erro = 'true'
                msgRet = 'Erro em getBiMdfePropVeic: ' + propCnpjCpf + ' / ' + veiculoPlaca + ' / ' + dataIni
                print(msgRet)
                print(e)
    #
    return '<ret><erro>' + erro + '</erro><msgRet>' + msgRet + '</msgRet></ret>'


def getBiMdfePropVeicComp(engine,request):
    usuario = request.args.get('u',type=str)
    senha = request.args.get('s',type=str)
    propCnpjCpf = request.args.get('p',type=str)
    veiculoPlaca = request.args.get('v',type=str)
    dataIni = request.args.get('di',type=str)
    #
    msgRet = geral.check_user_password(usuario, senha)
    if msgRet is not None:
        erro = 'true'
    else:
        if geral.strempty(propCnpjCpf) or geral.strempty(veiculoPlaca) or geral.strempty(dataIni):
            erro = 'true'
            msgRet = 'PARAMETROS INVALIDOS (p,v,di)'
        else:
            try:
                with getConnPG(engine) as connPG:
                    msgRet = dao.getBiMdfePropVeic(connPG, propCnpjCpf, veiculoPlaca, dataIni, comp=True)
                    if geral.strempty(msgRet):
                        erro = 'true'
                        msgRet = 'NENHUM MDFe ENCONTRADO'
                    else:
                        erro = 'false'
            except Exception as e:
                erro = 'true'
                msgRet = 'Erro em getBiMdfePropVeic: ' + propCnpjCpf + ' / ' + veiculoPlaca + ' / ' + dataIni
                print(msgRet)
                print(e)
    #
    return '<ret><erro>' + erro + '</erro><msgRet>' + msgRet + '</msgRet></ret>'


def getBiMdfeMotComp(engine,request):
    usuario = request.args.get('u',type=str)
    senha = request.args.get('s',type=str)
    motCpf = request.args.get('m',type=str)
    dataIni = request.args.get('di',type=str)
    #
    msgRet = geral.check_user_password(usuario, senha)
    if msgRet is not None:
        erro = 'true'
    else:
        if geral.strempty(motCpf) or geral.strempty(dataIni):
            erro = 'true'
            msgRet = 'PARAMETROS INVALIDOS (m,di)'
        else:
            try:
                with getConnPG(engine) as connPG:
                    msgRet = dao.getBiMdfeMot(connPG, motCpf, dataIni, comp=True)
                    if geral.strempty(msgRet):
                        erro = 'true'
                        msgRet = 'NENHUM MDFe ENCONTRADO'
                    else:
                        erro = 'false'
            except Exception as e:
                erro = 'true'
                msgRet = 'Erro em getBiMdfeMotComp: ' + motCpf + ' / ' + dataIni
                print(msgRet)
                print(e)
    #
    return '<ret><erro>' + erro + '</erro><msgRet>' + msgRet + '</msgRet></ret>'


def getBiMdfePerComp(engine,request):
    usuario = request.args.get('u',type=str)
    senha = request.args.get('s',type=str)
    dataIni = request.args.get('di',type=str)
    dataFim = request.args.get('df',type=str)
    #
    msgRet = geral.check_user_password(usuario, senha)
    if msgRet is not None:
        erro = 'true'
    else:
        if geral.strempty(dataIni) or geral.strempty(dataFim):
            erro = 'true'
            msgRet = 'PARAMETROS INVALIDOS (di,df)'
        else:
            try:
                if (geral.defstrtodate(dataFim.replace('-','/')) - geral.defstrtodate(dataIni.replace('-','/'))).days > 7:
                    erro = 'true'
                    msgRet = 'MAXIMO DE 7 (SETE) DIAS DISPONIVEIS PARA CONSULTA'
                else:
                    with getConnPG(engine) as connPG:
                        msgRet = dao.getBiMdfePer(connPG, dataIni, dataFim, comp=True)
                        if geral.strempty(msgRet):
                            erro = 'true'
                            msgRet = 'NENHUM MDFe ENCONTRADO'
                        else:
                            erro = 'false'
                            msgRet = base64.b64encode(gzip.compress(msgRet.encode())).decode()
            except Exception as e:
                erro = 'true'
                msgRet = 'Erro em getBiMdfePerComp: ' + dataIni + ' / ' + dataFim
                print(msgRet)
                print(e)
    #
    return '<ret><erro>' + erro + '</erro><msgRet>' + msgRet + '</msgRet></ret>'

