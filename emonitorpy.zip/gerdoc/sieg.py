import base64
import json
import urllib
from typing import Tuple

from ActionProcessor import ActionProcessor, Callable_cfg
from geral import deep_get
from urllib.parse import urlparse


class Sieg(ActionProcessor):
    # INSTANCIAS

    IMPORTAR_LOTE = 50151
    IMPORTAR_ESPECIFICO = 50152
    URL_BASE = 'https://api.sieg.com'
    URL_BASE_TEST = 'https://api.sieg.com'

    def __init__(self):
        self.add_callable_records('url', {
            self.IMPORTAR_LOTE: lambda context: context['url'] + '/aws/api-xml-search.ashx',
            self.IMPORTAR_ESPECIFICO: _url_importar_especifico,
        })

        request_builders: Callable_cfg = {
            self.IMPORTAR_LOTE: _importar_lote,
            self.IMPORTAR_ESPECIFICO: _importar_especifico
        }

        response_parsers: Callable_cfg = {
            self.DEFAULT_FUNCTION: _sieg_resposta,
        }

        super().__init__(request_builders, response_parsers)

    def build_request(self, context_req: dict, action_cod: int) -> Tuple[str, dict, str, dict, str]:
        (req, errors) = super().build_request(context_req, action_cod)
        ambiente = 1
        base = context_req.get('url', '')

        base = base.strip().rstrip('/') or (Sieg.URL_BASE if ambiente == 1 else Sieg.URL_BASE_TEST)
        context_req['url'] = base
        url = self.dispatch(action_cod, context_req, 'url')

        return url, {'Content-Type': 'application/json'}, req, {}, errors


def _importar_lote(req: dict, props: dict) -> Tuple[str, str]:
    dados: dict = {
        'apikey': props.get('token', ''),
        'email': props.get('usuario', ''),

        'xmltype': 'nfe',
        'take': req.get('quant_arquivos', ''),
        'skip': req.get('inicio_pagina', ''),
        'dataInicio': req.get('data_inicio', ''),
        'dataFim': req.get('data_fim', ''),
        'cnpjEmit': req.get('cnpj_emit', ''),
        'cnpjDest': req.get('cnpj_dest', ''),
        'cnpjRem': req.get('cnpj_dem', ''),
        'cnpjTom': req.get('cnpj_tom', ''),
        'downloadevent': req.get('download_event', ''),
    }

    return json.dumps(dados), ''


def _importar_especifico(req: dict) -> Tuple[str, str]:
    dados: dict = {
        'xmlkey': req.get('cod_xml', ''),
        'xmltype': 'nfe'
    }
    return json.dumps(dados), ''


def _url_importar_especifico(url: str, req: dict, props: dict):
    usuario = urllib.parse.quote(props.get('usuario'), safe='')
    token = urllib.parse.quote(props.get('token'), safe='')
    xmlkey = urllib.parse.quote(req.get('cod_xml'), safe='')
    xmltype = urllib.parse.quote(req.get('xmltype'), safe='')
    string_query = url + (
        '/aws/api-xml.ashx?ApiKey={}&email={}&xmlkey={}&xmltype={}'.format(token, usuario, xmlkey, xmltype))

    return string_query


def _sieg_resposta(resp: str, action_cod: int) -> Tuple[str, str]:
    try:
        resp_json: dict = json.loads(resp)
    except(Exception,):
        resp_json = {}

    if 'Error' in resp_json:
        erro = resp_json.get('Error')
        resp_body = {
            'sucesso': False,
            'msg_erro': 'Erro retornado pela Sieg: ' + erro.get('Status') + ' ' + erro.get('Message')
        }
        return json.dumps(resp_body), ''

    if action_cod == Sieg.IMPORTAR_ESPECIFICO:
        xmls = base64.b64encode(resp.encode()).decode('ascii')
    else:
        xmls = deep_get(resp_json, 'xmls')

    resp_body = {
        'sucesso': True,
        'conteudo': xmls
    }
    return json.dumps(resp_body), ''
