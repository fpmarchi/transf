import pandas as pd

arq_xls = '/home/edilmar/Downloads/PatrickCodMun.xls'
arq_csv = '/home/edilmar/Downloads/PatrickEmpresasAbertas.csv'
arq_csv_final = '/home/edilmar/Downloads/PatrickEmpresasAbertasFinal.csv'

df_xls = pd.read_excel(arq_xls, skiprows=0) # pular linha de cabecalho
#df_xls.sort_values(['uf','mun'], inplace=True) # salvar a planilha ordenada para acelerar busca
df_csv = pd.read_csv(arq_csv, skiprows=0, sep=';') # separador de campos = ;

i = 0
for row_df_csv in df_csv.iterrows():
    i += 1
    # if i != 1 and i != 21 and i != 71:
    #     continue
    # if i == 100:
    #     break
    cod_uf = int(row_df_csv[1][3])
    nom_municipio = row_df_csv[1][6].upper()
    row_df_xls = df_xls.query('mun == "' + nom_municipio + '" and uf == "' + str(cod_uf) + '"')
    try:
        cod_mun = str(row_df_xls['cod_mun'].values[0])
    except:
        cod_mun = '0000000' # nao encontrado
    print('Processando linha ' + str(i) + '... ' + nom_municipio + ' e ' + str(cod_uf) + ' => ' + str(cod_mun))
    df_csv.at[i-1,'cod_mun'] = cod_mun

df_csv.to_csv(arq_csv_final, sep=';')


